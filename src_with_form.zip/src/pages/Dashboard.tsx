import React from "react";
import MainContent from "../components/dashboard/MainContent";
import StatsPanel from "../components/dashboard/StatsPanel";
import { Box } from "@mui/material";

const DashBoard = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        gap: 2,
        width: "100%",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          flexGrow: 1,
          minWidth: 0, // 👈 Prevents overflow from flex child
        }}
      >
        <MainContent />
      </Box>

      <Box
        sx={{
          width: "397px",
          flexShrink: 0, // 👈 Prevents StatsPanel from shrinking
        }}
      >
        <StatsPanel />
      </Box>
    </Box>
  );
};

export default DashBoard;
