import React from "react";
import { Breadcrumbs, Typography, Link as MuiLink, Stack } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <Stack sx={{ bgcolor: "white", py: 1 }}>
      <Breadcrumbs 
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
      >
        {items.map((item, index) => (
          item.href ? (
            <MuiLink
              key={index}
              underline="hover"
              color="text.secondary"
              href={item.href}
            >
              {item.label}
            </MuiLink>
          ) : (
            <Typography key={index} color="text.primary">
              {item.label}
            </Typography>
          )
        ))}
      </Breadcrumbs>
    </Stack>
  );
};
