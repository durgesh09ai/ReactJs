import React, { useState } from "react";
import { Box, Typography, Badge, Link, Stack } from "@mui/material";
import { ProjectCard } from "./ProjectCard";
import { Pagination } from "./Pagination";

const projectsData = [
  {
    id: 1,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/56816273f2f98cdc829a9b1efaacf843afb57373?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "You & 1 other",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/22272303bd465eabf4b6babf40b62c4598991605?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/0adab6b19e8d58e2d2719d949bbd1c098dc6d389?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/92ebf2f24d6c9d9f32a010544c8d966c2a4bd551?placeholderIfAbsent=true",
  },
  {
    id: 2,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/56816273f2f98cdc829a9b1efaacf843afb57373?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9d6630bd895ccb96e054c434350dbd8b8ad634c3?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5794e1e4f247bf70e4664ff9b96658c1057fcbf2?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c2711a24fe70f285aada59fd8a5b044f66919039?placeholderIfAbsent=true",
  },
  {
    id: 3,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/56816273f2f98cdc829a9b1efaacf843afb57373?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/22027d1c71512a5cedcf8fbf47cdf2f8fa3e8ce7?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c51a6184f31dc2159a9ccdc043cf746524b1c440?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5959ec64654737c0fd866f60e0ca9fbb0284c1e4?placeholderIfAbsent=true",
  },
  {
    id: 4,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/56816273f2f98cdc829a9b1efaacf843afb57373?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f634ebead0cebfea9c6e3a5de033dbfa8fb88025?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/fdf7fc8fa35bffa188f862db5bb38499eafecf34?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/433024de92772179c79f018404f384f510cd4754?placeholderIfAbsent=true",
  },
  {
    id: 5,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/bad207fb3d4f96a296d3a1850d370d3270ad0397?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/fe36eb76397dc4d8298bdac45e7830cf89c13c18?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/1af76875fd5842a3a602ccae401b38a19f1ce600?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/4601a5350178845d95bf7ff95a46bb9e07cb5671?placeholderIfAbsent=true",
  },
  {
    id: 6,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/bad207fb3d4f96a296d3a1850d370d3270ad0397?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2ec118419b292467a19560df7b6f2e174f4f85c4?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a80f5f1bc2cd736a9b2ded1956516f9104c19c52?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/445c51fbe65b34a86da4dd18d47c3d2a65dbcaa8?placeholderIfAbsent=true",
  },
  {
    id: 7,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/bad207fb3d4f96a296d3a1850d370d3270ad0397?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f2630299337e7e485c5d021a217406d09cea58ae?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/18723fa5c952a0ff457425e757edfee00496ae1e?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d18a642fe2b55d62b759dd12fd20d69c6d226048?placeholderIfAbsent=true",
  },
  {
    id: 8,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/bad207fb3d4f96a296d3a1850d370d3270ad0397?placeholderIfAbsent=true",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/785c9d8cbfcc663c62296b57388f90b61c0a9aa9?placeholderIfAbsent=true",
    likeIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b4aeda8c7326d674b57eff2fe0ebf0767903d521?placeholderIfAbsent=true",
    starIconSrc: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/bb1296bafc862a33974fa435e99da75b39cf8e2c?placeholderIfAbsent=true",
  },
];

export const ProjectsSection = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const projectsPerPage = 4;
  const totalPages = Math.ceil(projectsData.length / projectsPerPage);

  const handlePageChange = (pageNumber:number) => {
    setCurrentPage(pageNumber);
  };

  const renderProjects = () => {
    const start = (currentPage - 1) * projectsPerPage;
    const selectedProjects = projectsData.slice(start, start + projectsPerPage);

    return (
      <Box
        display="flex"
        flexWrap="wrap"
        gap={2}
        mt={2}
        justifyContent={{ xs: "center", sm: "flex-start" }}
      >
        {selectedProjects.map((project) => (
         <Box
         key={project.id}
         sx={{
           width: {
             xs: "100%",   // 1 per row on xs
             sm: "48%",    // 2 per row on sm
             md: "31.5%",  // 3 per row on md
             lg: "23.5%",  // 4 per row on lg
           },
           flexGrow: 0,
           flexShrink: 0,
         }}
       >
            <ProjectCard {...project} />
          </Box>
        ))}
      </Box>
    );
  };

  return (
    <Box width="100%" mt={4}>
      {/* Header Section */}
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Stack direction="row" spacing={1} alignItems="center">
          <Typography variant="subtitle2" color="#1F2633" fontWeight="600">
            Projects Demo
          </Typography>
          <Box
            sx={{
              backgroundColor: "#E9F3F9",
              color: "#0F4977",
              fontSize: "10px",
              fontWeight: "800",
              borderRadius: "50%",
              width: 25,
              height: 25,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {projectsData.length}
          </Box>
        </Stack>
        <Link href="#" underline="hover" sx={{ fontSize: "10px", color: "#0F4977" }}>
          View all
        </Link>
      </Stack>

      {/* Projects Layout */}
      {renderProjects()}

      {/* Pagination */}
      <Box mt={2}>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </Box>
    </Box>
  );
};
