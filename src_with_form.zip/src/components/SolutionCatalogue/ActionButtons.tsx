import React from "react";
import { Box, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

const ActionButtons: React.FC = () => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  return (
    <Box display="flex" gap={2}>
      <Button
        variant="outlined"
        sx={{
          color: '#0F4977',
          borderColor: '#0F4977',
          textTransform: 'none',
          px: 2,
          py: 0.5,
        }}
      >
        Add New Solution
      </Button>
      <Button
        onClick={handleClick}
        variant="contained"
        sx={{
          backgroundColor: '#0F4977',
          color: '#fff',
          textTransform: 'none',
          px: 2,
          py: 0.5,
        }}
        startIcon={
          <img
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c0872bf93b4c3121aa771c98f043297941948cb0?placeholderIfAbsent=true"
            alt="Stats icon"
            style={{ width: 24 }}
          />
        }
      >
        My Stats & Rank
      </Button>
    </Box>
  );
};

export default ActionButtons;
