import React from "react";
import {
  Box,
  Typography,
  Paper,
  Stack,
  IconButton,
  Divider,
} from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";

interface TimelineChartProps {
  year: string;
  chartImageUrl: string;
}

export const TimelineChart: React.FC<TimelineChartProps> = ({
  year,
  chartImageUrl,
}) => {
  return (
    <Box width="100%" mt={4}>
      <Paper
        elevation={0}
        sx={{
          border: "1px solid #e4e4e4",
          px: 2,
          py: 1,
          borderRadius: "10px",
        }}
      >
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Typography variant="body1" fontWeight={500} color="#151718">
            Timeline View
          </Typography>
          <Box
            display="flex"
            alignItems="center"
            bgcolor="rgba(233,233,233,1)"
            px={1}
            py={0.5}
            borderRadius={1}
            sx={{ cursor: "pointer", "&:hover": { bgcolor: "rgba(220,220,220,1)" } }}
          >
            <Typography variant="body2">{year}</Typography>
            <IconButton size="small" sx={{ p: 0, ml: 1 }}>
              <ArrowDropDownIcon fontSize="small" />
            </IconButton>
          </Box>
        </Stack>
      </Paper>

      <Box mt={2} pl="5px">
        <Stack direction="row" spacing={1}>
          <Stack spacing={3.5} alignItems="flex-end" sx={{ fontSize: "8px", color: "rgba(91,97,118,1)" }}>
            <Typography>30m</Typography>
            <Typography>20m</Typography>
            <Typography>10m</Typography>
            <Typography ml={1}>0</Typography>
          </Stack>
          <Box flex={1} position="relative">
            <Divider sx={{ borderStyle: "dashed", mb: 1 }} />
            <Box position="relative" width="100%" pt="34%" sx={{ aspectRatio: "2.946" }}>
              <Box
                component="img"
                src={
                  chartImageUrl ||
                  "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d74362cacbb6c015baa799f6f21b399a9cfdc3e2?placeholderIfAbsent=true"
                }
                alt="Timeline chart"
                sx={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                }}
              />
              <Divider
                sx={{
                  borderStyle: "dashed",
                  position: "absolute",
                  top: "50%",
                  width: "100%",
                }}
              />
              <Divider
                sx={{
                  borderStyle: "dashed",
                  position: "absolute",
                  top: "calc(100% - 38px)",
                  width: "100%",
                }}
              />
            </Box>
            <Divider sx={{ borderStyle: "dashed", mt: 1 }} />
          </Box>
        </Stack>
        <Stack direction="row" spacing={1.5} mt={1} sx={{ fontSize: "8px", color: "rgba(91,97,118,1)" }}>
          {[
            "jan",
            "feb",
            "mar",
            "apr",
            "may",
            "jun",
            "jul",
            "aug",
            "sep",
            "oct",
            "nov",
            "dec",
          ].map((month) => (
            <Box key={month}>{month}</Box>
          ))}
        </Stack>
      </Box>
    </Box>
  );
};
