import { MainPageStore } from "./MainPageStore";

export class RootStore {
  mainPageStore: MainPageStore;

  constructor() {
    this.mainPageStore = new MainPageStore(); // ✅ match the property name
  }
}

const rootStore = new RootStore();
export default rootStore;
