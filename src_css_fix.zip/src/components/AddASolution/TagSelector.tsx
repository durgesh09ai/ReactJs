import React, { useState } from "react";
import {
  Box,
  Paper,
  Tabs,
  Tab,
  TextField,
  Typography,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Checkbox,
  ListItemButton,
  InputAdornment
} from "@mui/material";
import { styled } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";

interface Tag {
  id: string;
  label: string;
}

interface Category {
  id: string;
  label: string;
}

interface TagSelectorProps {
  selectedTags: Tag[];
  categories: Category[];
  onTagSelect: (tag: Tag) => void;
  onTagRemove: (tagId: string) => void;
}

const StyledChip = styled(Chip)(({ theme }) => ({
  backgroundColor: 'rgba(243,250,255,1)',
  borderRadius: '16px',
  '& .MuiChip-deleteIcon': {
    color: 'rgba(15,73,119,1)',
  }
}));

export const TagSelector: React.FC<TagSelectorProps> = ({
  selectedTags,
  categories,
  onTagSelect,
  onTagRemove,
}) => {
  const [activeTab, setActiveTab] = useState<string>("IMU");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const handleCategoryCheckboxChange = (category: Category) => {
    const exists = selectedTags.some((tag) => tag.id === category.id);
    if (exists) {
      onTagRemove(category.id);
    } else {
      onTagSelect({ id: category.id, label: category.label });
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: 1,
        borderColor: 'rgba(15,73,119,0.1)',
        borderRadius: 2,
        minWidth: '240px',
        minHeight: '502px',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <Box sx={{ width: '100%', borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          aria-label="Tag selector tabs"
        >
          <Tab
            label="IMU"
            value="IMU"
            sx={{
              fontSize: '0.75rem',
              '&.Mui-selected': {
                color: 'rgba(15,73,119,1)',
              }
            }}
          />
          <Tab
            label="SGU"
            value="SGU"
            sx={{
              fontSize: '0.75rem',
              '&.Mui-selected': {
                color: 'rgba(15,73,119,1)',
              }
            }}
          />
        </Tabs>
      </Box>

      <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
        <TextField
          placeholder="Search tags"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          size="small"
          fullWidth
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
          sx={{ mb: 2 }}
        />

        <Typography variant="caption" color="text.secondary" sx={{ mb: 1 }}>
          Selected tags
        </Typography>

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {selectedTags.map((tag) => (
            <StyledChip
              key={tag.id}
              label={tag.label}
              onDelete={() => onTagRemove(tag.id)}
              size="small"
            />
          ))}
        </Box>

        <Typography variant="caption" color="text.secondary" sx={{ mb: 1 }}>
          Choose {activeTab}
        </Typography>

        <List sx={{ flexGrow: 1, overflow: 'auto' }}>
          {categories.map((category) => (
            <ListItem disablePadding key={category.id}>
              <ListItemButton onClick={() => handleCategoryCheckboxChange(category)} sx={{ py: 0.5 }}>
                <ListItemIcon sx={{ minWidth: 'auto', mr: 1 }}>
                <Checkbox
                  checked={selectedTags.some((tag) => tag.id === category.id)}
                  size="small"
                />
                </ListItemIcon>
                <ListItemText
                  primary={category.label}
                  primaryTypographyProps={{ variant: 'body2' }}
                />
               
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Box>
    </Paper>
  );
};
