import React, { useState } from "react";
import {
  Box,
  Paper,
  Tabs,
  Tab,
  TextField,
  Typography,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Checkbox,
  ListItemButton,
  InputAdornment,
  Button
} from "@mui/material";
import { styled } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";

interface DocsUrl {
  id: string;
  label: string;
}

interface Category {
  id: string;
  label: string;
}

interface TagSelectorProps {
  selectedDocsUrl: DocsUrl[];
  categories: Category[];
  onDocUrlSelect: (docsUrl: DocsUrl) => void;
  onDocUrlRemove: (docUrlId: string) => void;
}

const StyledChip = styled(Chip)(({ theme }) => ({
  backgroundColor: 'rgba(243,250,255,1)',
  borderRadius: '16px',
  '& .MuiChip-deleteIcon': {
    color: 'rgba(15,73,119,1)',
  }
}));

export const AddUrlSection: React.FC<TagSelectorProps> = ({
  selectedDocsUrl,
  categories,
  onDocUrlSelect,
  onDocUrlRemove,
}) => {
  const [activeTab, setActiveTab] = useState<string>("IMU");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const handleCategoryCheckboxChange = (category: Category) => {
    const exists = selectedDocsUrl.some((tag) => tag.id === category.id);
    if (exists) {
        onDocUrlRemove(category.id);
    } else {
        onDocUrlSelect({ id: category.id, label: category.label });
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: 1,
        borderColor: 'rgba(15,73,119,0.1)',
        borderRadius: 2,
        minWidth: '240px',
        minHeight: '502px',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <Box sx={{ width: '100%', borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => setActiveTab(newValue)}
          aria-label="Tag selector tabs"
        >
          <Tab
            label="Reference Document URLs"
            value="Reference Document URLs"
            sx={{
              fontSize: '0.75rem',
              '&.Mui-selected': {
                color: 'rgba(15,73,119,1)',
              }
            }}
          />
         </Tabs>
         
         <Button
        variant="outlined"
        size="small"
        // onClick={onCancel}
      >
        +
      </Button>
      </Box>

      <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
        <Typography variant="body2" gutterBottom>
        Add Document Url:
      </Typography>
        <TextField
          placeholder="Add Document Url"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          size="small"
          fullWidth
          sx={{ mb: 2 }}
        />

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {selectedDocsUrl.map((docUrl) => (
            <StyledChip
              key={docUrl.id}
              label={docUrl.label}
              onDelete={() => onDocUrlRemove(docUrl.id)}
              size="small"
            />
          ))}
        </Box>


      </Box>
    </Paper>
  );
};
