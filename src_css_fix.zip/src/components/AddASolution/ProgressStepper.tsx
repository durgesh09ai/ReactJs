import React from "react";
import { Stepper, Step, StepLabel, Typography, Box, StepIconProps } from "@mui/material";
import { styled } from "@mui/material/styles";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

interface Step {
  id: string;
  label: string;
  completed: boolean;
  active: boolean;
}

interface ProgressStepperProps {
  steps: Step[];
  currentStep: number;
  totalSteps: number;
}

// Custom step icon
const CustomStepIcon = styled('div')<{
  completed?: boolean;
  active?: boolean;
}>(({ theme, completed, active }) => ({
  width: 26,
  height: 26,
  borderRadius: '50%',
  border: '1px solid rgba(217,217,217,1)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  '& .completedIcon': {
    backgroundColor: 'rgba(6,178,23,1)',
    width: 13,
    height: 13,
    borderRadius: '50%',
  }
}));

const StepIconComponent = (props: StepIconProps & { step: Step }) => {
  const { active, completed, step } = props;

  return (
    <CustomStepIcon
      completed={completed}
      active={active}
    >
      {completed && <div className="completedIcon" />}
    </CustomStepIcon>
  );
};

export const ProgressStepper: React.FC<ProgressStepperProps> = ({
  steps,
  currentStep,
  totalSteps,
}) => {
  return (
    <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center', mt: 2 }}>
      <Box sx={{ width: '100%' }}>
        <Typography 
          variant="caption" 
          color="text.secondary"
          sx={{ display: 'block', mb: 1 }}
        >
          {currentStep} of {totalSteps} steps completed
        </Typography>
        
        <Stepper activeStep={steps.findIndex(step => step.active)} sx={{ width: '100%' }}>
          {steps.map((step) => (
            <Step key={step.id} completed={step.completed}>
              <StepLabel
                StepIconComponent={(props: StepIconProps) => 
                  <StepIconComponent {...props} step={step} />
                }
                sx={{
                  '& .MuiStepLabel-label': {
                    typography: 'caption',
                    color: step.active ? 'text.primary' : 'text.secondary',
                  }
                }}
              >
                {step.label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
    </Box>
  );
};
