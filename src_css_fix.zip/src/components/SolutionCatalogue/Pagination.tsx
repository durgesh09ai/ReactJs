import React from "react";
import { Box, Button, IconButton, Stack } from "@mui/material";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <Stack direction="row" spacing={1} alignItems="center" justifyContent="center" mt={4}>
      {/* Previous Button */}
      <IconButton
        onClick={handlePrevious}
        disabled={currentPage === 1}
        aria-label="Previous page"
        sx={{ width: 40, height: 40 }}
      >
        <Box
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d20ca14fb0c6b3796bd3f1fa0cb71eea1c508f46?placeholderIfAbsent=true"
          alt="Previous"
          sx={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: 1 }}
        />
      </IconButton>

      {/* Page Buttons */}
      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
        const isActive = page === currentPage;

        return (
          <Button
            key={page}
            variant={isActive ? "contained" : "outlined"}
            size="small"
            onClick={() => onPageChange(page)}
            aria-label={`Page ${page}`}
            aria-current={isActive ? "page" : undefined}
            sx={{
              minWidth: 32,
              height: 32,
              padding: "5px",
              backgroundColor: isActive ? "rgba(15,73,119,1)" : "white",
              color: isActive ? "white" : "#212B36",
              borderColor: "rgba(15,73,119,1)",
              fontSize: "0.75rem",
              fontWeight: 700,
              "&:hover": {
                backgroundColor: isActive ? "rgba(15,73,119,0.9)" : "#f0f0f0",
              },
            }}
          >
            {page}
          </Button>
        );
      })}

      {/* Next Button */}
      <IconButton
        onClick={handleNext}
        disabled={currentPage === totalPages}
        aria-label="Next page"
        sx={{ width: 40, height: 40 }}
      >
        <Box
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d9d2af6c5dff197969662655f2ed16ac1b615c4a?placeholderIfAbsent=true"
          alt="Next"
          sx={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: 1 }}
        />
      </IconButton>
    </Stack>
  );
};
