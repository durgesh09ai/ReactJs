import React, { useState } from "react";
import { Box, Button, Typography } from "@mui/material";

interface TabItem {
  id: string;
  label: string;
}

interface ProjectTabsProps {
  tabs: TabItem[];
  activeTab?: string;
  onTabChange?: (tabId: string) => void;
  children: React.ReactNode;
}

export const ProjectTabs: React.FC<ProjectTabsProps> = ({
  tabs,
  activeTab: externalActiveTab,
  onTabChange,
  children,
}) => {
  const [internalActiveTab, setInternalActiveTab] = useState(
    externalActiveTab || tabs[0]?.id
  );

  const activeTabId = externalActiveTab || internalActiveTab;

  const handleTabClick = (tabId: string) => {
    if (onTabChange) {
      onTabChange(tabId);
    } else {
      setInternalActiveTab(tabId);
    }
  };

  return (
    <Box display="flex" flexDirection="column" width="100%">
      <Box
        display="flex"
        flexWrap="wrap"
        alignItems="center"
        sx={{
          gap: 1.5, // tighter gap
        }}
      >
        {tabs.map((tab) => {
          const isActive = activeTabId === tab.id;
          return (
            <Box key={tab.id}>
              <Button
                onClick={() => handleTabClick(tab.id)}
                disableRipple
                sx={{
                  textTransform: "none",
                  fontWeight: 500,
                  fontSize: "0.95rem",
                  color: isActive ? "rgba(15,73,119,1)" : "#98A2B2",
                  padding: "4px 8px",
                  minWidth: "auto",
                  lineHeight: 1,
                }}
              >
                {tab.label}
              </Button>
              <Box
                sx={{
                  height: "2px",
                  width: "100%",
                  backgroundColor: isActive ? "rgba(15,73,119,1)" : "transparent",
                  borderRadius: "1px",
                  mt: "2px",
                }}
              />
            </Box>
          );
        })}
      </Box>

      <Box mt={2}>{children}</Box>
    </Box>
  );
};
