import React, { useState } from "react";
import { Box, Button, Paper } from "@mui/material";

interface ProjectGalleryProps {
  mainImage: string;
  thumbnails: string[];
}

export const ProjectGallery: React.FC<ProjectGalleryProps> = ({
  mainImage,
  thumbnails = ["", "", "", ""],
}) => {
  const [selectedImage, setSelectedImage] = useState(mainImage);

  const handleThumbnailClick = (image: string) => {
    if (image) {
      setSelectedImage(image);
    }
  };

  return (
    <Paper
      elevation={1}
      sx={{
        backgroundColor: "rgba(237,237,237,1)",
        border: "1px solid #D4D4D4",
        borderRadius: "10px",
        px: { xs: 2, md: 6.5 },
        py: 2,
        width: "100%",
        boxShadow: "2px 0px 5px rgba(54, 58, 63, 0.08)",
      }}
    >
      <Box
        component="img"
        src={
          selectedImage ||
          "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/55d9b3fa6c3c0c94d9289dd5227f13c95d90481a?placeholderIfAbsent=true"
        }
        alt="Project preview"
        sx={{
          aspectRatio: "1.87",
          objectFit: "contain",
          width: "100%",
          borderRadius: 2,
        }}
      />
      <Box
        mt={3}
        display="flex"
        gap={4}
        flexWrap="wrap"
        alignItems="center"
        justifyContent="flex-start"
      >
        {thumbnails.map((thumbnail, index) => (
          <Button
            key={index}
            onClick={() => handleThumbnailClick(thumbnail)}
            aria-label={`Thumbnail ${index + 1}`}
            sx={{
              backgroundColor: "rgba(241,243,245,1)",
              width: "100px",
              height: "75px",
              borderRadius: "5px",
              flexShrink: 0,
              "&:hover": {
                opacity: 0.8,
                backgroundColor: "rgba(241,243,245,1)",
              },
            }}
          />
        ))}
      </Box>
    </Paper>
  );
};
