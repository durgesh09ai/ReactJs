import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  Typography,
  useMediaQuery,
  useTheme
} from "@mui/material";

import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import ExportButtonWithDialog from "./ExportButtonWithDialog";
import { useNavigate } from "react-router-dom";
import { DiagnosisCodeTable } from "./DiagnosisCodeTable";

interface ResearchReportProps {
  report: {
    markdown: string;
    docx: string;
    code_table?:any[];
  };
  handleDownloadReport: () => void;
  researchId?:string;
  version:string;
}

export const ResearchReport: React.FC<ResearchReportProps> = ({
  report,
  handleDownloadReport,
  researchId,
  version
}) => {

 const navigate = useNavigate();
 const theme = useTheme() ;
 const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));
 const iconSrc = "/report.svg";
 const [disableButton,setDisableButton] = useState(false);
 const [noClickMessage,setNoClickMessage] = useState(false);
 const [showDiagnosisCode,setShowDiagnosisCode] = useState(false);

 const handleNoClick = ()=>{
      setNoClickMessage(true);
      setDisableButton(true);
 }

 const handleYesClick = ()=>{
  setShowDiagnosisCode(true);
  setDisableButton(true);
}

const toTheExprimentPage = ()=>{
  navigate(`/protoweave/experiment/${researchId}/version/${version}`);
}

const code_table = report?.code_table;

// const code_table =  [
//   {
//       "Diagnosis": "Type 2 Diabetes Mellitus (T2DM)",
//       "Codes": "E11.9",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Type 2 Diabetes Mellitus (T2DM) with cardiovascular complications",
//       "Codes": "E11.51",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Major Adverse Cardiovascular Events (MACE)",
//       "Codes": "I21, I22, I25.1",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Heart Failure",
//       "Codes": "I50.9",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Stroke",
//       "Codes": "I63.9",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Hypertension",
//       "Codes": "I10",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Chronic Kidney Disease (CKD)",
//       "Codes": "N18.9",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Urinary Tract Infection (UTI)",
//       "Codes": "N39.0",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Dehydration",
//       "Codes": "E86.0",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Percutaneous Coronary Intervention (PCI)",
//       "Codes": "3E053CZ",
//       "Code Type": "HCPCS"
//   },
//   {
//       "Diagnosis": "Dapagliflozin",
//       "Codes": "99204F",
//       "Code Type": "HCPCS"
//   },
//   {
//       "Diagnosis": "Sitagliptin",
//       "Codes": "99213F",
//       "Code Type": "HCPCS"
//   },
//   {
//       "Diagnosis": "Cardiorenal protection",
//       "Codes": "G9879",
//       "Code Type": "HCPCS"
//   },
//   {
//       "Diagnosis": "Hypoglycemia",
//       "Codes": "E16.2",
//       "Code Type": "ICD"
//   },
//   {
//       "Diagnosis": "Chronic Coronary Syndrome",
//       "Codes": "I25.10",
//       "Code Type": "ICD"
//   }
// ];



  return (
    <Stack 
    direction= {isSmallScreen ? "column" : "row"}
    spacing={1} 
    width={{sx:"100%" ,sm:"100%",md:"98%"}}
    >
      <Avatar
        src={iconSrc}
        alt="Report"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          bgcolor: "#F3FAFF",
          p: 1.5,
          borderRadius: 3,
          fontSize: "0.875rem",
          color: "black",
          overflowWrap:"break-word",
        }}
      >
        {/* Export button at top-right */}
        <Box display="flex" justifyContent="flex-end" mb={1}>
          <ExportButtonWithDialog onExport={handleDownloadReport} />
        </Box>

        {/* Title content */}
        <Box
         fontWeight={500}
         fontSize="14px"
         mb={2}
         sx={{
          '& h1':{
            fontSize:18,
            fontWeight:700,
          },
          '& h2':{
            fontSize:16,
            fontWeight:700,
          },
          '& h3':{
            fontSize:14,
            fontWeight:700,
          },
          wordBreak:"break-word",
         }}
         >
        <Markdown remarkPlugins={[remarkGfm]}>{report.markdown}</Markdown>
        </Box>
        {/* Start Simulation Button */}
        {noClickMessage && (
        <Box display="flex" flexDirection={"column"} alignItems={"center"}>
        <Typography fontSize="14px" color="#4CAF50">
        Thankyou, you can start another research.
        </Typography>
        </Box>
        )}

  {!disableButton && code_table && (
  <Box display="flex" alignItems="center" gap={2} mt={2}>

  <Typography fontSize="14px" fontWeight={"bold"}>
    Do you want diagnosis codes as well?
  </Typography>
  <Button
    onClick={handleYesClick}
    sx={{
      bgcolor: "#4CAF50",
      color: "white",
      fontWeight: 500,
      px: 2,
      py: 0.75,
      borderRadius: 1.5,
      textTransform: "none",
      "&:hover": {
        bgcolor: "#3d9140",
      },
    }}
  >
    Yes
  </Button>

  <Button
    onClick={handleNoClick}
    sx={{
      bgcolor: "#4CAF50",
      color: "white",
      fontWeight: 500,
      px: 2,
      py: 0.75,
      borderRadius: 1.5,
      textTransform: "none",
      "&:hover": {
        bgcolor: "#3d9140",
      },
    }}
  >
    No
  </Button>
</Box>
)}

{/* Tabular code_table display */}
{showDiagnosisCode && code_table && (
<DiagnosisCodeTable 
code_table={code_table}
researchId={ researchId}
version = {version}
/>    
)}

</Paper>
</Stack>
  );
};
