import React, { useEffect, useState } from "react";
import { Box, MenuItem, Paper, Select, TextField, Typography } from "@mui/material";
import FormHeader from "./FormHeader";
import ResearchInfo from "./ResearchInfo";
import CriteriaSection from "./CriteriaSection";
import MedicalCodingSection from "./MedicalCodingSection";
import ParametersSection from "./ParametersSection";
import UploadSection from "./UploadSection";
import ActionButtons from "./ActionButtons";
import { databricksStore } from "../../../stores/cip/ProtoweaveGenAiStore/DatabricksStore";
import { researchStore } from "../../../stores/cip/ProtoweaveGenAiStore/ResearchStore";
import { observer } from "mobx-react-lite";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";

interface experimentConfigrationProps{
  experimentId:string;
  researchId:string;
}

const ExperimentInterface = (props:experimentConfigrationProps) => {

  const { experimentId ,researchId } = props;
  const [activeTab, setActiveTab] = useState("Configuration Form 1");
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());

  const dataresult = "";
  databricksStore.setDatabrickResult(dataresult);

  useEffect(() => {
    if (experimentId && researchId) {
      researchStore.fetchExperiment(experimentId, researchId);
    }
  }, [experimentId, researchId]);


  const code_table =  [
    {
        "Diagnosis": "Type 2 Diabetes Mellitus (T2DM)",
        "Codes": "E11.9",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Type 2 Diabetes Mellitus (T2DM) with cardiovascular complications",
        "Codes": "E11.51",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Major Adverse Cardiovascular Events (MACE)",
        "Codes": "I21, I22, I25.1",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Heart Failure",
        "Codes": "I50.9",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Stroke",
        "Codes": "I63.9",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Hypertension",
        "Codes": "I10",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Chronic Kidney Disease (CKD)",
        "Codes": "N18.9",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Urinary Tract Infection (UTI)",
        "Codes": "N39.0",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Dehydration",
        "Codes": "E86.0",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Percutaneous Coronary Intervention (PCI)",
        "Codes": "3E053CZ",
        "Code Type": "HCPCS"
    },
    {
        "Diagnosis": "Dapagliflozin",
        "Codes": "99204F",
        "Code Type": "HCPCS"
    },
    {
        "Diagnosis": "Sitagliptin",
        "Codes": "99213F",
        "Code Type": "HCPCS"
    },
    {
        "Diagnosis": "Cardiorenal protection",
        "Codes": "G9879",
        "Code Type": "HCPCS"
    },
    {
        "Diagnosis": "Hypoglycemia",
        "Codes": "E16.2",
        "Code Type": "ICD"
    },
    {
        "Diagnosis": "Chronic Coronary Syndrome",
        "Codes": "I25.10",
        "Code Type": "ICD"
    }
];


  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleUploadProtocol = () => {
    console.log("Upload protocol clicked");
    // Implement protocol upload functionality
  };

  const handleUploadData = () => {
    console.log("Upload data clicked");
    // Implement data upload functionality
  };

  const handleDuplicate = () => {
    console.log("Duplicate clicked");
    // Implement duplication functionality
  };

  const handleRunExperiment = () => {
    const dataresult1 = "test";
    databricksStore.setDatabrickResult(dataresult1);
    console.log("Run experiment clicked");
  };

  const labelStyle = {
    width: "200px",
    fontSize: 14,
    color: "black",
    mt: 1
  };
  
  const fieldStyle = {
    flex: 1,
    minWidth: 100
  };
  
  const rowStyle = {
    display: "flex",
    alignItems: "center",
    gap: 2,
    mb: 2
  };

  const Row = ({ label, children }: { label: string, children: React.ReactNode }) => (
    <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
      <Box sx={{ minWidth: 150 }}>
        <Typography sx={{ fontSize: 14, color: "black" }}>{label}</Typography>
      </Box>
      <Box>{children}</Box>
    </Box>
  );


  return (
    <Box sx={{ maxWidth: "684px", fontSize: "0.875rem" }}>
      <FormHeader
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onUploadProtocol={handleUploadProtocol}
      />
      
      <Box 
        sx={{ 
          width: "100%", 
          bgcolor: "#D9EDFF", 
          borderRadius: "0px 12px 12px 12px",
          p: 2,
          overflow: "hidden"
        }}
      >
        <ResearchInfo
          researchName="Diabetes type1"
          experimentName="Config 1"
          createdDate="May 24, 2025"
          ownerName="@dr.meera"
        />
        
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          borderRadius: 2,
          width: "100%"
        }}
      >
        <Typography
          sx={{
            fontWeight: "bold",
            fontSize: 14,
            color: "black",
            lineHeight: 1.2,
            mb: 2
          }}
        >
          Cohost Identification
        </Typography>

        {/* Age at Index */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Age at Index:</Typography>
          <Select
            value="40"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14 }}
          >
            <MenuItem value="10">10</MenuItem>
            <MenuItem value="20">20</MenuItem>
            <MenuItem value="40">40</MenuItem>
          </Select>
        </Box>

        {/* Race / Ethnicity */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Race / Ethnicity:</Typography>
          <Select
            value="10"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">Race1</MenuItem>
            <MenuItem value="20">Race2</MenuItem>
            <MenuItem value="40">Race3</MenuItem>
          </Select>
        </Box>

        {/* Region */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Region:</Typography>
          <Select
            value="40"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">Region1</MenuItem>
            <MenuItem value="20">Region2</MenuItem>
            <MenuItem value="40">Region3</MenuItem>
          </Select>
        </Box>

        {/* SDOH */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>SDOH:</Typography>
          <Select
            value="10"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">SDOH1</MenuItem>
            <MenuItem value="20">SDOH2</MenuItem>
            <MenuItem value="40">SDOH3</MenuItem>
          </Select>
        </Box>

        {/* Period of Interest */}
      <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
          <Box sx={{ width: 180 }}>
            <Typography sx={{ fontSize: 14, color: "black" }}>
              Period of Interest:
            </Typography>
          </Box>
          <Box sx={{ display: "flex", gap: 1,ml:4 }}>
            <DatePicker
              label="Start Date"
              value={startDate}
              onChange={(newDate) => setStartDate(newDate)}
              format="yyyy-MM-dd"
              slotProps={{
                textField: {
                  size: "small",
                  sx: { width: 150 ,fontSize:14 }
                }
              }}
            />
            <DatePicker
              label="End Date"
              value={endDate}
              onChange={(newDate) => setEndDate(newDate)}
              format="yyyy-MM-dd"
              slotProps={{
                textField: {
                  size: "small",
                  sx: { width: 150,fontSize:14  }
                }
              }}
            />
          </Box>
        </Box>
      </Paper>
    </LocalizationProvider>

      <Paper
      elevation={0}
      sx={{
        mt: 2,
        p: 2,
        borderRadius: 2,
        width: "100%"
      }}
      >
      <Typography
        sx={{
          fontWeight: "bold",
          fontSize: 14,
          color: "black",
          lineHeight: 1.2,
          mb: 2
        }}
      >
        Clinical Characteristic
      </Typography>

      {/* Age at Index */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Comorbidities:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Hypertension and Diabetes</MenuItem>
          <MenuItem value="20">Chronic Lung Disease and Heart Disease</MenuItem>
          <MenuItem value="40">Mental Health and Substance Use</MenuItem>
        </Select>
      </Box>

      {/* Race / Ethnicity */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Disease Specific Severity Measure:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Disease1</MenuItem>
          <MenuItem value="20">Disease2</MenuItem>
          <MenuItem value="40">Disease3</MenuItem>
        </Select>
      </Box>

      {/* Region */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Biomarkers/Labs:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Labs1</MenuItem>
          <MenuItem value="20">Labs2</MenuItem>
          <MenuItem value="40">Labs3</MenuItem>
        </Select>
      </Box>

      {/* SDOH */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Baseline Diagnosis:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Diagnosis1</MenuItem>
          <MenuItem value="20">Diagnosis2</MenuItem>
          <MenuItem value="40">Diagnosis3</MenuItem>
        </Select>
      </Box>
      </Paper>

        <Paper 
          elevation={0}
          sx={{ 
            mt: 2, 
            p: 2, 
            borderRadius: 2,
            width: "100%"
          }}
        >
          <CriteriaSection />
          <MedicalCodingSection />
        
        </Paper>

      <Paper
      elevation={0}
      sx={{
        mt: 2,
        p: 2,
        borderRadius: 2,
        width: "100%"
      }}
      >
      <Typography
        sx={{
          fontWeight: "bold",
          fontSize: 14,
          color: "black",
          lineHeight: 1.2,
          mb: 2
        }}
      >
       Inclusion / Exclusion Criteria

      </Typography>

      {/* Age at Index */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Disease Diagnosis:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Hypertension and Diabetes</MenuItem>
          <MenuItem value="20">Chronic Lung Disease and Heart Disease</MenuItem>
          <MenuItem value="40">Mental Health and Substance Use</MenuItem>
        </Select>
      </Box>

      {/* Race / Ethnicity */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Deceased:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Yes</MenuItem>
          <MenuItem value="20">No</MenuItem>
        </Select>
      </Box>

         <ActionButtons
        onDuplicate={handleDuplicate}
        onRunExperiment={handleRunExperiment}
        />
      </Paper>
       
     </Box>
    </Box>
  );
};

export default observer(ExperimentInterface);
