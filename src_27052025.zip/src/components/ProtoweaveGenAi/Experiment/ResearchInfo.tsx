import React, { useState } from "react";
import { Box, Typography, Paper } from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import { MenuItem, Select } from "@mui/material";

interface ResearchInfoProps {
  researchName: string;
  experimentName: string;
  createdDate: string;
  ownerName: string;
}

const ResearchInfo: React.FC<ResearchInfoProps> = ({
  researchName,
  experimentName,
  createdDate,
  ownerName,
}) => {

  const [selectedResearch, setSelectedResearch] = useState("Research A");


  return (
    <Paper
      elevation={0}
      sx={{
        width: "100%",
        p: 2,
        borderRadius: 2,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          gap: 2,
        }}
      >
        {/* Left section */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            gap: 2,
            minWidth: "60px",
          }}
        >
      <Box sx={{ width: "149px" }}>
            <Typography
              variant="body2"
              sx={{ color: "rgba(18, 18, 21, 0.30)", mb: 1 }}
            >
              Research Name
            </Typography>
            <Select
              value={selectedResearch}
              onChange={(e) => setSelectedResearch(e.target.value)}
              fullWidth
              size="small"
              displayEmpty
              sx={{
                fontSize: 12, 
                bgcolor: "white",
                "& .MuiSelect-icon": { fontSize: 20 },
                "& fieldset": { borderColor: "#0F4977" },
              }}
              MenuProps={{
                PaperProps: {
                  sx: {
                    "& .MuiMenuItem-root": {
                      fontSize: 12, 
                      py: 0.5,
                    },
                  },
                },
              }}
            >
              <MenuItem value="" disabled>
                Select research
              </MenuItem>
              <MenuItem value="Research A">Research A</MenuItem>
              <MenuItem value="Research B">Research B</MenuItem>
              <MenuItem value="Research C">Research C</MenuItem>
            </Select>

          </Box>

          <Box sx={{ flex: 1 }}>
          <Typography variant="body2" sx={{ color: "rgba(18, 18, 21, 0.30)" }}>
          Experiment Name
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              {experimentName}
            </Typography>
          </Box>
        </Box>

        {/* Right section */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            gap: 2,
            minWidth: "60px",
          }}
        >
          <Box sx={{ flex: 1 }}>
          <Typography variant="body2" sx={{ color: "rgba(18, 18, 21, 0.30)" }}>
          Created on
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              {createdDate}
            </Typography>
          </Box>

          <Box sx={{ flex: 1 }}>
          <Typography variant="body2" sx={{ color: "rgba(18, 18, 21, 0.30)" }}>
          Owner
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                mt: 1,
              }}
            >
              <PersonIcon sx={{ fontSize: 20 }} />
              <Typography variant="body2">{ownerName}</Typography>
            </Box>
          </Box>
        </Box>
      </Box>
    </Paper>
  );
};

export default ResearchInfo;
