import React, { useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Switch
} from "@mui/material";
import TeamMember from "./TeamMember";

interface AddWorkspaceCardProps {
  name: string;
  description: string;
  userId: string;
  team_members: string[];
  archive: boolean;
  onSubmit: (updatedWorkspace: any) => void;
}

const AddWorkspaceCard: React.FC<AddWorkspaceCardProps> = ({
  name,
  description,
  userId,
  team_members,
  archive,
  onSubmit
}) => {

  const [WSName, setWSName] = useState(name);
  const [WSdescription, setWSdescription] = useState(description);
  const [members, setMembers] = useState(team_members);
  const [isArchived, setIsArchived] = useState(archive);
  const [newMember, setNewMember] = useState("");

  const handleAddMember = () => {
    if (newMember && !members.includes(newMember)) {
      setMembers([...members, newMember]);
      setNewMember("");
    }
  };

  const handleSubmit = () => {
    const updatedWorkspace = {
      WS_name:WSName,
      WS_descrip:WSdescription,
      userId:userId,
      team_members:members,
      archive: isArchived,
    };
    onSubmit(updatedWorkspace);
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: "1px solid #E4E4E5",
        width: "100%",
        maxWidth: "527px",
        mt: 2,
        p: 2
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Typography variant="body2" fontWeight="bold">
          {name}
        </Typography>
        <Box
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/467fbc5a970c7fab7573b24ac1a4b6a612a0ddb3?placeholderIfAbsent=true"
          sx={{ width: 24, height: 24 }}
          alt="Options"
        />
      </Box>

      <Box mt={2}>
        <Typography variant="body2" fontWeight="bold" fontSize={14}>
          Workspace Name
        </Typography>
        <TextField
          fullWidth
          size="small"
          value={WSName}
          onChange={(e) => setWSName(e.target.value)}
          sx={{ "& input": { fontSize: 12 } }} 
        />

        <Typography variant="body2" fontWeight="bold" mt={2} fontSize={14}>
          Workspace Description
        </Typography>
        <TextField
          fullWidth
          multiline
          value={WSdescription}
          onChange={(e) => setWSdescription(e.target.value)}
          sx={{ "& textarea": { fontSize: 12 } }} 
        />
      </Box>
      <Box mt={1}>
        <Typography variant="body2" fontWeight="bold" fontSize={14}>
          Team Members:
        </Typography>
        <Box mt={1} ml={4}>
          <Typography variant="body2" fontSize={14}>
            Owner
          </Typography>
          <TextField
            size="small"
            fullWidth
            value={userId}
            sx={{ "& input": { fontSize: 12 } }} 
          />

          <Box mt={2} display="flex" gap={1}>
            <TextField
              size="small"
              label="Add team member"
              value={newMember}
              onChange={(e) => setNewMember(e.target.value)}
              fullWidth
              sx={{ 
                "& input": { fontSize: 12 },
                "& .MuiInputLabel-root": { fontSize: 12 } ,
              }} 
            />
            <Button
              variant="contained"
              onClick={handleAddMember}
              sx={{
                height: 32, 
                fontSize: 12,
                padding: "6px 16px" 
              }}
            >
              Add
            </Button>
          </Box>

          <Box mt={1}>
            {members && members.length > 0 && (
              <Typography variant="body2" fontSize={14}>
                Team Members:
              </Typography>
            )}
            {members.map((member, index) => (
              <Box key={index} mt={1}>
                <TeamMember email={member} userType='member'/>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
      <Box mt={1}>
        <Typography variant="body2" fontWeight="bold" fontSize={14}>
          Workspace Settings
        </Typography>

     <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mt: 1,
          pl: 2
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            bgcolor: 'white',
            borderRadius: 1,
            p: 0.5
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box 
                component="img"
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/190889642f933327d884e606f642c062034e414d?placeholderIfAbsent=true"
                sx={{ width: 24, height: 24 }}
                alt="Archive"
              />
              <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
                Archive Workspace
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)', textAlign: 'center' }}>
              (Hide this workspace for all user)
            </Typography>
          </Box>
          <Switch
            checked={isArchived}
            onChange={() => setIsArchived(!isArchived)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: '#0F4977',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          />
        </Box>

        <Box textAlign="right" mt={2}>
          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" 
            }}
          >
            Save
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default AddWorkspaceCard;
