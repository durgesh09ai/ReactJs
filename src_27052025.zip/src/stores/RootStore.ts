import { DatagenAiSyntheticStore } from "./cip/DatagenAiSyntheticStore";
import { ProtoweaveGenAiStore } from "./cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";
import { DatabricksStore } from "./cip/ProtoweaveGenAiStore/DatabricksStore";

export class RootStore {
  datagenAiSyntheticStore: DatagenAiSyntheticStore;
  dataProtoweaveGenAiStore: ProtoweaveGenAiStore;
  databricksStore: DatabricksStore;


  constructor() {
    this.datagenAiSyntheticStore = new DatagenAiSyntheticStore();
    this.dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();
    this.databricksStore = new DatabricksStore();

  }
}

const rootStore = new RootStore();
export default rootStore;
