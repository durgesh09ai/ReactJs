import React from "react";
import { observer } from "mobx-react-lite";
import { Box } from "@mui/material";
import Console from "../../../../components/ProtoweaveGenAi/Experiment/Console";
import ExperimentInterface from "../../../../components/ProtoweaveGenAi/Experiment/ExperimentInterface";
import { useParams } from "react-router-dom";

const ExperimentConfigration = () => {
  const { id:experimentId,researchId } = useParams();

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        gap: 2,
        width: "100%",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          flexGrow: 1,
          minWidth: 0, // 👈 Prevents overflow from flex child
        }}
      >
        <ExperimentInterface
        experimentId={experimentId}
        researchId = {researchId}
        />
      </Box>

      <Box
        sx={{
          width: "400px",
          flexShrink: 0, // 👈 Prevents StatsPanel from shrinking
        }}
      >
        <Console />
      </Box>
    </Box>
  );
};

export default observer(ExperimentConfigration);
