import React from "react";
import { Box, Typography, Stack } from "@mui/material";
import { observer } from "mobx-react-lite";
import { ProjectCard } from "./ProjectCard";

type Project = {
  id: number;
  title: string;
  description: string;
  tags: string[];
  imageSrc: string;
  commentCount: number;
  contributorCount: string;
  badgeIconSrc: string;
  likeIconSrc: string;
  starIconSrc: string;
};

interface ProjectsSectionProps {
  SectionName: string;
  projectList: Project[];
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = observer(
  ({ SectionName, projectList }) => (
    <Box width="100%" mt={4}>
      {/* ---- header ---- */}
      <Stack direction="row" spacing={1} alignItems="center">
        <Typography variant="subtitle2" fontWeight={600} fontSize={14}>
          {SectionName}
        </Typography>
        <Box
          sx={{
            backgroundColor: "#E9F3F9",
            color: "#0F4977",
            fontSize: 10,
            fontWeight: 800,
            borderRadius: "8px",
            width: 25,
            height: 25,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {projectList.length}
        </Box>
      </Stack>

      {/* ---- cards grid ---- */}
      <Box
        display="flex"
        flexWrap="wrap"
        gap={2}
        mt={2}
        justifyContent={{ xs: "center", sm: "flex-start" }}
      >
        {projectList.map((project, idx) => (
          <Box
            key={`${SectionName}-${project.id}-${idx}`}  
            sx={{
              width: {
                xs: "100%",
                sm: "48%",
                md: "31.5%",
                lg: "23.5%",
              },
              flexGrow: 0,
              flexShrink: 0,
            }}
          >
            <ProjectCard {...project} />
          </Box>
        ))}
      </Box>
    </Box>
  )
);
