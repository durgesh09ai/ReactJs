import React from "react";
import { observer } from "mobx-react-lite";

import {
  Box,
  Typography,
  Chip,
  Card,
  CardMedia,
  Button,
  Stack,
  Avatar,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import ThumbUpAltOutlinedIcon from '@mui/icons-material/ThumbUpAltOutlined';

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  imageSrc: string;
  commentCount: number;
  contributorCount: string;
  badgeIconSrc: string;
  likeIconSrc: string;
  starIconSrc: string;
}

export const ProjectCard: React.FC<ProjectCardProps> = observer(({
  title,
  description,
  tags,
  imageSrc,
  likeIconSrc,
  starIconSrc,
}) => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/solutioncataloguedetail");
  };

  return (
    <Card
      elevation={0}
      sx={{
        width: "100%", // ✅ Make the card responsive to container width
        borderRadius: 4,
        border: "1px solid rgba(172,172,172,0.2)",
        p: 2,
        position: "relative",
        bgcolor: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Star and Like Icons */}
      <Stack 
  direction="row" 
  spacing={1} 
  alignItems="center" 
  justifyContent="flex-end"  // <-- ADD THIS
  sx={{ minHeight: 24 }}
>
  <Avatar src={starIconSrc} alt="star icon" sx={{ width: 16, height: 16 }} />
  <Avatar src={likeIconSrc} alt="like icon" sx={{ width: 16, height: 16 }} />
</Stack>

      {/* Tags */}
      <Stack direction="row" spacing={1} mt={1} flexWrap="wrap">
        {tags.map((tag, index) => (
          <Chip
            key={index}
            label={tag}
            size="small"
            sx={{
              fontSize: 12,
              fontWeight:500,
              bgcolor: index === 0 ? "rgba(233,243,249,1)" : "rgba(15,73,119,0.1)",
              color: "rgba(15,73,119,1)",
              borderRadius: "999px",
              height: 20,
            }}
          />
        ))}
      </Stack>

      {/* Image with Floating Badge */}
      <Box
        sx={{
          position: "relative",
          mt: 2,
          cursor: "pointer",
          overflow: "hidden",
        }}
        onClick={handleClick}
      >
        <CardMedia
          component="img"
          image={imageSrc}
          alt={title}
          sx={{ aspectRatio: "1.91", borderRadius: 2 }}
        />
        <Avatar
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e797be27b400fbd4f0c6ce9e1342717a160306af?placeholderIfAbsent=true"
          alt="floating badge"
          sx={{
            position: "absolute",
            top: 8,
            left: 2,
            width: 25,
            height: 25,
            zIndex: 2,
          }}
        />
      </Box>

      {/* Title and Description */}
      <Box mt={2}>
        <Typography variant="subtitle2" fontWeight="500" fontSize={14}>
          {title}
        </Typography>
        <Typography
          variant="body2"
          color="text.secondary"
          mt={0.5}
          sx={{ fontSize: 12,fontWeight:400 }}
        >
          {description}
        </Typography>
      </Box>

    </Card>
  );
});
