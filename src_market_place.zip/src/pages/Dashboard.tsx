import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import { Container } from "@mui/material";
import { ProjectsSection } from "../components/Dashboard/ProjectsSection";
import { BannerVideosSection } from "../components/Dashboard/BannerVideosSection";
import { mainPageStore } from "../stores/MainPageStore";

const Dashboard: React.FC = observer(() => {
  useEffect(() => {
    mainPageStore.loadProjectsData();
  }, []);

  const filterBySGU = (arr: any[]) => {
    const selected = mainPageStore.selectedSGUs;
    if (!selected || selected.size === 0) return arr;
    return arr.filter((p) => selected.has(p.SGU));
  };

  if (mainPageStore.projectsLoading) return <div>Loading projects...</div>;
  if (mainPageStore.projectsError) return <div>Error: {mainPageStore.projectsError}</div>;

  const { Top10Products, Top10NewProducts, Top10MostUsedProducts } = mainPageStore.projectsByCategory;

  return (
    <Container>
      <BannerVideosSection />

      <ProjectsSection
        SectionName={Top10Products?.sectionName}
        projectList={filterBySGU(Top10Products?.projects)}
      />
      <ProjectsSection
        SectionName={Top10NewProducts?.sectionName}
        projectList={filterBySGU(Top10NewProducts?.projects)}
      />
      <ProjectsSection
        SectionName={Top10MostUsedProducts?.sectionName}
        projectList={filterBySGU(Top10MostUsedProducts?.projects)}
      />
    </Container>
  );
});

export default Dashboard;
