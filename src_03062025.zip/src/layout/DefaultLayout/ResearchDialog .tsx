import React from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, TextField, Button, Box, Typography } from '@mui/material';

const ResearchDialog = ({ dialogOpen, handleCloseDialog, handleFormChange, handleSubmit, formData }) => {
  return (
    <Dialog open={dialogOpen} onClose={handleCloseDialog} fullWidth maxWidth="sm">
      {/* Dialog Title */}
      <DialogTitle sx={{ textAlign: 'center', fontWeight: 'bold' }}>Let's Start Your Research!!</DialogTitle>

      <DialogContent>
        {/* Research Name TextField */}
        <TextField
          margin="dense"
          label="Give your research a name:"
          name="research_name"
          fullWidth
          value={formData.research_name}
          onChange={handleFormChange}
          sx={{
            marginBottom: 2,
            '& .MuiInputBase-input': {
              fontSize: '14px',
            },
          }}
        />

        {/* Research Description TextField */}
        <TextField
          margin="dense"
          label="What is it about? (Optional)"
          name="description"
          fullWidth
          multiline
          value={formData.description}
          onChange={handleFormChange}
          sx={{
            marginBottom: 2,
            '& .MuiInputBase-input': {
              fontSize: '14px',
            },
            minHeight: '80px',
          }}
        />

        {/* Description Text */}
        <Box mt={2}>
          <Typography variant="body2" sx={{ fontWeight: 'bold', fontSize: 12 }}>
            No experiments yet?
          </Typography>
          <Typography variant="body2" sx={{ fontSize: 14 }}>
            You can add experiments to this research after creation.
          </Typography>
        </Box>
      </DialogContent>

      <DialogActions>
        <Button onClick={handleCloseDialog} variant="outlined" color="primary">
          Cancel
        </Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          Submit
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ResearchDialog;
