import React, { useState } from 'react';
import { Box, Divider, Paper, Typography } from '@mui/material';
import { AgentHeader } from './AgentHeader';
import { AgentList } from './AgentList';
import { AgentForm } from './AgentForm';
import { Agent } from './AgentCard';

const AgentManagement: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: '1',
      name: 'PubMed',
      url: 'api.pubmed.org',
      description: 'Biomedical literature search agent',
      enabled: true,
      isDefault: true
    },
    {
      id: '2',
      name: 'Deep Research',
      url: 'deepsearch.ai',
      description: 'Biomedical literature search agent',
      enabled: false,
      isDefault: false
    }
  ]);

  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [isAddingAgent, setIsAddingAgent] = useState(false);

  const handleAddAgent = () => {
    setEditingAgent(null);
    setIsAddingAgent(true);
  };

  const handleEditAgent = (agent: Agent) => {
    setEditingAgent(agent);
    setIsAddingAgent(false);
  };

  const handleDeleteAgent = (agentToDelete: Agent) => {
    setAgents(agents.filter(agent => agent.id !== agentToDelete.id));
  };

  const handleToggleStatus = (agentToToggle: Agent, enabled: boolean) => {
    setAgents(agents.map(agent => 
      agent.id === agentToToggle.id ? { ...agent, enabled } : agent
    ));
  };

  const handleSetDefault = (agentToSetDefault: Agent, isDefault: boolean) => {
    setAgents(agents.map(agent => 
      agent.id === agentToSetDefault.id 
        ? { ...agent, isDefault } 
        : isDefault ? { ...agent, isDefault: false } : agent
    ));
  };

  const handleSaveAgent = (agentData: Partial<Agent>) => {
    if (editingAgent) {
      // Update existing agent
      setAgents(agents.map(agent => 
        agent.id === editingAgent.id ? { ...agent, ...agentData } : agent
      ));
    } else {
      // Add new agent
      const newAgent: Agent = {
        id: Date.now().toString(),
        name: agentData.name || 'New Agent',
        url: agentData.url || 'example.com',
        description: agentData.description || 'No description',
        enabled: agentData.enabled || false,
        isDefault: agentData.isDefault || false
      };
      setAgents([...agents, newAgent]);
    }
    setEditingAgent(null);
    setIsAddingAgent(false);
  };

  const handleCancelEdit = () => {
    setEditingAgent(null);
    setIsAddingAgent(false);
  };

  return (
    <Box sx={{
      display: 'flex',
      maxWidth: '720px',
      flexDirection: 'column',
      alignItems: 'stretch',
      justifyContent: 'center'
    }}>
      <Paper sx={{
        justifyContent: 'center',
        alignItems: 'stretch',
        border: '1px solid rgba(18,18,21,0.10)',
        display: 'flex',
        width: '100%',
        flexDirection: 'column',
        p: 2
      }}>

    <Box sx={{ width: "100%", px: 2, display: "flex", justifyContent: "space-between" }}>
      <Box sx={{ width: "100%", pb: 2 }}>
        <Typography variant="body1" sx={{ color: "#1d1b20",fontSize:'14px',fontWeight:400, }}>
        External Agents / MCP Setup
        </Typography>
        <Divider sx={{ mt: 1 }} />
      </Box>
    </Box>
   <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          border: "1px solid rgba(18,18,21,0.10)",
          padding: 2,
          width: "100%",
        }}
      >
        <AgentHeader onAddClick={handleAddAgent} />
        <AgentList 
          agents={agents}
          onEdit={handleEditAgent}
          onDelete={handleDeleteAgent}
          onToggleStatus={handleToggleStatus}
          onSetDefault={handleSetDefault}
        />
        {(isAddingAgent || editingAgent) && (
          <AgentForm 
            agent={editingAgent || undefined}
            onSave={handleSaveAgent}
            onCancel={handleCancelEdit}
          />
        )}
      </Paper>

      </Paper>
    </Box>
  );
};

export default AgentManagement;
