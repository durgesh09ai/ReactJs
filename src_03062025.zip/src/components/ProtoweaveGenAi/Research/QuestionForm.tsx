import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

interface QuestionAnswerBlockProps {
  questions: string[];
  answers: Record<string, string>;
  onChange: (question: string, answer: string) => void;
  onSubmit?: (approved: boolean) => void;
  showActions?: boolean;
}

const QuestionAnswerBlock: React.FC<QuestionAnswerBlockProps> = ({
  questions,
  answers,
  onChange,
  onSubmit,
  showActions = false,
}) => {
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  const handleApprove = () => {
    const newErrors: Record<string, boolean> = {};
    questions.forEach((q) => {
      if (!answers[q]?.trim()) {
        newErrors[q] = true;
      }
    });

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      onSubmit?.(true);
    }
  };

  return (
    <Stack direction="row" spacing={1} width="100%">
      <Avatar
        src="/chaticon.png"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": { width: 16, height: 16, objectFit: "contain" },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          flex: 1,
          p: 2.5,
          bgcolor: "#F3FAFF",
          borderRadius: 2,
        }}
      >
        <Stack spacing={2}>
          {questions.map((question) => (
            <Box key={question}>
              <Typography
                variant="body2"
                sx={{
                  color: "black",
                  lineHeight: "17px",
                  fontSize: "0.875rem",
                }}
              >
                {question}
              </Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Your answer"
                value={answers[question] || ""}
                error={errors[question]}
                helperText={errors[question] ? "This field is required." : ""}
                onChange={(e) => {
                  if (errors[question]) {
                    setErrors((prev) => ({ ...prev, [question]: false }));
                  }
                  onChange(question, e.target.value);
                }}
                sx={{
                  mt: 1.25,
                  "& .MuiOutlinedInput-root": {
                    bgcolor: "white",
                    fontSize: "0.875rem",
                  },
                }}
              />
            </Box>
          ))}
          {showActions && (
            <Box display="flex" justifyContent="flex-end" gap={2}>
              <Button
                variant="outlined"
                onClick={() => onSubmit?.(false)}
              >
                Request Revision
              </Button>
              <Button
                variant="contained"
                onClick={handleApprove}
              >
                Approve Plan
              </Button>
            </Box>
          )}
        </Stack>
      </Paper>
    </Stack>
  );
};

export default QuestionAnswerBlock;
