import React, { useState } from "react";
import { observer } from "mobx-react-lite";

import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  Typography,
  useMediaQuery,
  useTheme
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { researchStore } from "../../../stores/cip/ProtoweaveGenAiStore/ResearchStore";

export interface CodeEntry {
    Diagnosis: string;
    Codes: string;
    "Code Type": string;
  }
  
  interface DiagnosisParametersSectionProps {
    code_table: CodeEntry[];
    procedure_code_table:CodeEntry[];
    labtest_code_table:CodeEntry[];
    researchId : string;
    version:string;
  }

export const DiagnosisCodeTable: React.FC<DiagnosisParametersSectionProps> = observer(({
    code_table,procedure_code_table,labtest_code_table,researchId,version
  }) => {

    const { researchWS } = researchStore;
    const getworkspaceId =  researchWS?.workspace_id;

    const navigate = useNavigate();

    const insertExperimentConfig = async () => {
      const workspace_id = getworkspaceId;
      const configuration_name = "Configration";
 
       const insertedConfig =  await researchStore.insertExperimentConfig(
          researchId,
          workspace_id,
          configuration_name,
          code_table
        );
       const insertedId = insertedConfig.id;
       console.log("inserteddata" ,insertedId);
        navigate(`/protoweave/experiment/${insertedId}/research/${researchId}`);
      };

    // const toTheExprimentPage = ()=>{
    //  insertExperimentConfig();
    //  navigate(`/protoweave/experiment/${researchId}/version/${version}`);
    //   }

 return(
    <Box mt={2}>
      <Box display="flex" alignItems="center" gap={2} mb={1}>
        <Typography fontWeight={600} mb={1}>
          Diagnosis Code Table
        </Typography>
        <Button
          onClick={insertExperimentConfig}
            sx={{
            bgcolor: "#4CAF50",
            color: "white",
            fontWeight: 500,
            py: 0.75,
            borderRadius: 1.5,
            textTransform: "none",
            "&:hover": {
            bgcolor: "#3d9140",
            },
            }}
        >
          Start the Simulations Process
        </Button>
      </Box>

        <Box sx={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {Object.keys(code_table[0]).map((key) => (
                  <th
                    key={key}
                    style={{
                      border: "1px solid #ccc",
                      padding: "8px",
                      backgroundColor: "#e0f2ff",
                      fontWeight: "600",
                      textAlign: "left"
                    }}
                  >
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {code_table.map((row, index) => (
                <tr key={index}>
                  {Object.values(row).map((value, i) => (
                    <td
                      key={i}
                      style={{
                        border: "1px solid #ccc",
                        padding: "8px",
                        backgroundColor: index % 2 === 0 ? "#fff" : "#f9f9f9"
                      }}
                    >
                      {value}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </Box>
      </Box>
    )

  })