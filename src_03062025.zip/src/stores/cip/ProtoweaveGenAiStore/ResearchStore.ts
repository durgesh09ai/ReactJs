import { makeAutoObservable, runInAction,toJS } from "mobx";

class ResearchStore {
  sessionId: string | null = null;
  messages: any[] = [];
  thinkingData: any[] = [];
  experimentCodeData: any[] = [];
  configurationName: string | null = null;
  workspace_id: string | null =null;
  isResearching: boolean = false;
  report: { markdown: string; 
    docx: string;
    diagnosis_code_table:any[];
    procedure_code_table:any[];
    labtest_code_table:any[];
   } | null = null;
  researchWS:{ workspace_id:string }| null = null;
  ws: WebSocket | null = null;
  currentEditableIndex: number | null = null;
  versionList: string[] = [];
  error: string | null = null;
  loading:boolean = false;
  experimentLoading:boolean = false;
  versionOptions: string[] = [];
  researchList: string[] = [];
  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8002";


setMessages(newMessages: any[]) {
  this.messages = newMessages;
}

addMessage(newMessage: any) {
  this.messages.push(newMessage);
}


  constructor() {
    makeAutoObservable(this);
  }

  connectWebSocket() {
    if (!this.sessionId || !this.isResearching) return;

    this.ws = new WebSocket(`${this.apiUrl.replace("http", "ws")}/ws/research/${this.sessionId}`);

    this.ws.onopen = () => {
      console.log("WebSocket connected");
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log("WebSocket data");

      runInAction(() => {
        if(!this.thinkingData) this.thinkingData=[];
        this.thinkingData.push(data);
        console.log("WebSocket data==>",this.thinkingData);
      });

      if (data.step === "completed") {
        this.fetchReport();
        console.log("Final thinking Data",toJS(this.thinkingData));
      }
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    this.ws.onclose = () => {
      console.log("WebSocket disconnected");
      this.ws = null;

    };
  }

  cleanup() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  async fetchReport() {
    try {
      const response = await fetch(`${this.apiUrl}/research/report/${this.sessionId}`);
      const data = await response.json();
      runInAction(() => {
        this.report = { markdown: data.report,
           docx: data.docx,
           diagnosis_code_table: data?.diagnosis_code_table,
           procedure_code_table: data?.procedure_code_table,
           labtest_code_table: data?.labtest_code_table
          };
        this.isResearching = false;
      });
    } catch (error) {
      console.error("Error fetching report:", error);
    }
  }

  async fetchResearchWS(researchId:string) {
    try {
      const response = await fetch(`${this.apiUrl}/research_dashboard/research_data/${researchId}`);
      const data = await response.json();
      runInAction(() => {
        this.researchWS = { workspace_id: data && data[0].workspace_id}
      });
    } catch (error) {
      console.error("Error fetching report:", error);
    }
  }

  // Add inside the ResearchStore class

async handleSendTopic(topic: string) {
    try {
      this.loading = true;
      const response = await fetch(`${this.apiUrl}/research/plan`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        this.loading = false;
        this.messages = [];
        this.report = null;
        this.thinkingData = [];
        this.sessionId = data.plan_id;
        this.messages = [
          { role: "user", content: topic },
          {
            role: "assistant",
            content: "I need some clarification to better understand your research needs:",
            questions: data.questions,
          },
        ];
        this.currentEditableIndex = 1;
      });
    } catch (error) {
      console.error("Error creating research plan:", error);
    }
  }
  
  async handleSubmitAnswers(answers: Record<string, string>, approved: boolean) {
    try {
      this.loading = true;
      const response = await fetch(`${this.apiUrl}/research/plan/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan_id: this.sessionId,
          answers,
          approved,
          feedback: approved ? null : "Please revise the plan based on my answers.",
        }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        if (approved) {
          this.loading = false;
          this.isResearching = true;
          this.messages.push(
            { role: "user", content: "I approve this research plan." },
            {
              role: "assistant",
              content:
                "Thank you! I'll start the research process now. You can see my progress on the right panel.",
            },
          );
          this.currentEditableIndex = null;
          this.connectWebSocket();
        } else {
          this.messages.push(
            { role: "user", content: "I need some adjustments to the plan." },
            {
              role: "assistant",
              content: "I've revised the plan. Please provide more information:",
              questions: data.questions,
            },
          );
          this.currentEditableIndex = this.messages.length - 1;
        }
      });
    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
  }


  handleDownloadReport = () => {
    if (this.report?.docx) {
      // Convert base64 docx to blob
      const binaryContent = atob(this.report.docx);
      const byteArray = new Uint8Array(binaryContent.length);
      for (let i = 0; i < binaryContent.length; i++) {
        byteArray[i] = binaryContent.charCodeAt(i);
      }
      const blob = new Blob([byteArray], {
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "research_report.docx";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      console.error("DOCX version not available!");
    }
  };

  fetchChatVersionList = async (researchId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_chats/research_chat_versions/${researchId}`);
      if (!res.ok) throw new Error("Failed to fetch versions");
      const data = await res.json();
  
      runInAction(() => {
        this.versionOptions = data;
      });

      // if (Array.isArray(data) && data.length > 0 && typeof data[0] === "object") {
      //   const parsed = Object.entries(data[0]).map(([key, value]) => ({
      //     key,
      //     value:String(value),
      //   }));
  
      //   runInAction(() => {
      //     this.versionOptions = parsed;
      //   });
      // }
    } catch (error) {
      console.error("Error fetching version options:", error);
    }
  }


  fetchResearchList = async (workSpaceId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_dashboard/research_versions/${workSpaceId}`);
      if (!res.ok) throw new Error("Failed to fetch Research List");
      const data = await res.json();
  
      runInAction(() => {
        this.researchList = data;
      });
    } catch (error) {
      console.error("Error fetching Research List:", error);
    }
  }


  insertChatHistory = async (research_id: string, version: string, messageArray: any[]) => {
    console.log('researchId:',research_id,version);
    try {
      const response = await fetch(`${this.apiUrl}/research_chats/create_chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id:version,
          version:version,
          research_id,
          chat_history: messageArray,
        }),
      });
  
      if (!response.ok) throw new Error("Failed to insert messages");
      const data = await response.json();
      console.log("Inserted messages:", data);

      runInAction(() => {
        this.versionOptions.push(version)
      });

    } catch (error) {
      console.error("Error inserting messages:", error);
    }
  }

   updateChatHistoryFinalReport = async (chat_id:string,research_id: string, final_report:{}) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_chats/update_freport/${chat_id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({research_id,final_report}),
      });
    if (!res.ok) throw new Error("Failed to update Final report");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateChatHistoryThinkingProcess = async (chat_id:string,research_id: string, chat_thinking:{}) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_chats/update_thinking/${chat_id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({research_id,chat_thinking}),
      });
    if (!res.ok) throw new Error("Failed to update chat thinking");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  fetchChatHistory = async (researchId: string, version: string) => {
    this.loading = true;
    try {
      const response = await fetch(`${this.apiUrl}/research_chats/research_id/${researchId}/chat_data/${version}`);
      const data = await response.json();
  
      runInAction(() => {
        this.messages = data.chat_history || [];
        this.report = data.final_report || null;
        this.thinkingData = data.chat_thinking || [];
        this.loading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = "Failed to fetch chat history.";
        this.loading = false;
      });
      console.error("fetchChatHistory error", error);
    }
  }


  fetchExperiment = async (experimentId: string, researchId: string) => {
    this.experimentLoading = true;
    try {
      const response = await fetch(`${this.apiUrl}/configurations/config_id/${experimentId}/research/${researchId}`);
      const data = await response.json();
      runInAction(() => {
        this.experimentCodeData = data.code_table || [] ;
        this.configurationName = data.configuration_name || '';
        this.workspace_id = data.workspace_id || '';
        this.experimentLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = "Failed to fetch experiment Data.";
        this.experimentLoading = false;
      });
      console.error("fetch experiment Data error", error);
    }
  }


  insertExperimentConfig = async (research_id: string, workspace_id: string,configuration_name:string, code_table: any[]) => {
    console.log('Configration:',research_id,workspace_id);
    try {
      const response = await fetch(`${this.apiUrl}/configurations/create_configuration`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          research_id,
          workspace_id,
          configuration_name,
          code_table: code_table,
        }),
      });
  
      if (!response.ok) throw new Error("Failed to insert Code Table Data");
      const insertedExperimentData = await response.json();
      console.log("Inserted Experiment Configration:", insertedExperimentData);
     return insertedExperimentData;
    } catch (error) {
      console.error("Error inserting messages:", error);
    }
  }
  
 
}
export const researchStore = new ResearchStore();
