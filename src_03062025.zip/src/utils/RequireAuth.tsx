import React from "react";
import { Navigate, useLocation } from "react-router-dom";

// ✅ Replace this with real auth logic
const isAuthenticated = () => {
  return !!localStorage.getItem("token"); // or your actual auth logic
};

const RequireAuth = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();

  if (!isAuthenticated()) {
    // ⛔ Redirect to login with current location
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

export default RequireAuth;
