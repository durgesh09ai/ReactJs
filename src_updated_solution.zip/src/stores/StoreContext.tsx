import React, { createContext, useContext } from "react";
import rootStore from "./RootStore";

const StoreContext = createContext(rootStore);
export const useStores = () => useContext(StoreContext);

export const StoreProvider: React.FC<React.PropsWithChildren> = ({ children }) => (
  <StoreContext.Provider value={rootStore}>
    {children}
  </StoreContext.Provider>
);
