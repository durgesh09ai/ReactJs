import json
from typing import List, Dict, Any, Optional
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field

from utils.gemini import get_gemini_model

# Define the state for the planning agent
class PlanningState(BaseModel):
    """State for the planning agent workflow"""
    topic: str = Field(..., description="The healthcare research topic")
    clarification_questions: Optional[List[str]] = Field(None, description="List of clarification questions")
    clarification_answers: Optional[Dict[str, str]] = Field(None, description="Answers to clarification questions")
    feedback: Optional[str] = Field(None, description="Feedback on the plan")
    plan: Optional[Dict[str, Any]] = Field(None, description="The research plan")
    generate_questions: bool = Field(False, description="Whether to generate questions or finalize the plan")
    complete: bool = Field(False, description="Whether the planning process is complete")

# Define the planning agent tools
def generate_clarification_questions(state: PlanningState) -> PlanningState:
    """Generate clarification questions for the given healthcare research topic"""
    system_prompt = """
    You are a healthcare research planning assistant. Your task is to generate clarification questions 
    to better understand the research needs for a given healthcare topic.
    
    Generate 3-5 specific questions that would help clarify:
    1. The specific aspects of the topic to focus on
    2. The target audience for the research
    3. The depth of analysis required
    4. Any specific methodologies or approaches preferred
    5. Any specific gaps or areas of interest within the topic
    
    Return ONLY the questions as a JSON array of strings. Do not include any other text.
    """
    
    prompt = f"Generate clarification questions for the healthcare research topic: {state.topic}"
    
    # This would be an async call in practice, but we're using a synchronous version for simplicity
    model = get_gemini_model()
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=prompt)
    ]
    response = model.invoke(messages)
    
    # Parse the response to extract the questions
    try:
        # Check if the response is already in JSON format
        content = response.content
        if isinstance(content, str) and content.strip().startswith('[') and content.strip().endswith(']'):
            questions = json.loads(str(response.content))
        else:
            # Extract JSON if it's wrapped in markdown code blocks
            if "```json" in response.content:
                # Handle response content which could be string or list
                content = str(response.content) if isinstance(response.content, list) else response.content
                json_content = content.split("```json")[1].split("```")[0].strip()
                questions = json.loads(json_content)
            elif "```" in response.content:
                # Handle response content which could be string or list
                content = str(response.content) if isinstance(response.content, list) else response.content
                json_content = content.split("```")[1].strip()
                questions = json.loads(json_content)
            else:
                # If no JSON format is detected, try to parse line by line
                lines = str(response.content).strip().split('\n')
                questions = [line.strip().lstrip('0123456789.').strip() for line in lines if line.strip()]
        
        # Update the state with the questions
        state.clarification_questions = questions
        state.complete = True
        return state
        
    except Exception as e:
        # Fallback: just split by newlines and clean up
        lines = str(response.content).strip().split('\n')
        questions = [line.strip().lstrip('0123456789.').strip() for line in lines if line.strip()]
        
        # Update the state with the questions
        state.clarification_questions = questions
        state.complete = True
        return state

def create_research_plan(state: PlanningState) -> PlanningState:
    """Create a research plan based on the topic and clarification answers"""
    system_prompt = """
    You are a healthcare research planning assistant. Your task is to create a detailed research plan 
    based on the given topic and answers to clarification questions.
    
    The research plan should include:
    1. A clear research objective
    2. Key research questions to address
    3. A structured outline with sections (introduction, methodology, key areas to explore, conclusion)
    4. Specific search queries to use for finding relevant research papers
    5. The number of search iterations to perform (1-3)
    
    Return the plan as a JSON object with the following structure:
    {
        "objective": "The main research objective",
        "research_questions": ["Question 1", "Question 2", ...],
        "outline": {
            "introduction": "Brief description",
            "methodology": "Brief description",
            "sections": [
                {"title": "Section 1", "description": "Brief description"},
                {"title": "Section 2", "description": "Brief description"},
                ...
            ],
            "conclusion": "Brief description"
        },
        "search_queries": ["Query 1", "Query 2", ...],
        "search_iterations": 2
    }
    """
    
    # Format the clarification answers for the prompt
    answers_text = "\n".join([f"Q: {q}\nA: {a}" for q, a in state.clarification_answers.items()])
    
    prompt = f"Create a research plan for the healthcare topic: {state.topic}\n\nClarification answers:\n{answers_text}"
    
    # This would be an async call in practice
    model = get_gemini_model()
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=prompt)
    ]
    response = model.invoke(messages)
    
    # Parse the response to extract the plan
    try:
        # Extract JSON if it's wrapped in markdown code blocks
        if "```json" in response.content:
            content = str(response.content) if isinstance(response.content, list) else response.content
            json_content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in response.content:
            content = str(response.content) if isinstance(response.content, list) else response.content
            json_content = content.split("```")[1].strip()
        else:
            json_content = response.content
        
        plan = json.loads(str(json_content))
    except Exception as e:
        # If parsing fails, return a simplified plan
        plan = {
            "objective": f"Research on {state.topic}",
            "research_questions": [f"What are the latest developments in {state.topic}?"],
            "outline": {
                "introduction": f"Introduction to {state.topic}",
                "methodology": "Literature review using EuropePMC",
                "sections": [
                    {"title": "Current State", "description": f"Current state of {state.topic}"},
                    {"title": "Challenges", "description": f"Challenges in {state.topic}"},
                    {"title": "Future Directions", "description": f"Future directions for {state.topic}"}
                ],
                "conclusion": "Summary of findings and recommendations"
            },
            "search_queries": [state.topic],
            "search_iterations": 2
        }
    
    # Update the state with the plan and mark as complete
    state.plan = plan
    state.complete = True
    return state

def revise_research_plan(state: PlanningState) -> PlanningState:
    """Revise the research plan based on feedback"""
    system_prompt = """
    You are a healthcare research planning assistant. Your task is to revise a research plan 
    based on the given topic, answers to clarification questions, and feedback.
    
    The revised research plan should address the feedback provided and include:
    1. A clear research objective
    2. Key research questions to address
    3. A structured outline with sections (introduction, methodology, key areas to explore, conclusion)
    4. Specific search queries to use for finding relevant research papers
    5. The number of search iterations to perform (1-3)
    
    Return the revised plan as a JSON object with the following structure:
    {
        "objective": "The main research objective",
        "research_questions": ["Question 1", "Question 2", ...],
        "outline": {
            "introduction": "Brief description",
            "methodology": "Brief description",
            "sections": [
                {"title": "Section 1", "description": "Brief description"},
                {"title": "Section 2", "description": "Brief description"},
                ...
            ],
            "conclusion": "Brief description"
        },
        "search_queries": ["Query 1", "Query 2", ...],
        "search_iterations": 2
    }
    """
    
    # Format the clarification answers for the prompt
    answers_text = "\n".join([f"Q: {q}\nA: {a}" for q, a in state.clarification_answers.items()])
    
    prompt = f"Revise the research plan for the healthcare topic: {state.topic}\n\nClarification answers:\n{answers_text}\n\nFeedback to address:\n{state.feedback}"
    
    # This would be an async call in practice
    model = get_gemini_model()
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=prompt)
    ]
    response = model.invoke(messages)
    
    # Parse the response to extract the plan
    try:
        # Extract JSON if it's wrapped in markdown code blocks
        if "```json" in response.content:
            content = str(response.content) if isinstance(response.content, list) else response.content
            json_content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in response.content:
            content = str(response.content) if isinstance(response.content, list) else response.content
            json_content = content.split("```")[1].strip()
        else:
            json_content = response.content
        
        plan = json.loads(str(json_content))
    except Exception as e:
        # If parsing fails, return a simplified plan
        plan = {
            "objective": f"Revised research on {state.topic}",
            "research_questions": [f"What are the latest developments in {state.topic}?"],
            "outline": {
                "introduction": f"Introduction to {state.topic}",
                "methodology": "Literature review using EuropePMC",
                "sections": [
                    {"title": "Current State", "description": f"Current state of {state.topic}"},
                    {"title": "Challenges", "description": f"Challenges in {state.topic}"},
                    {"title": "Future Directions", "description": f"Future directions for {state.topic}"}
                ],
                "conclusion": "Summary of findings and recommendations"
            },
            "search_queries": [state.topic],
            "search_iterations": 2
        }
    
    # Update the state with the plan and mark as complete
    state.plan = plan
    state.complete = True
    return state

# Create the planning agent
def create_planning_agent():
    """Create and return a planning agent workflow"""
    # Create the state graph
    workflow = StateGraph(PlanningState)
    
    # Add nodes to the graph - note we're not using @tool decorators anymore
    workflow.add_node("generate_clarification", generate_clarification_questions)
    workflow.add_node("create_plan", create_research_plan)
    workflow.add_node("revise_plan", revise_research_plan)
    
    # Add conditional edges
    workflow.add_conditional_edges(
        "generate_clarification",
        lambda x: x.generate_questions,
        {True: END, False: "create_plan"}
    )
    
    # Add edges
    workflow.add_edge("create_plan", END)
    workflow.add_edge("revise_plan", END)
    
    # Set the entry point
    workflow.set_entry_point("generate_clarification")
    
    # Compile the workflow
    return workflow.compile()

# Function to run the planning agent
async def run_planning_agent(
    planning_agent,
    topic: str,
    clarification_answers: Optional[Dict[str, str]] = None,
    feedback: Optional[str] = None,
    generate_questions: bool = True
) -> Any:
    """Run the planning agent workflow"""
    # Initialize the state
    state = PlanningState(
        topic=topic,
        clarification_questions=None,
        clarification_answers=clarification_answers or {},
        plan=None,
        feedback=feedback,
        generate_questions=generate_questions,
        complete=False
    )
    
    # Run the workflow with the full state
    result = await planning_agent.ainvoke(state)
    
    # Return the appropriate result based on the state
    if generate_questions:
        return result["clarification_questions"]
    else:
        return result["plan"]