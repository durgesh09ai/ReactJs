import json
import asyncio
from typing import List, Dict, Any, Optional, Callable, Awaitable
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field

from utils.gemini import get_gemini_model
from utils.europepmc import EuropePMCClient
from utils.pubmed import PubMedClient

# Define the state for the research agent
class ResearchState(BaseModel):
    """State for the research agent workflow"""
    topic: str = Field(..., description="The healthcare research topic")
    plan: Dict[str, Any] = Field(..., description="The research plan")
    clarification_answers: Dict[str, str] = Field(..., description="Answers to clarification questions")
    search_queries: List[str] = Field(default_factory=list, description="Search queries to use")
    current_query_index: int = Field(0, description="Index of the current search query")
    search_results: List[Dict[str, Any]] = Field(default_factory=list, description="Results from search queries")
    papers_to_analyze: List[Dict[str, Any]] = Field(default_factory=list, description="Papers selected for detailed analysis")
    analyzed_papers: List[Dict[str, Any]] = Field(default_factory=list, description="Papers that have been analyzed")
    search_iterations: int = Field(0, description="Number of search iterations completed")
    max_search_iterations: int = Field(3, description="Maximum number of search iterations to perform")
    accumulated_research: Dict[str, Any] = Field(default_factory=dict, description="Accumulated research findings")
    report: Optional[str] = Field(None, description="The final research report")
    current_step: str = Field("initialize", description="Current step in the research process")
    complete: bool = Field(False, description="Whether the research process is complete")
    progress_callback: Optional[Callable[[str, Any, Optional[float]], Awaitable[None]]] = Field(None, exclude=True)

# Define the function to run the research agent
async def run_research_agent(
    research_agent,
    topic: str,
    plan: Dict[str, Any],
    clarification_answers: Dict[str, str],
    progress_callback: Optional[Callable[[str, Any, Optional[float]], Awaitable[None]]] = None
) -> str:
    """Run the research agent workflow"""
    # Initialize the state with the progress callback
    state = ResearchState(
        topic=topic,
        plan=plan,
        current_query_index=0,
        search_iterations=0,
        max_search_iterations=3,
        report=None,
        current_step="initialize",
        clarification_answers=clarification_answers,
        complete=False,
        progress_callback=progress_callback
    )
    
    # Create a config with the recursion limit
    config = {"recursion_limit": 100}
    
    # Run the workflow without tool_kwargs
    result = await research_agent.ainvoke(state, config=config)
    
    # Return the report
    return result["report"]

# Progress callback type
ProgressCallback = Callable[[str, Any, Optional[float]], Awaitable[None]]

# Define the research agent tools
async def initialize_research(state: ResearchState) -> ResearchState:
    """Initialize the research process by setting up search queries from the plan"""
    # Extract search queries from the plan
    search_queries = state.plan.get("search_queries", [])
    
    # If no search queries are provided, generate some based on the topic and research questions
    if not search_queries:
        topic = state.topic
        research_questions = state.plan.get("research_questions", [])
        
        # Create a basic query from the topic
        search_queries = [topic]
        
        # Add queries based on research questions
        for question in research_questions:
            search_queries.append(f"{topic} AND ({question})")
    
    # Update the state
    state.search_queries = search_queries
    state.max_search_iterations = state.plan.get("search_iterations", 3)
    state.current_step = "search"
    
    return state

async def search_papers(state: ResearchState, europe_pmc_client: EuropePMCClient, pubmed_client: PubMedClient = None) -> ResearchState:
    """Search for relevant papers on the research topic"""
    # Check if we have any search queries
    if not state.search_queries:
        # Generate initial queries if none exist
        state.search_queries = await generate_refined_queries(state.topic, {})
    
    # Check if we've processed all queries
    if state.current_query_index >= len(state.search_queries):
        # Move to the next step if we've processed all queries
        state.current_step = "select_papers"
        state.search_iterations += 1
        return state
    
    # Get the current search query
    current_query = state.search_queries[state.current_query_index]
    
    # Update progress
    if state.progress_callback:
        await state.progress_callback(
            "searching", 
            {
                "query": current_query, 
                "query_index": state.current_query_index + 1, 
                "total_queries": len(state.search_queries)
            },
            (state.current_query_index / len(state.search_queries)) * 25  # First 25% of progress is for searching
        )
    
    try:
        # Search for papers with error handling and retries
        max_retries = 3
        retry_count = 0

        # Search in EuropePMC
        while retry_count < max_retries:
            try:
                # Search for papers
                search_results = await europe_pmc_client.search(current_query, page_size=20)
                
                # Extract the results
                results = search_results.get("resultList", {}).get("result", [])

                # Add source information to the results
                for result in results:
                    result["source"] = "EuropePMC"
                
                # Add the results to the state
                state.search_results.extend(results)
                break  # Success, exit retry loop
            
            except Exception as e:
                retry_count += 1
                if retry_count >= max_retries:
                    # Log the error and continue with the next query
                    print(f"Error searching EuropePMC for papers after {max_retries} retries: {e}")
                    if state.progress_callback:
                        await state.progress_callback(
                            "error",
                            {"error": f"Failed to search EuropePMC for papers: {str(e)}"},
                            None
                        )
                else:
                    # Wait before retrying
                    await asyncio.sleep(1)
        
        # Search in PubMed if available
        if pubmed_client:
            retry_count = 0
            while retry_count < max_retries:
                try:
                    # Search for papers in PubMed
                    pubmed_results = await pubmed_client.search(current_query, page_size=20)
                    
                    # Extract the results
                    results = pubmed_results.get("resultList", {}).get("result", [])

                    # Add source information to the results
                    for result in results:
                        result["source"] = "PubMed"
                    
                    # Add the results to the state
                    state.search_results.extend(results)
                    break  # Success, exit retry loop
                
                except Exception as e:
                    retry_count += 1
                    if retry_count >= max_retries:
                        # Log the error and continue with the next query
                        print(f"Error searching PubMed for papers after {max_retries} retries: {e}")
                        if state.progress_callback:
                            await state.progress_callback(
                                "error",
                                {"error": f"Failed to search PubMed for papers: {str(e)}"},
                                None
                            )
                    else:
                        # Wait before retrying
                        await asyncio.sleep(1)
        
        # Move to the next query
        state.current_query_index += 1
        
        # If we've processed all queries, move to the next step
        if state.current_query_index >= len(state.search_queries):
            state.current_step = "select_papers"
            state.search_iterations += 1
    
    except Exception as e:
        # Log the error and continue with the next query
        print(f"Error in search process: {e}")
        if state.progress_callback:
            await state.progress_callback(
                "error",
                {"error": f"Error in search process: {str(e)}"},
                None
            )
        state.current_query_index += 1
    
    return state

async def select_papers_for_analysis(state: ResearchState) -> ResearchState:
    """Select the most relevant papers for detailed analysis"""
    # If we have no search results, move to the next step
    if not state.search_results:
        state.current_step = "generate_report"
        return state
    
    # Deduplicate papers by ID
    unique_papers = {}
    for paper in state.search_results:
        paper_id = paper.get("id")
        if paper_id and paper_id not in unique_papers:
            unique_papers[paper_id] = paper
    
    # Convert back to a list
    unique_paper_list = list(unique_papers.values())
    
    # Sort papers by relevance or recency
    # This is a simple implementation - in practice, you might want to use more sophisticated ranking
    sorted_papers = sorted(
        unique_paper_list,
        key=lambda p: p.get("pubYear", "0"),
        reverse=True  # Most recent first
    )
    
    # Select the top N papers for analysis
    from config import settings
    max_papers = settings.MAX_FULL_TEXT_PAPERS
    selected_papers = sorted_papers[:max_papers]
    
    # Add the selected papers to the state
    state.papers_to_analyze = selected_papers
    state.current_step = "analyze"

    if state.progress_callback:
        await state.progress_callback(
            "selecting_papers", 
            {
                "total_results": len(state.search_results),
                "selected_papers": selected_papers
            },
            30  # 30% progress after paper selection
        )
    
    return state

# Fix the analyze_papers function signature to match others
async def analyze_papers(state: ResearchState, europe_pmc_client: EuropePMCClient, pubmed_client: PubMedClient = None) -> ResearchState:
    """Analyze the selected papers in detail"""
    # If we have no papers to analyze, move to the next step
    if not state.papers_to_analyze:
        state.current_step = "synthesize"
        return state
    
    # Get the papers to analyze
    papers = state.papers_to_analyze
    
    # Process each paper
    for i, paper in enumerate(papers):
        # Update progress
        if state.progress_callback:
            progress_percent = 30 + ((i / len(papers)) * 30)  # 30-60% progress during analysis
            await state.progress_callback(
                "analyzing_paper", 
                {
                    "paper": paper.get("title", "Unknown"), 
                    "index": i + 1, 
                    "total": len(papers),
                    "source": paper.get("source", "Unknown")
                },
                progress_percent
            )
        
        try:
            # Get the paper ID and type
            paper_id = paper.get("id")
            paper_source = paper.get("source", "")
            
            # Determine the ID type and which client to use
            id_type = "pmid"
            client = europe_pmc_client

            if paper_source == "PMC":
                id_type = "pmc"
                client = europe_pmc_client
            elif paper_source == "PubMed":
                id_type = "pmid"
                client = pubmed_client if pubmed_client else europe_pmc_client
            elif "DOI" in paper:
                id_type = "doi"
                paper_id = paper.get("DOI")
                client = europe_pmc_client
            
            # Try to get the full text
            full_text = None
            if paper_source == "PMC":
                full_text = await europe_pmc_client.get_full_text(paper_id, "PMC")
            elif paper_source == "PubMed" and pubmed_client:
                full_text = await pubmed_client.get_full_text(paper_id, "pmid")
            
            # If we couldn't get the full text, use the abstract
            if not full_text and "abstractText" in paper:
                full_text = f"TITLE: {paper.get('title', '')}\n\nABSTRACT: {paper.get('abstractText', '')}"
            
            # If we still don't have any text, skip this paper
            if not full_text:
                continue
            
            # Analyze the paper
            analysis = await analyze_paper_content(paper, full_text)
            
            # Add the analysis to the state
            state.analyzed_papers.append({
                "paper": paper,
                "full_text": full_text[:1000] + "..." if full_text and len(full_text) > 1000 else full_text,  # Truncate for state size
                "analysis": analysis
            })
            
        except Exception as e:
            # Log the error and continue with the next paper
            print(f"Error analyzing paper {paper.get('id', 'unknown')}: {e}")
    
    # Clear the papers to analyze
    state.papers_to_analyze = []
    
    # Move to the next step
    state.current_step = "synthesize"
    
    return state

async def analyze_paper_content(paper: Dict[str, Any], full_text: str) -> Dict[str, Any]:
    """Analyze the content of a paper with enhanced error handling and quality checks"""
    system_prompt = """
    You are a healthcare research assistant. Your task is to analyze a research paper and extract key information.
    
    Please analyze the paper and provide the following information in JSON format:
    1. Key findings: The main results or discoveries of the paper (be specific and quantitative where possible)
    2. Methodology: The research methods used, including study design, sample size, and analysis techniques
    3. Strengths: The strengths or positive aspects of the research (focus on methodological rigor and significance)
    4. Limitations: Any limitations or weaknesses of the research (be specific about potential biases or gaps)
    5. Relevance: How relevant this paper is to the research topic (high, medium, low) with justification
    6. Future directions: Specific suggested future research directions based on gaps or limitations
    7. Evidence quality: Assessment of the quality of evidence (high, moderate, low) based on study design and methods
    8. Clinical implications: Potential implications for clinical practice or healthcare policy
    9. Objective: The objective of the research 
    10. Demographics: The demographics of the study participants (eg. gender, age, race/ethnicity, health status, country of origin)
    11. Sample type: The type of study (eg. randomized, non-randomized, placebo-controlled)    
    
    Return your analysis as a JSON object with these fields.
    """
    
    # Prepare the paper metadata for context
    metadata = f"Title: {paper.get('title', 'Unknown')}\n"
    metadata += f"Authors: {paper.get('authorString', 'Unknown')}\n"
    metadata += f"Journal: {paper.get('journalTitle', 'Unknown')}\n"
    metadata += f"Year: {paper.get('pubYear', 'Unknown')}\n"
    metadata += f"DOI: {paper.get('DOI', 'Unknown')}\n\n"
    
    # Limit the full text to a reasonable size for the model
    max_text_length = 10000  # Adjust based on model capabilities
    truncated_text = full_text[:max_text_length] + "..." if len(full_text) > max_text_length else full_text
    
    prompt = f"Analyze the following research paper:\n\n{metadata}\n\nPaper Content:\n{truncated_text}"
    
    try:
        # Generate the analysis
        model = get_gemini_model()
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=prompt)
        ]
        response = model.invoke(messages)
        
        # Parse the response to extract the analysis
        try:
            # Extract JSON if it's wrapped in markdown code blocks
            if "```json" in response.content:
                # Extract content between ```json and ``` markers
                content = response.content
                if isinstance(content, str):
                    json_content = content.split("```json")[1].split("```")[0].strip()
                else:
                    # Handle case where content is a list
                    json_content = str(content)
            elif "```" in response.content:
                # Handle case where content could be string or list
                content = response.content
                if isinstance(content, str):
                    json_content = content.split("```")[1].strip()
                else:
                    # Handle case where content is a list
                    json_content = str(content)
            else:
                json_content = response.content
            
            # Handle both string and list responses from the model
            if isinstance(json_content, str):
                analysis = json.loads(json_content)
            else:
                # If json_content is already a list/dict, use it directly
                analysis = json_content
        except Exception as e:
            # If parsing fails, return a simplified analysis
            analysis = {
                "key_findings": "Could not extract key findings",
                "methodology": "Could not extract methodology",
                "strengths": "Could not extract strengths",
                "limitations": "Could not extract limitations",
                "relevance": "medium",
                "future_directions": "Could not extract future directions"
            }
        
        # Ensure analysis is a dictionary before returning
        if isinstance(analysis, dict):
            return analysis
        elif isinstance(analysis, list):
            # Convert list to dictionary if needed
            return {"analysis_items": analysis}
        else:
            # Convert any other type to a dictionary
            return {"analysis": analysis}
    
    except Exception as e:
        # Return a placeholder analysis in case of error
        return {
            "key_findings": f"Error analyzing paper: {str(e)}",
            "methodology": "Unknown",
            "strengths": "Unknown",
            "limitations": "Unknown",
            "relevance": "unknown",
            "future_directions": "Unknown"
        }

async def synthesize_research(state: ResearchState) -> ResearchState:
    """Synthesize the analyzed papers into accumulated research findings"""
    # Update progress
    if state.progress_callback:
        await state.progress_callback(
            "synthesizing_research", 
            {"papers_analyzed": len(state.analyzed_papers)},
            70  # 70% progress after synthesis
        )
    
    # If we have no analyzed papers, check if we should do another search iteration
    if not state.analyzed_papers:
        if state.search_iterations < state.max_search_iterations:
            # Reset for another search iteration
            state.current_query_index = 0
            state.current_step = "search"
            return state
        else:
            # Move to report generation
            state.current_step = "generate_report"
            return state
    
    # Extract the analyses from the analyzed papers
    paper_analyses = [{
        "title": paper["paper"].get("title", "Unknown"),
        "authors": paper["paper"].get("authorString", "Unknown"),
        "year": paper["paper"].get("pubYear", "Unknown"),
        "journal": paper["paper"].get("journalTitle", "Unknown"),
        "analysis": paper["analysis"]
    } for paper in state.analyzed_papers]
    
    # Synthesize the research
    synthesis = await synthesize_paper_analyses(state.topic, state.plan, paper_analyses)
    
    # Update the accumulated research
    if not state.accumulated_research:
        state.accumulated_research = {}
    
    # Merge the synthesis with the accumulated research
    for key, value in synthesis.items():
        if key in state.accumulated_research:
            # If the key already exists, append the new value
            if isinstance(state.accumulated_research[key], list) and isinstance(value, list):
                state.accumulated_research[key].extend(value)
            elif isinstance(state.accumulated_research[key], dict) and isinstance(value, dict):
                state.accumulated_research[key].update(value)
            else:
                # For other types, just replace with the new value
                state.accumulated_research[key] = value
        else:
            # If the key doesn't exist, add it
            state.accumulated_research[key] = value
    
    # Check if we should do another search iteration
    if state.search_iterations < state.max_search_iterations:
        # Generate new search queries based on the accumulated research
        new_queries = await generate_refined_queries(state.topic, state.accumulated_research)
        
        # Add the new queries to the existing ones
        state.search_queries.extend(new_queries)
        
        # Reset for another search iteration
        state.current_query_index = len(state.search_queries) - len(new_queries)  # Start from the new queries
        state.current_step = "search"
    else:
        # Move to report generation
        state.current_step = "generate_report"
    
    return state

async def synthesize_paper_analyses(topic: str, plan: Dict[str, Any], paper_analyses: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Synthesize the analyses of multiple papers with enhanced quality assessment"""
    system_prompt = """
    You are a healthcare research assistant. Your task is to synthesize analyses from multiple research papers 
    into a coherent set of findings related to a specific research topic.
    
    Please synthesize the paper analyses and provide the following information in JSON format:
    1. Key themes: The main themes or patterns across the papers, with evidence strength assessment
    2. Consensus findings: Findings that multiple papers agree on, with level of agreement (strong, moderate, weak)
    3. Contradictions: Areas where papers disagree or present conflicting results, with possible explanations
    4. Research gaps: Specific gaps in the current research, prioritized by importance
    5. Methodological insights: Critical assessment of research methodologies used in the field
    6. Future directions: Prioritized list of promising directions for future research
    7. Evidence synthesis: Overall assessment of evidence quality and reliability
    8. Clinical recommendations: Evidence-based recommendations for practice
    9. Research trends: Emerging trends and shifts in research focus over time
    10. Knowledge evolution: How understanding of the topic has evolved
    
    Return your synthesis as a JSON object with these fields.
    """
    
    # Format the paper analyses for the prompt
    papers_text = ""
    for i, paper in enumerate(paper_analyses):
        papers_text += f"Paper {i+1}: {paper['title']}\n"
        papers_text += f"Authors: {paper['authors']}\n"
        papers_text += f"Year: {paper['year']}\n"
        papers_text += f"Journal: {paper['journal']}\n"
        papers_text += f"Key findings: {paper['analysis'].get('key_findings', 'Unknown')}\n"
        papers_text += f"Methodology: {paper['analysis'].get('methodology', 'Unknown')}\n"
        papers_text += f"Strengths: {paper['analysis'].get('strengths', 'Unknown')}\n"
        papers_text += f"Limitations: {paper['analysis'].get('limitations', 'Unknown')}\n"
        papers_text += f"Relevance: {paper['analysis'].get('relevance', 'Unknown')}\n"
        papers_text += f"Future directions: {paper['analysis'].get('future_directions', 'Unknown')}\n\n"
    
    # Extract research questions from the plan
    research_questions = plan.get("research_questions", [])
    questions_text = "\n".join([f"- {q}" for q in research_questions])
    
    prompt = f"Synthesize the following paper analyses for the research topic: {topic}\n\n"
    prompt += f"Research questions:\n{questions_text}\n\n"
    prompt += f"Paper analyses:\n{papers_text}"
    
    try:
        # Generate the synthesis
        model = get_gemini_model()
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=prompt)
        ]
        response = model.invoke(messages)
        
        # Parse the response to extract the synthesis
        try:
            # Extract JSON if it's wrapped in markdown code blocks
            if "```json" in response.content:
                # Handle both string and list responses
                content = response.content
                if isinstance(content, str):
                    json_content = content.split("```json")[1].split("```")[0].strip()
                else:
                    # If content is a list, convert to string
                    json_content = str(content)
            elif "```" in response.content:
                # Handle both string and list responses
                content = response.content
                if isinstance(content, str):
                    json_content = content.split("```")[1].strip()
                else:
                    # If content is a list, convert to string
                    json_content = str(content)
            else:
                json_content = response.content
            
            # Handle both string and structured content
            if isinstance(json_content, str):
                synthesis = json.loads(json_content)
            elif isinstance(json_content, (list, dict)):
                synthesis = json_content
            else:
                synthesis = {"error": "Invalid response format"}
        except Exception as e:
            # If parsing fails, return a simplified synthesis
            synthesis = {
                "key_themes": ["Could not extract key themes"],
                "consensus_findings": ["Could not extract consensus findings"],
                "contradictions": ["Could not extract contradictions"],
                "research_gaps": ["Could not extract research gaps"],
                "methodological_insights": ["Could not extract methodological insights"],
                "future_directions": ["Could not extract future directions"]
            }
        
        # Ensure synthesis is a dictionary before returning
        if isinstance(synthesis, dict):
            return synthesis
        elif isinstance(synthesis, list):
            # Convert list to dictionary
            return {"synthesis_items": synthesis}
        else:
            # Convert any other type to dictionary
            return {"synthesis": synthesis}
    
    except Exception as e:
        # Return a placeholder synthesis in case of error
        return {
            "key_themes": [f"Error synthesizing research: {str(e)}"],
            "consensus_findings": ["Unknown"],
            "contradictions": ["Unknown"],
            "research_gaps": ["Unknown"],
            "methodological_insights": ["Unknown"],
            "future_directions": ["Unknown"]
        }

async def generate_refined_queries(topic: str, accumulated_research: Dict[str, Any]) -> List[str]:
    """Generate refined search queries based on accumulated research"""
    system_prompt = """
    You are a healthcare research assistant. Your task is to generate refined search queries 
    based on accumulated research findings to explore research gaps and promising directions.
    
    Please generate 2-3 specific search queries that will help address gaps in the current research 
    or explore promising directions identified in the accumulated research.
    
    Return ONLY the search queries as a JSON array of strings. Do not include any other text.
    """
    
    # Format the accumulated research for the prompt
    research_text = json.dumps(accumulated_research, indent=2)
    
    prompt = f"Generate refined search queries for the research topic: {topic}\n\n"
    prompt += f"Based on the following accumulated research:\n{research_text}"
    
    try:
        # Generate the queries
        model = get_gemini_model()
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=prompt)
        ]
        response = model.invoke(messages)
        
        # Parse the response to extract the queries
        try:
            # Check if the response is already in JSON format
            if isinstance(response.content, str) and response.content.strip().startswith('[') and response.content.strip().endswith(']'):
                queries = json.loads(response.content)
            else:
                # Extract JSON if it's wrapped in markdown code blocks
                if "```json" in response.content:
                    # Handle both string and list responses
                    content = response.content
                    if isinstance(content, str):
                        json_content = content.split("```json")[1].split("```")[0].strip()
                    else:
                        # If content is a list, convert to string
                        json_content = str(content)
                    queries = json.loads(json_content)
                elif "```" in response.content:
                    # Handle both string and list responses
                    content = response.content
                    if isinstance(content, str):
                        json_content = content.split("```")[1].strip()
                    else:
                        # If content is a list, convert to string
                        json_content = str(content)
                    queries = json.loads(json_content)
                else:
                    # If no JSON format is detected, try to parse line by line
                    # Handle both string and list responses
                    content = response.content
                    if isinstance(content, str):
                        lines = content.strip().split('\n')
                    else:
                        # If content is a list, convert to list of strings
                        lines = [str(item) for item in content]
                    queries = [line.strip().lstrip('0123456789.').strip() for line in lines if line.strip()]
        except Exception as e:
            # Fallback: just split by newlines and clean up
            # Handle both string and list responses
            content = response.content
            if isinstance(content, str):
                lines = content.strip().split('\n')
            else:
                # If content is a list, convert to list of strings
                lines = [str(item) for item in content]
            queries = [line.strip().lstrip('0123456789.').strip() for line in lines if line.strip()]
        
        # Ensure we have at least one query
        if not queries:
            queries = [f"{topic} research gaps"]
        
        return queries
    
    except Exception as e:
        # Return a default query in case of error
        return [f"{topic} research gaps"]

async def generate_research_report(state: ResearchState) -> ResearchState:
    """Generate the final research report"""
    # Update progress
    if state.progress_callback:
        await state.progress_callback(
            "generating_report", 
            {},
            90  # 90% progress during report generation
        )
    
    # Generate the report
    report = await generate_report(state.topic, state.plan, state.accumulated_research, state.analyzed_papers)
    
    # Update the state
    state.report = report
    state.current_step = "complete"
    state.complete = True
    
    # Final progress update
    if state.progress_callback:
        await state.progress_callback(
            "completed", 
            {"report_available": True},
            100  # 100% progress when complete
        )
    
    return state

async def generate_report(topic: str, plan: Dict[str, Any], accumulated_research: Dict[str, Any], analyzed_papers: List[Dict[str, Any]]) -> str:
    """Generate the final research report"""
    system_prompt = """
    You are a healthcare research assistant. Your task is to generate a comprehensive research report 
    based on accumulated research findings and analyzed papers.
    
    The report should follow the outline provided in the research plan and include the following sections:
    1. Introduction: Overview of the topic and research objectives
    2. Methodology: Description of the research approach and methods
    3. Findings: Detailed presentation of the research findings, organized by themes or research questions
    4. Discussion: Analysis and interpretation of the findings, including consensus, contradictions, and gaps
    5. Conclusion: Summary of key insights and implications
    6. Recommendations: Suggestions for future research and practice
    
    The report should be well-structured, evidence-based, and written in a formal academic style.
    Use markdown formatting for headings, lists, and emphasis.
    """
    
    # Extract outline from the plan
    outline = plan.get("outline", {})
    introduction = outline.get("introduction", f"Introduction to {topic}")
    methodology = outline.get("methodology", "Literature review using EuropePMC")
    sections = outline.get("sections", [])
    conclusion = outline.get("conclusion", "Summary of findings and recommendations")
    
    # Format the accumulated research for the prompt
    research_text = json.dumps(accumulated_research, indent=2)
    
    # Format the analyzed papers for the prompt
    papers_text = ""
    for i, paper in enumerate(analyzed_papers[:5]):  # Limit to 5 papers to avoid token limits
        papers_text += f"Paper {i+1}: {paper['paper'].get('title', 'Unknown')}\n"
        papers_text += f"Authors: {paper['paper'].get('authorString', 'Unknown')}\n"
        papers_text += f"Year: {paper['paper'].get('pubYear', 'Unknown')}\n"
        papers_text += f"Journal: {paper['paper'].get('journalTitle', 'Unknown')}\n"
        papers_text += f"Key findings: {paper['analysis'].get('key_findings', 'Unknown')}\n\n"
    
    # Extract research questions from the plan
    research_questions = plan.get("research_questions", [])
    questions_text = "\n".join([f"- {q}" for q in research_questions])
    
    # Format the sections for the prompt
    sections_text = "\n".join([f"- {section.get('title')}: {section.get('description')}" for section in sections])
    
    prompt = f"Generate a comprehensive research report on: {topic}\n\n"
    prompt += f"Research questions:\n{questions_text}\n\n"
    prompt += f"Outline:\n"
    prompt += f"- Introduction: {introduction}\n"
    prompt += f"- Methodology: {methodology}\n"
    prompt += f"- Sections:\n{sections_text}\n"
    prompt += f"- Conclusion: {conclusion}\n\n"
    prompt += f"Based on the following accumulated research:\n{research_text}\n\n"
    prompt += f"And the following analyzed papers:\n{papers_text}"
    
    try:
        # Generate the report
        model = get_gemini_model()
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=prompt)
        ]
        response = model.invoke(messages)
        
        # Return the report
        # Ensure we return a string response
        content = response.content
        if isinstance(content, str):
            return content
        elif isinstance(content, list):
            # Convert list to string by joining elements
            return '\n'.join(str(item) for item in content)
        else:
            # Convert any other type to string
            return str(content)
    
    except Exception as e:
        # Return an error message in case of failure
        return f"Error generating research report: {str(e)}\n\nPlease try again or contact support."

# Define the research agent workflow
def create_research_agent(europe_pmc_client: EuropePMCClient, pubmed_client: PubMedClient = None):
    """Create and return a research agent workflow"""
    # Create the state graph
    workflow = StateGraph(ResearchState)
    
    # Define async wrappers for functions that need the client
    async def search_with_client(state):
        return await search_papers(state, europe_pmc_client, pubmed_client)
    
    async def analyze_with_client(state):
        return await analyze_papers(state, europe_pmc_client, pubmed_client)
    
    # Add nodes to the graph
    workflow.add_node("initialize", initialize_research)
    workflow.add_node("search", search_with_client)
    workflow.add_node("select_papers", select_papers_for_analysis)
    workflow.add_node("analyze", analyze_with_client)
    workflow.add_node("synthesize", synthesize_research)
    workflow.add_node("generate_report", generate_research_report)
    
    # Define a single router function based on current_step
    def router(state):
        if state.complete:
            return END
        return state.current_step
    
    # Add edges with the simplified router
    workflow.add_conditional_edges(
        "initialize",
        router,
        {
            "search": "search",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "search",
        router,
        {
            "select_papers": "select_papers",
            "search": "search",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "select_papers",
        router,
        {
            "analyze": "analyze",
            "generate_report": "generate_report",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "analyze",
        router,
        {
            "synthesize": "synthesize",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "synthesize",
        router,
        {
            "search": "search",
            "generate_report": "generate_report",
            END: END
        }
    )
    
    workflow.add_conditional_edges(
        "generate_report",
        router,
        {
            END: END
        }
    )
    
    # Set the entry point
    workflow.set_entry_point("initialize")
    
    # Compile the workflow
    return workflow.compile()

# Function to run the research agent
async def run_research_agent(
    research_agent,
    topic: str,
    plan: Dict[str, Any],
    clarification_answers: Dict[str, str],
    progress_callback: Optional[ProgressCallback] = None
) -> str:
    """Run the research agent workflow"""
    # Initialize the state with the progress callback
    state = ResearchState(
        topic=topic,
        plan=plan,
        current_query_index=0,
        search_iterations=0,
        max_search_iterations=3,
        report=None,
        current_step="initialize",
        clarification_answers=clarification_answers,
        complete=False,
        progress_callback=progress_callback
    )
    
    # Create a config with the recursion limit
    config = {"recursion_limit": 100}
    
    # Run the workflow without tool_kwargs
    result = await research_agent.ainvoke(state, config=config)
    
    # Return the report
    return result["report"]