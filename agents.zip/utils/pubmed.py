import aiohttp
import asyncio
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup
from config import settings

class PubMedClient:
    """Client for interacting with the PubMed API via E-utilities"""
    
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or settings.PUBMED_API_URL
        self.api_key = getattr(settings, 'PUBMED_API_KEY', None)
    
    async def search(self, query: str, page: int = 1, page_size: int = 10) -> Dict[str, Any]:
        """Search for papers in PubMed
        
        Args:
            query: The search query
            page: The page number (1-based)
            page_size: Number of results per page
            
        Returns:
            Dict containing search results
        """
        # Calculate retstart for pagination
        retstart = (page - 1) * page_size
        
        # First, search for IDs
        params = {
            'db': 'pubmed',
            'term': query,
            'retstart': retstart,
            'retmax': page_size,
            'retmode': 'json',
            'sort': 'relevance'
        }
        
        if self.api_key:
            params['api_key'] = self.api_key
        
        async with aiohttp.ClientSession() as session:
            # Step 1: Get the IDs
            async with session.get(f"{self.base_url}/esearch.fcgi", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"PubMed API error: {response.status} - {error_text}")
                
                search_data = await response.json()
                id_list = search_data.get('esearchresult', {}).get('idlist', [])
                
                if not id_list:
                    return {"resultList": {"result": []}}
                
                # Step 2: Fetch details for these IDs
                fetch_params = {
                    'db': 'pubmed',
                    'id': ','.join(id_list),
                    'retmode': 'json'
                }
                
                if self.api_key:
                    fetch_params['api_key'] = self.api_key
                
                async with session.get(f"{self.base_url}/esummary.fcgi", params=fetch_params) as fetch_response:
                    if fetch_response.status != 200:
                        error_text = await fetch_response.text()
                        raise Exception(f"PubMed API error: {fetch_response.status} - {error_text}")
                    
                    details_data = await fetch_response.json()
                    
                    # Transform to match EuropePMC format
                    results = []
                    for paper_id in id_list:
                        if paper_id in details_data.get('result', {}):
                            paper = details_data['result'][paper_id]

                            # Fix the author string formatting
                            author_string = ""
                            if 'authors' in paper and isinstance(paper['authors'], list):
                                author_names = []
                                for author in paper['authors']:
                                    if isinstance(author, dict) and 'name' in author:
                                        author_names.append(author['name'])
                                    elif isinstance(author, str):
                                        author_names.append(author)
                                author_string = ', '.join(author_names)
                            
                            # Map PubMed fields to EuropePMC format
                            transformed_paper = {
                                "id": paper_id,
                                "source": "PubMed",
                                "title": paper.get('title', ''),
                                "authorString": author_string,
                                "journalTitle": paper.get('fulljournalname', ''),
                                "pubYear": paper.get('pubdate', '').split()[0] if paper.get('pubdate') else '',
                                "abstractText": '',  # Will need separate request for abstract
                                "pmid": paper_id,
                                "DOI": paper.get('elocationid', '').replace('doi: ', '') if paper.get('elocationid', '').startswith('doi: ') else ''
                            }
                            results.append(transformed_paper)
                    
                    return {"resultList": {"result": results}}
    
    async def get_paper_details(self, paper_id: str, id_type: str = 'pmid') -> Dict[str, Any]:
        """Get detailed information about a specific paper
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier (pmid only for PubMed)
            
        Returns:
            Dict containing paper details
        """
        if id_type.lower() != 'pmid':
            raise ValueError("PubMed only supports PMID as identifier type")
        
        params = {
            'db': 'pubmed',
            'id': paper_id,
            'retmode': 'json'
        }
        
        if self.api_key:
            params['api_key'] = self.api_key
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/esummary.fcgi", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"PubMed API error: {response.status} - {error_text}")
                
                data = await response.json()
                
                if paper_id not in data.get('result', {}):
                    raise Exception(f"Paper with ID {paper_id} not found")
                
                paper = data['result'][paper_id]
                
                # Get abstract in a separate request
                abstract = await self._get_abstract(paper_id)

                author_string = ""
                if 'authors' in paper and isinstance(paper['authors'], list):
                    author_names = []
                    for author in paper['authors']:
                        if isinstance(author, dict) and 'name' in author:
                            author_names.append(author['name'])
                        elif isinstance(author, str):
                            author_names.append(author)
                    author_string = ', '.join(author_names)
                
                # Transform to match EuropePMC format
                result = {
                    "id": paper_id,
                    "source": "PubMed",
                    "title": paper.get('title', ''),
                    "authorString": author_string,
                    "journalTitle": paper.get('fulljournalname', ''),
                    "pubYear": paper.get('pubdate', '').split()[0] if paper.get('pubdate') else '',
                    "abstractText": abstract,
                    "pmid": paper_id,
                    "DOI": paper.get('elocationid', '').replace('doi: ', '') if paper.get('elocationid', '').startswith('doi: ') else ''
                }
                
                return result
    
    async def _get_abstract(self, paper_id: str) -> str:
        """Get the abstract for a paper
        
        Args:
            paper_id: The paper identifier
            
        Returns:
            String containing the abstract
        """
        params = {
            'db': 'pubmed',
            'id': paper_id,
            'retmode': 'xml'
        }
        
        if self.api_key:
            params['api_key'] = self.api_key
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/efetch.fcgi", params=params) as response:
                if response.status != 200:
                    return ""
                
                xml_content = await response.text()
                
                # Parse XML to extract abstract
                soup = BeautifulSoup(xml_content, 'lxml')
                abstract_tag = soup.find('abstract')
                
                if abstract_tag:
                    # Extract all paragraphs from the abstract
                    paragraphs = abstract_tag.find_all('abstracttext')
                    abstract_text = ' '.join([p.get_text() for p in paragraphs])
                    return abstract_text
                
                return ""
    
    async def get_full_text(self, paper_id: str, id_type: str = 'pmid') -> Optional[str]:
        """Get the full text of a paper if available
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier
            
        Returns:
            String containing the full text or None if not available
        """
        # PubMed doesn't provide direct full text access
        # We'll try to get the abstract and other available information
        
        try:
            paper_details = await self.get_paper_details(paper_id, id_type)
            
            title = paper_details.get('title', '')
            abstract = paper_details.get('abstractText', '')
            
            if not title and not abstract:
                return None
            
            full_text = f"TITLE: {title}\n\nABSTRACT: {abstract}\n\nBODY: Full text not available through PubMed API"
            return full_text
            
        except Exception as e:
            print(f"Error getting full text for {paper_id}: {e}")
            return None
    
    async def fetch_multiple_papers(self, paper_ids: List[str], id_type: str = 'pmid') -> List[Dict[str, Any]]:
        """Fetch details for multiple papers in parallel
        
        Args:
            paper_ids: List of paper identifiers
            id_type: The type of identifier
            
        Returns:
            List of paper details
        """
        tasks = [self.get_paper_details(paper_id, id_type) for paper_id in paper_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        valid_results = []
        for result in results:
            if isinstance(result, Exception):
                print(f"Error fetching paper: {result}")
            else:
                valid_results.append(result)
        
        return valid_results
    
    async def fetch_multiple_full_texts(self, paper_ids: List[str], id_type: str = 'pmid') -> Dict[str, Optional[str]]:
        """Fetch full text for multiple papers in parallel
        
        Args:
            paper_ids: List of paper identifiers
            id_type: The type of identifier
            
        Returns:
            Dict mapping paper_id to full text (or None if not available)
        """
        tasks = {paper_id: self.get_full_text(paper_id, id_type) for paper_id in paper_ids}
        
        results = {}
        for paper_id, task in tasks.items():
            try:
                results[paper_id] = await task
            except Exception as e:
                print(f"Error fetching full text for {paper_id}: {e}")
                results[paper_id] = None
        
        return results