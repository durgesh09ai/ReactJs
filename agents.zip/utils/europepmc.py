import aiohttp
import asyncio
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup
from config import settings

class EuropePMCClient:
    """Client for interacting with the EuropePMC API"""
    
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or settings.EUROPEPMC_API_URL
    
    async def search(self, query: str, page: int = 1, page_size: int = 10) -> Dict[str, Any]:
        """Search for papers in EuropePMC
        
        Args:
            query: The search query
            page: The page number (1-based)
            page_size: Number of results per page
            
        Returns:
            Dict containing search results
        """
        params = {
            'query': query,
            'resultType': 'core',
            'cursorMark': '*',
            'pageSize': page_size,
            'format': 'json'
        }
        
        # Calculate cursor position for pagination
        if page > 1:
            # This is simplified; in a real implementation, you'd need to track the nextCursorMark
            params['cursorMark'] = f'*+{(page-1)*page_size}'
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/search", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"EuropePMC API error: {response.status} - {error_text}")
                
                data = await response.json()
                return data
    
    async def get_paper_details(self, paper_id: str, id_type: str = 'pmid') -> Dict[str, Any]:
        """Get detailed information about a specific paper
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier (pmid, pmcid, doi)
            
        Returns:
            Dict containing paper details
        """
        params = {
            'format': 'json'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/{id_type}/{paper_id}", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"EuropePMC API error: {response.status} - {error_text}")
                
                data = await response.json()
                return data
    
    async def get_full_text(self, paper_id: Any | None, id_type: str = 'PMC') -> Optional[str]:
        """Get the full text of a paper if available
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier (PMC for PubMed Central)
            
        Returns:
            String containing the full text or None if not available
        """
        # For PMC articles, we can try to get the full text XML
        if id_type.upper() == 'PMC':
            url = f"{self.base_url}/{id_type.lower()}/{paper_id}/fullTextXML"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status != 200:
                        return None
                    
                    xml_content = await response.text()
                    
                    # Parse XML to extract text content
                    soup = BeautifulSoup(xml_content, 'lxml')
                    
                    # Extract title
                    title = soup.find('article-title')
                    title_text = title.get_text() if title else ""
                    
                    # Extract abstract
                    abstract = soup.find('abstract')
                    abstract_text = abstract.get_text() if abstract else ""
                    
                    # Extract body text
                    body = soup.find('body')
                    body_text = ""
                    if body:
                        # Extract all paragraphs
                        paragraphs = soup.find_all('p')
                        body_text = "\n\n".join([p.get_text() for p in paragraphs])
                    
                    # Combine all text
                    full_text = f"TITLE: {title_text}\n\nABSTRACT: {abstract_text}\n\nBODY:\n{body_text}"
                    return full_text
        
        # For other ID types, we might need different approaches
        return None
    
    async def get_paper_citations(self, paper_id: str, id_type: str = 'pmid') -> List[Dict[str, Any]]:
        """Get papers that cite the specified paper
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier
            
        Returns:
            List of papers citing the specified paper
        """
        params = {
            'query': f"{id_type.upper()}:{paper_id}",
            'resultType': 'core',
            'pageSize': 100,
            'format': 'json'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/citations/{id_type}/{paper_id}", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"EuropePMC API error: {response.status} - {error_text}")
                
                data = await response.json()
                return data.get('citationList', {}).get('citation', [])
    
    async def get_paper_references(self, paper_id: str, id_type: str = 'pmid') -> List[Dict[str, Any]]:
        """Get references cited by the specified paper
        
        Args:
            paper_id: The paper identifier
            id_type: The type of identifier
            
        Returns:
            List of references cited by the specified paper
        """
        params = {
            'format': 'json'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}/{id_type}/{paper_id}/references", params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"EuropePMC API error: {response.status} - {error_text}")
                
                data = await response.json()
                return data.get('referenceList', {}).get('reference', [])
    
    async def fetch_multiple_papers(self, paper_ids: List[str], id_type: str = 'pmid') -> List[Dict[str, Any]]:
        """Fetch details for multiple papers in parallel
        
        Args:
            paper_ids: List of paper identifiers
            id_type: The type of identifier
            
        Returns:
            List of paper details
        """
        tasks = [self.get_paper_details(paper_id, id_type) for paper_id in paper_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        valid_results = []
        for result in results:
            if isinstance(result, Exception):
                print(f"Error fetching paper: {result}")
            else:
                valid_results.append(result)
        
        return valid_results
    
    async def fetch_multiple_full_texts(self, paper_ids: List[str], id_type: str = 'PMC') -> Dict[str, Optional[str]]:
        """Fetch full text for multiple papers in parallel
        
        Args:
            paper_ids: List of paper identifiers
            id_type: The type of identifier
            
        Returns:
            Dict mapping paper_id to full text (or None if not available)
        """
        tasks = {paper_id: self.get_full_text(paper_id, id_type) for paper_id in paper_ids}
        
        results = {}
        for paper_id, task in tasks.items():
            try:
                results[paper_id] = await task
            except Exception as e:
                print(f"Error fetching full text for {paper_id}: {e}")
                results[paper_id] = None
        
        return results