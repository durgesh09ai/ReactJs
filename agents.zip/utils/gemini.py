from typing import Dict, Any, Optional
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import HumanMessage, SystemMessage
from config import settings
from pydantic import SecretStr

# Create a Gemini model instance for direct use
def get_gemini_model():
    """Get a configured Gemini model instance"""
    return ChatGoogleGenerativeAI(
        model=settings.GEMINI_MODEL,
        api_key=SecretStr(settings.GOOGLE_API_KEY),
        temperature=0.7,
        top_p=0.95,
        top_k=40,
        max_tokens=8000,
    )

# Function to generate text using Gemini
async def generate_text(prompt: str, system_prompt: Optional[str] = None) -> str:
    """Generate text using the Gemini model"""
    model = get_gemini_model()

    messages = []
    if system_prompt:
        messages.append(SystemMessage(content=system_prompt))

    messages.append(HumanMessage(content=prompt))

    response = await model.agenerate([messages])
    return response.generations[0][0].text

# Function to generate structured output using Gemini
async def generate_structured_output(prompt: str, system_prompt: Optional[str] = None) -> Dict[str, Any]:
    """Generate structured output (parsed as JSON) using the Gemini model"""
    import json

    # Add instruction to return JSON
    if system_prompt:
        system_prompt += "\nPlease provide your response in valid JSON format."
    else:
        system_prompt = "Please provide your response in valid JSON format."

    response_text = await generate_text(prompt, system_prompt)

    # Try to parse the response as JSON
    try:
        # Find JSON content if it's wrapped in markdown code blocks
        if "```json" in response_text:
            json_content = response_text.split("```json")[1].split("```")[0].strip()
        elif "```" in response_text:
            json_content = response_text.split("```")[1].strip()
        else:
            json_content = response_text

        return json.loads(json_content)
    except json.JSONDecodeError:
        # If parsing fails, return the raw text in a dict
        return {"raw_response": response_text}
