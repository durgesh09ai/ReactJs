import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# Load environment variables from .env file
load_dotenv(override=True)

class Settings(BaseSettings):
    # Application settings
    APP_NAME: str = "EXL ProtoWeave.AI"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"
    
    # Google Gemini API settings
    GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    
    # EuropePMC API settings
    EUROPEPMC_API_URL: str = "https://www.ebi.ac.uk/europepmc/webservices/rest"

    # PubMed API settings
    PUBMED_API_URL: str = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    PUBMED_API_KEY: str = os.getenv("PUBMED_API_KEY", "")  # Optional, add your API key if you have one
    
    # Agent settings
    MAX_SEARCH_RESULTS: int = int(os.getenv("MAX_SEARCH_RESULTS", "20"))
    MAX_FULL_TEXT_PAPERS: int = int(os.getenv("MAX_FULL_TEXT_PAPERS", "20"))
    MAX_SEARCH_ITERATIONS: int = int(os.getenv("MAX_SEARCH_ITERATIONS", "3"))
    
    class Config:
        env_file = ".env"

# Create settings instance
# After loading settings
settings = Settings()

# Validate required settings
if not settings.GOOGLE_API_KEY:
    print("WARNING: GOOGLE_API_KEY is not set. The application will not function properly.")
    print("Please create a .env file with your GOOGLE_API_KEY.")