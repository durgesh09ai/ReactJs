import asyncio
import json
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import pypandoc
from pypandoc.pandoc_download import download_pandoc
import tempfile
import os
import base64

# Import our custom modules
from agents.planning_agent import create_planning_agent, run_planning_agent
from agents.research_agent import create_research_agent, run_research_agent
from utils.europepmc import EuropePMCClient
from utils.pubmed import PubMedClient

try:
    pypandoc.get_pandoc_version()
except OSError:
    print("Pandoc is not installed. Downloading now...")
    download_pandoc()

# Create API clients
europe_pmc_client = EuropePMCClient()
pubmed_client = PubMedClient()

# Define request and response models
class ResearchRequest(BaseModel):
    topic: str = Field(..., description="The healthcare research topic to investigate")
    user_id: Optional[str] = Field(None, description="Optional user identifier")
    
class ClarificationResponse(BaseModel):
    questions: List[str] = Field(..., description="List of clarification questions")
    plan_id: str = Field(..., description="Unique identifier for this planning session")

class PlanFeedback(BaseModel):
    plan_id: str = Field(..., description="Unique identifier for the planning session")
    answers: Dict[str, str] = Field(..., description="Answers to clarification questions")
    approved: bool = Field(..., description="Whether the plan is approved or needs revision")
    feedback: Optional[str] = Field(None, description="Optional feedback on the plan")

class ResearchStatus(BaseModel):
    status: str = Field(..., description="Current status of the research")
    progress: float = Field(..., description="Progress percentage (0-100)")
    current_step: str = Field(..., description="Current step being executed")

# Store active research sessions
active_sessions = {}

# FastAPI app setup
app = FastAPI(title="EXL ProtoWeave.AI API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        if session_id not in self.active_connections:
            self.active_connections[session_id] = []
        self.active_connections[session_id].append(websocket)

    def disconnect(self, websocket: WebSocket, session_id: str):
        if session_id in self.active_connections:
            if websocket in self.active_connections[session_id]:
                self.active_connections[session_id].remove(websocket)
            if not self.active_connections[session_id]:
                del self.active_connections[session_id]

    async def broadcast(self, message: str, session_id: str):
        if session_id in self.active_connections:
            for connection in self.active_connections[session_id]:
                try:
                    await connection.send_text(message)
                except Exception:
                    # Handle disconnected clients
                    pass

manager = ConnectionManager()

@app.get("/")
async def root():
    return {"message": "EXL ProtoWeave.AI API"}

@app.post("/research/plan", response_model=ClarificationResponse)
async def create_research_plan(request: ResearchRequest):
    """Create a research plan and generate clarification questions"""
    try:
        # Create a unique session ID
        import uuid
        session_id = str(uuid.uuid4())
        
        # Initialize the planning agent
        planning_agent = create_planning_agent()
        
        # Generate clarification questions
        questions = await run_planning_agent(
            planning_agent, 
            topic=request.topic,
            generate_questions=True
        )
        
        # Store the session information
        active_sessions[session_id] = {
            "topic": request.topic,
            "user_id": request.user_id,
            "planning_agent": planning_agent,
            "questions": questions,
            "status": "planning",
            "answers": {}
        }
        
        return ClarificationResponse(questions=questions, plan_id=session_id)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating research plan: {str(e)}")

@app.post("/research/plan/feedback")
async def provide_plan_feedback(feedback: PlanFeedback, background_tasks: BackgroundTasks):
    """Process feedback on the research plan and start research if approved"""
    if feedback.plan_id not in active_sessions:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    session = active_sessions[feedback.plan_id]
    session["answers"] = feedback.answers
    
    if feedback.approved:
        # Plan is approved, finalize it and start research
        try:
            # Finalize the plan
            final_plan = await run_planning_agent(
                session["planning_agent"],
                topic=session["topic"],
                clarification_answers=feedback.answers,
                generate_questions=False
            )
            
            # Update session status
            session["status"] = "researching"
            session["plan"] = final_plan
            
            # Start research in background
            background_tasks.add_task(
                start_research_process,
                session_id=feedback.plan_id
            )
            
            return {"message": "Research started", "session_id": feedback.plan_id}
        
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error starting research: {str(e)}")
    else:
        # Plan needs revision
        try:
            # Revise the plan based on feedback
            revised_questions = await run_planning_agent(
                session["planning_agent"],
                topic=session["topic"],
                clarification_answers=feedback.answers,
                feedback=feedback.feedback,
                generate_questions=True
            )
            
            # Update session with new questions
            session["questions"] = revised_questions
            
            return ClarificationResponse(questions=revised_questions, plan_id=feedback.plan_id)
        
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error revising plan: {str(e)}")

@app.get("/research/report/{session_id}")
async def get_research_report(session_id: str):
    """Get the final research report"""
    if session_id not in active_sessions:
        raise HTTPException(status_code=404, detail="Research session not found")
    
    session = active_sessions[session_id]
    
    if session.get("status") != "completed":
        raise HTTPException(status_code=400, detail="Research not yet completed")
    
    report_md = session.get("report", "No report available")

    # Convert markdown to docx using pypandoc
    try:
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as temp_docx:
            docx_path = temp_docx.name
            
        pypandoc.convert_text(
            report_md,
            to="docx",
            format="md",
            outputfile=docx_path
        )
        
        with open(docx_path, 'rb') as docx_file:
            docx_content = docx_file.read()
        
        os.unlink(docx_path)
        
        return {
            "report": report_md,
            "docx": base64.b64encode(docx_content).decode('utf-8')
        }
            
    except Exception as e:
        print(f"Error converting to DOCX: {str(e)}")
        return {"report": report_md}

@app.websocket("/ws/research/{session_id}")
async def research_websocket(websocket: WebSocket, session_id: str):
    """WebSocket endpoint for streaming research progress"""
    await manager.connect(websocket, session_id)
    
    try:
        while True:
            # Keep the connection alive
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        manager.disconnect(websocket, session_id)

async def start_research_process(session_id: str):
    """Start the research process for a given session"""
    if session_id not in active_sessions:
        return
    
    session = active_sessions[session_id]
    
    try:
        # Initialize the research agent with both clients
        research_agent = create_research_agent(europe_pmc_client, pubmed_client)
        session["research_agent"] = research_agent
        
        # Function to send progress updates
        async def send_update(step: str, details: Any = None, progress: float = None):
            # Add source information to details if it's a paper-related step
            if details and step in ["searching", "analyzing_paper", "selecting_papers"]:
                # For searching step, add source counts
                if step == "searching" and "results" in details:
                    # Count papers by source
                    source_counts = {}
                    for paper in details.get("results", []):
                        source = paper.get("source", "Unknown")
                        source_counts[source] = source_counts.get(source, 0) + 1
                    details["source_counts"] = source_counts
                
                # For analyzing_paper step, add the source of the current paper
                elif step == "analyzing_paper" and "paper_data" in details:
                    # Include the source in the details
                    details["source"] = details["paper_data"].get("source", "Unknown")
                
                # For selecting_papers step, add source distribution
                elif step == "selecting_papers" and "selected_papers" in details:
                    # Count selected papers by source
                    selected_papers_list = details.get("selected_papers", [])
                    if isinstance(selected_papers_list, list):
                        source_distribution = {}
                        for paper in selected_papers_list:
                            source = paper.get("source", "Unknown")
                            source_distribution[source] = source_distribution.get(source, 0) + 1
                        details["source_distribution"] = source_distribution

            message = {
                "step": step,
                "details": details,
                "progress": progress or session.get("progress", 0.0)
            }
            
            await manager.broadcast(json.dumps(message), session_id)
        
        # Run the research process
        report = await run_research_agent(
            research_agent,
            topic=session["topic"],
            plan=session["plan"],
            clarification_answers=session["answers"],
            progress_callback=send_update
        )
        
        # Update session with the final report
        session["status"] = "completed"
        session["progress"] = 100.0
        session["report"] = report
        
        # Send final update
        await send_update("completed", {"report_available": True}, 100.0)
    
    except Exception as e:
        # Handle errors
        import traceback
        error_traceback = traceback.format_exc()
        print(f"Error in research process: {str(e)}")
        print(f"Traceback: {error_traceback}")
        
        session["status"] = "error"
        session["error"] = str(e)
        session["error_traceback"] = error_traceback
        
        # Send error update
        await manager.broadcast(
            json.dumps({
                "step": "error",
                "details": {"error": str(e), "traceback": error_traceback},
                "progress": session.get("progress", 0.0)
            }),
            session_id
        )

@app.get("/research/status/{session_id}")
async def get_research_status(session_id: str):
    """Get the current status of a research session"""
    if session_id not in active_sessions:
        raise HTTPException(status_code=404, detail="Research session not found")
    
    session = active_sessions[session_id]
    
    response = {
        "status": session.get("status", "unknown"),
        "progress": session.get("progress", 0.0),
        "current_step": session.get("current_step", "")
    }
    
    # Add error details if available
    if session.get("status") == "error" and "error" in session:
        response["error"] = session.get("error")
        if "error_traceback" in session:
            response["error_traceback"] = session.get("error_traceback")
    
    return response


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="localhost", port=8000, reload=True)