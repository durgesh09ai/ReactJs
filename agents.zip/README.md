# EXL ProtoWeave.AI

A deep research agent for healthcare research that uses planning and research stages with different agents performing specialized tasks. The system uses EuropePMC API and PubMed for fetching research papers and performs thorough analysis to help researchers find gaps in current research and provide recommendations for future research.

## Features

- **Planning Stage**: Generates clarification questions and creates a structured research plan
- **Research Stage**: Searches for relevant papers, analyzes them, and synthesizes findings
- **Streaming**: Streams the agent's thinking process and steps to the frontend
- **Interactive**: Allows users to provide feedback on the research plan
- **Comprehensive Reports**: Generates detailed research reports with findings and recommendations

## Architecture

The system is built with the following components:

- **Backend**: FastAPI for API endpoints and WebSocket streaming
- **LLM Provider**: Google Gemini for natural language processing
- **Agentic Framework**: Langchain and Langgraph for creating the research agents
- **Research API**: EuropePMC and PubMed for fetching research papers and full-text content

## Setup

### Prerequisites

- Python 3.8+
- Google API Key for Gemini
- PubMed API Key (optional)

### Installation

1. Clone the repository

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create a `.env` file based on the `.env.example` template:
   ```bash
   cp .env.example .env
   ```

4. Add your Google API key to the `.env` file:
   ```
   GOOGLE_API_KEY=your_google_api_key_here
   ```

5. (Optional) Add your PubMed API key to the `.env` file:
   ```
   PUBMED_API_KEY=your_pubmed_api_key_here
   ```

### Running the Application

Start the FastAPI server:

```bash
uvicorn main:app --reload
```

The API will be available at http://localhost:8000

## API Endpoints

### Planning Stage

- `POST /research/plan`: Create a research plan and generate clarification questions
- `POST /research/plan/feedback`: Process feedback on the research plan and start research if approved

### Research Stage

- `GET /research/status/{session_id}`: Get the current status of a research session
- `GET /research/report/{session_id}`: Get the final research report
- `WebSocket /ws/research/{session_id}`: WebSocket endpoint for streaming research progress

## Usage Example

1. Create a research plan:
   ```bash
   curl -X POST "http://localhost:8000/research/plan" \
     -H "Content-Type: application/json" \
     -d '{"topic": "Artificial Intelligence in Cancer Diagnosis"}'
   ```

2. Provide feedback on the plan:
   ```bash
   curl -X POST "http://localhost:8000/research/plan/feedback" \
     -H "Content-Type: application/json" \
     -d '{
       "plan_id": "your_plan_id",
       "answers": {
         "question1": "answer1",
         "question2": "answer2"
       },
       "approved": true
     }'
   ```

3. Connect to the WebSocket to receive streaming updates:
   ```javascript
   const socket = new WebSocket('ws://localhost:8000/ws/research/your_session_id');
   socket.onmessage = (event) => {
     const data = JSON.parse(event.data);
     console.log(data);
   };
   ```

4. Get the final report:
   ```bash
   curl -X GET "http://localhost:8000/research/report/your_session_id"
   ```

## Project Structure

```
├── main.py                # FastAPI application and endpoints
├── config.py              # Configuration settings
├── agents/                # Agent implementations
│   ├── planning_agent.py  # Planning stage agent
│   └── research_agent.py  # Research stage agent
├── utils/                 # Utility modules
│   ├── europepmc.py       # EuropePMC API client
│   └── gemini.py          # Google Gemini integration
└── requirements.txt       # Project dependencies
```

## Error Handling

The application includes comprehensive error handling for:
- API request failures
- LLM generation errors
- Research paper fetching issues
- WebSocket connection problems

## Future Improvements

- Add support for more research databases beyond EuropePMC
- Implement caching for research results to improve performance
- Add user authentication and research history
- Enhance the analysis with domain-specific knowledge