import React from "react";
import { Box, Typography, Stack, Paper } from "@mui/material";

// Define item type with optional `sub`
type TimelineItem = {
  percent: number;
  message: string;
  sub?: string;
};

type TimelineSection = {
  section: string;
  items: TimelineItem[];
};

const data: TimelineSection[] = [
  {
    section: "Researching in the progress",
    items: [
      { percent: 43, message: "I need some clarification to better understand your research needs:" },
      { percent: 23, message: "I need some clarification to better understand your research needs:" },
      { percent: 13, message: "I need some clarification to better understand your research needs:" },
    ],
  },
  {
    section: "Analyzing the process",
    items: [
      {
        percent: 50,
        message: "Diabetes Overtreatment and Hypoglycemia in Older Patients With Type",
        sub: "Paper 20 of 20",
      },
      {
        percent: 30,
        message: "Diabetes Overtreatment and Hypoglycemia in Older Patients With Type",
        sub: "Paper 43 of 20",
      },
    ],
  },
];


const StatsPanel = () => {
  return (
   <>
<Box
  sx={{
    borderRadius: "16px 16px 0 0",
    backgroundColor: "#D9EDFF",
    p: 0.6,
    width: "100%",
    maxWidth: 500,
    mx: "auto",
    mb: "1px",
  }}
>
  <Box
    sx={{
      borderRadius: "16px 16px 0 0",
      backgroundColor: "#fff",
      width: "100%",
      p:1
    }}
  >
    <Typography variant="h6" align="center" fontSize={14} fontWeight={400}>
      Reasoning
    </Typography>
  </Box>
</Box>

    <Box
      sx={{
        border: "1px solid #CFE3F3",
        borderRadius: "0 0 16px 16px",
        backgroundColor: "#D9EDFF",
        p: 2,
        width: "100%",
        maxWidth: 500,
        mx: "auto",
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "row", position: "relative" , border: "1px solid #fff",
        borderRadius: "16px",
        backgroundColor: "#fff",p:2,}}>
        {/* Vertical Line */}
        <Box
          sx={{
            width: "2px",
            display: "flex",
            justifyContent: "center",
            position: "relative",
          }}
        >
          <Box
            sx={{
              position: "absolute",
              top: 0,
              bottom: 0,
              left: "50%",
              transform: "translateX(-50%)",
              }}
          />
        </Box>

        {/* Content */}
        <Box sx={{ flex: 1 }}>
          {data.map((section, sIndex) => (
            <Box key={sIndex} sx={{ mb: 3 }}>
              <Typography
                variant="subtitle2"
                sx={{
                  display: "inline-block",
                  backgroundColor: "rgba(18, 18, 21, 0.30)",
                  color:"#fff",
                  px: 1.5,
                  py: 0.5,
                  borderRadius: "0 8px 8px 0",
                  fontWeight: 600,
                  fontSize: "0.75rem",
                  mb: 1,
                }}
              >
                {section.section}
              </Typography>

              <Stack spacing={0}>
                {section.items.map((item, iIndex) => (
                <Box key={iIndex} sx={{borderLeft:"2px solid #ccc",backgroundColor: "#e4e4e533",
                 p:1}}>

                  <Box key={iIndex} sx={{ display: "flex", alignItems: "flex-start" }}>
                    {/* Connector (dot + horizontal line) */}
                    <Box
                      sx={{
                        width: 24,
                        height: 24,
                        position: "relative",
                        flexShrink: 0,
                        mt: 1,
                   
                      }}
                    >
                      {/* Dot */}
                      <Box
                        sx={{
                          position: "absolute",
                          top: "50%",
                          right: "-15%",
                          transform: "translate(-50%, -50%)",
                          width: 8,
                          height: 8,
                          borderRadius: "50%",
                          backgroundColor: "#ccc",
                          zIndex: 1,
                        }}
                      />
                      {/* Horizontal Line */}
                      <Box
                        sx={{
                          position: "absolute",
                          top: "50%",
                          right:"35%",
                          height: 2,
                          width: "100%",
                          backgroundColor: "#B0BEC5",
                          transform: "translateY(-50%)",
                          zIndex: 0,
                        }}
                      />
                    </Box>

                    {/* Text Section */}
                    <Box sx={{ flex: 1, ml: 1 }}>
                      {/* Status Line */}
                      <Typography
                        variant="subtitle2"
                        sx={{
                          fontSize: "0.8rem",
                          color: "#636262",
                          fontWeight: 500,
                          mb: 0.5,
                          pt:1,
                        }}
                      >
                        {section.section.includes("Researching")
                          ? `Searching the Queries (${item.percent}%)`
                          : `Analyzing Paper (${item.percent}%)`}
                      </Typography>

                      {/* Message Card */}
                      <Paper
                        elevation={0}
                        sx={{ p: 1.5, backgroundColor: "#fff" }}
                      >
                        <Typography
                          variant="body2"
                          sx={{ fontSize: "0.85rem" }}
                        >
                          {item.message}
                        </Typography>
                        {item.sub && (
                          <Typography
                            variant="caption"
                            sx={{ color: "#999", display: "block", mt: 0.5 }}
                          >
                            {item.sub}
                          </Typography>
                        )}
                      </Paper>
                    </Box>
                  </Box>
                  </Box>
                ))}
              </Stack>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
    </>
  );
};




export default StatsPanel;
