import React, { useState } from "react";
import { Paper, Box } from "@mui/material";
import { ExistingModelsSection } from "./ExistingModelsSection";
import { EditModelForm, ModelData } from "./EditModelForm";
import { ActionButtons } from "./ActionButtons";
import SetupHeader from "./SetupHeader";

// Mock initial data
const initialModels: ModelData[] = [
  {
    id: '123eee',
    name: "GPT-4 Turbo",
    endpoint: "api.openai.com",
    apiKey: "••••••••••••••••"
  },
  {
    id: '123wweee',
    name: "Claude 3",
    endpoint: "claude.ai/api",
    apiKey: "••••••••••••••••"
  },
  {
    id: '123333eee',
    name: "Claude 3",
    endpoint: "local-server:8000",
    apiKey: "••••••••••••••••"
  }
];

export const ModelConfigurationPanel: React.FC = () => {
  const [models, setModels] = useState<ModelData[]>(initialModels);
  const [selectedModel, setSelectedModel] = useState<ModelData | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const handleAddModel = () => {
   
    setIsEditing(true);
  };


  const handleUpdateModel = (updatedModel: ModelData) => {
    if (updatedModel.id) {
      setModels(models.map(model =>
        model.id === updatedModel.id ? updatedModel : model
      ));
    } else {
      const newModel: ModelData = {
        id: 'weq3242',
        name: "New Model",
        endpoint: "https://api.example.com/model",
        apiKey: "asdasdsad"
  
      };
      setModels((prevModels) => [...prevModels, newModel]);
      setSelectedModel(newModel);
    }
    setIsEditing(false);
    setSelectedModel(null);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setSelectedModel(null);
  };

  const handleSave = () => {
    if (selectedModel) {
      handleUpdateModel(selectedModel);
    }
  };

  const handleEditModel = (id: string) => {
    const modelToEdit = models.find((m) => m.id === id);
    if (modelToEdit) {
      setSelectedModel(modelToEdit);
      setIsEditing(true);
    }
  };
  
  const handleDeleteModel = (id: string) => {
    setModels((prev) => prev.filter((model) => model.id !== id));
  };

  return (
    <Paper elevation={1} sx={{ maxWidth: "820px", pb: "20px", px: 1, borderRadius: 2 }}>
      <SetupHeader title="LLM Model selection" />
    <Box
      sx={{
        display: "flex",
        maxWidth: "527px",
        flexDirection: "column",
        justifyContent: "center",
        textTransform: "none",
      }}
    >
      <Paper
        elevation={1}
        sx={{
          display: "flex",
          flexDirection: "column",
          border: "1px solid rgba(18,18,21,0.10)",
          padding: 2,
          width: "100%",
        }}
      >
        <ExistingModelsSection
          models={models}
          onAddModel={handleAddModel}
          onEditModel={handleEditModel}
          onDeleteModel={handleDeleteModel}
        />

        {isEditing && (
          <EditModelForm
            model={selectedModel}
            onUpdate={setSelectedModel}
            handleCancel={handleCancel}
            handleSave={handleSave}
          />
        )}


        
      </Paper>
    </Box>
        </Paper>
  );
};
