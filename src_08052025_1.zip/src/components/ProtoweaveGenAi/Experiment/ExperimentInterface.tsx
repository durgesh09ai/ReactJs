import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Container,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import FormSelect from "./FormSelect";
import FormField from "./FormField";
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import CloseIcon from '@mui/icons-material/Close';
import IconButton from '@mui/material/IconButton';
import { useNavigate } from "react-router-dom";

export const ExperimentInterface: React.FC = () => {
  const navigate = useNavigate();

  const handleClose = () => {
    navigate("/protoweave");
  };

  return (
    <Box sx={{ maxWidth: 684, width: "100%" }}>
      {/* Header */}
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 1,
          p: 1.25,
          border: 3,
          borderColor: "#D9EDFF",
          borderRadius: "8px 8px 0 0",
          width: "fit-content",
        }}
     >
  <Typography variant="body1" fontWeight={500}>
    Configuration Form 1
  </Typography>
  <IconButton size="small" sx={{ p: 0.5 }} onClick={handleClose}>
    <CloseIcon fontSize="small" />
  </IconButton>
</Paper>

      {/* Form Body */}
      <Box
        sx={{
          minHeight: 798,
          bgcolor: "#D9EDFF",
          p: 2,
          borderRadius: "0 12px 12px 12px",
        }}
      >
        <Paper
          elevation={0}
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 2,
            p: 2,
            borderRadius: 4,
            height: "100%",
          }}
        >
          <FormSelect label="Select Diet Groups" placeholder="Your answer" />
          <FormField label="Sample Size per Group:" placeholder="Your answer" />
          <FormField label="Duration (in weeks):" placeholder="Your answer" />
          <FormField label="Measurement Metric:" placeholder="Your answer" />

            <FormField
              label="What level of detail is needed for the proposed research protocols? "
              placeholder="Your answer"
            />
             <FormField
              label="What level of detail is needed for the proposed research protocols?"
              placeholder="Your answer"
            />
             <FormField
              label="What level of detail is needed for the proposed research protocols?"
              placeholder="Your answer"
            />
         

          {/* Buttons */}
          <Stack
              direction="row"
              spacing={1}
              sx={{
                mt: 2,
                display: "flex",
                justifyContent: "flex-end", 
                width: "100%",             
              }}
            >
              <Button
                variant="outlined"
                color="primary"
                startIcon={<ContentCopyIcon />}
              >
                Duplicate
              </Button>
              <Button variant="contained" color="success">
                Run Simulation
              </Button>
            </Stack>

        </Paper>
      </Box>
    </Box>
  );
};
