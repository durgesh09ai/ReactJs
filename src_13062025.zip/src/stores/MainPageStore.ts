import { makeAutoObservable, runInAction } from "mobx";
import { API_BASE_URL } from "./config/config";

export class MainPageStore {
  data: any = null;
  loading: boolean = false;
  error: string | null = null;
  sidebarCollapsed:boolean = true;
  sidemenuloading:boolean = false;
  apiUrl: string = API_BASE_URL;
  sidebarData: any = null;
  statData: any = null;
  typeOptionsList: string[] = [];
  technologyOptionsList: string[] = [];
  clientOptionsList: string[] = [];
  analyticsOptionsList: string[]= [];
  payerValueChain:string[] = [];
  solutionCatalogueData: any = null;
  
  constructor() {
    makeAutoObservable(this);
  }

  setSidebarCollapsed = () => {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  fetchSideMenuData = async () => {
    console.log('connection:::',API_BASE_URL)
    try {
      this.sidemenuloading = true;
      const res = await fetch(`${this.apiUrl}/dashboard/leftmenulist`);
      if (!res.ok) throw new Error("Failed to fetch sidemenu data");
      const data = await res.json();
      runInAction(() => {
        this.sidebarData = data;
        this.sidemenuloading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };
  
  fetchStatData = async (userId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/datastate/userid/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch datastate data");
      const data = await res.json();
      runInAction(() => {
        this.statData = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchByTypeOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/navigator/typelist`);
      if (!res.ok) throw new Error("Failed to fetch Type List");
      const data = await res.json();
        runInAction(() => {
        this.typeOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Type List options:", error);
    }
  }


  fetchByTechnologyOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/navigator/technology`);
      if (!res.ok) throw new Error("Failed to fetch Technology List");
      const data = await res.json();
        runInAction(() => {
        this.technologyOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Technology List options:", error);
    }
  }

  fetchByClientOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/navigator/client`);
      if (!res.ok) throw new Error("Failed to fetch Client List");
      const data = await res.json();
        runInAction(() => {
        this.clientOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Client List options:", error);
    }
  }

  fetchByAnalyticsOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/navigator/analytics`);
      if (!res.ok) throw new Error("Failed to fetch Analytics List");
      const data = await res.json();
        runInAction(() => {
        this.analyticsOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Analytics List options:", error);
    }
  }

  fetchPayerValueChain = async (
     userId:string,
     ptype: string,
     ptechnology: string,
     pclient:string,
     panalytics:string,
     ) => {
    try {
      const response = await fetch(`${this.apiUrl}/navigator/payer_value_chain/${userId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ptype,
          ptechnology,
          pclient,
          panalytics
        }),
      });
  
      if (!response.ok) throw new Error("Failed to fetch PayerValueChain Data");
      const payerValueChain = await response.json();
     return payerValueChain;
    } catch (error) {
      console.error("Error inserting messages:", error);
    }
  }


  fetchSolutionCatalogueData = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/solutioncatalogue/solutioncataloguelist/`);
      if (!res.ok) throw new Error("Failed to fetch datastate data");
      const data = await res.json();
      runInAction(() => {
        this.solutionCatalogueData = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };



}

export const mainPageStore = new MainPageStore();
