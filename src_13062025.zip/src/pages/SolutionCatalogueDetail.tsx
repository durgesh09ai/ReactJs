import React, { useState } from "react";
import { Box, Stack, Typography } from "@mui/material";
import { Breadcrumb } from "../components/SolutionCatalogueDetail/Breadcrum";
import { ProjectHeader } from "../components/SolutionCatalogueDetail/ProjectHeader";
import { ProjectGallery } from "../components/SolutionCatalogueDetail/ProjectGallery";
import { ProjectTabs } from "../components/SolutionCatalogueDetail/ProjectTabs";
import { TechnologyBadge } from "../components/SolutionCatalogueDetail/TechnologyBadge";
import { TeamMember } from "../components/SolutionCatalogueDetail/TeamMember";
import { StatisticsCard } from "../components/SolutionCatalogueDetail/StatisticsCard";

const SolutionCatalogueDetail: React.FC = () => {
  const [activeTab, setActiveTab] = useState("description");

  const breadcrumbItems = [
    { label: "Home", href: "/" },
    { label: "Databricks GenAI partner recognition", href: "/" },
  ];

  const projectTabs = [
    { id: "description", label: "Project Description" },
    { id: "technology", label: "Technology" },
    { id: "access", label: "Access" },
    { id: "progress", label: "Progress" },
    { id: "opportunity", label: "Opportunity" },
  ];

  const statistics = [
    { change: "+219", label: "subscribers", value: "14,855" },
    { change: "+219", label: "subscribers", value: "14,855" },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "description":
        return (
          <Stack spacing={2}>
            <Typography sx={{ color: "rgba(74,74,74,1)", fontWeight: 400, lineHeight: "25px" }}>
              Generative AI based solution which provides code generation, insights, code
              translation, debugging, along with advanced metrics analysis as well.
            </Typography>
          </Stack>
        );
      case "technology":
        return (
          <Stack spacing={2}>
            <Stack direction="row" alignItems="center" spacing={2}>
              <Typography fontWeight={600} color="#1F2633" fontSize="1rem">
                Frontend Technology -
              </Typography>
              <TechnologyBadge label="Streamlit" />
            </Stack>
            <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap">
              <Typography fontWeight={600} color="#1F2633" fontSize="1rem">
                Backend Technology -
              </Typography>
              <Stack direction="row" spacing={1}>
                <TechnologyBadge label="Python" />
                <TechnologyBadge label="GenAI" />
                <TechnologyBadge label="LLMs" />
                <TechnologyBadge label="NLP" />
              </Stack>
            </Stack>
          </Stack>
        );
      case "access":
        return <Typography>Access details for the solution will be listed here.</Typography>;
      case "progress":
        return <Typography>Progress indicators and milestones go here.</Typography>;
      case "opportunity":
        return <Typography>Opportunity and business impact overview goes here.</Typography>;
      default:
        return null;
    }
  };

  return (
    <Box sx={{ px: 2, py: 0 }}>
      <Breadcrumb items={breadcrumbItems} />
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          gap: 3,
        }}
      >
        {/* LEFT SECTION */}
        <Box sx={{ flex: 1 }}>
        <Box >
        <ProjectHeader title="Databricks GenAI partner recognition" />
      </Box>

          <ProjectGallery
            mainImage="./55d9b3fa6c3c0c94d9289dd5227f13c95d90481a.png"
            thumbnails={["", "", "", ""]}
          />

          <Box mt={2}>
            <ProjectTabs
              tabs={projectTabs}
              activeTab={activeTab}
              onTabChange={(id) => setActiveTab(id)}
            >
              {renderTabContent()}
            </ProjectTabs>
          </Box>
        </Box>

        {/* RIGHT SECTION */}
        <Box sx={{ flex: "0 0 360px", maxWidth: 360,mt:2 }}>
          {/* Statistics Box */}
          <Box
            sx={{
              backgroundColor: "#FAFAFA",
              border: "0px solid rgba(120,120,120,0.1)",
              pt: 2,
              pb: 4,
              px: 2,
              mb: 2,
            }}
          >
            <StatisticsCard title="Our Products" timeframe="last 48h" statistics={statistics} />
           </Box>

          {/* Team Created Box */}
          <Box
            sx={{
              backgroundColor: "white",
              border: "1px solid rgba(0,0,0,0.2)",
              borderRadius: 1,
              p: 2,
            }}
          >
            <Typography
              fontWeight={600}
              fontSize="1rem"
              color="rgba(21,23,24,1)"
              sx={{ pb: 1, borderBottom: "1px solid rgba(0,0,0,0.2)" }}
            >
              Team Created
            </Typography>

            <Box mt={2}>
              <TeamMember
                name="Demo User"
                role="Manager"
                avatar="./proimage.png"
                badge={{ label: "Team lead", variant: "blue" }}
                isActive={true}
              />
              <Box mt={2}>
                <TeamMember
                  name="Demo User2"
                  role="Manager"
                  avatar="./proimage.png"
                  badge={{ label: "Python Developer", variant: "blue" }}
                  isActive={false}
                />
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default SolutionCatalogueDetail;
