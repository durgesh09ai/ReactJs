import React from "react";
import { Container, Box } from "@mui/material";
import { CaseStudyFlow } from "../components/AddASolution/CaseStudyFlow";

const AddASolution: React.FC = () => {
  return (
    <Container sx={{ py: 1 }}>
      <CaseStudyFlow />
    </Container>
  );
};

export {AddASolution};