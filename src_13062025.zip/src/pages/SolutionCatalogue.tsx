import React from "react";
import { Container, Box } from "@mui/material";
import Breadcrumb from "../components/SolutionCatalogue/Breadcrumb";
import ActionButtons from "../components/SolutionCatalogue/ActionButtons";
import { FilterSection } from "../components/SolutionCatalogue/FilterSection";
import { ProjectsSection } from "../components/SolutionCatalogue/ProjectsSection";


const SolutionCatalogue = () => {
  const breadcrumbItems = [
    { label: "Dashboard", active: false },
    { label: "Projects Demos", active: true },
  ];

  return (
    <Container>
      <Box>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={4}>
          <Breadcrumb items={breadcrumbItems} />
          <ActionButtons />
        </Box>
        <Box maxWidth="1134px" width="100%">
          <FilterSection />
          <ProjectsSection />
        </Box>
      </Box>
    </Container>
  );
};

export default SolutionCatalogue;
