import React from "react";
import { Box } from "@mui/material";
import DetailContent from "../components/dashboard/DetailContent";

const DashboardDetail = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 4 }, // padding for responsive spacing
      }}
    >
      <DetailContent />
    </Box>
  );
};

export default DashboardDetail;
