import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import {
  Box,
  Typography,
  Avatar,
} from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import NavItem from "./NavItem";
import {mainPageStore } from "../../stores/MainPageStore"
import { Link } from "react-router-dom";

const Sidebar = observer(() => {

  const loggedInUserId = "admin@gmail.com";
  const {sidebarCollapsed,setSidebarCollapsed, sidebarData, fetchSideMenuData, sidemenuloading }  = mainPageStore;
  
  useEffect(() => {
    fetchSideMenuData();
  }, [fetchSideMenuData]);

  const collapsed = sidebarCollapsed;
  const toggleSidebar = () => {
    setSidebarCollapsed();
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh"
      px={!collapsed ? 2 : 1 }
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
    >
      {/* Top Section */}
      <Box flexGrow={1}>
        {/* Header */}
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          py={1.2}
          borderBottom="1px solid rgba(0,0,0,0.1)"
        >
          <Typography
            variant="h6"
            sx={{
              fontSize: "28px",
              fontWeight: 600,
              color: "#e7552b",
              whiteSpace: "nowrap",
              mr:"4px"
            }}
          >
            {"EXL"}
          </Typography>
            <Avatar
              src={!collapsed ? './resize.svg' : './openIcon.svg'}
              alt="Logo"
              sx={{ width: 24, height: 24,cursor:"pointer" }}
              variant="square"
              onClick= {toggleSidebar}
            />
        
        </Box>

        {/* Navigation Items */}


        {collapsed && (
        <Box display="flex" flexDirection="column" sx={{ mt: 2,textAlign:"center" }}>
          <Link to="/" style={{textDecoration:"none"}}>
          <HomeIcon sx={{color:"#888",fontSize:20}}/> 
          </Link>           
          </Box>
           )}  

        {!collapsed && (
        <Box display="flex" flexDirection="column" sx={{ mt: 2 }}>
          {/* Example Static Section Title */}
            <Typography
              sx={{
                fontSize: "12px",
                textTransform: "uppercase",
                color: "#888",
                px: 2,
                py: 1,
              }}
            >
              Home
            </Typography>
      
          <NavItem
            icon="./menuIcon.svg"
            label="Quality and Compliance"
            collapsed={collapsed}
            subItems={[
              { label: "Quality Reports", count: 5, href: "/" },
              { label: "Compliance Dashboard",
                count: 8,
                href: "/",
              },
              { label: "Audit Logs", count: 7, href: "/" },
            ]}
          />

          <NavItem
            icon="./menuIcon.svg"
            label="Data and analytics LOB"
            collapsed={collapsed}
            subItems={[
              { label: "Data Insights", count: 10, href: "/" },
              {
                label: "Analytics Dashboard",
                count: 10,
                href: "/",
              },
            ]}
          />

          <NavItem
            icon="./menuIcon.svg"
            label="Life Science LOB"
            collapsed={collapsed}
          />

          <NavItem
            icon="./menuIcon.svg"
            label="Risk Quality Measures"
            collapsed={collapsed}
          />
        </Box>
         )}

      </Box>

      {/* Footer Items pinned to bottom */}
      {!collapsed && (
        <Box mt={2}>
          <NavItem
            icon="./bookmark.svg"
            label="Bookmarked"
            showCount={false}
            collapsed={collapsed}
          />
          <NavItem
            icon="./setting.svg"
            label="Settings"
            showCount={false}
            collapsed={collapsed}
          />
        </Box>
      )}
    </Box>
  );
});

export default Sidebar;