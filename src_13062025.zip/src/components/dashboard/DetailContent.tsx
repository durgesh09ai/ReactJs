
import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import DetailStatCard from "../ui/dashboard/DetailStatCard";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import { useNavigate } from "react-router-dom";
import { mainPageStore } from "../../stores/MainPageStore";

const DetailContent = () => {
  const navigate = useNavigate();
  const userId = "admin@gmail.com";
  const { fetchStatData,
    statData,
    fetchByTypeOptions,
    fetchByTechnologyOptions,
    fetchByClientOptions,
    fetchByAnalyticsOptions,
    typeOptionsList,
    technologyOptionsList,
    clientOptionsList,
    analyticsOptionsList,
   }  = mainPageStore;

  useEffect(() => {
    fetchStatData(userId);
    fetchByTypeOptions();
    fetchByTechnologyOptions();
    fetchByClientOptions();
  }, [userId]);


  useEffect(() => {
    fetchByAnalyticsOptions();
  }, [userId]);


  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  const addSolution = () => {
    navigate("/addasolution");
  };


  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px'
    }}>

<Box 
  sx={{ 
    display: "flex", 
    justifyContent: "flex-end", 
    gap: 2 // Adjust the spacing between buttons
  }}
>
  <Button 
   onClick={addSolution}
    variant="outlined" 
    startIcon={<AddIcon />} 
    sx={{ 
      color: "#0F4977", 
      borderColor: "#0F4977",
      fontSize: "12px", // Smaller text
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
      height:'40px',
      borderRadius: '8px',
      "&:hover": {
        borderColor: "#0F4977",
        backgroundColor: "rgba(15, 73, 119, 0.04)"
      }
    }}
  >
    Add New Solution
  </Button>

  <Button 
  onClick={handleClick}
    variant="contained" 
    startIcon={<EmojiEventsIcon />} // Champion icon for "My Stat and Rank"
    sx={{ 
      color: "#FFF", 
      borderColor: "#0F4977",
      fontSize: "14px", 
      borderRadius: '8px',
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
    }}
  >
    My Stat and Rank
  </Button>
</Box>


<Stack
  direction="row"
  spacing={2}
  sx={{
    mt: 2,
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  }}
>
  {['Team', 'Total Demos', 'Total Active Projects','Most liked'].map((items, idx) => (
    <Box
      key={idx}
      sx={{
        flex: '1 1 22%', // allows shrinking a bit to fit 4
        minWidth: '200px', // fallback for mobile
        maxWidth: '25%',
      }}
    >
      <DetailStatCard
        value="125"
        label={`${items}`}
        icon="./team1.svg"
        trend="+12%"
        trendIcon="./arrow.svg"
        trendText="Since last month"
      />
    </Box>
  ))}
</Stack>



      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>
          <Box sx={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '48px'
          }}>
            
            <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
              Value Delivered Across the Payer Value Chain.
            </Typography>
          </Box>

<Paper
  sx={{
    p: 3,
    mt: 2,
    borderRadius: 2,
    border: 'none',
    boxShadow: 'none',
  }}
>
  <Stack
    direction="row"
    spacing={2}
    sx={{
      flexWrap: 'nowrap',
      minWidth: '100%',
    }}
  >
    {/* [ 'By Type', 'By Technology', 'By Client', 'By Digital & Analytics' ] */}


      <Box
        key="By Type"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By Type
        </FormLabel>
      <FilterDropdown label="By Type" />
      </FormControl>
      </Box>

       <Box
        key="By Technology"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By Technology
        </FormLabel>
      <FilterDropdown label="By Technology" />
      </FormControl>
      </Box>
      
      <Box
        key="By Client"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By Client
        </FormLabel>
      <FilterDropdown label="By Client" />
      </FormControl>
      </Box>

      <Box
        key="By Digital & Analytics"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By Digital & Analytics
        </FormLabel>
      <FilterDropdown label="By Digital & Analytics" />
      </FormControl>
      </Box>
    
  </Stack>
</Paper>


        {/* Cards Section */}
    <Box sx={{ mt: 2 }}>
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, 1fr)',
            md: 'repeat(3, 1fr)',
            lg: 'repeat(4, 1fr)',
          },
          gap: 2,
        }}
      >

        {[
          {
            icon: "./actual.svg",
            label: "Actuarial / Underwriting",
            value: "6",
          },
          {
            icon: "./benefits.svg",
            label: "Benefits Design",
            value: "8",
          },
          {
            icon: "./claim.svg",
            label: "Claims/Ops",
            value: "2",
          },
          {
            icon: "./clinical.svg",
            label: "Clinical Management",
            value: "12",
          },
          {
            icon: "./cservices.svg",
            label: "Clinical Services",
            value: "1",
          },
          {
            icon: "./custservices.svg",
            label: "Customer Services",
            value: "13",
          },
          {
            icon: "./medicalcost.svg",
            label: "Medical Cost Management",
            value: "14",
          },
          {
            icon: "./network.svg",
            label: "Network Management",
            value: "7",
          },
        ].map(({ icon, label, value }) => (
          <Box key={label}>
            <DataCard
              icon={icon}
              label={label}
              value={value}
              labelSx={{ fontWeight: 'bold', fontSize: '0.9rem' }}
            />
          </Box>
        ))}
      </Box>
    </Box>

        
        </Box>
      </Box>
    </Box>
  );
};

export default observer(DetailContent);

