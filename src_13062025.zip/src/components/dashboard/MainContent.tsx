
import React from "react";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import StatCard from "../ui/dashboard/StatCard";
import { useNavigate } from "react-router-dom";

const MainContent: React.FC = () => {

  const navigate = useNavigate();
  const addSolution = () => {
    navigate("/addasolution");
  };

  const stats = [
    {
      value: "89",
      label: "Team",
      icon: "./team1.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Total Demos",
      icon: "./team2.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Total Active Projects",
      icon: "./team3.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Most liked",
      icon: "team4.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
  ];

  const data = [
    { icon: "./actual.svg", label: "Actuarial / Underwriting", value: "6" },
    { icon: "./benefits.svg", label: "Benefits Design", value: "8" },
    { icon: "./claim.svg", label: "Claims/Ops", value: "2" },
    { icon: "./clinical.svg", label: "Clinical Management", value: "12" },
    { icon: "./cservices.svg", label: "Clinical Services", value: "1" },
    { icon: "./custservices.svg", label: "Customer Services", value: "13" },
    { icon: "./medicalcost.svg", label: "Medical Cost Management", value: "14" },
    { icon: "./medicalcost.svg", label: "Network Management", value: "7" }
  ];
  
  
  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px',
      gap: '16px',
    }}>
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'flex-end'
      }}>
        <Button 
          variant="outlined" 
          startIcon={<AddIcon />} 
          onClick={addSolution}
          sx={{ 
            color: '#0F4977', 
            borderColor: '#0F4977',
            boxShadow: '0px 1px 3px 0px rgba(96,108,128,0.05)',
            '&:hover': {
              borderColor: '#0F4977',
              backgroundColor: 'rgba(15, 73, 119, 0.04)'
            }
          }}
        >
          Add New Solution
        </Button>
      </Box>

      <Box
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    gap: '40px',
    alignSelf: 'stretch',
  }}
>  <Stack direction="row" flexWrap="wrap" spacing={2} useFlexGap>
    {stats.map((stat, index) => (
      <Box
        key={index}
        sx={{ width: { xs: '100%', md: 'calc(50% - 8px)' } }}
      >
        <StatCard
          value={stat.value}
          label={stat.label}
          icon={stat.icon}
          trend={stat.trend}
          trendIcon={stat.trendIcon}
          trendText={stat.trendText}
        />
      </Box>
    ))}
  </Stack>
</Box>


      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>


          <Box sx={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '48px'
          }}>
            <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
              Value Delivered Across the Payer Value Chain.
            </Typography>
          </Box>


          <Paper
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: '16px',
    gap: '32px',
    alignSelf: 'stretch',
    borderRadius: '8px',
    backgroundColor: '#FFF',
    border: 'none',
    boxShadow: 'none',
    mt: 2,
  }}
>
<Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
>    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
      <FormLabel  sx={{ 
                mb: 1, 
                color: '#000', 
                fontSize: '14px', 
                fontStyle: 'normal', 
                fontWeight: 400, 
                lineHeight: 'normal'
                
         }}>By Type</FormLabel> {/* Reduced font size */}
       <FilterDropdown label="by Type" />
      </FormControl>
    </Box>
    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By technology</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="By technology" />
      </FormControl>
    </Box>
  </Stack>


  <Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
>    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Client</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="By Client" />
      </FormControl>
    </Box>
    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Digital & Analytics</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="By Digital & Analytics" />
      </FormControl>
    </Box>
  </Stack>
</Paper>


<Box sx={{ mt: 2 }}>
  <Box
    sx={{
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      gap: 2, // horizontal and vertical spacing
    }}
  >
    {data.map((item, index) => (
      <Box 
        key={index} 
        sx={{ 
          width: 'calc(50% - 8px)', // two items per row with 16px total spacing
        }}
      >
        <DataCard 
          icon={item.icon} 
          label={item.label} 
          value={item.value} 
          labelSx={{ fontWeight: 'bold', fontSize: '0.9rem' }}
        />
      </Box>
    ))}
  </Box>
</Box>

        </Box>
      </Box>
    </Box>
  );
};

export default MainContent;
