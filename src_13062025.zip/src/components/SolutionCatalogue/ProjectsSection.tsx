import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Typography, Link, Stack } from "@mui/material";
import { ProjectCard } from "./ProjectCard";
import { Pagination } from "./Pagination";
import { mainPageStore } from "../../stores/MainPageStore";



const projectsData = [
  {
    id: 1,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "You & 1 other",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 2,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 3,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 4,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 5,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 6,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 7,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
  {
    id: 8,
    title: "Provider data Management",
    description:
      "Streamline collection, validation, and maintenance of provider information effortlessly.",
    tags: ["Payer", "Underwriting"],
    imageSrc: "./project_image.png",
    commentCount: 0,
    contributorCount: "1",
    badgeIconSrc: "./redthumb.svg",
    likeIconSrc: "./threedot.svg",
    starIconSrc: "./bookmark.svg",
  },
];

export const ProjectsSection = observer(() => {
  const [currentPage, setCurrentPage] = useState(1);
  const projectsPerPage = 4;
  const totalPages = Math.ceil(projectsData.length / projectsPerPage);

  const handlePageChange = (pageNumber:number) => {
    setCurrentPage(pageNumber);
  };


  const { fetchSolutionCatalogueData,
    solutionCatalogueData,
   }  = mainPageStore;

   useEffect(() => {
    fetchSolutionCatalogueData();
  }, []);


  const renderProjects = () => {
    const start = (currentPage - 1) * projectsPerPage;
    const selectedProjects = projectsData.slice(start, start + projectsPerPage);

    return (
      <Box
        display="flex"
        flexWrap="wrap"
        gap={2}
        mt={2}
        justifyContent={{ xs: "center", sm: "flex-start" }}
      >
        {selectedProjects.map((project) => (
         <Box
         key={project.id}
         sx={{
           width: {
             xs: "100%",   // 1 per row on xs
             sm: "48%",    // 2 per row on sm
             md: "31.5%",  // 3 per row on md
             lg: "23.5%",  // 4 per row on lg
           },
           flexGrow: 0,
           flexShrink: 0,
         }}
       >
            <ProjectCard {...project} />
          </Box>
        ))}
      </Box>
    );
  };

  return (
    <Box width="100%" mt={1}>
      {/* Header Section */}
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Stack direction="row" spacing={1} alignItems="center">
          <Typography variant="subtitle2" color="#1F2633" fontWeight="600" fontSize={14}>
            Projects Demo
          </Typography>
          <Box
            sx={{
              backgroundColor: "#E9F3F9",
              color: "#0F4977",
              fontSize: "10px",
              fontWeight: "800",
              borderRadius: "8px",
              width: 25,
              height: 25,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {projectsData.length}
          </Box>
        </Stack>
        <Link href="#" underline="hover" sx={{ fontSize: "10px", color: "#0F4977",fontWeight:"400" }}>
          View all
        </Link>
      </Stack>

      {/* Projects Layout */}
      {renderProjects()}

      {/* Pagination */}
      <Box mt={2}>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </Box>
    </Box>
  );
});
