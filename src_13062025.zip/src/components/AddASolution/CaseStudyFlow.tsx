import React, { useState } from "react";
import { Paper, Box } from "@mui/material";
import { SolutionTypeSelector } from "./SolutionTypeSelector";
import { ProgressStepper } from "./ProgressStepper";
import { BasicInfoForm } from "./BasicInfoForm";
import { ActionButtons } from "../ActionButtons";
import { Breadcrumb } from "./Breadcrumb";
import { TagSelector } from "./TagSelector";
import { CaseStudyDetailsForm } from "./CaseStudyDetailsForm";
import { AddUrlSection } from "./AddUrlSection";
import { TermAndGamification } from "./TermAndGamification";
import { SuccessCard } from "./SuccessCard";

interface Tag {
  id: string;
  label: string;
}

interface DocsUrl {
    id: string;
    label: string;
  }

interface Category {
  id: string;
  label: string;
}

const DocsUrls = [
    { id: "case-study", label: "Case Study.pdf" },
    { id: "product", label: "Product.pdf" },
    { id: "accelerator", label: "Accelerator.pdf" },
    { id: "demo", label: "Demo.pdf" },
    { id: "success-story", label: "Success Story.pdf" },
    { id: "product-2", label: "Product.pdf" },
    { id: "rfi-rfp", label: "RFI/RFPs.pdf" },
  ];

export const CaseStudyFlow: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSolutionType, setSelectedSolutionType] = useState("case-study");
  const [selectedTags, setSelectedTags] = useState<Tag[]>([]);
  const [selectedDocsUrl, setSelectedDocsUrl] = useState<DocsUrl[]>(DocsUrls);


  const breadcrumbItems = [
    { label: "Home", href: "/" },
    { label: "Add a project" },
  ];

  const solutionTypes = [
    { id: "case-study", label: "Case Study" },
    { id: "product", label: "Product" },
    { id: "accelerator", label: "Accelerator" },
    { id: "demo", label: "Demo" },
    { id: "success-story", label: "Success Story" },
    { id: "product-2", label: "Product" },
    { id: "rfi-rfp", label: "RFI/RFPs" },
  ];

  const categories: Category[] = [
    { id: "23", label: "Insurance" },
    { id: "30", label: "Healthcare" },
    { id: "31", label: "Banking and Capital Markets" },
    { id: "32", label: "Growth Markets" },
  ];

  const handleSolutionTypeChange = (typeId: string) => {
    setSelectedSolutionType(typeId);
  };

  const handleTagSelect = (tag: Tag) => {
    if (!selectedTags.some((t) => t.id === tag.id)) {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleTagRemove = (tagId: string) => {
    setSelectedTags(selectedTags.filter((tag) => tag.id !== tagId));
  };

  const handleDocUrlSelect = (docsUrl: DocsUrl) => {
    if (!selectedDocsUrl.some((t) => t.id === docsUrl.id)) {
        setSelectedDocsUrl([...selectedDocsUrl, docsUrl]);
    }
  };

  const handleDocUrlRemove = (DocsUrlId: string) => {
    setSelectedDocsUrl(selectedDocsUrl.filter((docsUrl) => docsUrl.id !== DocsUrlId));
  };


  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = () => {
    console.log("Saving form data...");
  };

  const handleCancel = () => {
    console.log("Cancelling...");
  };

  const steps = [
    { id: "basic", label: "Basic" },
    { id: "details", label: "Case Study Details" },
    { id: "team", label: "Team & Gamification" },
    { id: "completed", label: "Completed" },
  ];

  if(currentStep === 4){
    return (
        <Box sx={{ py: 1 }}>
          <Paper
            elevation={0}
            sx={{
              mt: 4,
              p: 4,
              bgcolor: "#0F4977",
              borderRadius: "20px",
              border: "1px solid rgba(15,73,119,1)",
            }}
          >
        <Box sx={{ flex: 7, minWidth: 0 }}>
        <SuccessCard />
        </Box>
    </Paper>
    </Box>
    )
  }



  return (
    <Box sx={{ py: 1 }}>
      <Breadcrumb items={breadcrumbItems} />

      <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          bgcolor: "rgba(243,250,255,1)",
          borderRadius: "20px",
          border: "1px solid rgba(15,73,119,1)",
        }}
      >

            <SolutionTypeSelector
            options={solutionTypes}
            defaultSelected={selectedSolutionType}
            onChange={handleSolutionTypeChange}
            />
            
        <Paper elevation={0} sx={{ mt: 1, p: 1, borderRadius: 2 }}>
           <ProgressStepper
            steps={steps.map((step, idx) => ({
              ...step,
              completed: idx  < currentStep,
              active: idx  === currentStep,
            }))}
            currentStep={currentStep}
            totalSteps={4}
          />
        
          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 2,
              mt: 2,
              width: "100%",
            }}
          >
            {/* Left column */}
            <Box sx={{ flex: 7, minWidth: 0 }}>
              {currentStep === 1 && <BasicInfoForm onSave={handleSave} />}
              {currentStep === 2 && <CaseStudyDetailsForm onSave={handleSave} />}
              {currentStep === 3 && <TermAndGamification onSave={handleSave} />}
              <Box sx={{ mt: 1 }}>
                <ActionButtons
                  onPrevious={handlePrevious}
                  onSave={handleSave}
                  onNext={handleNext}
                  isPreviousDisabled={currentStep === 1}
                  isNextDisabled={currentStep === 4}
                />
              </Box>
             
            </Box>

            {/* Right column */}
            <Box sx={{ flex: 3, minWidth: 0 }}>
              {currentStep === 1 && (
                <TagSelector
                  selectedTags={selectedTags}
                  categories={categories}
                  onTagSelect={handleTagSelect}
                  onTagRemove={handleTagRemove}
                />
              )}
              {currentStep === 2 && (
                <AddUrlSection
                  selectedDocsUrl={selectedDocsUrl}
                  onDocUrlSelect={handleDocUrlSelect}
                  onDocUrlRemove={handleDocUrlRemove}
                />
              )}
              {currentStep === 3 && <div></div>}
            </Box>
          </Box>
        </Paper>
      </Paper>
    </Box>
  );
};
