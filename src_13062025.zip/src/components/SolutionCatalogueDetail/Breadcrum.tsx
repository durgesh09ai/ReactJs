import React from "react";
import { Box, Breadcrumbs, Link, Typography } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

export interface BreadcrumbItem {
  label: string;
  href: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <nav aria-label="Breadcrumb">
      <Box
        bgcolor="white"
        py={1}
        px={0}
        display="flex"
        flexWrap="wrap"
        width="100%"
      >
        <Breadcrumbs
          separator={
            <NavigateNextIcon
              sx={{ fontSize: "0.75rem", color: "rgba(75,75,75,1)" }}
            />
          }
          sx={{
            color: "rgba(75,75,75,1)",
            fontSize: "0.875rem",
            fontWeight: 400,
            lineHeight: 1,
          }}
        >
          {items.map((item, index) => {
            const isLast = index === items.length - 1;
            return isLast ? (
              <Typography key={index} color="#4B4B4B" sx={{ whiteSpace: "nowrap" ,fontWeight:'400',fontSize:'14' }}>
                {item.label}
              </Typography>
            ) : (
              <Link
                key={index}
                href={item.href}
                underline="hover"
                sx={{
                  color: "rgba(75,75,75,1)",
                  "&:hover": { color: "rgba(30, 64, 175, 1)" }, // blue-600
                  whiteSpace: "nowrap",
                  fontWeight:400,
                  fontSize:14,
                }}
              >
                {item.label}
              </Link>
            );
          })}
        </Breadcrumbs>
      </Box>
    </nav>
  );
};
