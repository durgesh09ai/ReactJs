import React from "react";
import { Box, Chip, Stack, Typography } from "@mui/material";

interface StatisticProps {
  change: string;
  label: string;
  value: string;
}

interface StatisticsCardProps {
  title: string;
  timeframe: string;
  statistics: StatisticProps[];
}

const tags = ["Payer", "Underwriting"];

export const StatisticsCard: React.FC<StatisticsCardProps> = ({
  title,
  timeframe,
  statistics,
}) => {
  return (
    <Box width="100%">
      {/* Header */}
      <Box
        bgcolor="white"
        border="1px solid #F4F4F5"
        borderRadius="10px"
        px={2}
        py={1}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        fontWeight={500}
      >
        <Typography sx={{ color: "#151718", fontSize: "16px", fontWeight: 600 }}>
          {title}
        </Typography>
      </Box>

      {/* Content */}
      <Box
        display="flex"
        flexWrap="wrap"
        gap={3}
        mt={1}
      >
        {statistics.map((stat, index) => (
          <Box
            key={index}
            display="flex"
            width="100%"
            maxWidth="500px"
            border="1px solid #f0f0f0"
            borderRadius="10px"
            p={1}
            gap={2}
            bgcolor="white"
          >
            {/* Image */}
            <Box minWidth="100px">
              <img
                src="./project_image.png"
                alt="Project"
                width="100%"
                height="60px"
                style={{ objectFit: "cover", borderRadius: "6px" }}
              />
            </Box>

            {/* Text Content */}
            <Box display="flex" flexDirection="column" flexGrow={1}>
              <Typography fontWeight={500} fontSize="14px" mb={0.5}>
                ProtoWeave
              </Typography>
              <Typography fontSize="12px" color="text.secondary">
                Streamline collection, validation, and maintenance of provider information effortlessly.
              </Typography>

              {/* Tags */}
              <Stack direction="row" spacing={1} mt={1} flexWrap="wrap">
                {tags.map((tag, tagIndex) => (
                  <Chip
                    key={tagIndex}
                    label={tag}
                    size="small"
                    sx={{
                      fontSize: 12,
                      fontWeight: 500,
                      bgcolor:
                        tagIndex === 0 ? "rgba(233,243,249,1)" : "rgba(15,73,119,0.1)",
                      color: "rgba(15,73,119,1)",
                      borderRadius: "999px",
                      height: 20,
                    }}
                  />
                ))}
              </Stack>
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};