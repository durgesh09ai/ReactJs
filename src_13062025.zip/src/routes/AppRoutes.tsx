import { BrowserRouter, Routes, Route } from "react-router-dom";
import DashBoard from "../pages/Dashboard";
import DashboardDetail from "../pages/DashboardDetail";
import SolutionCatalogue from "../pages/SolutionCatalogue";
import SolutionCatalogueDetail from "../pages/SolutionCatalogueDetail";
import { AddASolution } from "../pages/AddASolution";
import NavigatorLayout from "../layout/NavigatorLayout/Layout";

export const AppRoutes = () => (
   <Routes>
     <Route element={<NavigatorLayout />}>
       <Route path="/" element={<DashboardDetail />} />
       <Route path="/dashboarddetail" element={<DashBoard />} />
       <Route path="/solutioncatalogue" element={<SolutionCatalogue />} />
       <Route path="/solutioncataloguedetail" element={<SolutionCatalogueDetail />} />
       <Route path="/addasolution" element={<AddASolution/>} />
    </Route>
   </Routes>
);
