import { makeAutoObservable, runInAction } from "mobx";

export class DatabricksStore {
  databricksData = {
    id:"",
    userId:"",
    api_key: "",
    databricks_url: "",
    catalog_name: "",
    schema_name: "",
  };

  loading:boolean = false;
  error: string | null = null;
  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8002";
  databrickResult:string = "";

  constructor() {
    makeAutoObservable(this);
  }

  setDatabrickResult(databrickText: string) {
    this.databrickResult = databrickText;
    console.log('databrickText::',databrickText);
  }

    fetchDatabricksData = async () => {
    this.loading = true;
    try {
      const res = await fetch(`${this.apiUrl}/databricksDB/databricks`);
      const data = await res.json();
      runInAction(() => {
        this.databricksData = data;
        this.loading = false;
      });
    } catch (err: any) {
      runInAction(() => {
        this.error = err.message || "Failed to fetch data";
        this.loading = false;
      });
    }
  }

  updateDatabricksData = async (updatedData: typeof this.databricksData) => {
    try {
      const res = await fetch(`${this.apiUrl}/databricksDB/databricks_update`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      });
  
      if (!res.ok) throw new Error("Failed to update workspace");
      runInAction(() => {
        this.databricksData = updatedData;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  postDataToDataBrick = async (data: {
    pipeline_name:string;
    diagnosis_codes_data: any[];
    start_date: string;
    end_date: string;
    config_id: string;
    research_id: string;
    workspace_id:string;
  }) => {
    try {
        const res = await fetch(`${this.apiUrl}/databricksPL/databricks_pipeline`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
     if (!res.ok) {
        throw new Error("Failed to send data to Data Brick");
      }
      } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };


}

export const databricksStore = new DatabricksStore();
