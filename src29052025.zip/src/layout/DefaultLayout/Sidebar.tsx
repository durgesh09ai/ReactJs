import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Collapse,
  Avatar,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  CircularProgress,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import SettingsIcon from "@mui/icons-material/Settings";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { observer } from "mobx-react-lite";
import { v4 as uuidv4 } from 'uuid';
import { dataProtoweaveGenAiStore } from "../../stores/cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";

const Sidebar = () => {
  const navigate = useNavigate();
  const navLinks = [{ label: "Home", to: "/" }];

  const [expanded, setExpanded] = useState({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({ research_name: "", description: "" });
  const [formErrors, setFormErrors] = useState({ research_name: false });
  const [currentSection, setCurrentSection] = useState<{ workspaceName?: string; workspace_id?: string } | null>(null);
  
  const { sidebarData ,fetchSideMenuData,sidemenuloading } = dataProtoweaveGenAiStore;

  const loggedInUserId = "admin@gmail.com";
  const thinScrollbarStyles = {
    "&::-webkit-scrollbar": {
      width: "6px",
    },
    "&::-webkit-scrollbar-track": {
      backgroundColor: "#f1f1f1",
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: "#c1c1c1",
      borderRadius: "3px",
    },
    scrollbarWidth: "thin", // For Firefox
    scrollbarColor: "#c1c1c1 #f1f1f1", // For Firefox
  };


  useEffect(() => {
    fetchSideMenuData(loggedInUserId);
  }, [fetchSideMenuData]);

  const experimentConfig = () => {
    navigate("/protoweave/experiment");
  };

  const toggleExpand = (key: string) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleOpenDialog = (section: { workspaceName?: string; workspace_id?: string }) => {
    setCurrentSection(section);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setFormData({ research_name: "", description: "" });
    setCurrentSection(null);
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.research_name.trim()) {
      setFormErrors({ research_name: true });
      return;
    }
   setFormErrors({ research_name: false }); // Clear error
   if (!currentSection?.workspace_id) {
    console.log(`workspace_id not found ${currentSection?.workspaceName} : ${currentSection?.workspace_id}`)
    return;
   }
    try {
     const newTtems =  await dataProtoweaveGenAiStore.addResearchItem({
        research_name: formData.research_name,
        description: formData.description,
        workspace_id: currentSection.workspace_id,
      });
      handleCloseDialog();
      navigate(`protoweave/research/${newTtems.id}`);
    } catch (e) {
      console.error("Error submitting form", e);
    }
  };
 
   const getItemRoute = (sectionTitle: string, id: number,research_id:string) => {
    const lower = sectionTitle.toLowerCase();
    if (lower.includes("configuration")) return `/protoweave/experiment/${id}/research/${research_id}`;
    if (lower.includes("research")) return `/protoweave/research/${id}`;
    return `/`; 
  };
  

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="100vh"
      px={2}
      py={1}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      bgcolor="#fff"
      maxWidth="300px"
      width="100%"
      boxShadow="1px 0 2px rgba(0,0,0,0.1)"
    >
      {/* Header */}
      <Box display="flex"
        alignItems="center"
        justifyContent="space-between"
        height={55}
        borderBottom="1px solid rgba(0,0,0,0.1)"
        > 
        <Box sx={{marginLeft:"15px"}}>
          <img width={70} src="/EXL_Service_logo.png"/>
        </Box>
        <Avatar
          src="/minimize.svg"
          sx={{ width: 24, height: 24 }}
          variant="square"
        />
      </Box>

      {/* Nav Links */}
      <Box sx={{
        flexGrow:1,
        overflow:"auto",
        mt:2,
        pr:1,
        ...thinScrollbarStyles,
      }}>
      <Box>
        <List disablePadding>
          {navLinks.map(({ label, to }, i) => (
            <ListItem
              key={i}
              component={Link}
              to={to}
              disablePadding
              sx={{
                textDecoration: "none",
                color: "inherit",
                px: 1,
                py: 1,
                "&:hover": {
                  backgroundColor: "#f5f5f5",
                },
              }}
            >
              <ListItemText primary={label} primaryTypographyProps={{ fontSize: "14px" }} />
            </ListItem>
          ))}
        </List>
      </Box>

      { sidemenuloading && (<Box sx={{ alignItems:"center", width:50,height:50}}><CircularProgress /></Box> )}

      {/* Workspaces */}
      {sidebarData && sidebarData.workspacelist.map((workspace, wi) => {
        const workspaceKey = `workspace-${wi}`;
        return (
          <Box key={workspaceKey} sx={{ mt: 2 }}>
          <Paper
           sx={{
              bgcolor: expanded[workspaceKey] ? "#fff" : "#F3FAFF",
              borderRadius: 2,
              p: 1,
              mx: expanded[workspaceKey] ? "2px" : 0,
              transition: "background-color 0.3s, margin 0.3s",
            }}
            elevation={expanded[workspaceKey] ? 1 : 0}
          >
            {/* Workspace Header */}
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              onClick={() => toggleExpand(workspaceKey)}
              sx={{ cursor: "pointer", py: 0.5 }}
            >
              <Typography fontSize="14px" fontWeight={600} color="#343434">
                {workspace.title}
              </Typography>
              <IconButton size="small">
                <ExpandMoreIcon
                  fontSize="small"
                  sx={{
                    transform: expanded[workspaceKey] ? "rotate(180deg)" : "rotate(0deg)",
                    transition: "0.2s",
                  }}
                />
              </IconButton>
            </Box>
        
            <Collapse in={expanded[workspaceKey]}>
              {workspace.items.map((section, si) => {
                const sectionTitle =
                  section.researchname || section.configurationname || "Experiment";
                const sectionData = section.data || [];
                return (
                  <Box key={si} mt={1}>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                      sx={{ py: 0.5 }}
                    >
                      <Typography fontSize="14px" fontWeight={500} color="#0F4977">
                        {sectionTitle}
                      </Typography>
                      <IconButton
                        size="small"
                        onClick={() =>
                          sectionTitle.toLowerCase() === "configuration"
                            ? experimentConfig()
                            : handleOpenDialog({ workspaceName: workspace.title, workspace_id: workspace.id })
                        }
                      >
                        <AddIcon fontSize="small" />
                      </IconButton>

                    </Box>
                  <List dense disablePadding>
                    {sectionData.map((item) => (
                      <ListItem
                        key={item.id}
                        sx={{ pl: 2, cursor: "pointer" }}
                        onClick={() => navigate(getItemRoute(sectionTitle, item.id,item.research_id))}
                      >
                        <ListItemText
                          primary={item.title}
                          primaryTypographyProps={{ fontSize: "13px" }}
                        />
                      </ListItem>
                    ))}
                  </List>
                  </Box>
                );
              })}
            </Collapse>
          </Paper>
        </Box>
        
        );
      })}

      {/* Settings Link */}
      <Box mt="auto" px={1} py={2}>
        <ListItem
          component={Link}
          to="/protoweave/settings"
          sx={{
            textDecoration: "none",
            color: "inherit",
            px: 1,
            py: 1,
            borderRadius: 1,
            "&:hover": {
              backgroundColor: "#f5f5f5",
            },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 }} />
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
        </ListItem>
      </Box>

      </Box>

      {/* Dialog Form */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} fullWidth maxWidth="sm">
        <DialogTitle sx={{ textAlign: "center", fontWeight: "bold", fontSize:'14px'}}>Let's Start Your Research !!</DialogTitle>
        <DialogContent>
        <TextField
            margin="dense"
            label="Give your research a name:"
            name="research_name"
            required
            fullWidth
            value={formData.research_name}
            onChange={handleFormChange}
            error={formErrors.research_name}
            helperText={formErrors.research_name ? "Research name is required!" : ""}
          />
          <TextField
            margin="dense"
            label="What is it about? (Optional)"
            name="description"
            fullWidth
            value={formData.description}
            onChange={handleFormChange}
            sx={{
              marginBottom: 0,
              '& .MuiInputBase-input': {
                fontSize: "14px",
              },
            }}
          />
          <Box>
            <Typography variant="body2" sx={{ fontWeight: "bold", fontSize: 12,mt:1 }}>
              No experiments yet?
            </Typography>
            <Typography variant="body2" sx={{ fontSize: 14 }}>
              You can add experiments to this research after creation.
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} variant="outlined" color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default observer(Sidebar);
