import React from "react";
import { Button, Stack, Typography, Box } from "@mui/material";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";

interface ActionButtonsProps {
  onCancel: () => void;
  onSave: () => void;
  saveDisabled?: boolean;
}

export const ActionButtons: React.FC<ActionButtonsProps> = ({
  onCancel,
  onSave,
  saveDisabled = false
}) => {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
      <Stack direction="row" spacing={2}>
        <Button
          onClick={onCancel}
          variant="outlined"
          startIcon={<CancelIcon />}
          sx={{
            color: "#0F4977",
            borderColor: "#0F4977",
            textTransform: "none",
            borderRadius: 1,
            py: 0.5,
            px: 2,
          }}
          aria-label="Cancel"
        >
          Cancel
        </Button>

        <Button
          onClick={onSave}
          disabled={saveDisabled}
          variant="contained"
          startIcon={<SaveIcon />}
          sx={{
            backgroundColor: "#0F4977",
            borderColor: "#0F4977",
            color: "#fff",
            textTransform: "none",
            borderRadius: 1,
            py: 0.5,
            px: 2,
            opacity: saveDisabled ? 0.5 : 1,
            cursor: saveDisabled ? "not-allowed" : "pointer",
          }}
          aria-label="Save"
        >
          Save
        </Button>
      </Stack>
    </Box>
  );
};
