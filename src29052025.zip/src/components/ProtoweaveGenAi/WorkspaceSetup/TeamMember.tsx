import React from "react";
import { Box, Chip } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';

interface TeamMemberProps {
  email: string;
  userType: string;
  removeTeamMember?: (memberList:string)=>void;

}

const TeamMember: React.FC<TeamMemberProps> = ({ email ,userType,removeTeamMember}) => {

  const isRemovable = userType!=='owner';

  const handleRemove = () => {
    if (email.trim()) {
       removeTeamMember(email);
    }
  };

  return (
    
    <Chip
      label={email}
      sx={{
        bgcolor: '#F3FAFF',
        color: '#0F4977',
        borderRadius: '1rem',
        height: 'auto',
        py: 0.5,
      }}
      onDelete={isRemovable? handleRemove : undefined}
      deleteIcon={
        isRemovable ? (
        <Box 
          component="img"
          src="../delete_team.svg"
          sx={{ width: 16, aspectRatio: 0.94, marginRight: 1 }}
          alt="Remove"
        />)
        : undefined
       
      }
      
    />



  );
};

export default TeamMember;
