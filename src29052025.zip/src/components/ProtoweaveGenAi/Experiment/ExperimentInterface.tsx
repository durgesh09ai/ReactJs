import React, { useEffect, useState } from "react";
import { Box, Button, MenuItem, Paper, Select, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography } from "@mui/material";
import FormHeader from "./FormHeader";
import ResearchInfo from "./ResearchInfo";
import CriteriaSection from "./CriteriaSection";
import MedicalCodingSection from "./MedicalCodingSection";
import ParametersSection from "./ParametersSection";
import UploadSection from "./UploadSection";
import ActionButtons from "./ActionButtons";
import { databricksStore } from "../../../stores/cip/ProtoweaveGenAiStore/DatabricksStore";
import { researchStore } from "../../../stores/cip/ProtoweaveGenAiStore/ResearchStore";
import { observer } from "mobx-react-lite";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import AddIcon from "@mui/icons-material/Add";
import { toJS } from "mobx";

interface experimentConfigrationProps{
  experimentId:string;
  researchId:string;
}

const ExperimentInterface = (props:experimentConfigrationProps) => {
  const { experimentCodeData,configurationName,experimentLoading,workspace_id,researchList,report,researchWS } = researchStore;
  const { experimentId ,researchId } = props;
  const [activeTab, setActiveTab] = useState("Configuration Form");
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());
  const [editableCodeTable, setEditableCodeTable] = useState([]);
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [researchData, setResearchData] = useState([]);


 const procedualCode = report?.procedure_code_table;
 const labTestCode = report?.labtest_code_table;

 const getworkspaceId =  researchWS?.workspace_id;

  useEffect(() => {
    if (experimentId && researchId) {
      researchStore.fetchExperiment(experimentId, researchId);
    }
  }, [experimentId, researchId]);


  useEffect(() => {
    if (experimentCodeData && Array.isArray(experimentCodeData)) {
      setEditableCodeTable(experimentCodeData);
    }
  }, [experimentCodeData]);

  useEffect(() => {
    if(experimentId && workspace_id){
      researchStore.fetchResearchList(getworkspaceId);
    }
 }, [experimentId,workspace_id]);


  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleUploadProtocol = () => {
    console.log("Upload protocol clicked");
    // Implement protocol upload functionality
  };

  const handleUploadData = () => {
    console.log("Upload data clicked");
    // Implement data upload functionality
  };

  const handleDuplicate = () => {
    console.log("Duplicate clicked");
    // Implement duplication functionality
  };



 const handleRunExperiment = async () => {
  try {
    const payload = {
      pipeline_name:"Generate_data_using_python_pyspark",
      diagnosis_codes_data: editableCodeTable,
      start_date: startDate?.toISOString().split("T")[0],  // Format as YYYY-MM-DD
      end_date: endDate?.toISOString().split("T")[0],
      config_id:experimentId,
      research_id:researchId,
      workspace_id: getworkspaceId,
    };

    console.log("Submitting experiment with payload:", payload);
    await databricksStore.postDataToDataBrick(payload);

    const dataresult = "test";
    databricksStore.setDatabrickResult(dataresult);

    //alert("Experiment submitted successfully!");
  } catch (error) {
    alert("Failed to run experiment. Check console for details.");
    console.error(error);
  }
};

 const handleCellChange = (index: number, key: string, value: string) => {
    const updated = [...editableCodeTable];
    updated[index][key as keyof typeof updated[0]] = value;
    setEditableCodeTable(updated);
  };

  const saveRow = () => {
    setEditingRowIndex(null);
    console.log("Saved Table:", editableCodeTable);
  };

  const todayDate = new Date().toLocaleDateString("en-US", {
  year: "numeric",
  month: "long",
  day: "numeric",
});

  const labelStyle = {
    width: "200px",
    fontSize: 14,
    color: "black",
    mt: 1
  };
  
  const fieldStyle = {
    flex: 1,
    minWidth: 100
  };
  
  const rowStyle = {
    display: "flex",
    alignItems: "center",
    gap: 2,
    mb: 2
  };

  const Row = ({ label, children }: { label: string, children: React.ReactNode }) => (
    <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
      <Box sx={{ minWidth: 150 }}>
        <Typography sx={{ fontSize: 14, color: "black" }}>{label}</Typography>
      </Box>
      <Box>{children}</Box>
    </Box>
  );


  return (
    <Box sx={{ maxWidth: "684px", fontSize: "0.875rem" }}>
      <FormHeader
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onUploadProtocol={handleUploadProtocol}
      />
      
      <Box 
        sx={{ 
          width: "100%", 
          bgcolor: "#D9EDFF", 
          borderRadius: "0px 12px 12px 12px",
          p: 2,
          overflow: "hidden"
        }}
      >
        <ResearchInfo
          researchData={researchList}
          researchId={researchId}
          researchName="Diabetes type1"
          experimentName={configurationName ?? 'Config'}
          createdDate={todayDate}
          ownerName="@dr.meera"
        />
        
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          borderRadius: 2,
          width: "100%"
        }}
      >
        <Typography
          sx={{
            fontWeight: "bold",
            fontSize: 14,
            color: "black",
            lineHeight: 1.2,
            mb: 2
          }}
        >
          Cohort Identification
        </Typography>

        {/* Age at Index */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Age at Index:</Typography>
          <Select
            value="40"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14 }}
          >
            <MenuItem value="10">10</MenuItem>
            <MenuItem value="20">20</MenuItem>
            <MenuItem value="40">40</MenuItem>
          </Select>
        </Box>

        {/* Race / Ethnicity */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Race / Ethnicity:</Typography>
          <Select
            value="10"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">Race1</MenuItem>
            <MenuItem value="20">Race2</MenuItem>
            <MenuItem value="40">Race3</MenuItem>
          </Select>
        </Box>

        {/* Region */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>Region:</Typography>
          <Select
            value="40"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">Region1</MenuItem>
            <MenuItem value="20">Region2</MenuItem>
            <MenuItem value="40">Region3</MenuItem>
          </Select>
        </Box>

        {/* SDOH */}
        <Box sx={rowStyle}>
          <Typography sx={labelStyle}>SDOH:</Typography>
          <Select
            value="10"
            size="small"
            sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
          >
            <MenuItem value="10">SDOH1</MenuItem>
            <MenuItem value="20">SDOH2</MenuItem>
            <MenuItem value="40">SDOH3</MenuItem>
          </Select>
        </Box>

        {/* Period of Interest */}
      <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
          <Box sx={{ width: 180 }}>
            <Typography sx={{ fontSize: 14, color: "black" }}>
              Period of Interest:
            </Typography>
          </Box>
          <Box sx={{ display: "flex", gap: 1,ml:4 }}>
            <DatePicker
              label="Start Date"
              value={startDate}
              onChange={(newDate) => setStartDate(newDate)}
              format="yyyy-MM-dd"
              slotProps={{
                textField: {
                  size: "small",
                  sx: { width: 150 ,fontSize:14 }
                }
              }}
            />
            <DatePicker
              label="End Date"
              value={endDate}
              onChange={(newDate) => setEndDate(newDate)}
              format="yyyy-MM-dd"
              slotProps={{
                textField: {
                  size: "small",
                  sx: { width: 150,fontSize:14  }
                }
              }}
            />
          </Box>
        </Box>
      </Paper>
    </LocalizationProvider>

      <Paper
      elevation={0}
      sx={{
        mt: 2,
        p: 2,
        borderRadius: 2,
        width: "100%"
      }}
      >
      <Typography
        sx={{
          fontWeight: "bold",
          fontSize: 14,
          color: "black",
          lineHeight: 1.2,
          mb: 2
        }}
      >
        Clinical Characteristic
      </Typography>

      {/* Age at Index */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Comorbidities:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Hypertension and Diabetes</MenuItem>
          <MenuItem value="20">Chronic Lung Disease and Heart Disease</MenuItem>
          <MenuItem value="40">Mental Health and Substance Use</MenuItem>
        </Select>
      </Box>

      {/* Race / Ethnicity */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Disease Specific Severity Measure:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Disease1</MenuItem>
          <MenuItem value="20">Disease2</MenuItem>
          <MenuItem value="40">Disease3</MenuItem>
        </Select>
      </Box>

      {/* Region */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Biomarkers/Labs:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Labs1</MenuItem>
          <MenuItem value="20">Labs2</MenuItem>
          <MenuItem value="40">Labs3</MenuItem>
        </Select>
      </Box>

      {/* SDOH */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Baseline Diagnosis:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Diagnosis1</MenuItem>
          <MenuItem value="20">Diagnosis2</MenuItem>
          <MenuItem value="40">Diagnosis3</MenuItem>
        </Select>
      </Box>
      </Paper>

        <Paper 
          elevation={0}
          sx={{ 
            mt: 2, 
            p: 2, 
            borderRadius: 2,
            width: "100%"
          }}
        >
          <CriteriaSection />
          {/* <MedicalCodingSection /> */}

 <Box 
        sx={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          flexWrap: "wrap",
          gap: { xs: 2, md: 3 },
          mt:4,
          mb:4,
        }}
      >
        <Typography 
        sx={{ 
            fontWeight: "bold",
            fontSize:14,
            color: "black",
            lineHeight: 1.2
        }}
        >
          Diagnosis Codes
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
           onClick={() => {
              const newRow = { Diagnosis: "", Codes: "", "Code Type": "" };
              setEditableCodeTable((prev) => [...prev, newRow]);
              setEditingRowIndex(editableCodeTable.length);
            }}
          sx={{
            borderColor: "#0F4977",
            color: "black",
            textTransform: "none",
            bgcolor: "white",
            minHeight: 32,
            "&:hover": {
              bgcolor: "#f0f7ff",
              borderColor: "#0F4977"
            }
          }}
        >
          Add codes
        </Button>
</Box>

  <Box
    sx={{
      maxHeight: 200,
      overflowY: "auto",
      border: "1px solid #ccc",
      borderRadius: 1,
    }}
  >
    { experimentLoading ? (
    <Typography>Loading..</Typography>
    )
    :(
    <Table size="small" stickyHeader>
      <TableHead>
        <TableRow  sx={{ bgcolor: "#D9EDFF" }}>
          { editableCodeTable.length>0 && Object.keys(editableCodeTable[0]).map((key) => (
            <TableCell key={key} sx={{ fontWeight: "bold" }}>
              {key}
            </TableCell>
          ))}
          <TableCell />
        </TableRow>
      </TableHead>
      <TableBody>
        {editableCodeTable && editableCodeTable.map((row, rowIndex) => (
          <TableRow
            key={rowIndex}
            hover
            onClick={() => setEditingRowIndex(rowIndex)}
          >
           {Object.entries(row).map(([key, value]) => {
                const cellValue = value as React.ReactNode;
                return (
                  <TableCell key={key}>
                    {editingRowIndex === rowIndex ? (
                      <TextField
                        value={String(value)}
                        size="small"
                        fullWidth
                        onChange={(e) => handleCellChange(rowIndex, key, e.target.value)}
                      />
                    ) : (
                      cellValue
                    )}
                  </TableCell>
                );
              })}
            <TableCell>
              {editingRowIndex === rowIndex && (
                <Button
                  variant="contained"
                  size="small"
                  onClick={(e) => {
                    e.stopPropagation();
                    saveRow();
                  }}
                >
                  Save
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
    )}
  </Box>

  {/* Procedual Code */}


  <Box 
        sx={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          flexWrap: "wrap",
          gap: { xs: 2, md: 3 },
          mt:4,
          mb:4,
        }}
      >
        <Typography 
        sx={{ 
            fontWeight: "bold",
            fontSize:14,
            color: "black",
            lineHeight: 1.2
        }}
        >
          Procedure Codes
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
         sx={{
            borderColor: "#0F4977",
            color: "black",
            textTransform: "none",
            bgcolor: "white",
            minHeight: 32,
            "&:hover": {
              bgcolor: "#f0f7ff",
              borderColor: "#0F4977"
            }
          }}
        >
          Add codes
        </Button>
</Box>

  <Box
    sx={{
      maxHeight: 200,
      overflowY: "auto",
      border: "1px solid #ccc",
      borderRadius: 1,
    }}
  >
    { experimentLoading ? (
    <Typography>Loading..</Typography>
    )
    :(
    <Table size="small" stickyHeader>
      <TableHead>
        <TableRow  sx={{ bgcolor: "#D9EDFF" }}>
          { procedualCode && procedualCode.length>0 && Object.keys(procedualCode[0]).map((key) => (
            <TableCell key={key} sx={{ fontWeight: "bold" }}>
              {key}
            </TableCell>
          ))}
          <TableCell />
        </TableRow>
      </TableHead>
      <TableBody>
        {procedualCode && procedualCode.map((row, rowIndex) => (
          <TableRow
            key={rowIndex}
          >
           {Object.entries(row).map(([key, value]) => {
                const cellValue = value as React.ReactNode;
                return (
                  <TableCell key={key}>
                    {cellValue}
                  </TableCell>
                );
              })}
            <TableCell>
              {editingRowIndex === rowIndex && (
                <Button
                  variant="contained"
                  size="small"
                 >
                  Save
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
    )}
  </Box>


   {/* labTestCode Code */}


   <Box 
        sx={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          flexWrap: "wrap",
          gap: { xs: 2, md: 3 },
          mt:4,
          mb:4,
        }}
      >
        <Typography 
        sx={{ 
            fontWeight: "bold",
            fontSize:14,
            color: "black",
            lineHeight: 1.2
        }}
        >
          LabTest Codes
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
         sx={{
            borderColor: "#0F4977",
            color: "black",
            textTransform: "none",
            bgcolor: "white",
            minHeight: 32,
            "&:hover": {
              bgcolor: "#f0f7ff",
              borderColor: "#0F4977"
            }
          }}
        >
          Add codes
        </Button>
</Box>

  <Box
    sx={{
      maxHeight: 200,
      overflowY: "auto",
      border: "1px solid #ccc",
      borderRadius: 1,
    }}
  >
    { experimentLoading ? (
    <Typography>Loading..</Typography>
    )
    :(
    <Table size="small" stickyHeader>
      <TableHead>
        <TableRow  sx={{ bgcolor: "#D9EDFF" }}>
          { labTestCode && labTestCode.length>0 && Object.keys(labTestCode[0]).map((key) => (
            <TableCell key={key} sx={{ fontWeight: "bold" }}>
              {key}
            </TableCell>
          ))}
          <TableCell />
        </TableRow>
      </TableHead>
      <TableBody>
        {labTestCode && labTestCode.map((row, rowIndex) => (
          <TableRow
            key={rowIndex}
          >
           {Object.entries(row).map(([key, value]) => {
                const cellValue = value as React.ReactNode;
                return (
                  <TableCell key={key}>
                    {cellValue}
                  </TableCell>
                );
              })}
            <TableCell>
              {editingRowIndex === rowIndex && (
                <Button
                  variant="contained"
                  size="small"
                 >
                  Save
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
    )}
  </Box>

        
        </Paper>

      <Paper
      elevation={0}
      sx={{
        mt: 2,
        p: 2,
        borderRadius: 2,
        width: "100%"
      }}
      >
      <Typography
        sx={{
          fontWeight: "bold",
          fontSize: 14,
          color: "black",
          lineHeight: 1.2,
          mb: 2
        }}
      >
       Exclusion Criteria

      </Typography>

      {/* Age at Index */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Disease Diagnosis:</Typography>
        <Select
          value="40"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1 ,fontSize:14 }}
        >
          <MenuItem value="10">Hypertension and Diabetes</MenuItem>
          <MenuItem value="20">Chronic Lung Disease and Heart Disease</MenuItem>
          <MenuItem value="40">Mental Health and Substance Use</MenuItem>
        </Select>
      </Box>

      {/* Race / Ethnicity */}
      <Box sx={rowStyle}>
        <Typography sx={labelStyle}>Deceased:</Typography>
        <Select
          value="10"
          size="small"
          sx={{ ...fieldStyle, bgcolor: "white", borderRadius: 1,fontSize:14  }}
        >
          <MenuItem value="10">Yes</MenuItem>
          <MenuItem value="20">No</MenuItem>
        </Select>
      </Box>

         <ActionButtons
        onDuplicate={handleDuplicate}
        onRunExperiment={handleRunExperiment}
        />
      </Paper>
       
     </Box>
    </Box>
  );
};

export default observer(ExperimentInterface);