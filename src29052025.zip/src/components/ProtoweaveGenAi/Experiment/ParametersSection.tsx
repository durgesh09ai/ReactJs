import React, { useState } from "react";
import { 
  Box, 
  Typography, 
  Button, 
  TextField, 
  Paper
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";

interface ParametersSectionProps {
  initialParameters?: {
    treatmentGroup: string;
    duration: string;
  };
}

const ParametersSection: React.FC<ParametersSectionProps> = ({
  initialParameters = {
    treatmentGroup: "Tamoxifen",
    duration: "24 weeks"
  }
}) => {
  const [parameters, setParameters] = useState(initialParameters);
  const [isAddingParameter, setIsAddingParameter] = useState(false);
  const [newParameter, setNewParameter] = useState({
    name: "",
    value: ""
  });

  const handleAddParameter = () => {
    setIsAddingParameter(true);
  };

  const handleSaveParameter = () => {
    if (newParameter.name && newParameter.value) {
      setParameters({
        ...parameters,
        [newParameter.name]: newParameter.value
      });
      setNewParameter({ name: "", value: "" });
    }
    setIsAddingParameter(false);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Box 
        sx={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          flexWrap: "wrap",
          gap: { xs: 2, md: 3 }
        }}
      >
       <Typography 
        sx={{ 
            fontWeight: "bold",
            fontSize:14,
            color: "black",
            lineHeight: 1.2
        }}
        >
          Study-specific Parameters
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
          onClick={handleAddParameter}
          sx={{
            borderColor: "#0F4977",
            color: "black",
            textTransform: "none",
            bgcolor: "white",
            minHeight: 32,
            "&:hover": {
              bgcolor: "#f0f7ff",
              borderColor: "#0F4977"
            }
          }}
        >
          Add Parameters
        </Button>
      </Box>
      
      <Box sx={{ mt: 2, pt: 1 }}>
        {isAddingParameter ? (
          <Box sx={{ mt: 1 }}>
            <Box sx={{ display: "flex", gap: 2, mb: 2 }}>
              <TextField
                value={newParameter.name}
                onChange={(e) => setNewParameter({...newParameter, name: e.target.value})}
                placeholder="Parameter name"
                fullWidth
                variant="outlined"
                size="small"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 1,
                    bgcolor: "white"
                  }
                }}
              />
              <TextField
                value={newParameter.value}
                onChange={(e) => setNewParameter({...newParameter, value: e.target.value})}
                placeholder="Parameter value"
                fullWidth
                variant="outlined"
                size="small"
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 1,
                    bgcolor: "white"
                  }
                }}
              />
            </Box>
            <Button 
              variant="contained" 
              onClick={handleSaveParameter}
              sx={{
                bgcolor: "#0F4977",
                borderRadius: 2,
                "&:hover": {
                  bgcolor: "#0a3256"
                }
              }}
            >
              Save
            </Button>
          </Box>
        ) : (
          <Box>
            <Paper 
              variant="outlined"
              sx={{ 
                p: 1.5, 
                borderRadius: 1,
                bgcolor: "white",
                minWidth: "60px"
              }}
            >
              <Typography variant="body2">
                Treatment Group: {parameters.treatmentGroup}
              </Typography>
            </Paper>
            
            <Paper 
              variant="outlined"
              sx={{ 
                p: 1.5, 
                mt: 1,
                borderRadius: 1,
                bgcolor: "white",
                minWidth: "60px"
              }}
            >
              <Typography variant="body2">
                Duration: {parameters.duration}
              </Typography>
            </Paper>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default ParametersSection;
