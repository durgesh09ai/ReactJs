import React, { useState } from "react";
import { 
  Box, 
  Typography, 
  Button, 
  Select, 
  MenuItem, 
  TextField, 
  Paper,
  SelectChangeEvent
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";

interface MedicalCodingProps {
  initialCodes?: {
    diagnosis: string;
    procedure: string;
    labTests: string;
  };
}

const MedicalCodingSection: React.FC<MedicalCodingProps> = ({
  initialCodes = {
    diagnosis: "C50.9, C50.1",
    procedure: "85.12, 85.20",
    labTests: "CA 15-3, BRCA1 Panel"
  }
}) => {
  const [codes, setCodes] = useState(initialCodes);
  const [isAddingCodes, setIsAddingCodes] = useState(false);
  const [newCode, setNewCode] = useState({
    type: "diagnosis",
    value: ""
  });

  const handleAddCodes = () => {
    setIsAddingCodes(true);
  };

  const handleSaveCodes = () => {
    if (newCode.value.trim()) {
      setCodes({
        ...codes,
        [newCode.type]: newCode.value
      });
      setNewCode({ type: "diagnosis", value: "" });
    }
    setIsAddingCodes(false);
  };

  const handleTypeChange = (event: SelectChangeEvent) => {
    setNewCode({...newCode, type: event.target.value});
  };

  return (
    <Box sx={{ width: "100%", mt: 4 }}>
      <Box 
        sx={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          flexWrap: "wrap",
          gap: { xs: 2, md: 3 }
        }}
      >
        <Typography 
        sx={{ 
            fontWeight: "bold",
            fontSize:14,
            color: "black",
            lineHeight: 1.2
        }}
        >
          Medical Coding
        </Typography>
        
        <Button
          variant="outlined"
          startIcon={<AddIcon />}
          onClick={handleAddCodes}
          sx={{
            borderColor: "#0F4977",
            color: "black",
            textTransform: "none",
            bgcolor: "white",
            minHeight: 32,
            "&:hover": {
              bgcolor: "#f0f7ff",
              borderColor: "#0F4977"
            }
          }}
        >
          Add codes
        </Button>
      </Box>

      {isAddingCodes ? (
        <Box sx={{ mt: 2 }}>
          <Box sx={{ display: "flex", gap: 2, mb: 2 }}>
            <Select
              value={newCode.type}
              onChange={handleTypeChange}
              size="small"
              sx={{
                bgcolor: "white",
                borderRadius: 1,
                minWidth: 130
              }}
            >
              <MenuItem value="diagnosis">Diagnosis</MenuItem>
              <MenuItem value="procedure">Procedure</MenuItem>
              <MenuItem value="labTests">Lab Tests</MenuItem>
            </Select>
            
            <TextField
              value={newCode.value}
              onChange={(e) => setNewCode({...newCode, value: e.target.value})}
              placeholder="Enter codes separated by commas"
              fullWidth
              variant="outlined"
              size="small"
              sx={{
                '& .MuiOutlinedInput-root': {
                  borderRadius: 1,
                  bgcolor: "white"
                }
              }}
            />
          </Box>
          
          <Button 
            variant="contained" 
            onClick={handleSaveCodes}
            sx={{
              bgcolor: "#0F4977",
              borderRadius: 2,
              "&:hover": {
                bgcolor: "#0a3256"
              }
            }}
          >
            Save
          </Button>
        </Box>
      ) : (
        <>
          <Paper 
            variant="outlined"
            sx={{ 
              p: 1.5, 
              mt: 1, 
              borderRadius: 1,
              bgcolor: "white",
              minWidth: "60px"
            }}
          >
            <Typography variant="body2">
              Diagnosis Codes: {codes.diagnosis}
            </Typography>
          </Paper>
          
          <Paper 
            variant="outlined"
            sx={{ 
              p: 1.5, 
              mt: 1, 
              borderRadius: 1,
              bgcolor: "white",
              minWidth: "60px"
            }}
          >
            <Typography variant="body2">
              Procedure Codes: {codes.procedure}
            </Typography>
          </Paper>
          
          <Paper 
            variant="outlined"
            sx={{ 
              p: 1.5, 
              mt: 1, 
              borderRadius: 1,
              bgcolor: "white",
              minWidth: "60px"
            }}
          >
            <Typography variant="body2">
              Lab Tests: {codes.labTests}
            </Typography>
          </Paper>
        </>
      )}
    </Box>
  );
};

export default MedicalCodingSection;
