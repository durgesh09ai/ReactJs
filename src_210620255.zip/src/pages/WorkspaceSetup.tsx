import React, { useState } from "react";
import { Box, Container } from "@mui/material";
import UserProfile from "../components/UserProfile/UserProfile";
import Sidebar from "../components/WorkspaceSetup/Sidebar";
import SolutionPanel  from "../components/WorkspaceSetup/SolutionPanel";

const WorkspaceSetup: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState("User Profile");

  const renderContent = () => {
    switch (selectedItem) {
      case "User Profile":
        return <UserProfile />;
      case "Manage Solutions":
         return <SolutionPanel />;
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="xl" sx={{m:0,p:0}}>
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          bgcolor: '#fff',
          p: 0,
          borderRadius: 2,
          justifyContent: 'center',
          alignItems: 'flex-start',
          my: 1
          }}
      >
        <Sidebar selectedLabel={selectedItem} onSelect={setSelectedItem} />
        <Box sx={{ flexGrow: 1, minWidth: "82%" }}>
          {renderContent()}
        </Box>
      </Box>
    </Container>
  );
};

export default WorkspaceSetup;
