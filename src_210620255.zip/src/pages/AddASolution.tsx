import React from "react";
import { Container, Box } from "@mui/material";
import { SolutionFormFlow } from "../components/AddASolution/SolutionFormFlow";

const AddASolution: React.FC = () => {
  return (
    <Container sx={{ py: 1 }}>
      <SolutionFormFlow />
    </Container>
  );
};

export {AddASolution};