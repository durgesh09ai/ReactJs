import React from 'react';
import {
  Box,
  Typography,
  IconButton,
  Chip,
  Card,
  CardContent,
  CardMedia,
  Stack,
  Avatar,
} from '@mui/material';

interface ProductCardProps {
  id: string;
  name: string;
  description: string;
  tags:string[];
  profile_img: string;
  views:number;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  description,
  tags,
  profile_img,
  views
}) => {

  const starIconSrc = '/threedot.svg';
  const likeIconSrc = '/bookmark.svg';
  const imageUrl = "/project_image.png";

  return (
    <Card
      elevation={1}
      sx={{
        display: 'flex',
        flexDirection: 'row',
        p: 1,
        borderRadius: 2,
        border: '1px solid rgba(172,172,172,0.2)',
        minWidth: "280",
        gap: 1,
      }}
    >
      <CardMedia
        component="img"
        image={imageUrl}
        alt={`${name} preview`}
        sx={{
          width: "40%",
          height: 'auto',
          objectFit: 'contain',
          borderRadius: 1
        }}
      />

      <CardContent sx={{ flex: 1, p: 0 ,'&:last-child': { pb: 0 } }}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="subtitle1" fontWeight={500} fontSize={14}>
            {name}
          </Typography>
          <Stack 
            direction="row" 
            spacing={1} 
            alignItems="center" 
            justifyContent="flex-end" 
            sx={{ minHeight: 24 }}
          >
            <Avatar src={`${starIconSrc}`} alt="star icon" sx={{ width: 16, height: 16 }} />
            <Avatar src={`${likeIconSrc}`} alt="like icon" sx={{ width: 16, height: 16 }} />
          </Stack>
        </Box>

        <Typography
          color="text.secondary"
          sx={{ mt: 0.5, mb: 0,fontSize:"12px" }}
        >
          {description}
        </Typography>

        <Box display="flex" gap={1} flexWrap="wrap">
          {tags.map((badge, index) => (
            <Chip
              key={index}
              label={badge}
              color={'secondary'}
              size="small"
            />
          ))}
        </Box>
      </CardContent>

 
    </Card>
  );
};