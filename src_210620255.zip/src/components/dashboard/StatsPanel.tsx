import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";
import UserProfile from "../ui/dashboard/UserProfile";
import LeaderboardItem from "../ui/dashboard/LeaderboardItem";
import LeaderboardFilterDropdown from "../ui/dashboard/LeaderboardFilterDropdown";
import { useNavigate } from "react-router-dom";

const StatsPanel  = () => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };

  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "365px",
        p: 1,
      }}
    >
     <Button
    onClick={handleClick}
  fullWidth
  sx={{
    backgroundColor: "white",
    borderRadius: "20px",
    px: 2,
    py: 1.5,
    textTransform: "none",
    fontWeight: 500,
    fontSize: "0.875rem",
    color: "black",
    display: "flex",
    alignItems: "center",
    gap: 2,
    justifyContent: "flex-start", // ✅ THIS makes it left-aligned
  }}
>
  <Avatar
    src="./rightarrow.svg"
    alt="Close"
    sx={{ width: 18, height: 18, borderRadius: "8px" }}
  />
<Typography
  sx={{
    my: "auto",
    color: "#000",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 500,
    lineHeight: "normal"
  }}
>
  Close My stats & rank
</Typography>
</Button>


      <UserProfile
        name="Umesh jain"
        role="Sales & info manager"
        avatar="./b522349175b734ad87f721737d0337e9eac00b6e.png"
        points={453}
      />

      {/* Leaderboard Filter Box (No Shadow) */}
      <Box
        sx={{
          display: "flex",
          padding: "0px 8px 16px 8px",
          flex: "1 0 0",
          flexDirection: "column",
          alignItems: "center",
          overflow: "hidden",
          alignSelf: "stretch",
          borderRadius: "12px",
          backgroundColor: "#FFF",
        }}
      >
        <Box
          sx={{
            backgroundColor: "white",
            borderTopLeftRadius: 1,
            px: 2,
            py: 1,
          }}
        >
        <Box>
        <Typography variant="h6" fontSize={16} fontWeight={600}>
        Leaderboard Filter
        </Typography>
        </Box>
        </Box>

        <Box sx={{ width: "100%", py: 2 }}>
          <Stack spacing={2}>
            {["IMU", "SGU", "Timeframe"].map((label, index) => (
              <Box key={index}>
                <Typography variant="body2" fontWeight={500} mb={0.5}>
                  {label}
                </Typography>
                <LeaderboardFilterDropdown
                  label={label === "Timeframe" ? "This month" : "Healthcare"}
                />
              </Box>
            ))}
          </Stack>

          <Box mt={4}>
            <Typography
              variant="h6"
              fontSize={16}
              fontWeight={600}
              align="center"
              mb={2}
            >
              Top 3 Contributors
            </Typography>

            <LeaderboardItem
              image="./593b94be8cb9a648463cfeb0e0358289550ff142.png"
              rank={1}
              name="Abhishek Wadhwa"
            />
            <LeaderboardItem
              image="./f8c93e7ce2bd0551f68f73336b86944c8fba3ef3.png"
              rank={2}
              name="Abhishek Wadhwa"
            />
            <LeaderboardItem
              image="./591c01d24467f2c2a8d6c083930c05d2ace27632.png"
              rank={3}
              name="Abhishek Wadhwa"
            />
          </Box>


          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
  <Button
    variant="outlined"
    sx={{
      fontSize: "0.75rem",
      textTransform: "none",
      borderColor: "#0F4977",
      color: "#0F4977",
      borderRadius: 2,
      px: 2,
      py: 1.2,
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
      borderWidth: '1px',
    }}
  >
    View Top contributors
  </Button>
</Box>

        </Box>
      </Box>
    </Paper>
  );
};

export default StatsPanel;
