import React, { useState, useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export interface BasicInfoFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

export const CaseStudyDetailsForm: React.FC<BasicInfoFormProps> = ({
  data,
  onDataChange,
}) => {
  const [formData, setFormData] = useState<any>(data || {});

  // Prevent infinite loop by checking deep equality before setting state
  useEffect(() => {
    if (JSON.stringify(data) !== JSON.stringify(formData)) {
      setFormData(data || {});
    }
  }, [data]);

  // Notify parent when formData changes
  useEffect(() => {
    if (typeof onDataChange === "function") {
      onDataChange(formData);
    }
  }, [formData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({ ...prev, [name]: value }));
  };

  const handleArrayFieldChange = (field: string, value: any[]) => {
    setFormData((prev: any) => ({ ...prev, [field]: value }));
  };

  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "320px",
  };

  const createSelectSection = (
    title: string,
    field: string,
    options: { key: string; label: string }[]
  ) => (
    <Box sx={{ width: 260 }}>
      <Typography variant="body2" gutterBottom>
        {title}
      </Typography>
      <Autocomplete
        multiple
        options={options}
        disableCloseOnSelect
        value={formData[field] || []}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => handleArrayFieldChange(field, newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null}
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label={`Select ${title}`}
            placeholder={`Select ${title}`}
            size="small"
            InputLabelProps={{ sx: { fontSize: 14 } }}
          />
        )}
      />
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {(formData[field] || []).map((item: any) => (
          <Chip
            key={item.key}
            label={item.label}
            onDelete={() =>
              handleArrayFieldChange(
                field,
                formData[field].filter((v: any) => v.key !== item.key)
              )
            }
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>
  );

  const sectionData = {
    workType: [
      { key: "reporting", label: "Reporting/MI" },
      { key: "strategy", label: "Strategy" },
      { key: "analytics", label: "Analytics Data Management" },
      { key: "modeling", label: "Modeling" },
      { key: "management", label: "Model Risk Management" },
      { key: "monitoring", label: "Model Monitoring" },
      { key: "engineering", label: "Data Engineering" },
      { key: "software", label: "Software Engineering" },
      { key: "others", label: "Others" },
    ],
    scopeComplexity: [
      { key: "simple", label: "Simple" },
      { key: "medium", label: "Medium" },
      { key: "complex", label: "Complex" },
    ],
    valueProposition: [
      { key: "supplying-talent", label: "Supplying Talent" },
      { key: "influence-analytics-output", label: "Influence Analytics Output" },
      { key: "influence-business-outcomes", label: "Influence Business Outcomes" },
    ],
    AIMLPenetration: [
      { key: "no-ai-ml", label: "No AI-ML" },
      { key: "basic-ml", label: "Basic ML" },
      { key: "advanced-ai-ml", label: "Advanced AI-ML" },
    ],
    degreeofClient: [
      { key: "no-advocacy", label: "No Advocacy" },
      { key: "internal-advocacy", label: "Internal Advocacy" },
      { key: "external-advocacy", label: "External Advocacy" },
    ],
  };

  return (
    <Paper elevation={0} sx={{ width: "100%", flexGrow: 1, p: 2, minHeight: "582px" }}>
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" style={{ width: "20px", height: "20px" }} />
          <Typography variant="subtitle1">Case Study Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">General Information</Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 2,
            alignItems: "flex-start",
            width: "100%",
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ flex: 1 }}>
            {createSelectSection("Work Type", "workType", sectionData.workType)}
            {createSelectSection("Scope Complexity", "scopeComplexity", sectionData.scopeComplexity)}
            {createSelectSection("Value Proposition", "valueProposition", sectionData.valueProposition)}
            {createSelectSection("AI-ML Penetration", "AIMLPenetration", sectionData.AIMLPenetration)}

            <Typography variant="body2" gutterBottom>Case Study Details</Typography>
            <TextField
              name="caseStudyDetails"
              value={formData.caseStudyDetails || ""}
              onChange={handleChange}
              label="Case Study Details"
              placeholder="Enter Case Study Details"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />

            <Typography variant="body2" gutterBottom>Solution</Typography>
            <TextField
              name="solution"
              value={formData.solution || ""}
              onChange={handleChange}
              label="Solution"
              placeholder="Enter Solution Detail"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />
          </Stack>

          {/* Right Column */}
          <Stack spacing={2} sx={{ flex: 1 }}>
            <Typography variant="body2" gutterBottom>Scope Complexity Description</Typography>
            <TextField
              name="scopeDescription"
              value={formData.scopeDescription || ""}
              onChange={handleChange}
              label="Scope Complexity Description"
              placeholder="Enter Description"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />

            <Typography variant="body2" gutterBottom>Value Proposition Description</Typography>
            <TextField
              name="valuePropositionDescription"
              value={formData.valuePropositionDescription || ""}
              onChange={handleChange}
              label="Value Proposition Description"
              placeholder="Enter Description"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />

            {createSelectSection("Degree of Client Advocacy", "degreeofClient", sectionData.degreeofClient)}

            <Typography variant="body2" gutterBottom>Problem Detail</Typography>
            <TextField
              name="problem"
              value={formData.problem || ""}
              onChange={handleChange}
              label="Problem"
              placeholder="Enter Problem"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />

            <Typography variant="body2" gutterBottom>Outcome Detail</Typography>
            <TextField
              name="outcome"
              value={formData.outcome || ""}
              onChange={handleChange}
              label="Outcome"
              placeholder="Enter Outcome"
              multiline
              rows={4}
              size="small"
              sx={textFieldStyle}
              InputProps={{ sx: inputStyle }}
            />
          </Stack>
        </Box>
      </Stack>
    </Paper>
  );
};
