import React, { useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface ClientStoryDetailsFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

const degreeofClientAdvocacy = [
  { key: "no-advocacy", label: "No Advocacy" },
  { key: "internal-advocacy", label: "Internal Advocacy" },
  { key: "external-advocacy", label: "External Advocacy" },
];

const solutionsInvolved = [
  { key: "case-studies", label: "Case Studies" },
  { key: "accelerator", label: "Accelerator" },
  { key: "framework", label: "Framework" },
  { key: "product", label: "Product" },
  { key: "rfi-rfp", label: "RFI/RFP" },
];

export const ClientStoryDetailsForm: React.FC<ClientStoryDetailsFormProps> = ({ data, onDataChange }) => {
  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const handleDeleteChip = (field: string, key: string) => {
    const updated = (data[field] || []).filter((item: any) => item.key !== key);
    onDataChange({ ...data, [field]: updated });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onDataChange({ ...data, [name]: value });
  };

  return (
    <Paper elevation={0} sx={{ width: { xs: "100%", md: "704px" }, flexGrow: 1, p: 2, minHeight: "480px" }}>
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" style={{ width: "20px", height: "20px" }} />
          <Typography variant="subtitle1">Client Story Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">General Information</Typography>

        <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, columnGap: 2, rowGap: 2, justifyContent: "flex-start", alignItems: "flex-start", width: '100%' }}>
          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box>
              <Typography variant="body2" gutterBottom>Opportunity</Typography>
              <TextField
                name="opportunity"
                value={data.opportunity || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={{ width: "320px" }}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Opportunity Detail"
                multiline
                rows={4}
              />
            </Box>

            <Box sx={{ width: 320 }}>
              <Typography variant="body2" gutterBottom>Degree of client advocacy</Typography>
              <Autocomplete
                multiple
                options={degreeofClientAdvocacy}
                disableCloseOnSelect
                value={data.clientAdvocacy || []}
                getOptionLabel={(option) => option.label}
                onChange={(_, newValue) => onDataChange({ ...data, clientAdvocacy: newValue })}
                isOptionEqualToValue={(option, value) => option.key === value.key}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Degree of Advocacy"
                    placeholder="Select Degree of Advocacy"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.clientAdvocacy || []).map((item: any) => (
                  <Chip
                    key={item.key}
                    label={item.label}
                    onDelete={() => handleDeleteChip("clientAdvocacy", item.key)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>
          </Stack>

          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box>
              <Typography variant="body2" gutterBottom>Storyline Editor</Typography>
              <TextField
                name="storyline"
                value={data.storyline || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={{ width: "320px" }}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Value Proposition Description"
                multiline
                rows={4}
              />
            </Box>

            <Box sx={{ width: 320 }}>
              <Typography variant="body2" gutterBottom>Solutions Involved</Typography>
              <Autocomplete
                multiple
                options={solutionsInvolved}
                disableCloseOnSelect
                value={data.solutionsInvolved || []}
                getOptionLabel={(option) => option.label}
                onChange={(_, newValue) => onDataChange({ ...data, solutionsInvolved: newValue })}
                isOptionEqualToValue={(option, value) => option.key === value.key}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Solutions"
                    placeholder="Select Solutions"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.solutionsInvolved || []).map((item: any) => (
                  <Chip
                    key={item.key}
                    label={item.label}
                    onDelete={() => handleDeleteChip("solutionsInvolved", item.key)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>
          </Stack>
        </Box>

        <Box>
          <Typography variant="body2" gutterBottom>Results / Outcomes</Typography>
          <TextField
            name="results"
            value={data.results || ""}
            onChange={handleChange}
            variant="outlined"
            size="small"
            sx={{ width: "680px" }}
            InputProps={{ sx: inputStyle }}
            placeholder="Enter Results / Outcomes"
            multiline
            rows={4}
          />
        </Box>
      </Stack>
    </Paper>
  );
};
