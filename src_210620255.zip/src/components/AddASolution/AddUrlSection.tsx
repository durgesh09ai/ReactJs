import React, { useState } from "react";
import {
  Box,
  Paper,
  TextField,
  Typography,
  Chip,
  Button,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";
import { observer } from "mobx-react-lite";
import { solutionFormStore } from "../../stores/SolutionFormStore";

interface DocsUrl {
  id: string;
  label: string;
}

const StyledChip = styled(Chip)(() => ({
  backgroundColor: "rgba(243,250,255,1)",
  borderRadius: "16px",
  "& .MuiChip-deleteIcon": {
    color: "rgba(15,73,119,1)",
  },
}));

export const AddUrlSection: React.FC = observer(() => {
  const [showForm, setShowForm] = useState(false);
  const [url, setUrl] = useState("");

  // Directly access observable MobX data (no duplication in local state)
  const selectedDocsUrl: DocsUrl[] = Array.isArray(solutionFormStore.formData["docsUrl"])
    ? solutionFormStore.formData["docsUrl"]
    : [];

  const updateDocs = (docs: DocsUrl[]) => {
    solutionFormStore.updateStepData("docsUrl", docs);
  };

  const handleAdd = () => {
    if (!url.trim()) return;
    const newDoc: DocsUrl = {
      id: Date.now().toString(),
      label: url.trim(),
    };
    updateDocs([...selectedDocsUrl, newDoc]);
    setUrl("");
    setShowForm(false);
  };

  const handleRemove = (id: string) => {
    const updated = selectedDocsUrl.filter((doc) => doc.id !== id);
    updateDocs(updated);
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: 1,
        borderColor: "rgba(15,73,119,0.1)",
        borderRadius: 2,
        minWidth: "240px",
        minHeight: "502px",
        flexGrow: 1,
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          p: 1,
          borderBottom: 2,
          borderColor: "#0c3b61",
        }}
      >
        <Typography variant="body2" sx={{ fontWeight: 500 }}>
          Reference Document URLs
        </Typography>
        <Button
          variant="contained"
          size="small"
          sx={{
            backgroundColor: "#0F4977",
            borderRadius: "8px",
            color: "#fff",
            textTransform: "none",
            fontSize: "0.75rem",
            padding: "4px 12px",
            minWidth: "unset",
            "&:hover": {
              backgroundColor: "#0c3b61",
            },
          }}
          onClick={() => setShowForm((prev) => !prev)}
        >
          +
        </Button>
      </Box>

      {/* Input form */}
      {showForm && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 1 }}>
          <Typography variant="body2" gutterBottom>
            Add Document URL:
          </Typography>
          <TextField
            placeholder="https://example.com/doc.pdf"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            size="small"
            fullWidth
          />
          <Button
            variant="contained"
            size="small"
            onClick={handleAdd}
            sx={{
              alignSelf: "flex-start",
              backgroundColor: "#0F4977",
              textTransform: "none",
              fontSize: "0.75rem",
              "&:hover": {
                backgroundColor: "#0c3b61",
              },
            }}
          >
            Add
          </Button>
        </Box>
      )}

      {/* Selected URLs */}
      <Box sx={{ display: "flex", flexDirection: "column", gap: 1, p: 2 }}>
        {selectedDocsUrl.length > 0 && (
          <Typography variant="body2" sx={{ fontWeight: 500, fontSize: "12px" }}>
            Selected Documents
          </Typography>
        )}
        {selectedDocsUrl.map((docUrl) => (
          <StyledChip
            key={docUrl.id}
            sx={{ fontSize: 12, color: "#0c3b61" }}
            label={
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <InsertDriveFileIcon sx={{ fontSize: 16, color: "#0c3b61" }} />
                <span>{docUrl.label}</span>
              </Box>
            }
            onDelete={() => handleRemove(docUrl.id)}
            size="small"
          />
        ))}
      </Box>
    </Paper>
  );
});
