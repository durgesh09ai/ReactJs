import React, { useState, useEffect } from "react";
import {
  Typography,
  Box,
  Paper,
  Radio,
  RadioGroup,
  FormControlLabel,
  Stack
} from "@mui/material";

interface SolutionType {
  id: string;
  label: string;
}

interface SolutionTypeSelectorProps {
  options: SolutionType[];
  defaultSelected?: string;
  onChange?: (selectedId: string) => void;
  disabled?: boolean; 
}

export const SolutionTypeSelector: React.FC<SolutionTypeSelectorProps> = ({
  options,
  defaultSelected,
  onChange,
  disabled = false, // ✅ Default to false
}) => {
  const [selected, setSelected] = useState<string>(defaultSelected || "");

  useEffect(() => {
    if (defaultSelected) {
      setSelected(defaultSelected);
    }
  }, [defaultSelected]);

  const handleSelect = (id: string) => {
    setSelected(id);
    if (onChange) {
      onChange(id);
    }
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Typography variant="body1" sx={{ mb: 1 }}>
        Add a solution type
      </Typography>

      <RadioGroup
        value={selected}
        onChange={(e) => handleSelect(e.target.value)}
        row
      >
        <Stack
          direction="row"
          spacing={1}
          sx={{ flexWrap: 'nowrap', overflowX: 'auto' }}
        >
          {options.map((option) => (
            <Paper
              key={option.id}
              elevation={0}
              sx={{
                border: 1,
                borderColor: 'rgba(211,209,209,0.4)',
                borderRadius: 2,
                px: 1,
                py: 0.5,
                minWidth: 100,
                height: 40,
                display: 'flex',
                alignItems: 'center',
                opacity: disabled ? 0.5 : 1, // ✅ Visual cue
              }}
            >
              <FormControlLabel
                value={option.id}
                control={
                  <Radio
                    disabled={disabled} // ✅ Disable radio
                    size="small"
                    sx={{
                      color: 'rgba(211,209,209,0.4)',
                      '&.Mui-checked': {
                        color: 'rgba(15,73,119,1)',
                      },
                      p: 0.5
                    }}
                  />
                }
                label={option.label}
                disabled={disabled} // ✅ Disable label click
                sx={{
                  m: 0,
                  '.MuiFormControlLabel-label': {
                    fontSize: '0.7rem'
                  }
                }}
              />
            </Paper>
          ))}
        </Stack>
      </RadioGroup>
    </Box>
  );
};