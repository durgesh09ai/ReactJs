import React, { useState } from "react";
import { Box, Button, Paper } from "@mui/material";
import ProfileHeader from "./ProfileHeader";
import ProfileFormField from "./ProfileFormField";
import ProfilePicture from "./ProfilePicture";



interface UserProfileProps {
  initialData?: {
    name: string;
    contact: string;
    email: string;
    profilePicture: string;
  };
}

 const UserProfile: React.FC<UserProfileProps> = ({
  initialData = {
    name: "Dr.Anil",
    contact: "98217836",
    email: "abcd@gmail.com",
    profilePicture: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a12264b35f1b63095e4f5d76a1ef582c1253aaee?placeholderIfAbsent=true"
  }
}) => {
  const [userData, setUserData] = useState(initialData);

  const handleEditPhoto = () => {
    // In a real application, this would open a file picker or modal
    console.log("Edit photo clicked");
  };

  const handleUpdate = () => {
    console.log("Update clicked");
  };

  return (
    <Paper 
      elevation={1}
      sx={{ 
        maxWidth: "100%",
        pb: "20px",
        px: 1,
        borderRadius: 1
      }}
    >
      <ProfileHeader title="User Profile" />
      
      <Box 
        sx={{ 
          display: "flex",
          width: "100%", 
          gap: 4,
          flexWrap: "wrap",
          alignItems: "stretch"
        }}
      >
        <Box 
          sx={{ 
            display: "flex",
            flexDirection: "column",
            minWidth: 300,
            width: "340px",
            justifyContent: "center",
            whiteSpace: "nowrap"
          }}
        >
          <ProfileFormField label="Name" value={userData.name} />
          <ProfileFormField label="Contact" value={userData.contact} />
          <ProfileFormField label="Email" value={userData.email} />
          <Button
            variant="contained"
            sx={{ mt: 2, alignSelf: "flex-start" }}
            onClick={handleUpdate}
          >
            Update
          </Button>
        </Box>
        
        <ProfilePicture 
          imageUrl={userData.profilePicture} 
          onEditClick={handleEditPhoto} 
        />
      </Box>
    </Paper>
  );
};

export default UserProfile;
