import { makeAutoObservable, runInAction } from "mobx";
import { API_BASE_URL } from "./config/config";

export class SolutionFormStore {
  formData: Record<string, any> = {};

  constructor() {
    makeAutoObservable(this);
  }

  updateStepData(stepKey: string, data: any) {
    this.formData[stepKey] = data;
  }

  getStepData(stepKey: string) {
    return this.formData[stepKey] || {};
  }

  async submit() {
    console.log("Submitting", this.formData);
    // await axios.post("/api/submit", this.formData);
  }

  reset() {
    this.formData = {};
  }
}

export const solutionFormStore = new SolutionFormStore();
