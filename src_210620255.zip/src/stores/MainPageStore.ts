import { makeAutoObservable, runInAction } from "mobx";
import { API_BASE_URL } from "./config/config";

export type dropDownItems = {
  id:string;
  name:string;
}

export type statItems = {
  solution_type:string;
  count:number;
}

export class MainPageStore {
  data: any = null;
  loading: boolean = false;
  sidemenuloading:boolean = false;
  catalogloading: boolean = false;
  bussinessunitloading:boolean = false;
  solutionlistloading:boolean=false;
  error: string | null = null;
  sidebarCollapsed:boolean = true;
  apiUrl: string = API_BASE_URL;
  sidebarData: any = null;
  statData: statItems[] = [];
  statDataByUser: statItems[] = [];
  typeOptionsList: any = null;
  technologyOptionsList: dropDownItems[] = [];
  clientOptionsList:  dropDownItems[] = [];
  analyticsOptionsList:  dropDownItems[] = [];
  payerValueChain:string[] = [];
  solutionCatalogueData: any = null;
  filterOptionsList:  dropDownItems[] = [];
  bussinessUnitListData: any = null;
  solutionListData: any = null;


  constructor() {
    makeAutoObservable(this);
  }

  setSidebarCollapsed = () => {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  fetchSideMenuData = async () => {
    console.log('connection:::',API_BASE_URL)
    try {
      this.sidemenuloading = true;
      const res = await fetch(`${this.apiUrl}/dashboard/leftmenulist`);
      if (!res.ok) throw new Error("Failed to fetch sidemenu data");
      const data = await res.json();
      runInAction(() => {
        this.sidebarData = data;
        this.sidemenuloading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchFillerListData = async (filters:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/filter_lists?filter=${filters}`);
      if (!res.ok) throw new Error("Failed to fetch filter list");
      const data = await res.json();
      return data;
     } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
    return [];
  };

 
  fetchStatData = async (userId?:number) => {
   // let parameter ='';
    try {
      this.loading = true;
      // if(userId){
      // parameter = `?userid=${userId}`;
      // }
      const res = await fetch(`${this.apiUrl}/dashboard/subtypes_count`);
      if (!res.ok) throw new Error("Failed to fetch datastate data");
      const data = await res.json();
      runInAction(() => {
        this.loading = false;
      });
      return data;
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchStatDataByUser = async (userId?:number) => {
     try {
       this.loading = true;
       const res = await fetch(`${this.apiUrl}/dashboard/subtypes_count?userid=${userId}`);
       if (!res.ok) throw new Error("Failed to fetch datastate data");
       const data = await res.json();
       runInAction(() => {
         this.loading = false;
         this.statDataByUser = data;
       });
     } catch (e: any) {
       runInAction(() => {
         this.error = e.message;
       });
     }
   };


  fetchByTypeOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/typelist`);
      if (!res.ok) throw new Error("Failed to fetch Type List");
      const data = await res.json();
        runInAction(() => {
        this.typeOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Type List options:", error);
    }
  }


  fetchByTechnologyOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/techlist`);
      if (!res.ok) throw new Error("Failed to fetch Technology List");
      const data = await res.json();
        runInAction(() => {
        this.technologyOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Technology List options:", error);
    }
  }

  fetchByClientOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/clientlist`);
      if (!res.ok) throw new Error("Failed to fetch Client List");
      const data = await res.json();
        runInAction(() => {
        this.clientOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Client List options:", error);
    }
  }

  fetchByAnalyticsOptions = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/categorytype_list`);
      if (!res.ok) throw new Error("Failed to fetch Analytics List");
      const data = await res.json();
        runInAction(() => {
        this.analyticsOptionsList = data;
      });
    } catch (error) {
      console.error("Error fetching Analytics List options:", error);
    }
  }

  fetchPayerValueChain = async (
     userId:string,
     ptype: string,
     ptechnology: string,
     pclient:string,
     panalytics:string,
     ) => {
    try {
      const response = await fetch(`${this.apiUrl}/navigator/payer_value_chain/${userId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ptype,
          ptechnology,
          pclient,
          panalytics
        }),
      });
  
      if (!response.ok) throw new Error("Failed to fetch PayerValueChain Data");
      const payerValueChain = await response.json();
     return payerValueChain;
    } catch (error) {
      console.error("Error inserting messages:", error);
    }
  }


  fetchSolutionCatalogueData = async (
    getId?:string,
    getMenuType?:string,
    solutionType?:string,
    tech?:string,
    client?:string,
    offset?:number,
    limit?:number
    ) => {
    try {
      this.catalogloading = true;
      const setOffset = offset ?? 0;
      const setLimit = limit ?? 12;
  
      const getSolId = (getId!=='all') ? getId : '';
      const getMenuTypes = (getMenuType!=='all') ? getMenuType : '';
      const getSolutionType = (solutionType!=='all') ? solutionType : '';
      const getTech = (tech!=='all') ? tech : '';
      const getClient = (client!=='all') ? client : '';

      let res:Response;

      res = await fetch(`${this.apiUrl}/soln_catalogue/page_solns_update?menu_type=${getMenuTypes}&filter_id=${getSolId}&solution_type=${getSolutionType}&tech=${getTech}&client=${getClient}&offset=${setOffset}&limit=${setLimit}`);

    //   if(getId=='all' && getMenuTypes=='all' ){ 
    //    res = await fetch(`${this.apiUrl}/soln_catalogue/page_solns?offset=${setOffset}&limit=${setLimit}`);
    //  }else{
    //    res = await fetch(`${this.apiUrl}/soln_catalogue/soln_leftmenu?menu_type=${getMenuTypes}&filter_id=${getId}&offset=${setOffset}&limit=${setLimit}`);
    //   }
    
      if (!res.ok) throw new Error("Failed to fetch datastate data");
      const data = await res.json();
      runInAction(() => {
        this.catalogloading = false;
        this.solutionCatalogueData = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  fetchBussinessUnitListData = async (
    imu?:string,
    sgu?:string,
    offset?:number,
    limit?:number
    ) => {
    try {
      this.bussinessunitloading = true;
      const setOffset = offset ?? 0;
      const setLimit = limit ?? 8;
      const res = await fetch(`${this.apiUrl}/dashboard/dashboard_filter_main?imu=${imu}&sgu=${sgu}&offset=${setOffset}&limit=${setLimit}`);
      if (!res.ok) throw new Error("Failed to fetch Bussiness Unit List Data");
      const data = await res.json();
      runInAction(() => {
        this.bussinessunitloading = false;
        this.bussinessUnitListData = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchSolutionListData = async (
    offset?:number,
    limit?:number
    ) => {
    try {
      this.solutionlistloading = true;
      const setOffset = offset ?? 0;
      const setLimit = limit ?? 8;
      const res = await fetch(`${this.apiUrl}/user/solution_list?offset=${setOffset}&limit=${setLimit}`);
      if (!res.ok) throw new Error("Failed to fetch Solution List Data");
      const data = await res.json();
      runInAction(() => {
        this.solutionlistloading = false;
        this.solutionListData = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


}

export const mainPageStore = new MainPageStore();
