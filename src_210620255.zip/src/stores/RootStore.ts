import { MainPageStore } from "./MainPageStore";
import { SolutionFormStore } from "./SolutionFormStore";

export class RootStore {
  mainPageStore: MainPageStore;
  solutionFormStore: SolutionFormStore;

  constructor() {
    this.mainPageStore = new MainPageStore();
    this.solutionFormStore = new SolutionFormStore();
  }
}

const rootStore = new RootStore();
export default rootStore;
