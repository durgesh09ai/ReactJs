import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch, TextField, InputAdornment, Container, RadioGroup, FormControlLabel, Radio, List as MUIList, ListItem as MUIListItem, ListItemText as MUIListItemText, FormControl, Select, MenuItem, styled } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import SendIcon from "@mui/icons-material/Send";
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import DescriptionIcon from '@mui/icons-material/Description';

import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, {
  AccordionSummaryProps,
  accordionSummaryClasses,
} from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';

const Accordion = styled((props: AccordionProps) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  border: `1px solid ${theme.palette.divider}`,
  '&:not(:last-child)': {
    borderBottom: 0,
  },
  '&::before': {
    display: 'none',
  },
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.9rem' }} />}
    {...props}
  />
))(({ theme }) => ({
  backgroundColor: 'rgba(0, 0, 0, .03)',
  flexDirection: 'row-reverse',
  [`& .${accordionSummaryClasses.expandIconWrapper}.${accordionSummaryClasses.expanded}`]:
    {
      transform: 'rotate(90deg)',
    },
  [`& .${accordionSummaryClasses.content}`]: {
    marginLeft: theme.spacing(1),
  },
  ...theme.applyStyles('dark', {
    backgroundColor: 'rgba(255, 255, 255, .05)',
  }),
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderTop: '1px solid rgba(0, 0, 0, .125)',
}));


interface ContentProps {
  backgroundColor: string;
  messages: { user: string; model: string }[];
  selectedAgent: string;
  selectedTopic: string;
  setSelectedTopic: React.Dispatch<React.SetStateAction<string>>;
  topics: string[];
  papers: string[];
}


export const Content = ({ backgroundColor, selectedAgent, selectedTopic, setSelectedTopic, topics, papers }: ContentProps) => {

  const [expanded, setExpanded] = useState<string | false>(false);
  const [askInputs, setAskInputs] = useState<{ [key: number]: string }>({});
  const [showAskInput, setShowAskInput] = useState<{ [key: number]: boolean }>({});
  const [askResults, setAskResults] = useState<{ [key: number]: string }>({});

  const handleChange = (panel: string) => (_event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false);
  };

  const handleAskToggle = (index: number) => {
    setShowAskInput((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const handleAskSubmit = (index: number) => {
    const query = askInputs[index] || "";
    const response = `Response for: ${query}`;
    setAskResults((prev) => ({ ...prev, [index]: response }));
    setAskInputs((prev) => ({ ...prev, [index]: "" }));
  };

  return (
    <Box sx={{ flexGrow: 1, p: 3, color: "#fff", backgroundColor: backgroundColor , minHeight: "calc(100vh - 64px)", display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
      <Toolbar />
      <Container >
        {selectedAgent === "TopicWeaver" && (
          <>
            <Typography variant="h4">TopicWeaver: Topic Analysis & Selection</Typography>
            <Typography variant="body1">
              Explore topics extracted from the filtered papers and select one for deeper analysis.
            </Typography>
         
            <Typography variant="subtitle2" sx={{ mt: 2 }}>Choose your Topic</Typography>
            <RadioGroup
              row
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
            >
              {topics.map((topic) => (
                <FormControlLabel key={topic} value={topic} control={<Radio sx={{
                  color: 'blue',
                  '&.Mui-checked': {
                    color: 'red',
                  },
                }}/>} label={topic} />
              ))}
            </RadioGroup>

            <Typography variant="h6" sx={{ mt: 3 }}>Papers Related To Topic: {selectedTopic}</Typography>
        {papers.map((paper, index) => (
        <Accordion expanded={expanded === `panel1${index}`} onChange={handleChange(`panel1${index}`)}  sx={{ backgroundColor: "#1e1e1e", color: "#ECECF1" }}>
        <AccordionSummary
        aria-controls={`panel1${index}`}
        id={`panel1${index}`}
        sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
        >
        <DescriptionIcon sx={{ color: 'primary.main' }} /> 
  <Typography component="span">{paper}</Typography>
</AccordionSummary>
        <AccordionDetails sx={{ backgroundColor: "#222", color: "#fff" }}>
            <Box sx={{ display: "flex", gap: 1, justifyContent: "flex-start", mb: 1 }}>
              <Button size="small" variant="contained" sx={{ fontSize: "12px" }}>Details</Button>
              <Button size="small" variant="contained" startIcon={<PictureAsPdfIcon />} sx={{ fontSize: "12px" }}>Open PDF</Button>
              <Button size="small" variant="contained" startIcon={<HelpOutlineIcon />} sx={{ fontSize: "12px" }} onClick={() => handleAskToggle(index)}>Ask</Button>
            </Box>
            {showAskInput[index] && (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                <TextField
                  size="small"
                  value={askInputs[index] || ""}
                  onChange={(e) => setAskInputs({ ...askInputs, [index]: e.target.value })}
                  placeholder="Ask your question..."
                  sx={{ flexGrow: 1, fontSize: "12px", backgroundColor: "#343541", color: "#fff" }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => handleAskSubmit(index)}>
                          <ArrowForwardIcon />
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                />
              </Box>
            )}

            {askResults[index] && (
              <Typography sx={{ fontSize: "12px", mb: 1 }}>{askResults[index]}</Typography>
            )}
        </AccordionDetails>
      </Accordion>
        ))}
          </>
        )}

        {selectedAgent === "LitSeek" && (
          <>
            <Typography variant="h4">LitSeek: Search & Filter Literature</Typography>
            <Typography variant="body1" sx={{ mt: 1, backgroundColor: "#f0f8ff", p: 1 }}>
              Use this agent to search for research papers, apply filters, and view the fetched list.
            </Typography>
            <TextField
              fullWidth
              variant="outlined"
              placeholder="Type your healthcare-related question here..."
              sx={{ mt: 2 }}
            />
            <Button variant="contained" sx={{ mt: 2, backgroundColor: "#e74c3c" }}>Search</Button>
          </>
        )}

        {selectedAgent === "InsightGen" && (
          <Paper sx={{ p: 3, borderRadius: 2, boxShadow: 3 }}>
            <Typography variant="h4">InsightGen: Insights Generation & Reporting</Typography>
            <Typography variant="body1" sx={{ mt: 1, backgroundColor: "#f0f8ff", p: 1 }}>
              Generate summaries, analyze findings, and export reports based on your selected topic.
            </Typography>
            <Typography variant="h6" sx={{ mt: 2 }}>Selected Topic: <b>Diabetes</b></Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>Based on Research Question: <i>Effectiveness and Safety of Dapagliflozin in Type 2 Diabetes Mellitus Management</i></Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>Found 3 paper(s) related to this topic.</Typography>

            <FormControl fullWidth sx={{ mt: 2 }}>
              <Typography variant="subtitle1">Select Review Format</Typography>
              <Select defaultValue="Paper-wise Information">
                <MenuItem value="Paper-wise Information">Paper-wise Information</MenuItem>
              </Select>
            </FormControl>

            <FormControl fullWidth sx={{ mt: 2 }}>
              <Typography variant="subtitle1">Select Information To Extract</Typography>
              <Select defaultValue="" displayEmpty>
                <MenuItem value="" disabled>Choose an option</MenuItem>
              </Select>
            </FormControl>

            <Button variant="contained" sx={{ mt: 3, backgroundColor: "#e74c3c" }}>Generate Review</Button>
          </Paper>
        )}
      </Container>
    </Box>
  );
};
