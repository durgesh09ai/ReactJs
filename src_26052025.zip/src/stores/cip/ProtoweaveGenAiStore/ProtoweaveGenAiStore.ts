import { makeAutoObservable, runInAction } from "mobx";
//import { fetchJson } from "../../../utils/http";

export class ProtoweaveGenAiStore {
  sidebarData: any = null;
  loading:boolean = false;
  sidemenuloading:boolean = false;
  error: string | null = null;
  workspaceList: any[] = [];
  versionList: string[] = [];
  loggedInUser:string = "";

  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8002";

  constructor() {
    makeAutoObservable(this);
  }

  setLoggedInUser() {
    this.loggedInUser = "admin@gmail.com";
  }

  // fetchSideMenuData1 = async () => {
  //   try {
  //     const result = await fetchJson("http://localhost:3000/sidemenudata.json");
  //     runInAction(() => {
  //       this.sidebarData = result;
  //     });
  //   } catch (e: any) {
  //     runInAction(() => {
  //       this.error = e.message || "Unknown error";
  //     });
  //   }
  // };

  fetchSideMenuData = async (userId:string) => {
    try {
      this.sidemenuloading = true;
      const res = await fetch(`${this.apiUrl}/workspace/sidemenudata/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch workspaces");
      const data = await res.json();
      runInAction(() => {
        this.sidebarData = data;
        this.sidemenuloading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  addResearchItem = async (data: { research_name: string; description: string; workspace_id: string }) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_dashboard/create_research`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add research item");
      }
  
      const newResearchItem = await res.json();
  
      runInAction(() => {
        // Find the workspace by workspace_id
        const workspace = this.sidebarData.workspacelist.find(w => w.id === data.workspace_id);
        if (workspace) {
          console.log("Inside wordkspace");
          // Find the "Research" item
          const researchItem = workspace.items.find(item => item.researchname === "Research");
          if (researchItem) {
            console.log("Inside")
            // researchItem.data.push({
            //   id: newResearchItem.id,
            //   title: newResearchItem.research_name || "New Research"
            // });
            researchItem.data = [{
                 id: newResearchItem.id,
                 title: newResearchItem.research_name || "New Research"
                },...researchItem.data];
            console.log("Inside::",researchItem.data);
          } 
        }
      });
  
      return newResearchItem;

    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Error while adding  Research";
      });
    }
  };

  addResearchItem1 = async (data: {research_name: string; description: string; workspace_id: string }) => {
    try {
        const res = await fetch(`${this.apiUrl}/research_dashboard/create_research`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add research item");
      }
        // Re-fetch the SideMenu data
    //  await this.fetchSideMenuData(this.loggedInUser);
      } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };


  fetchWorkspaces = async (userId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/workspaces/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch workspaces");
      const data = await res.json();
      runInAction(() => {
        this.workspaceList = data;
        this.loading = true;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWorkspace = async (id: string, updates: {id:string,userId:string, WS_name: string; WS_descrip: string }) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/RenameWorkspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
  
      if (!res.ok) throw new Error("Failed to update workspace");
  
      const updatedWorkspace = await res.json();
      runInAction(() => {
        const index = this.workspaceList.findIndex((ws) => ws.id === id);
        if (index !== -1) {
          this.workspaceList[index] = updatedWorkspace;
        }
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWorkspaceArchive = async (id: string, updates: {id:string,userId:string, archive: boolean;}) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/Archive_workspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
    if (!res.ok) throw new Error("Failed to update workspace");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  addWorkspace = async (workspace: any) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/create_workspace`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workspace),
      });
      if (!res.ok) throw new Error("Failed to add workspace");
      const newWorkspace = await res.json();
      runInAction(() => {
        this.workspaceList.unshift(newWorkspace);
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWSTeamMember = async (id: string, updates: {id:string,userId:string, team_members: string[];}) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/ReTeam_Workspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
    if (!res.ok) throw new Error("Failed to update workspace");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

 
}

export const dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();
