import React from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  Typography,
  useMediaQuery,
  useTheme
} from "@mui/material";

import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import ExportButtonWithDialog from "./ExportButtonWithDialog";

interface ResearchReportProps {
  report: {
    markdown: string;
    docx: string;
  };
  handleDownloadReport: () => void;
  onStartSimulation?: () => void;
}

export const ResearchReport: React.FC<ResearchReportProps> = ({
  report,
  handleDownloadReport,
  onStartSimulation
}) => {
 
 const theme = useTheme() ;
 const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));
  
const iconSrc = "/report.svg";

  return (
    <Stack 
    direction= {isSmallScreen ? "column" : "row"}
    spacing={1} 
    width={{sx:"100%" ,sm:"100%",md:"98%"}}
    >
      <Avatar
        src={iconSrc}
        alt="Report"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          bgcolor: "#F3FAFF",
          p: 1.5,
          borderRadius: 3,
          fontSize: "0.875rem",
          color: "black",
          overflowWrap:"break-word",
        }}
      >
        {/* Export button at top-right */}
        <Box display="flex" justifyContent="flex-end" mb={1}>
          <ExportButtonWithDialog onExport={handleDownloadReport} />
        </Box>

        {/* Title content */}
        <Box
         fontWeight={500}
         fontSize="14px"
         mb={2}
         sx={{
          '& h1':{
            fontSize:18,
            fontWeight:700,
          },
          '& h2':{
            fontSize:16,
            fontWeight:700,
          },
          '& h3':{
            fontSize:14,
            fontWeight:700,
          },
          wordBreak:"break-word",
         }}
         >
        <Markdown remarkPlugins={[remarkGfm]}>{report.markdown}</Markdown>
        </Box>

        {/* Start Simulation Button */}
        <Box display="flex" justifyContent="flex-end">
          <Button
            onClick={onStartSimulation}
            sx={{
              bgcolor: "#4CAF50",
              color: "white",
              fontWeight: 500,
              px: 2,
              py: 0.75,
              borderRadius: 1.5,
              textTransform: "none",
              "&:hover": {
                bgcolor: "#3d9140",
              },
            }}
          >
            Start Simulation
          </Button>
        </Box>
      </Paper>
    </Stack>
  );
};
