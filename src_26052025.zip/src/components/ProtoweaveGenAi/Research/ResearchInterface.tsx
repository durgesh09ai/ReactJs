import React, { useEffect, useRef, useState } from "react";
import {
  Avatar,
  Box,
  Container,
  Paper,
  Stack,
  Typography,
  FormControl,
  Select,
  MenuItem,
  TextField,
  IconButton,
  Button,
} from "@mui/material";
import { observer } from "mobx-react-lite";
import { researchStore } from "../../../stores/cip/ProtoweaveGenAiStore/ResearchStore";
import QuestionAnswerBlock from "./QuestionForm";
import { ChatMessage } from "./ChatMessage";
import { ResearchReport } from "./ResearchReport";
import { useNavigate } from "react-router-dom";

type ResearchInterfaceProps = {
  researchId:string|undefined;
  sessionId:string;
}

export const ResearchInterface: React.FC<ResearchInterfaceProps> = observer(({
  researchId,
  sessionId,
}) => {

  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [planDecided, setPlanDecided] = useState(false);
  const [promtAdded, setPromtAdded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [version, setVersion] = useState("");
  const { messages, report, isResearching,fetchChatVersionList,versionOptions,thinkingData } = researchStore;
 // const { id:researchId } = useParams();

  useEffect(() => {
     if(researchId){
       fetchChatVersionList(researchId);
     }
  }, [researchId,sessionId]);

  useEffect(() => {
    if (versionOptions.length > 0) {
      setVersion(versionOptions[0]);
    }else{
      setVersion(sessionId);
    } 
  }, [versionOptions,researchId,sessionId]);
  

  console.log('version::',version);
console.log('researchId::',researchId);
console.log('versionOptions::',versionOptions.length);

  useEffect(() => {
    if (version && researchId && !promtAdded) {
      console.log('Durgesh::',version);
      researchStore.fetchChatHistory(researchId, version);
    }
  }, [version, researchId]);



  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.questions) {
      const initialAnswers: Record<string, string> = {};
      lastMessage.questions.forEach((q: string) => {
        initialAnswers[q] = lastMessage.answers?.[q] || "";
      });
      setAnswers(initialAnswers);
    }
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isResearching]);

  const handleSend = () => {
    if (input.trim()) {
      researchStore.handleSendTopic(input.trim());
      setInput("");
      setPlanDecided(false);
      setPromtAdded(true);
    }
  };

  const handleAnswerChange = (question: string, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [question]: answer,
    }));
  };


  const insertChatHistoryMessages = async () => {
    console.log('test chatHistory')
      await researchStore.insertChatHistory(
        researchId,
        sessionId,
        messages
      );
      setPromtAdded(false);
  };

  const updateChatHistoryFinalReport = async () => {
    console.log('test chatHistory report')
      await researchStore.updateChatHistoryFinalReport(
        sessionId,
        researchId,
        report
      );
  };

  const updateThinkingProcess = async () => {
    console.log('ChatHistoryThinkingProcess')
      await researchStore.updateChatHistoryThinkingProcess(
        sessionId,
        researchId,
        thinkingData
      );
  };

  useEffect(() => {
    if (!isResearching && report && sessionId) {
      updateChatHistoryFinalReport();
      updateThinkingProcess();
    } 
  }, [report]);

  const handleSubmitAnswers = async (approved: boolean) => {
    await researchStore.handleSubmitAnswers(answers, approved);
    if (approved) {
       setPlanDecided(true);
       insertChatHistoryMessages();
    }
  };

  const handleStartSimulation = () => {
    navigate("/protoweave/experiment");
  };

  const handleDownloadReport = () => {
    researchStore.handleDownloadReport();
    console.log("Download report triggered");
  };

  return (
    <Container
      maxWidth="md"
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "83vh",
        paddingBottom: "1px",
      }}
    >
      <Stack spacing={2} sx={{ flexGrow: 1, overflow: "auto" }}>
        <Box sx={{ width: 200 }}>
          <FormControl fullWidth size="small">
          <Select
              value={version ?? 'Version 1'}
              onChange={(e) => setVersion(e.target.value)}
          >
          {researchStore.versionOptions.length > 0
          ? researchStore.versionOptions.map((option,index) => (
            <MenuItem key={option} value={option}>
              Version {versionOptions.length-(index)}
            </MenuItem>
          ))
          : (
          <MenuItem key={version ?? 'Version 1'} value={version ?? 'Version 1'}>
           Version 1
          </MenuItem>
          )
          }
          </Select>
          </FormControl>
        </Box>

        {/* Messages Display */}
        <Stack spacing={2} maxWidth={498}>
          {messages.length === 0 && !report && (
            <ChatMessage
              content="I need some clarification to better understand your research needs:"
              sender="assistant"
            />
          )}

          {!researchId && (
            <ChatMessage
              content="Please create or select any research Topic."
              sender="assistant"
            />
          )}

          {messages.map((msg, index) => (
            <Box key={index}>
              <ChatMessage content={msg.content} sender={msg.role} />
              {msg.questions && (
                <QuestionAnswerBlock
                  questions={msg.questions}
                  answers={answers}
                  onChange={handleAnswerChange}
                  showActions={
                    !planDecided &&
                    msg.questions &&
                    index === researchStore.currentEditableIndex
                  }
                  onSubmit={handleSubmitAnswers}
                />
              )}
            </Box>
          ))}

          {isResearching && (
            <ChatMessage content="Thinking..." sender="assistant" isThinking={true} />
          )}

          <div ref={messagesEndRef} />
        </Stack>

        {report && !promtAdded && (
          <ResearchReport
            report={report}
            handleDownloadReport={handleDownloadReport}
            onStartSimulation={handleStartSimulation}
          />
        )}
      </Stack>

      {/* Input Section */}
      <Box sx={{ position: "sticky", bottom: 0, width: "100%" }}>
        <Stack spacing={1.5} mt={4} width="100%">
          <Paper
            elevation={0}
            sx={{
              border: "2px solid rgba(18, 18, 21, 0.30)",
              minHeight: 100,
              width: "100%",
              bgcolor: "white",
              px: 2,
              py: 2,
              borderRadius: 3.75,
              position: "relative",
            }}
          >
            <TextField
              multiline
              fullWidth
              placeholder="Start writing your research or experiment here!"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyUp={(e) => e.key === "Enter" && handleSend()}
              disabled={isResearching || !researchId}
              InputProps={{ style: { paddingBottom: 50 } }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: "0.875rem",
                  fontWeight: 400,
                  color: "black",
                  padding: 0,
                  "& .MuiOutlinedInput-notchedOutline": {
                    border: "none",
                  },
                },
              }}
            />

            {/* Bottom-right icons */}
            <Box
              sx={{
                position: "absolute",
                bottom: 16,
                right: 16,
                display: "flex",
                gap: 1.5,
              }}
            >
              <IconButton>
                <img
                  src="/attachment.svg"
                  alt="Attachment"
                  style={{ width: 24, height: 24, objectFit: "contain" }}
                />
              </IconButton>
              <IconButton
                onClick={handleSend}
                sx={{
                  width: 34,
                  height: 34,
                  bgcolor: "#0F4977",
                  p: 0.875,
                  borderRadius: "50%",
                  "&:hover": { bgcolor: "#0c3d68" },
                }}
              >
                <img
                  src="/send.svg"
                  alt="Send"
                  style={{ width: 20, height: 20, objectFit: "contain" }}
                />
              </IconButton>
            </Box>
          </Paper>

          {/* Upload button */}
          <Box display="flex" justifyContent="flex-end">
            <Button
              variant="outlined"
              sx={{
                color: "#0F4977",
                fontSize: "0.875rem",
                fontWeight: 500,
                px: 2,
                py: 0.75,
                borderRadius: 1.5,
                border: "1px solid rgba(15,73,119,1)",
                textTransform: "none",
              }}
            >
              Upload Research
            </Button>
          </Box>
        </Stack>
      </Box>
    </Container>
  );
});
