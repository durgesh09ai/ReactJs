import React from 'react';
import { Box, Typography } from '@mui/material';
import { AgentCard, Agent } from './AgentCard';

interface AgentListProps {
  agents: Agent[];
  onEdit: (agent: Agent) => void;
  onDelete: (agent: Agent) => void;
  onToggleStatus: (agent: Agent, enabled: boolean) => void;
  onSetDefault: (agent: Agent, isDefault: boolean) => void;
}

export const AgentList: React.FC<AgentListProps> = ({
  agents,
  onEdit,
  onDelete,
  onToggleStatus,
  onSetDefault
}) => {
  return (
    <Box sx={{
      width: '100%',
      maxWidth: '495px',
      mt: 2
    }}>
      <Typography sx={{
        alignSelf: 'stretch',
        textAlign:'center',
        width: '100%',
        fontSize: '14px',
        color: '#1d1b20',
        fontWeight: 500,
        lineHeight: 1.2
      }}>
        Existing Agents
      </Typography>
      {agents.map((agent) => (
        <AgentCard
          key={agent.id}
          agent={agent}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleStatus={onToggleStatus}
          onSetDefault={onSetDefault}
        />
      ))}
    </Box>
  );
};
