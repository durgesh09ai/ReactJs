import React from "react";
import { Box, Typography, TextField } from "@mui/material";

interface ProfileFormFieldProps {
  label: string;
  value: string;
}

const ProfileFormField: React.FC<ProfileFormFieldProps> = ({ label, value }) => {
  return (
    <Box sx={{ mt: 2, "&:first-of-type": { mt: 0 } }}>
      <Typography 
        variant="body1" 
        sx={{ 
          fontWeight: 'bold', 
          color: "#1d1b20", 
          lineHeight: 1.2 ,
          fontSize:'14px',
        }}
      >
        {label}
      </Typography>
      <TextField
        variant="outlined"
        value={value}
        sx={{
          mt: 1,
          width: "350px",         // Decrease width
          bgcolor: "#EAF2F7",
          "& .MuiOutlinedInput-input": {
            height: "30px",       // Decrease height
            padding: "8px",       // Adjust internal padding
            fontSize: "0.875rem"  // Optional: make font smaller
          },
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "rgba(18,18,21,0.30)"
          }
        }}
        InputProps={{
          readOnly: true,
        }}
      />
    </Box>
  );
};

export default ProfileFormField;
