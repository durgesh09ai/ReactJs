import React from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  Typography,
} from "@mui/material";

import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import ExportButtonWithDialog from "./ExportButtonWithDialog";

interface ResearchReportProps {
  report: {
    markdown: string;
    docx: string;
  };
  handleDownloadReport: () => void;
  onStartSimulation?: () => void;
}

export const ResearchReport: React.FC<ResearchReportProps> = ({
  report,
  handleDownloadReport,
  onStartSimulation
}) => {
  
const iconSrc = "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/408d72eeb5a648bfbde4a812ac7888ee115284c0?placeholderIfAbsent=true";

  return (
    <Stack direction="row" spacing={1} maxWidth="100%" width={469}>
      <Avatar
        src={iconSrc}
        alt="Report"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          width: "100%",
          bgcolor: "#F3FAFF",
          p: 2.5,
          borderRadius: 3,
          fontSize: "0.875rem",
          color: "black",
        }}
      >
        {/* Export button at top-right */}
        <Box display="flex" justifyContent="flex-end" mb={1}>
          <ExportButtonWithDialog onExport={handleDownloadReport} />
        </Box>

        {/* Title content */}
        <Box fontWeight={500} fontSize="14px" mb={2}>
        <Markdown remarkPlugins={[remarkGfm]}>{report.markdown}</Markdown>
        </Box>

        {/* Start Simulation Button */}
        <Box display="flex" justifyContent="flex-end">
          <Button
            onClick={onStartSimulation}
            sx={{
              bgcolor: "#4CAF50",
              color: "white",
              fontWeight: 500,
              px: 2,
              py: 0.75,
              borderRadius: 1.5,
              textTransform: "none",
              "&:hover": {
                bgcolor: "#3d9140",
              },
            }}
          >
            Start Simulation
          </Button>
        </Box>
      </Paper>
    </Stack>
  );
};
