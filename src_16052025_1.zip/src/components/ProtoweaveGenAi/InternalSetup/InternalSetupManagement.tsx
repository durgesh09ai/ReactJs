import React, { useState } from 'react';
import { Box, Divider, Paper, Typography } from '@mui/material';
import { SetupHeader } from './SetupHeader';
import { InternalSiteList } from './InternalSiteList';
import { SetupForm } from './SetupForm';
import { Setup } from './SetupCard';

const InternalSetupManagement: React.FC = () => {
  const [internalSetup, setInternalSetup] = useState<Setup[]>([
    {
      id: '1',
      name: 'Agent: SharePoint – Research Docs ',
      description: 'Access clinical trial documents from SharePoint',
      url: 'https://sharepoint.org/research',
      username: 'Dr.meera',
      password: '**********',
      enabled: true
    },
    {
      id: '2',
      name: 'Agent: SharePoint –Claims Data',
      description: 'Access clinical trial documents from SharePoint Biomedical literature search agent',
      url: 'https://sharepoint.org/research',
      username: 'Dr.Anurag',
      password: '**********',
      enabled: false
    }
  ]);

  const [editingSetup, setEditingSetup] = useState<Setup | null>(null);
  const [isAddingSetup, setIsAddingSetup] = useState(false);

  const handleAddSetup = () => {
    setEditingSetup(null);
    setIsAddingSetup(true);
  };

  const handleEditSetup = (setup: Setup) => {
    setEditingSetup(setup);
    setIsAddingSetup(false);
  };

  const handleDeleteSetup = (setupToDelete: Setup) => {
    setInternalSetup(internalSetup.filter(setup => setup.id !== setupToDelete.id));
  };

  const handleToggleStatus = (setupToToggle: Setup, enabled: boolean) => {
    setInternalSetup(internalSetup.map(setup => 
      setup.id === setupToToggle.id ? { ...setup, enabled } : setup
    ));
  };

  const handleSetDefault = (internalToSetDefault: Setup, isDefault: boolean) => {
    setInternalSetup(internalSetup.map(setup => 
      setup.id === internalToSetDefault.id 
        ? { ...setup, isDefault } 
        : isDefault ? { ...setup, isDefault: false } : setup
    ));
  };

  const handleSaveAgent = (internalSetupData: Partial<Setup>) => {
    if (editingSetup) {
      // Update existing agent
      setInternalSetup(internalSetup.map(setup => 
        setup.id === editingSetup.id ? { ...setup, ...internalSetupData } : setup
      ));
    } else {
      // Add new agent
      const newSetup: Setup = {
        id: Date.now().toString(),
        name: internalSetupData.name || 'New Setup',
        username:internalSetupData.name || 'New username',
        password:internalSetupData.password || 'New password',
        url: internalSetupData.url || 'example.com',
        description: internalSetupData.description || 'No description',
        enabled: internalSetupData.enabled || false,
      };
      setInternalSetup([...internalSetup, newSetup]);
    }
    setEditingSetup(null);
    setIsAddingSetup(false);
  };

  const handleCancelEdit = () => {
    setEditingSetup(null);
    setIsAddingSetup(false);
  };

  return (
    <Box sx={{
      display: 'flex',
      maxWidth: '720px',
      flexDirection: 'column',
      alignItems: 'stretch',
      justifyContent: 'center'
    }}>
      <Paper sx={{
        justifyContent: 'center',
        alignItems: 'stretch',
        border: '1px solid rgba(18,18,21,0.10)',
        display: 'flex',
        width: '100%',
        flexDirection: 'column',
        p: 2
      }}>

    <Box sx={{ width: "100%", px: 2, display: "flex", justifyContent: "space-between" }}>
      <Box sx={{ width: "100%", pb: 2 }}>
        <Typography variant="body1" sx={{ color: "#1d1b20",fontSize:'14px',fontWeight:400, }}>
        Internal Site Configration
        </Typography>
        <Divider sx={{ mt: 1 }} />
      </Box>
    </Box>
   <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          border: "1px solid rgba(18,18,21,0.10)",
          padding: 2,
          width: "100%",
        }}
      >
        <SetupHeader onAddClick={handleAddSetup} />
        <InternalSiteList 
          setup={internalSetup}
          onEdit={handleEditSetup}
          onDelete={handleDeleteSetup}
          onToggleStatus={handleToggleStatus}
        />
        {(isAddingSetup || editingSetup) && (
          <SetupForm 
            setup={editingSetup || undefined}
            onSave={handleSaveAgent}
            onCancel={handleCancelEdit}
          />
        )}
      </Paper>

      </Paper>
    </Box>
  );
};

export default InternalSetupManagement;
