import React from "react";
import { Box, Typography, Button, Stack } from "@mui/material";
import { ModelData } from "./EditModelForm";
import { ModelItem } from "./ModelItem";


interface ExistingModelsSectionProps {
  models: ModelData[];
  onAddModel: () => void;
  onEditModel: (id: string) => void;
  onDeleteModel: (id: string) => void;
}

export const ExistingModelsSection: React.FC<ExistingModelsSectionProps> = ({
  models,
  onAddModel,
  onEditModel,
  onDeleteModel
}) => {
  return (
    <Box sx={{ width: "100%", maxWidth: "495px", minHeight:250 }}>
      <Typography
        variant="body1"
        sx={{
          color: "#1d1b20",
          fontSize:14,
          fontWeight: 'bold',
          lineHeight: 1.2,
          textAlign:'center'
        }}
      >
        LLM Model Configurations
      </Typography>

      <Box sx={{ mt: 4 }}>
        <Stack
          direction="row"
          spacing={2}
          justifyContent="space-between"
          flexWrap="wrap"
          alignItems="center"
        >
          <Typography
            variant="body1"
            sx={{ color: "#1d1b20", fontWeight: 'bold', lineHeight: 1.2,fontSize:14 }}
          >
            Existing Models:
          </Typography>
          <Typography
            variant="body2"
            onClick={onAddModel}
            sx={{
              color: "#0F4977",
              fontWeight: "bold",
              fontSize: 14,
              cursor: "pointer",
              textDecoration: "underline",
              "&:hover": {
                color: "#0c3a60"
              }
            }}
          >
            Add Model
          </Typography>
        </Stack>

        <Box sx={{ mt: "25px", display: "flex", flexDirection: "column" }}>
        {models.map((model) => (
          <Box key={model.id}>
            <ModelItem
              id={model.id}
              name={model.name}
              endpoint={model.endpoint}
              onEdit={onEditModel}
              onDelete={onDeleteModel}
            />
          </Box>
        ))}

        </Box>
      </Box>
    </Box>
  );
};
