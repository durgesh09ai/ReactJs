import React from "react";
import { Outlet } from "react-router-dom";
import styles from "./Layout.module.css";
import Header from "./Header";
import Sidebar from "./Sidebar";
import DatagenAiSyntheticMenu from "../../pages/CIP/Demos/DatagenAiSynthetic/DatagenAiSyntheticMenu";

const DefaultLayout = () => {
  return (
    <div className={styles.wrapper}>
      <Header />
      <div className={styles.body}>
        <Sidebar />
        <main className={styles.content}>
          <Outlet /> {/* This renders the current page based on the route */}
        </main>
      </div>
    </div>
  );
};

export default DefaultLayout;
