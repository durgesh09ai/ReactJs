import { makeAutoObservable, runInAction } from "mobx";
import { fetchJson } from "../../../utils/http";

export class ProtoweaveGenAiStore {
  sidebarData: any = null;
  error: string | null = null;

  constructor() {
    makeAutoObservable(this);
  }

  fetchSideMenuData = async () => {
    try {
      const result = await fetchJson("./sidemenudata.json");
      runInAction(() => {
        this.sidebarData = result;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };

  addResearchItem = async (data: {id: string, title: string; description: string; researchId: string }) => {
    try {
      const res = await fetch("/addresearch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add research item");
      }
        // Re-fetch the SideMenu data
      await this.fetchSideMenuData();
      } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };
  

}

export const dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();
