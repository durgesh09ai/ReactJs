
import React, { useState } from "react";
import { 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  Box,
  Chip,
  IconButton,
  Collapse,
  List
} from "@mui/material";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

interface NavItemProps {
  icon: string;
  label: string;
  count?: number;
  showCount?: boolean;
  collapsed?: boolean;
  subItems?: Array<{label: string; icon?: string}>;
}

const NavItem: React.FC<NavItemProps> = ({
  icon,
  label,
  count = 0,
  showCount = true,
  collapsed = false,
  subItems = []
}) => {
  const [open, setOpen] = useState(false);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setOpen(!open);
    console.log(`Arrow clicked for ${label}`);
  };
  
  const hasSubItems = subItems.length > 0;

  return (
    <>
      <ListItem 
        sx={{ 
          py: 0.5, 
          px: 1,
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          '&:hover': {
            bgcolor: 'rgba(0, 0, 0, 0.04)'
          }
        }} 
        disablePadding 
      >
      {!collapsed && (
        <Box sx={{ display: 'flex', alignItems: 'center', flex: 1 }}>
          <ListItemIcon sx={{ minWidth: collapsed ? 24 : 40, mr: 1 }}>
            <Box 
              component="img"
              src={icon}
              alt={label || "menu item"}
              sx={{ width: 24, height: 24 }}
            />
          </ListItemIcon>
            <ListItemText 
              primary={label} 
              primaryTypographyProps={{ 
                variant: 'body2', 
                fontWeight: 'normal',
                noWrap: true,
                sx: { maxWidth: '180px' }
              }}
            />
        </Box>
      )}

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {!collapsed && showCount && count > 0 && (
            <Chip
              label={count}
              size="small"
              sx={{
                height: 20,
                fontSize: 10,
                fontWeight: 800,
                bgcolor: 'rgba(243,250,255,1)',
                color: '#0F4977',
              }}
            />
          )}
          
          {!collapsed && hasSubItems && (
            <IconButton 
              edge="end" 
              size="small" 
              onClick={handleToggle}
              sx={{ 
                padding: 0.5
              }}
            >
              {open ? <KeyboardArrowUpIcon fontSize="small" /> : <KeyboardArrowDownIcon fontSize="small" />}
            </IconButton>
          )}
        </Box>
      </ListItem>
      
      {hasSubItems && !collapsed && (
        <Collapse in={open} timeout="auto" unmountOnExit>
          <List component="div" disablePadding sx={{ pl: 4 }}>
            {subItems.map((item, index) => (
              <ListItem key={index} sx={{ py: 0.5, cursor: 'pointer', '&:hover': { bgcolor: 'rgba(0, 0, 0, 0.04)' } }}>
                {item.icon && (
                  <ListItemIcon sx={{ minWidth: 30 }}>
                    <Box 
                      component="img"
                      src={item.icon}
                      alt={item.label}
                      sx={{ width: 20, height: 20 }}
                    />
                  </ListItemIcon>
                )}
                <ListItemText 
                  primary={item.label} 
                  primaryTypographyProps={{ 
                    variant: 'body2',
                    fontSize: '0.875rem'
                  }} 
                />
              </ListItem>
            ))}
          </List>
        </Collapse>
      )}
    </>
  );
};

export default NavItem;
