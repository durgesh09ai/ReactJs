import React from "react";
import { Box, Typography, TextField } from "@mui/material";

interface SetupFormFieldProps {
  label: string;
  value: string;
  readOnly?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name?: string;
  type?: string;
}

const SetupFormField: React.FC<SetupFormFieldProps> = ({
  label,
  value,
  readOnly = true,
  onChange,
  name,
  type = "text",
}) => {
  return (
    <Box sx={{ mt: 2, "&:first-of-type": { mt: 0 } }}>
      <Typography
        variant="body1"
        sx={{
          fontWeight: "bold",
          color: "#1d1b20",
          lineHeight: 1.2,
          fontSize: "14px",
        }}
      >
        {label}
      </Typography>
      <TextField
        variant="outlined"
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        sx={{
          mt: 1,
          width: "450px",
          bgcolor: readOnly ? "#EAF2F7" : "white",
          "& .MuiOutlinedInput-input": {
            height: "20px",
            padding: "8px",
            fontSize: "0.875rem",
          },
          "& .MuiOutlinedInput-notchedOutline": {
            borderColor: "rgba(18,18,21,0.30)",
          },
        }}
        InputProps={{ readOnly }}
      />
    </Box>
  );
};

export default SetupFormField;
