import React from "react";
import { Box, Typography, IconButton, Chip } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';

interface TeamMemberProps {
  email: string;
}

const TeamMember: React.FC<TeamMemberProps> = ({ email }) => {
  const handleRemove = () => {
    console.log("Remove team member:", email);
    // Here you would typically call an API to remove the team member
  };

  return (
    <Chip
      label={email}
      sx={{
        bgcolor: '#F3FAFF',
        color: '#0F4977',
        borderRadius: '1rem',
        height: 'auto',
        py: 0.5,
      }}
      onDelete={handleRemove}
      deleteIcon={
        <Box 
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/4ca570403bbe5f71cc75b77700d182f793af7dfb?placeholderIfAbsent=true"
          sx={{ width: 16, aspectRatio: 0.94, marginRight: 1 }}
          alt="Remove"
        />
      }
    />
  );
};

export default TeamMember;
