
  import React, { useState } from "react";
  import { 
    Box, 
    Typography, 
    Paper, 
    Button, 
    Switch, 
    IconButton, 
    Grid,
    Divider 
  } from "@mui/material";

  import { TextField } from "@mui/material"; 
  import TeamMember from "./TeamMember";
  

  interface WorkspaceCardProps {
    name: string;
    description: string;
    fullDescription: string;
    owner: string;
    members: string[];
    isToggleOn: boolean;
  }

  const WorkspaceCard: React.FC<WorkspaceCardProps> = ({
    name,
    description,
    fullDescription,
    owner,
    members,
    isToggleOn
  }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isArchived, setIsArchived] = useState(isToggleOn);
    const [showAddMember, setShowAddMember] = useState(false);
    const [newMember, setNewMember] = useState("");
    const [membersList, setMembersList] = useState<string[]>(members);

    const [isEditing, setIsEditing] = useState(false);
    const [editedName, setEditedName] = useState(name);
    const [editedDescription, setEditedDescription] = useState(fullDescription);

    const handleAddMember = () => {
      if (newMember.trim()) {
        setMembersList([...membersList, newMember.trim()]);
        setNewMember("");
        setShowAddMember(false);
      }
    };


    return (
      <Paper 
        elevation={0}
        sx={{ 
          border: '1px solid #E4E4E5',
          width: '100%', 
          maxWidth: '527px', 
          mt: 2,
          p: 2
        }}
      >
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box>
            <Typography variant="body2" sx={{ color: 'black', fontWeight: 'bold' }}>
              {name}
            </Typography>
            <Typography variant="body2" sx={{ color: '#1d1b20', mt: 1 }}>
              {description}
            </Typography>
          </Box>
          <Box 
            component="img"
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/467fbc5a970c7fab7573b24ac1a4b6a612a0ddb3?placeholderIfAbsent=true"
            sx={{ width: 24, height: 24 }}
            alt="Options"
          />
        </Box>
        
        <Box sx={{ mt: 1 }}>
          <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
            Description
          </Typography>
          <Typography variant="body2" sx={{ color: '#1d1b20', mt: 1, lineHeight: '17px' }}>
            {fullDescription}
            <Box
              component="span"
              onClick={() => setIsExpanded(!isExpanded)}
              sx={{ 
                ml: 0.5,
                color: '#0F4977',
                textDecoration: 'underline',
                cursor: 'pointer'
              }}
            >
              See {isExpanded ? "less" : "more"}
            </Box>
          </Typography>
        </Box>
        
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          mt: 1,
          flexWrap: 'wrap'
        }}>
          <Box sx={{ width: '255px', minWidth: '240px' }}>
            <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
              Team Members:
            </Typography>

            {showAddMember && (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
                <TextField
                  size="small"
                  label="Add team member"
                  required
                  value={newMember}
                  onChange={(e) => setNewMember(e.target.value)}
                  sx={{ 
                    "& input": { fontSize: 12 },
                    "& .MuiInputLabel-root": { fontSize: 12 } ,
                    flexGrow: 1, minWidth: '240px'
                  }} 
                />
                <Button variant="contained" onClick={handleAddMember} sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" 
            }}>
                  Add
                </Button>
              </Box>
            )}

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1, pl: 2 }}>
              <Typography variant="body2" sx={{ color: '#121215' }}>
                Owner
              </Typography>
              <TeamMember email={owner} />
            </Box>
            <Box sx={{ pl: 2, mt: 1 }}>
              {membersList.map((member, index) => (
                <Box key={index} sx={{ mt: index > 0 ? 1 : 0 }}>
                  <TeamMember email={member} />
                </Box>
              ))}
            </Box>
          </Box>
          
          <Button
            variant="outlined"
            onClick={()=>setShowAddMember(true)}
            startIcon={
              <Box 
                component="img"
                src={isToggleOn ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/35002a56fd64e9d397909d58bdd04fc4371c7257?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e8e239c0d5d2f94a887cf482d258e047cec5deb7?placeholderIfAbsent=true"}
                sx={{ width: 24, height: 24 }}
                alt="Add member"
              />
            }
            sx={{
              color: '#0F4977',
              borderColor: '#0F4977',
              textTransform: 'none',
              fontWeight: 'medium',
              py: 0.5,
              px: 1,
              height: 'fit-content'
            }}
          >
            Add Member
          </Button>
        </Box>
        
        <Box sx={{ mt: 1 }}>
          <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
            Workspace Settings
          </Typography>
          
          <Box sx={{ mt: 1, pl: 2 }}>

          {isEditing && (
  <Box sx={{ mt: 2, pl: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
    <TextField
      label="Workspace Name"
      value={editedName}
      onChange={(e) => setEditedName(e.target.value)}
      fullWidth
      size="small"
      sx={{ 
        "& input": { fontSize: 12 },
        "& .MuiInputLabel-root": { fontSize: 12 } ,
      }} 
    />
    <TextField
      label="Workspace Description"
      value={editedDescription}
      onChange={(e) => setEditedDescription(e.target.value)}
      fullWidth
      multiline
      sx={{ 
        "& .MuiInputBase-root": { fontSize: 14 },
        "& .MuiInputLabel-root": { fontSize: 14 } ,
      }} 
    />
    <Box sx={{ display: 'flex', gap: 1 }}>
      <Button
        variant="contained"
        onClick={() => {
          setIsEditing(false);
        }}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Update
      </Button>
      <Button
        variant="outlined"
        onClick={() => {
          setIsEditing(false);
        }}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Cancel
      </Button>
    </Box>
  </Box>
)}


            {!isEditing && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Button
                variant="text"
                onClick={() => setIsEditing(!isEditing)}
                startIcon={
                  <Box 
                    component="img"
                    src={isToggleOn ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/38d78a3aa6d5f99b6b5c2b9d2da99d2587b8bcab?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/69523dae9b503db0228e28a943c595ab1beed123?placeholderIfAbsent=true"}
                    sx={{ width: 24, height: 24 }}
                    alt="Edit"
                  />
                }
                sx={{
                  color: '#0F4977',
                  textTransform: 'none',
                  fontWeight: 'medium',
                  py: 0.5,
                  px: 1,
                  minWidth: 'auto'
                }}
              >
                Edit Details
              </Button>
              <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)' }}>
                (Update name or description)
              </Typography>
            </Box>
              )}

            {isToggleOn ? (
              <Box sx={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                mt: 2,
                pl: 2
              }}>
                <Box sx={{ 
                  display: 'flex', 
                  flexDirection: 'column',
                  bgcolor: 'white',
                  borderRadius: 1,
                  p: 0.5
                }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box 
                      component="img"
                      src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/190889642f933327d884e606f642c062034e414d?placeholderIfAbsent=true"
                      sx={{ width: 24, height: 24 }}
                      alt="Archive"
                    />
                    <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
                      Archive Workspace
                    </Typography>
                  </Box>
                  <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)', textAlign: 'center' }}>
                    (Hide this workspace for all user)
                  </Typography>
                </Box>
                <Switch
                  checked={isArchived}
                  onChange={() => setIsArchived(!isArchived)}
                  sx={{
                    '& .MuiSwitch-track': {
                      backgroundColor: '#0F4977',
                    },
                    '& .MuiSwitch-thumb': {
                      backgroundColor: 'white',
                    },
                  }}
                />
              </Box>
            ) : (
              <Box sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: 1,
                mt: 2,
                pl: 2
              }}>
                <Button
                  variant="text"
                  startIcon={
                    <Box 
                      component="img"
                      src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/be2e4367849d916a4a5943f6dbb97e2b81303391?placeholderIfAbsent=true"
                      sx={{ width: 24, height: 24 }}
                      alt="Archive"
                    />
                  }
                  onClick={() => setIsArchived(!isArchived)}
                  sx={{
                    color: '#0F4977',
                    textTransform: 'none',
                    fontWeight: 'medium',
                    py: 0.5,
                    px: 1
                  }}
                >
                  Archive Workspace
                </Button>
                <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)' }}>
                  (Hide this workspace for all user)
                </Typography>
              </Box>
            )}
          </Box>
        </Box>
      </Paper>
    );
  };

  export default WorkspaceCard;
