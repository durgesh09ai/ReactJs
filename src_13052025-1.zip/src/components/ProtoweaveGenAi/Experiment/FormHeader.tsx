import React from "react";
import { Box, Tab, Button, Typography } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import CloseIcon from '@mui/icons-material/Close';
import IconButton from '@mui/material/IconButton';
import { useNavigate } from "react-router-dom";

interface FormHeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onUploadProtocol: () => void;
}

const FormHeader: React.FC<FormHeaderProps> = ({
  onUploadProtocol,
}) => {

const navigate = useNavigate();
const handleClose = () => {
    navigate("/");
    };

  return (
    <Box sx={{ 
      display: "flex", 
      width: "100%", 
      justifyContent: "space-between", 
      flexWrap: "wrap",
      gap: { xs: 2, md: 3 }
    }}>
      <Box 
        component="div"
        role="tab"
        tabIndex={0}
        sx={{ 
          display: "flex", 
          alignItems: "center", 
          justifyContent: "center", 
          p: 0.50, 
          gap: 1,
          border: 3,
          borderColor: "#D9EDFF",
          borderRadius: "8px 8px 0px 0px",
          cursor: "pointer"
        }}
      >
        <Typography sx={{ my: "auto",fontSize:14,fontWeight:400 }}>
          Configuration Form 1
        </Typography>
        <IconButton size="small" sx={{ p: 0.5 }} onClick={handleClose}>
    <CloseIcon fontSize="small" />
  </IconButton>

      </Box>
      
      <Button
        variant="outlined"
        startIcon={<CloudUploadIcon />}
        onClick={onUploadProtocol}
        sx={{
          borderColor: "#0F4977",
          color: "#000",
          height: "100%",
          textTransform: "none",
          backgroundColor: "white",
          padding: "6px 16px",
          "&:hover": {
            backgroundColor: "#f0f7ff",
            borderColor: "#0F4977"
          }
        }}
      >
        Upload the protocol
      </Button>
    </Box>
  );
};

export default FormHeader;
