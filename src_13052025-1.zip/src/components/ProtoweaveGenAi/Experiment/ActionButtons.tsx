import React from "react";
import { Box, Button } from "@mui/material";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

interface ActionButtonsProps {
  onDuplicate: () => void;
  onRunExperiment: () => void;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({
  onDuplicate,
  onRunExperiment,
}) => {
  return (
    <Box 
    sx={{ 
      display: "flex", 
      justifyContent: "flex-end", 
      alignItems: "center", 
      gap: 2, 
      mt: 4,
      width: "100%" 
    }}
     >
      <Button
        variant="outlined"
        startIcon={<ContentCopyIcon />}
        onClick={onDuplicate}
        sx={{
          borderColor: "#0F4977",
          color: "#0F4977",
          textTransform: "none",
          whiteSpace: "nowrap",
          "&:hover": {
            bgcolor: "#f0f7ff",
            borderColor: "#0F4977"
          }
        }}
      >
        Duplicate
      </Button>
      
      <Button
        variant="contained"
        onClick={onRunExperiment}
        sx={{
          bgcolor: "#4CAF50",
          color: "white",
          border: "none",
          "&:hover": {
            bgcolor: "#3d8b40"
          }
        }}
      >
        Run Experiment
      </Button>
    </Box>
  );
};

export default ActionButtons;
