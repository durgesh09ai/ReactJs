import React from "react";
import { TextField, Box, Typography } from "@mui/material";

interface FormFieldProps {
  label: string;
  placeholder?: string;
}

const FormField: React.FC<FormFieldProps> = ({
  label,
  placeholder = "Your answer",
}) => {
  return (
    <Box sx={{ width: "100%" }}>
      <Typography variant="body1" fontWeight={500} sx={{ mb: 0.5 }}>
        {label}
      </Typography>
      <TextField
        fullWidth
        placeholder={placeholder}
        variant="outlined"
        aria-label={label}
     
      />
    </Box>
  );
};

export default FormField;
