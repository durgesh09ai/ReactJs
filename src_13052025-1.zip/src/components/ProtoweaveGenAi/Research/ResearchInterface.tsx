import React, { useEffect, useRef, useState } from "react";
import {
  Avatar,
  Box,
  Container,
  Paper,
  Stack,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  IconButton,
  Button,
} from "@mui/material";
import { observer } from "mobx-react-lite";
import { researchStore } from "../../../stores/cip/ProtoweaveGenAiStore/ResearchStore";
import QuestionAnswerBlock from "./QuestionForm";
import { ChatMessage } from "./ChatMessage";
import { ResearchReport } from "./ResearchReport";

export const ResearchInterface: React.FC = observer(() => {
  const [version, setVersion] = useState("v1");
  const [input, setInput] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [planDecided, setPlanDecided] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { messages,report,isResearching } = researchStore;

  // Update answers when questions are received
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.questions) {
      const initialAnswers: Record<string, string> = {};
      lastMessage.questions.forEach((q: string) => {
        initialAnswers[q] = lastMessage.answers?.[q] || "";
      });
      setAnswers(initialAnswers);
    }
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (input.trim()) {
      researchStore.handleSendTopic(input.trim());
      setInput("");
      setPlanDecided(false); // reset state for new topic
    }
  };

  const handleAnswerChange = (question: string, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [question]: answer,
    }));
  };

  const handleSubmitAnswers = (approved: boolean) => {
    researchStore.handleSubmitAnswers(answers, approved);
    if (approved) {
    setPlanDecided(true);
  } 
  };

  const handleStartSimulation = () => {
    console.log("Simulation started");
  };

  const handleDownloadReport = () => {
    // Example: export logic or placeholder
    console.log("Download report triggered");
  };

  return (
    <Container
      maxWidth="md"
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "90vh",
        paddingBottom: "20px",
      }}
    >
      <Stack spacing={4} sx={{ flexGrow: 1, overflow: "auto" }}>
        <Box sx={{ width: 200 }}>
          <FormControl fullWidth size="small">
            <Select
              labelId="version-select-label"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
            >
              <MenuItem value="v1">version v1</MenuItem>
              <MenuItem value="v2">version v2</MenuItem>
              <MenuItem value="v3">version v3</MenuItem>
            </Select>
          </FormControl>
        </Box>

        {/* Messages Display */}
        <Stack spacing={2} maxWidth={498}>

        {messages.length === 0 && !report && (
          <ChatMessage
            content="I need some clarification to better understand your research needs:"
            sender="assistant"
          />
        )}

        {messages.map((msg, index) => (
            <Box key={index}>
            <ChatMessage content={msg.content} sender={msg.role} />
            {msg.questions && (
            <QuestionAnswerBlock
              questions={msg.questions}
              answers={answers}
              onChange={handleAnswerChange}
              showActions={
              !planDecided &&
              msg.questions &&
              index === researchStore.currentEditableIndex
            }
              onSubmit={handleSubmitAnswers}
            />
            )}
            </Box>
            ))}

          <div ref={messagesEndRef} />
        </Stack>

        {report && (
          <ResearchReport
          report={report}
          handleDownloadReport={handleDownloadReport}
          onStartSimulation={handleStartSimulation}
        />
        )}

      </Stack>

      {/* Input Section */}
      <Box sx={{ position: "sticky", bottom: 0, width: "100%" }}>
        <Stack spacing={1.5} mt={4} width="100%">
          <Paper
            elevation={0}
            sx={{
              border: "2px solid rgba(18, 18, 21, 0.30)",
              minHeight: 151,
              width: "100%",
              bgcolor: "white",
              px: 2,
              py: 2,
              borderRadius: 3.75,
              position: "relative",
            }}
          >
            <TextField
              multiline
              fullWidth
              placeholder="Start writing your research or experiment here!"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyUp={(e) => e.key === "Enter" && handleSend()}
              disabled={messages.length > 0 || isResearching}
              InputProps={{
                style: { paddingBottom: 80 },
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  fontSize: "0.875rem",
                  fontWeight: 400,
                  color: "black",
                  padding: 0,
                  "& .MuiOutlinedInput-notchedOutline": {
                    border: "none",
                  },
                },
              }}
            />

            {/* Bottom-right icons */}
            <Box
              sx={{
                position: "absolute",
                bottom: 16,
                right: 16,
                display: "flex",
                gap: 1.5,
              }}
            >
              <IconButton>
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/208c98e9fb324089677fa2c76539c52b7b4c731c?placeholderIfAbsent=true"
                  alt="Attachment"
                  style={{ width: 24, height: 24, objectFit: "contain" }}
                />
              </IconButton>
              <IconButton
                onClick={handleSend}
                sx={{
                  width: 34,
                  height: 34,
                  bgcolor: "#0F4977",
                  p: 0.875,
                  borderRadius: "50%",
                  "&:hover": { bgcolor: "#0c3d68" },
                }}
              >
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9b62b1d965bb49c78d05f90501225ad1be2b363?placeholderIfAbsent=true"
                  alt="Send"
                  style={{ width: 20, height: 20, objectFit: "contain" }}
                />
              </IconButton>
            </Box>
          </Paper>

          {/* Upload button */}
          <Box display="flex" justifyContent="flex-end">
            <Button
              variant="outlined"
              sx={{
                color: "#0F4977",
                fontSize: "0.875rem",
                fontWeight: 500,
                px: 2,
                py: 0.75,
                borderRadius: 1.5,
                border: "1px solid rgba(15,73,119,1)",
                textTransform: "none",
              }}
            >
              Upload Research
            </Button>
          </Box>
        </Stack>
      </Box>
    </Container>
  );
});
