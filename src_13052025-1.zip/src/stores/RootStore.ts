import { DatagenAiSyntheticStore } from "./cip/DatagenAiSyntheticStore";
import { ProtoweaveGenAiStore } from "./cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";

export class RootStore {
  datagenAiSyntheticStore: DatagenAiSyntheticStore;
  dataProtoweaveGenAiStore: ProtoweaveGenAiStore;


  constructor() {
    this.datagenAiSyntheticStore = new DatagenAiSyntheticStore();
    this.dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();

  }
}

const rootStore = new RootStore();
export default rootStore;
