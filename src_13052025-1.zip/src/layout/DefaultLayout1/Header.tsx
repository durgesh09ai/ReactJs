const Header = () => (
  <header
    style={{
      padding: "1rem",
      background: "#333",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      gap: "1rem",
    }}
  >
    {/* Replace 'logo.png' with your actual logo path */}
    <img src="/EXL_Service_logo.png" alt="Logo" style={{ height: "40px" }} />
    <h2></h2>
  </header>
);

export default Header;
