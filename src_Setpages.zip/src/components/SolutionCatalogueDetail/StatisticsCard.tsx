import React from "react";
import { Box, Typography } from "@mui/material";
import { StatisticItem } from "./StatisticItem"; // adjust path as needed

interface StatisticProps {
  change: string;
  label: string;
  value: string;
}

interface StatisticsCardProps {
  title: string;
  timeframe: string;
  statistics: StatisticProps[];
}

export const StatisticsCard: React.FC<StatisticsCardProps> = ({
  title,
  timeframe,
  statistics,
}) => {
  return (
    <Box width="100%">
      <Box
        bgcolor="white"
        border="1px solid"
        borderColor="#F4F4F5"
        borderRadius="10px"
        px={4}
        py={2}
        display="flex"
        flexDirection="column"
        fontWeight={500}
      >
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          width="100%"
        >
          <Typography
            sx={{ color: "#151718", fontSize: "16px", fontWeight: 600 }}
          >
            {title}
          </Typography>
          <Typography
            sx={{
              color: "rgba(63,151,255,1)",
              fontSize: "14px",
              textAlign: "right",
              fontWeight:500,
            }}
          >
            {timeframe}
          </Typography>
        </Box>
      </Box>

      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        gap={10}
        mt={4}
        textAlign="center"
        flexWrap="wrap"
      >
        {statistics.map((stat, index) => (
          <StatisticItem key={index} {...stat} />
        ))}
      </Box>
    </Box>
  );
};
