import React from "react";
import { Box, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import AddIcon from '@mui/icons-material/Add';

const ActionButtons: React.FC = () => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  return (
    <Box 
    sx={{ 
      display: "flex", 
      justifyContent: "flex-end", 
      gap: 2 // Adjust the spacing between buttons
    }}
  >
    <Button 
      variant="outlined" 
      startIcon={<AddIcon />} 
      sx={{ 
        color: "#0F4977", 
        borderColor: "#0F4977",
        fontSize: "12px", // Smaller text
        boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
        height:'40px',
        borderRadius: '8px',
        "&:hover": {
          borderColor: "#0F4977",
          backgroundColor: "rgba(15, 73, 119, 0.04)"
        }
      }}
    >
      Add New Solution
    </Button>
  
    <Button 
    onClick={handleClick}
      variant="contained" 
      startIcon={<EmojiEventsIcon />} // Champion icon for "My Stat and Rank"
      sx={{ 
        color: "#FFF", 
        borderColor: "#0F4977",
        fontSize: "14px", 
        borderRadius: '8px',
        boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
      }}
    >
      My Stat and Rank
    </Button>
  </Box>
  );
};

export default ActionButtons;
