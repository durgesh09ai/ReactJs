// ContractListing.tsx
import { useState, useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { contractStore } from '../../stores/ContractStore';
import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Paper,
  TextField,
  Checkbox,
  Typography,
  Button,
  Select,
  MenuItem,
  Stack,
  Drawer,
  Chip,
  InputLabel,
  FormControl,
  IconButton,
  CircularProgress,
  Menu,
} from '@mui/material';
import { Pagination } from '../../components/SolutionCatalogue/Pagination';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from '@mui/icons-material/Replay';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import EditNoteIcon from '@mui/icons-material/EditNote';
import OpenInBrowserIcon from '@mui/icons-material/OpenInBrowser';

const rowsPerPage = 5;



const ContractListing = () => {

   useEffect(()=>{
    contractStore.fetchContractListing();
   },[])

  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const isMenuOpen = Boolean(anchorEl);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState<number | null>(null);

  const [filterValues, setFilterValues] = useState({
    hospital: '',
    contract: '',
    cisType: '',
    cdgType: '',
    taxId: '',
    date: '',
    
    ccgCategory:'',
  });

  
// Filtered data directly reactive via MobX
const filteredData = contractStore.contracts
  .filter((row) => {
    const matchesDate =
      !filterValues.date ||
      new Date(row.start_date).toISOString().split('T')[0] === filterValues.date;

    return (
      (!filterValues.hospital ||
        row.hospital.toLowerCase().includes(filterValues.hospital.toLowerCase())) &&
      (!filterValues.contract || row.contract === filterValues.contract) &&
      (!filterValues.cisType || row.cis_type === filterValues.cisType) &&
      (!filterValues.cdgType || row.cis_type === filterValues.cdgType) 
    );
  })
  .filter(
    (row) =>
      row.hospital.toLowerCase().includes(search.toLowerCase()) ||
      row.contract.toLowerCase().includes(search.toLowerCase()) 
  );

// Paginate directly, reactive via MobX
const paginatedData = filteredData.slice(
  (currentPage - 1) * rowsPerPage,
  currentPage * rowsPerPage
);


  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
  };



  return (
    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', width: '100%',height:'100%', p: 1, mt: 2 }}>
      
        {contractStore.isLoading?(
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
        ):(
 <Box>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>
          <TextField
            size="small"
            placeholder="Quick Search"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
          />

          <Stack direction="row" spacing={1}>
         
            <Button
              variant="outlined"
              startIcon={<FilterAltIcon />}
              size="small"
              onClick={() => setFilterDrawerOpen(true)}
            >
              Filter
            </Button>
          </Stack>
        </Stack>

        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead sx={{ bgcolor: '#0F4977' }}>
              <TableRow>
                {['Hospital/Physician Name', 'CIS ID', 'CIS ID Type','Description', 'Action'].map((heading, i) => (
                  <TableCell key={i} sx={{ color: 'white',fontSize:'14px' }}>{heading}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, idx) => {
                const isSelected = selectedRows.includes(idx);
                return (
                  <TableRow key={idx} sx={{ bgcolor: isSelected ? '#e3f2fd' : 'inherit' }}>
                   
                   <TableCell>{row.hospital}</TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.description}</TableCell>
                    
                     <TableCell>
                  <IconButton size="small" onClick={(e) => setAnchorEl(e.currentTarget)}>
                    <MoreVertIcon sx={{ fontSize: 14 }} />
                  </IconButton>

                  <Menu
              anchorEl={anchorEl}
              open={isMenuOpen}
              onClose={() => setAnchorEl(null)}
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              transformOrigin={{ vertical: "top", horizontal: "right" }}
              PaperProps={{
                elevation: 1, 
                sx: {
                  boxShadow: 'none', 
                  border: '1px solid #ccc', 
                  mt: 0.2 
                }
              }}
            >
            <MenuItem onClick={() => setAnchorEl(null)} sx={{ fontSize: 12 }}>
              <OpenInBrowserIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Open
            </MenuItem>
            <MenuItem onClick={() => setAnchorEl(null)} sx={{ fontSize: 12 }}>
              <EditNoteIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Edit
            </MenuItem>
            <MenuItem
              onClick={() => {
                setDeleteConfirmOpen(true);
                setRowToDelete(idx);  // Pass the row index
                setAnchorEl(null);
              }}
              sx={{ fontSize: 12 }}
            >
              <DeleteIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Delete
            </MenuItem>
          </Menu>

          </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        <Box mt={2}>
          {Math.ceil(filteredData.length / rowsPerPage) > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={Math.ceil(filteredData.length / rowsPerPage)}
              onPageChange={handlePageChange}
            />
          )}
        </Box>

        {/* Filter Drawer */}
        <Drawer anchor="right" open={filterDrawerOpen} onClose={() => setFilterDrawerOpen(false)}>
          <Box sx={{ width: 320, p: 3 }}>
            <Stack direction="row" alignItems="center" mb={2} spacing={1}>
                <IconButton onClick={() => setFilterDrawerOpen(false)} size='small'>
                <ChevronRightIcon />
              </IconButton>
              <Typography variant="h6" sx={{fontSize:14}}>Filter</Typography>
            
            </Stack>
            <Stack spacing={2}>
              <TextField  size="small" label="Hospital/Physician Name" fullWidth value={filterValues.hospital} onChange={(e) => handleFilterChange('hospital', e.target.value)}  InputLabelProps={{sx:{fontSize:14}}} inputProps={{style:{fontSize:14}}}/>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>Contract Type</InputLabel>
                <Select label="Contract Type" value={filterValues.contract} onChange={(e) => handleFilterChange('contract', e.target.value)} sx={{fontSize:14}}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Hospital">Hospital</MenuItem>
                  <MenuItem value="Physician">Physician</MenuItem>
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>CIS Type</InputLabel>
                <Select sx={{fontSize:14}} label="CIS Type" value={filterValues.cisType} onChange={(e) => handleFilterChange('cisType', e.target.value)}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Pricer">Pricer</MenuItem>
                  <MenuItem value="DRG">DRG</MenuItem>
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>CDG Type</InputLabel>
                <Select sx={{fontSize:14}} label="CDG Type" value={filterValues.cdgType} onChange={(e) => handleFilterChange('cdgType', e.target.value)}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Pricer">Pricer</MenuItem>
                  <MenuItem value="DRG">DRG</MenuItem>
                </Select>
              </FormControl>
     
              <Button variant="contained" fullWidth sx={{ bgcolor: '#003366', mt: 2,fontSize:14}} onClick={() => setFilterDrawerOpen(false)}>
                Save
              </Button>
            </Stack>
          </Box>
        </Drawer>


      </Box>
        )}
       
    </Paper>
  );
};

export default observer(ContractListing);
