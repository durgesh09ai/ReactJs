// DetailContent.tsx
import React, { useEffect } from "react";
import { observer } from 'mobx-react-lite';
import { summaryStore } from '../../stores/DetailContentStore';
import {
  Box, Typography,
  Paper,
  Stack, CircularProgress,
  Button
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Breadcrumb } from "./Breadcrumb";

interface dropDownItems {
  id: string;
  name: string;
}

interface statItems {
  solution_type: string;
  count: number;
}

  const breadcrumbItems = [
    { label: "Home", href: "/" },
    { label: "Contract Page" },
  ];

const DetailContent = () => {
  const navigate = useNavigate();
   const AddContract = () => navigate("/add-contract");


  useEffect(()=>{
    summaryStore.fetchSummaryData();
  },[])

   return (
      <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
       <Paper
        elevation={0}
        sx={{
          backgroundColor: "white",
          borderRadius: "10px",
          width: "100%",
          p: 1,
        }}
      >
      <Breadcrumb items={breadcrumbItems} />

      <Stack direction="row" justifyContent="space-between" sx={{ height: "50px" }}>
      <Box
          sx={{
            display: "flex",
            alignItems: "flex-end", 
            height: "100%",
          }}
        >
          <Typography sx={{ fontSize: "14px", fontWeight: "bold" }}>
            Contract Shell Builder
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "flex-end",
            height: "100%",
          }}
        >
          <Button  
          onClick={AddContract}
          variant="contained" size="small" sx={{ textTransform: "none" }} >
          Add Contract
          </Button>
        </Box>
      </Stack>

     </Paper>
  </Box>
   
  );
};

export default observer(DetailContent);
