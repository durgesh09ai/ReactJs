import React, { useEffect } from "react";
import { observer } from 'mobx-react-lite';
import { summaryStore } from '../../stores/DetailContentStore';
import {
  Box, Typography,
  Paper, Stack,
  Button, TextField,
  MenuItem
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Breadcrumb } from "./Breadcrumb";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const breadcrumbItems = [
  { label: "Home", href: "/" },
  { label: "Contract Page" },
  { label: "Add Contract" },
];

const ccgTypes = [
  { value: "Type A", label: "Type A" },
  { value: "Type B", label: "Type B" },
  { value: "Type C", label: "Type C" }
];

const AddContract = () => {
  const navigate = useNavigate();
  const contractPageClick = () => navigate("/contract-builder");
  const providerPageClick = () => navigate("/contract-provider");

  useEffect(() => {
    summaryStore.fetchSummaryData();
  }, []);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
      <Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 2 }}>
        <Breadcrumb items={breadcrumbItems} />

        {/* 🔹 Title Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "16px", fontWeight: "bold",mt:3 }}>
            Create Contract Shell Builder
          </Typography>
        </Box>

        {/* 🔹 Basic Info Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "14px", fontWeight: "normal", color: '#888' }}>
            Basic Information
          </Typography>
        </Box>

{/* 📝 Form Fields - 2 per row using Stack */}
<Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 1 }}>
  <Box sx={{ maxWidth: 720, ml: 0 }}>

<Stack spacing={2} sx={{ mb: 2 }}>
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Hospital/Physician Name
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter name"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        CCG Type
      </Typography>
      <TextField
        variant="outlined"
        select
        fullWidth
        size="small"
        placeholder="Select type"
      >
        {ccgTypes.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </TextField>
    </Box>
  </Stack>

  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        CIS ID
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter ID"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Description
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter description"
      />
    </Box>
  </Stack>
</Stack>

{/* ✅ Save / Cancel Buttons */}
<Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mb: 3 }}>
  <Button variant="outlined" size="small" sx={{ textTransform: "none" }}>
    Cancel
  </Button>
  <Button variant="contained" size="small" sx={{ textTransform: "none" }}>
    Save
  </Button>
</Stack>

</Box>
</Paper>

{/* 🟢 Status Message */}

<Box sx={{ backgroundColor: '#F3FAFF', borderRadius: '10px', p: 2, mb: 2 }}>
  {/* ✅ Icon + Bold Status Message */}
  <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
    <CheckCircleIcon sx={{ color: 'green' }} />
    <Typography sx={{ fontSize: "14px", fontWeight: "bold" }}>
      Nice! Your contract shell is ready.
    </Typography>
  </Stack>

  {/* 📝 Instruction + Buttons in Same Row */}
  <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
    <Typography sx={{ fontSize: "14px", fontWeight: "normal",paddingLeft:4 }}>
      To add providers like doctors, hospitals, or unions, you’ll need to open the case shell first.
    </Typography>
    <Stack direction="row" spacing={2}>
      <Button variant="outlined" size="small" sx={{ textTransform: "none" }}
       onClick={contractPageClick}
      >
       Return to Contract
      </Button>
      <Button variant="contained" size="small" sx={{ textTransform: "none" }}
       onClick={providerPageClick}
      >
        Add Providers
      </Button>
    </Stack>
  </Stack>
</Box>





      </Paper>
    </Box>
  );
};

export default observer(AddContract);
