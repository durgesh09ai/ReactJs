// ContractListing.tsx
import { useState, useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { contractStore } from '../../stores/ContractStore';
import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Paper,
  TextField,
  Typography,
  Button,
  Select,
  MenuItem,
  Stack,
  Drawer,
  Chip,
  InputLabel,
  FormControl,
  IconButton,
  CircularProgress,
  Menu,
} from '@mui/material';
import { Pagination } from '../SolutionCatalogue/Pagination';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import DeleteIcon from "@mui/icons-material/Delete";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import EditNoteIcon from '@mui/icons-material/EditNote';
import OpenInBrowserIcon from '@mui/icons-material/OpenInBrowser';
import { Breadcrumb } from './Breadcrumb';
import HistoryDetailContent from './HistoryDetailContent';

const rowsPerPage = 5;

const RateHistoryListing = () => {

   useEffect(()=>{
    contractStore.fetchContractListing();
   },[])

  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const isMenuOpen = Boolean(anchorEl);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState<number | null>(null);

  const [filterValues, setFilterValues] = useState({
    hospital: '',
    contract: '',
    cisType: '',
    cdgType: '',
    taxId: '',
    date: '',
    
  });

  
// Filtered data directly reactive via MobX
const filteredData = contractStore.contracts
  .filter((row) => {
    const matchesDate =
      !filterValues.date ||
      new Date(row.start_date).toISOString().split('T')[0] === filterValues.date;

    return (
      (!filterValues.hospital ||
        row.hospital.toLowerCase().includes(filterValues.hospital.toLowerCase())) &&
      (!filterValues.contract || row.contract === filterValues.contract) &&
      (!filterValues.cisType || row.cis_type === filterValues.cisType) &&
      (!filterValues.cdgType || row.cis_type === filterValues.cdgType) 
    );
  })
  .filter(
    (row) =>
      row.hospital.toLowerCase().includes(search.toLowerCase()) ||
      row.contract.toLowerCase().includes(search.toLowerCase()) 
  );

// Paginate directly, reactive via MobX
const paginatedData = filteredData.slice(
  (currentPage - 1) * rowsPerPage,
  currentPage * rowsPerPage
);


  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleViewClick = () => {
  console.log('Viewing:');
};

  return (
    <>
    <HistoryDetailContent/>

    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', width: '100%',height:'100%', mt:2 }}>
      
        {contractStore.isLoading?(
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
        ):(
       <Box>
      
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>

          <TextField
            size="small"
            placeholder="Quick Search"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
          />

        </Stack>

        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead sx={{ bgcolor: '#0F4977' }}>
              <TableRow>
                {['Process Date', 'Process By', 'Result'].map((heading, i) => (
                  <TableCell key={i} sx={{ color: 'white',fontSize:'14px' }}>{heading}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, idx) => {
                const isSelected = selectedRows.includes(idx);
                return (
                  <TableRow key={idx} sx={{ bgcolor: isSelected ? '#e3f2fd' : 'inherit' }}>
                   <TableCell>28/07/2025</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>
                      <Button
                        size="small"
                        variant="text"
                        sx={{
                          textTransform: 'none',
                          fontSize: '13px',
                          color: '#0F4977',
                          textDecoration: 'underline',
                          padding: 0,
                          minWidth: 'auto'
                        }}
                        onClick={() => handleViewClick()}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>

        <Box mt={2}>
          {Math.ceil(filteredData.length / rowsPerPage) > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={Math.ceil(filteredData.length / rowsPerPage)}
              onPageChange={handlePageChange}
            />
          )}
        </Box>

      </Box>
        )}
       
    </Paper>
    </>
  );
};

export default observer(RateHistoryListing);
