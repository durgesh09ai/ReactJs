import React, { useEffect } from "react";
import { observer } from 'mobx-react-lite';
import { summaryStore } from '../../stores/DetailContentStore';
import {
  Box, Typography,
  Paper, Stack,
  Button, TextField,
  MenuItem
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Breadcrumb } from "./Breadcrumb";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const breadcrumbItems = [
  { label: "Home", href: "/" },
  { label: "Contract Page" },
  { label: "Add Contract" },
];

const ccgTypes = [
  { value: "Type A", label: "Type A" },
  { value: "Type B", label: "Type B" },
  { value: "Type C", label: "Type C" }
];

const AddProvider = () => {
  const navigate = useNavigate();
  const providerPageClick = () => navigate("/contract-provider");

  useEffect(() => {
    summaryStore.fetchSummaryData();
  }, []);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
      <Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 2 }}>
        <Breadcrumb items={breadcrumbItems} />

        {/* 🔹 Title Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "16px", fontWeight: "bold",mt:3 }}>
            Create Contract Provider
          </Typography>
        </Box>

        {/* 🔹 Basic Info Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "14px", fontWeight: "normal", color: '#888' }}>
            Basic Information
          </Typography>
        </Box>

{/* 📝 Form Fields - 2 per row using Stack */}
<Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 1 }}>
  <Box sx={{ maxWidth: 750, ml: 0 }}>

<Stack spacing={2} sx={{ mb: 2 }}>
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
       Provider ID
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter Provider ID"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
       Network ID (Use comma to seperate values e.g. 101,102)
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter Network ID"
      />
    </Box>
  </Stack>

  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Tax ID (Use comma to seperate values e.g. 101,102)
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter Tax ID"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        LOB (Use comma to seperate values e.g. 101,102)
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter LOB"
      />
    </Box>
  </Stack>

  <Stack direction="row" spacing={2}>
 
 <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Description
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter description"
      />
    </Box>
  </Stack>


</Stack>

{/* ✅ Save / Cancel Buttons */}
<Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mb: 3 }}>
  <Button variant="outlined" size="small" sx={{ textTransform: "none" }}
   onClick={providerPageClick}
  >
    Cancel
  </Button>
  <Button variant="contained" size="small" sx={{ textTransform: "none" }}>
    Save
  </Button>
</Stack>

</Box>
</Paper>

      </Paper>
    </Box>
  );
};

export default observer(AddProvider);
