import React from 'react';
import { Box, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import InfoOutlineIcon from '@mui/icons-material/InfoOutline';

const StyledHeaderBox = styled(Box)(({ theme }) => ({
  width: '100%',
  borderRadius: '16.386px',
  background: '#fff',
  border: '1px solid #ccc',
  padding: '16px',
}));

const FlexContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  gap: '16px',
}));

const StepBox = styled(Box)(({ theme }) => ({
  backgroundColor: '#F3FAFF', // updated background color
  color: theme.palette.text.primary,
  borderRadius: '8px',
  padding: '8px 12px',
  flex: '1 1 calc(50% - 8px)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  minWidth: '240px',
}));

export const ContractFlow: React.FC = () => {
  const steps = [
    'Step 1: Review contract details',
    'Step 2: Add service clauses',
    'Step 3: Set pricing terms',
    'Step 4: Final approval',
  ];

  return (
    <StyledHeaderBox>
      <Typography variant="subtitle1" sx={{ fontSize: 14, marginBottom: 2,fontWeight:"bold" }}>
        Contract WorkFlow
      </Typography>

      <FlexContainer>
        {steps.map((step, index) => (
          <StepBox key={index}>
            <Typography variant="body2">{step}</Typography>
             <InfoOutlineIcon fontSize="small" sx={{border:"0.1px"}} /> 
         </StepBox>
        ))}
      </FlexContainer>
    </StyledHeaderBox>
  );
};
