import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import { styled } from '@mui/material/styles';
import HomeIcon from '@mui/icons-material/Home';
import SearchIcon from '@mui/icons-material/Search';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import InfoIcon from '@mui/icons-material/Info';
import AddIcon from '@mui/icons-material/Add';
import VisibilityIcon from '@mui/icons-material/Visibility';

const StyledHeaderBox = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '100px',
  position: 'relative',
  borderRadius: '16.386px',
  background: '#fff',
  border: '1px solid #ccc',
  overflow: 'hidden',
}));

const ContentBox = styled(Box)({
  position: 'absolute',
  bottom: '16px',
  left: '27px',
});

const ButtonContainer = styled(Box)({
  display: 'flex',
  gap: '10px',
  marginTop: '8px',
});

export const QuickAction: React.FC = () => {
  return (
    <StyledHeaderBox>
      <ContentBox>
        <Typography variant="subtitle1" sx={{ fontSize: 14,fontWeight:"bold" }}>
          Quick Action
        </Typography>
        <ButtonContainer>
          <Button variant="outlined" startIcon={<AddIcon />} sx={{ fontSize: '12px', fontWeight: 'normal', textTransform: 'none'  }}>
            Add Previous
          </Button>
          <Button variant="outlined" startIcon={<AddIcon />} sx={{ fontSize: '12px', fontWeight: 'normal', textTransform: 'none'  }}>
            Add Services
          </Button>
          <Button variant="outlined" startIcon={<AddIcon />} sx={{ fontSize: '12px', fontWeight: 'normal', textTransform: 'none'  }}>
            Set Rates
          </Button>
          <Button
            variant="outlined"
            startIcon={<VisibilityIcon />}
            sx={{ fontSize: '12px', fontWeight: 'normal', textTransform: 'none'  }}
          >
            View Existing Contract
          </Button>
          <Button variant="outlined" startIcon={<InfoIcon />} sx={{ fontSize: '12px', fontWeight: 'normal' , textTransform: 'none' }}>
            Help & Contract
          </Button>
        </ButtonContainer>
      </ContentBox>
    </StyledHeaderBox>
  );
};
