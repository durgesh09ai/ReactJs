import React, { useState, useEffect } from "react";
import {
  Paper,
  Box,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Divider,
  TextField,
  SelectChangeEvent,
  FormControl,
  InputLabel,
  Select,
} from "@mui/material";
import dayjs from "dayjs";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { observer } from "mobx-react-lite";
import { mainPageStore } from "../../stores/MainPageStore";
import SetupHeader from "./SetupHeader";
import { Pagination } from "../SolutionCatalogue/Pagination";
import SearchIcon from "@mui/icons-material/Search";

const columnWidths = [
  "30px", // S.NO
  "190px", // Solution Name
  "90px", // Type
  "125px", // IMU
  "125px", // SGU
  "150px", // Created On
  "70px", // Status
  "40px",  // Views
  "50px",  // Actions
];

const SolutionPanel: React.FC = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [input, setInput] = useState("");
  const [status, setStatus] = React.useState('');

  const [currentPage, setCurrentPage] = useState(1);
  const productPerPage = 20;
  const start = (currentPage - 1) * productPerPage;

  const {
    fetchSolutionListData,
    solutionListData,
    solutionlistloading
  } = mainPageStore;

  useEffect(() => {
    fetchSolutionListData(start, productPerPage);
  }, [currentPage]);

  const isMenuOpen = Boolean(anchorEl);
  const solutionlist = solutionListData?.result ?? [];
  const totalResult = solutionListData?.remain_count;

  const totalPages = (solutionListData && totalResult) ? Math.ceil(totalResult / productPerPage) : 0 ;

  const handlePageChange = (pageNumber:number) => {
    setCurrentPage(pageNumber);
  };



  const handleStatusChange = (event: SelectChangeEvent) => {
    setStatus(event.target.value as string);
  };


  const handleInput = (event:any) => {
    console.log(event.target.value);
    setInput(event.target.value.toLowerCase());
  };

  const columnTitles = [
    "S.No",
    "Solution Name",
    "Type",
    "IMU",
    "SGU",
    "Created On",
    "Status",
    "Views",
    "Actions",
  ];

  const formatCosmosDate = (
    timestamp: number,
    format: "full" | "date" | "time" = "full"
  ): string => {
    if (!timestamp || typeof timestamp !== "number") return "";
  
    const date = dayjs.unix(timestamp); 
  
    switch (format) {
      case "date":
        return date.format("DD-MM-YYYY"); 
      case "time":
        return date.format("hh:mm A"); 
      case "full":
      default:
        return date.format("DD-MM-YYYY, hh:mm A"); 
    }
  };

  return (
<Paper elevation={1} sx={{ maxWidth: "100%", pb: 2, px: 1, borderRadius: 1 }}>
 <Box sx={{ width: "100%", px: 2, py: 2 }}>
  {/* Top row: Left title + Right controls */}
  <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 2 }}>
    {/* Left: Title */}
    <Typography
      variant="body1"
      sx={{ color: "#1d1b20", fontSize: "16px", fontWeight: 400 }}
    >
      My Solution
    </Typography>

    {/* Right: Select + Search */}
    <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
      {/* Select */}
      <FormControl  sx={{ width: 150}} size="small">
        <InputLabel id="demo-simple-select-label">Select Status</InputLabel>
        <Select
          id="demo-simple-select"
          value=""
          onChange={handleStatusChange}
          label="Select Status"
        >
          <MenuItem value={"Active"}>Active</MenuItem>
          <MenuItem value={"InActive"}>InActive</MenuItem>
        </Select>
      </FormControl>

      {/* Search */}
      <Box sx={{ display: "flex", alignItems: "center" }}>
        <TextField
          onInput={handleInput}
          id="search-bar"
          label="Search title"
          variant="outlined"
          placeholder="Search..."
          size="small"
          sx={{ width: 250 }}
        />
        <IconButton type="submit" aria-label="search">
          <SearchIcon sx={{ color: "blue" }} />
        </IconButton>
      </Box>
    </Box>
  </Box>

  {/* Divider */}
  <Divider sx={{ mt: 2 }} />
</Box>

      <Paper
        elevation={0}
        sx={{
          border: "1px solid rgba(18,18,21,0.10)",
          borderRadius: 0,
          padding: 0,
          overflowX: "auto",
        }}
      >
        {/* Header Row */}
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: columnWidths.join(" "),
            alignItems: "center",
            backgroundColor: "#0F4977",
            color: "#fff",
            px: 2,
            py: 1,
            fontSize: 12,
            fontWeight: 400,
          }}
        >
          {columnTitles.map((title, index) => (
            <Typography
              key={index}
              sx={{ fontSize:12, textAlign: index === columnTitles.length - 1 ? "right" : "left" }}
            >
              {title}
            </Typography>
          ))}
        </Box>

        {solutionlistloading && solutionlist.length==0 && 
        <Box sx={{display:"flex", justifyContent:"center", alignItems:"center", width:"60%", height:55}}>Loading<img src="/loader3.gif"/></Box>    
        }

        {/* Data Rows */}
        {solutionlist.map((item: any,index:number) => (
          <Box
            key={item.id}
            sx={{
              display: "grid",
              gridTemplateColumns: columnWidths.join(" "),
              alignItems: "center",
              px: 2,
              py: 0.5,
              borderBottom: "1px solid #f0f0f0",
              fontSize: 12,
              fontWeight:400,
            }}
          >
           
          
            <Typography sx={{fontSize:12}}>{index + 1}.</Typography>
            <Typography sx={{fontSize:12}}>{item.name}</Typography>
            <Typography sx={{fontSize:12}}>{item.solution_type || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{item.imu[0]?.name || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{item.sgu[0]?.name || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{formatCosmosDate(item.createdDate, "date" || "-")}</Typography>
            <Typography sx={{fontSize:12}}>Active</Typography>
            <Typography sx={{fontSize:12}}>{item.views}</Typography>

            <Box sx={{ display: "flex", justifyContent: "flex-end"}}>
              <IconButton
                size="small"
                onClick={(e) => setAnchorEl(e.currentTarget)}
              >
                <MoreVertIcon  sx={{fontSize:14}} />
              </IconButton>

              <Menu
              anchorEl={anchorEl}
              open={isMenuOpen}
              onClose={() => setAnchorEl(null)}
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              transformOrigin={{ vertical: "top", horizontal: "right" }}
              PaperProps={{
                elevation: 1, // reduces the default shadow
                sx: {
                  boxShadow: 'none', // or customize: '0px 2px 6px rgba(0,0,0,0.1)'
                  border: '1px solid #ccc', // optional for light border
                  mt: 0.2 // margin top if needed
                }
              }}
            >
            <MenuItem onClick={() => setAnchorEl(null)} sx={{ fontSize: 12 }}>
              <EditIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Edit
            </MenuItem>
            <MenuItem onClick={() => setAnchorEl(null)} sx={{ fontSize: 12 }}>
              <DeleteIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Archive
            </MenuItem>
          </Menu>
         
            </Box>
          </Box>
        ))}
      </Paper>

      <Box mt={2}>
      {totalPages>0 && <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      }
      </Box>


    </Paper>
  );
};

export default observer(SolutionPanel);