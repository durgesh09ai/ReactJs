import React from 'react';
import { Box, Typography, Button, Card } from '@mui/material';
import { styled } from '@mui/material/styles';
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';

interface FeatureCardProps {
  cardNumber: string;
  title: string;
  description: string;
  features: Array<{
    title: string;
    description: string;
  }>;
  imageUrl: string;
  onExplore?: () => void;
}

const StyledCard = styled(Card)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  padding: '16px',
  borderRadius: '16px',
  border: '1px solid rgba(166, 166, 166, 0.3)',
  backgroundColor: 'white',
  width: '100%',
}));

const HeaderBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  gap: '8px',
  marginBottom: '24px',
});

const ContentRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  gap: '24px',
  width: '100%',
  [theme.breakpoints.down('sm')]: {
    flexDirection: 'column',
  },
}));

const LeftColumn = styled(Box)({
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  gap: '12px',
});

const FeatureItem = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  gap: '4px',
});

const ExploreButton = styled(Button)({
  width: '200px',
  height: '39px',
  backgroundColor: '#0F4977',
  color: 'white',
  fontSize: '0.875rem',
  fontWeight: 500,
  borderRadius: '8px',
  marginTop: '16px',
});

const FeatureImage = styled('img')({
  width: '100%',
  maxWidth: '362px',
  height: 'auto',
  objectFit: 'cover',
  borderRadius: '8px',
});

const HeaderCardBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  width: '100%',
  marginBottom: '16px',
}));

const CardNumberText = styled(Typography)({
  fontFamily: 'Roboto Mono, monospace',
  fontSize: '64px',
  fontWeight: 500,
  color: '#0F4977',
});

const ArrowCircle = styled(Box)(({ theme }) => ({
  width: '40px',
  height: '40px',
  borderRadius: '50%',
  backgroundColor: '#0F4977',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
}));


export const FeatureCard: React.FC<FeatureCardProps> = ({
  cardNumber,
  title,
  description,
  features,
  imageUrl,
  onExplore,
}) => {
  const handleExploreClick = () => {
    if (onExplore) onExplore();
  };

  return (
    <StyledCard elevation={0}>
 
    <HeaderCardBox>
      <CardNumberText>{cardNumber}</CardNumberText>
      <ArrowCircle>
        <ArrowRightAltIcon sx={{ color: 'white' }} />
      </ArrowCircle>
    </HeaderCardBox>

      {/* Title and Description Block */}
      <HeaderBox>
        <Typography
          variant="h6"
          sx={{ fontSize: '1.25rem', fontWeight: 600, color: '#000' }}
        >
          {title}
        </Typography>
        <Typography
          sx={{ fontSize: '0.875rem', fontWeight: 400, color: '#555' }}
        >
          {description}
        </Typography>
      </HeaderBox>

      {/* Two Columns: Left - Top Features, Right - Image */}
      <ContentRow>
        {/* Left Column - Features */}
        <LeftColumn>
          <Typography
            sx={{ fontSize: '0.875rem', fontWeight: 500, color: '#000' }}
          >
            Top Features
          </Typography>
          {features.map((feature, index) => (
            <FeatureItem key={index}>
              <Typography
                sx={{ fontSize: '0.875rem', color: '#000', lineHeight: 1.4 }}
              >
                {index + 1}.{' '}
                <Box component="span" sx={{ fontWeight: 600 }}>
                  {feature.title}
                </Box>{' '}
                - {feature.description}
              </Typography>
            </FeatureItem>
          ))}

          <ExploreButton onClick={handleExploreClick}>
            Let's explore
          </ExploreButton>
        </LeftColumn>

        {/* Right Column - Image */}
        <Box sx={{ maxWidth: '362px', width: '100%' }}>
        <FeatureImage src={imageUrl} alt={`${title} illustration`} />
       </Box>
      </ContentRow>
    </StyledCard>
  );
};
