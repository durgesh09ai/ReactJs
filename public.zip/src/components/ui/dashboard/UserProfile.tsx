import React from "react";
import { Box, Typography, Avatar, Paper } from "@mui/material";
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';

interface UserProfileProps {
  name: string;
  role: string;
  avatar: string;
  points: number;
  profileproducts?:string;
  imuLabel?:string;
  sguLabel?:string;
}

const UserProfile: React.FC<UserProfileProps> = ({
  name,
  role,
  avatar,
  points,
  profileproducts,
  imuLabel,
  sguLabel,
}) => {
  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "white",
        border: "1px solid #F5F5F5",
        borderRadius: 2,
        px: 2,
        py: 2,
         mt: "2px",
         mb: "2px",
        width: "100%",
      }}
    >
      {/* Profile section */}

      {!profileproducts?(<Box display="flex" alignItems="center" gap={2.5} px={2}>
        <Box sx={{ width: 90 }}>
          <Avatar
            src={avatar}
            alt={name}
            sx={{
              width: 90,
              height: 90,
              borderRadius: 0,
              objectFit: "contain",
            }}
            variant="square"
          />
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            color: "rgba(52,52,52,1)",
            fontSize: "0.80rem",
            width: 155,
          }}
        >
          <Typography fontWeight={600} fontSize="0.8rem">
            {name}
          </Typography>
          <Typography fontWeight={500} mt={1} fontSize="0.80rem">
            {role}
          </Typography>

          <Box display="flex" alignItems="center" gap={1} mt={1}>
            <Box display="flex" alignItems="center" gap={0.5} fontWeight={600}>
              <Avatar
                src="./points.svg"
                alt="Points"
                sx={{
                  width: 14,
                  height: 14,
                  boxShadow: "0px 1px 4px rgba(110,116,134,0.12)",
                }}
              />
              <Typography fontSize="0.80rem">{points}</Typography>
            </Box>
            <Typography fontWeight={400} fontSize="0.80rem">
              Points
            </Typography>
          </Box>
     
        


        </Box>
      </Box>):(
        <Box sx={{display:'flex',alignContent:'space-between'}}>
        <Box display="flex" alignItems="center" gap={2.5} px={2} width='100%'>
        <Box sx={{ width: 90 }}>
          <Avatar
            src={avatar}
            alt={name}
            sx={{
              width: 90,
              height: 90,
              borderRadius: 0,
              objectFit: "contain",
            }}
            variant="square"
          />
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            color: "rgba(52,52,52,1)",
            fontSize: "0.80rem",
            width: 155,
          }}
        >
          <Typography fontWeight={600} fontSize="0.8rem">
            {name}
          </Typography>
          <Typography fontWeight={500} mt={1} fontSize="0.80rem">
            {role}
          </Typography>

          <Box display="flex" alignItems="center" gap={1} mt={1}>
            <Box display="flex" alignItems="center" gap={0.5} fontWeight={600}>
              <Avatar
                src="./points.svg"
                alt="Points"
                sx={{
                  width: 14,
                  height: 14,
                  boxShadow: "0px 1px 4px rgba(110,116,134,0.12)",
                }}
              />
              <Typography fontSize="0.80rem">{points}</Typography>
            </Box>
            <Typography fontWeight={400} fontSize="0.80rem">
              Points
            </Typography>
          </Box>
     
  
          <Box display="flex" flexDirection="column" gap={1} width={280}>
          <Box display="flex">
          <Box
                   sx={{
                     display: "flex",
                     textAlign: "center",                  
                     flex:3,                 
                     background: "#0F4977",
                   }}
                 >
                   {/* No.{rank} Contributor and the batch */}
                   <Typography
                     variant="body2"
                     color="#FFF"
                     fontSize="12px"
                    
                     
                     sx={{ flexGrow: 1 }}
                   >
                     IMU
                   </Typography>
                   </Box>

                       <Box
                   sx={{
                     display: "flex",
                     textAlign: "center",                  
                     flex:7,                 
                     background: "#EAF2F7"
                   }}
                 >
                   {/* No.{rank} Contributor and the batch */}
                   <Typography
                     variant="body2"
                     color="#000"
                     fontSize="12px"
                     
                     sx={{ flexGrow: 1 }}
                   >
                     {/* Helathcare */}
                     {imuLabel}
                   </Typography>
                   </Box>
                   </Box>
                   <Box display="flex">
          <Box
                   sx={{
                     display: "flex",
                     textAlign: "center",                  
                     flex:3,                 
                     background: "#0F4977",
                   }}
                 >
                   {/* No.{rank} Contributor and the batch */}
                   <Typography
                     variant="body2"
                     color="#FFF"
                     fontSize="12px"
                     
                     
                     sx={{ flexGrow: 1 }}
                   >
                     SGU
                   </Typography>
                   </Box>

                       <Box
                   sx={{
                     display: "flex",
                     textAlign: "center",                  
                     flex:7,                 
                     background: "#EAF2F7"
                   }}
                 >
                   {/* No.{rank} Contributor and the batch */}
                   <Typography
                     variant="body2"
                     color="#000"
                     fontSize="12px"
                     
                    
                     sx={{ flexGrow: 1 }}
                   >
                    {sguLabel}
                     {/* Analytics & AI  */}
                   </Typography>
                   </Box>
                   </Box>
                   </Box>
                   


        </Box>
      </Box>



      <Box
            sx={{
              display: "flex",
              
              position: "relative",
              width: "30px", // Add width to make space for the batch
            }}
          >
            <WorkspacePremiumIcon
              sx={{
                width: 30,
                height: 30,
                color: "#0F4977", // Golden icon
              }}
            />
            <Box
              sx={{
                position: "absolute",
                top: "3px", // Adjust the position
                right: "6px", // Adjust the position
                backgroundColor: "white", // White background for the rank
                color: "#0F4977", // Rank number color matching the background
                fontSize: "0.75rem", // Adjust the font size
                fontWeight: 600,
                width: "18px",
                height: "18px",
                borderRadius: "50%", // Circle shape for the batch
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10,
                border: "2px solid #0F4977", // Border color matching the background
              }}
            >
              {'1'}
            </Box>
          </Box> 


      </Box>
      )}

      {/* Goals section */}

      {!profileproducts && (<Box
        mt="30px"
        p={1.5}
        display="flex"
        alignItems="center"
        gap={1}
        bgcolor="rgba(243,250,255,1)"
        borderRadius={2}
        fontWeight={500}
        fontSize="0.80rem"
        color="black"
      >
        <Avatar
          src="./goal.png"
          alt="Goal"
          sx={{ width: 16, height: 16 }}
          variant="square"
        />
        <Typography fontSize="0.80rem" fontWeight={600}>Goals in a Month:</Typography>
        <Typography fontSize="0.80rem">Read 6 case studies</Typography>
      </Box>)}
    </Paper>
  );
};

export default UserProfile;
