
import React, { useState } from "react";
import { 
  MenuItem, 
  Select, 
  FormControl,
  SelectChangeEvent
} from "@mui/material";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { Category } from "@/components/dashboard/StatsPanel";

interface FilterDropdownProps {
  label: string;
  items:Category[];
  selectedItemId:string;
  onChange:(id:string)=>void;
}



const FilterDropdown: React.FC<FilterDropdownProps> = ({ label,items,selectedItemId,onChange }) => {
  
// console.log('items',items);
  

  // const handleChange = (event: SelectChangeEvent) => {
  //   setValue(event.target.value);
  // };

  return (
    <FormControl fullWidth>
      <Select
        value={selectedItemId} onChange={(e)=>onChange(e.target.value)}       
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '12px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value={label} sx={{ mb: 1, color: 'black', fontSize: '14px' }}>{`Select ${label}`}</MenuItem>
        {
          items?.map((item)=>(
            <MenuItem key={item?.id} value={item?.id}>{item?.name}</MenuItem>
          ))
        }
        
     
      </Select>
    </FormControl>
  );
};

export default FilterDropdown;
