import React, { ReactNode } from "react";
import { 
  Card, 
  CardContent, 
  Box, 
  Typography, 
  Avatar,
  Stack
} from "@mui/material";

interface StatCardProps {
  value: number;
  label: string;
}

const icon = '';

const typeIcon: Record<string, string> = {
  "Total no of files": "Casestudy_Icon.svg",
  "Total no of uploaded files": "Casestudy_Icon.svg",
};

const NumberFormatter = (number:number) => {
  const formatted = new Intl.NumberFormat('en-US').format(number);
  return <div>{formatted}</div>;
};

const UploadDetailStatCard: React.FC<StatCardProps> = ({
  value,
  label,
}) => {
  return (
<Card 

sx={{ 
      border:'1px solid',
      borderColor:'#E4E4E5',
      borderRadius: '16px',
      backgroundColor: '#FFF',
      p: '8px',
      height: '70px',
      boxShadow: 'none' 
    }}>


      <CardContent sx={{ p: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', }}>
        <Box
        sx={{
          width: 28,
          height: 28,
          border:"1px solid",
          borderColor:"#FDF4EE",
          bgcolor: "#fff",
          p: 2,
          pt:2,
          borderRadius: "8px", 
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
      
        <Avatar
         src={typeIcon[label] || icon}
         alt={label}
         sx={{
         width: 44,
         height: 44,
         p: '10px',
         pb:2,
         }}
         />
         </Box>
          <Box sx={{ml:"8px"}}>
             <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem',color:"#000" }}>
              {label}
            </Typography>
            <Typography variant="h4" component="div" sx={{ fontWeight: "bold", fontSize: '24px' }}>
              {NumberFormatter(value)}
            </Typography>
           
          </Box>
         
        </Box>

      </CardContent>
    </Card>
  );
};

export default UploadDetailStatCard;
