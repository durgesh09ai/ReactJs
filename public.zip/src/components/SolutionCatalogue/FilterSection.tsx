import React, { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Stack,
  Menu,
  MenuItem,
  Checkbox,
  ListItemText,
} from '@mui/material';

import ViewListIcon from '@mui/icons-material/ViewList';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import ViewComfyAltIcon from '@mui/icons-material/ViewComfyAlt';
import GridViewIcon from '@mui/icons-material/GridView';
import FilterListIcon from '@mui/icons-material/FilterList';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import LanguageIcon from '@mui/icons-material/Language';
import { styled } from '@mui/material/styles';

const FilterContainer = styled(Paper)`
  padding: 16px;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  width: 100%;
  background-color: white;
`;

const FilterRow = styled(Box)`
  display: flex;
  align-items: flex-end;
  flex-wrap: nowrap;
  gap: 24px;
  width: 100%;
  overflow-x: auto;
`;

const FilterItemWrapper = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: flex-end;
  flex: 1;
  min-width: 180px;   // Reduced minimum width to save space
  max-width: 220px;   // Optional: limit width to prevent overflow
`;

const DropdownBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 46px;
  padding: 0 15px;
  border: 1px solid rgba(211, 209, 209, 0.4);
  border-radius: 8px;
  background-color: white;
  width: 100%;
  cursor: pointer;
  flex-wrap: wrap;
  gap: 8px;
`;

const TagLabel = styled(Box)`
  background-color: rgba(15, 73, 119, 0.1);
  color: rgba(15, 73, 119, 1);
  font-size: 10px;  // Reduced font size
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 16px;
`;

const Icon = styled('img')`
  width: 9px;
`;

const ViewButton = styled(Button)<{ active?: boolean }>`
  background-color: ${({ active }) => (active ? '#0F4977' : 'white')} !important;
  min-height: 36px;  // Reduced button height
  width: 48px;       // Reduced button width
  padding: 6px;
  border: 1px solid rgba(211, 209, 209, 0.4);
  border-radius: ${({ active }) => (active ? '8px' : '8px 0 0 8px')} !important;

  img {
    width: 20px;    // Reduced icon size
  }
`;

const LabelButton = styled(Box)`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px; // Reduced padding
  background-color: white;
  border-radius: 8px;
  font-size: 10px;    // Reduced font size
  font-weight: 500;
  color: black;

  img {
    width: 20px;    // Reduced icon size
  }
`;

export const FilterSection: React.FC = () => {
  const tagOptions = ['Underwriting', 'Risk', 'Claims', 'Policy'];
  const techOptions = ['React', 'Angular', 'Vue', 'Next.js'];

  const [selectedTags, setSelectedTags] = useState<string[]>(['Underwriting']);
  const [selectedTech, setSelectedTech] = useState<string>('React');

  const [anchorElTag, setAnchorElTag] = useState<null | HTMLElement>(null);
  const [anchorElTech, setAnchorElTech] = useState<null | HTMLElement>(null);

  const openTagMenu = Boolean(anchorElTag);
  const openTechMenu = Boolean(anchorElTech);

  const handleTagToggle = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <FilterContainer elevation={0}>
      <FilterRow>
        {/* MULTI-SELECT TAG DROPDOWN */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={400} color="black" fontSize={14}>
            By tags
          </Typography>
          <DropdownBox onClick={(e) => setAnchorElTag(e.currentTarget)} sx={{height:'46px',borderRadius: '8px', }}>
            <Box display="flex" gap="6px" flexWrap="wrap" flex="1">
              {selectedTags.map((tag) => (
                <TagLabel key={tag}>{tag}</TagLabel>
              ))}
            </Box>
            <Icon
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/42810ee322064081dbafb4b6974f487d2ed70b22?placeholderIfAbsent=true"
              alt="dropdown"
            />
          </DropdownBox>
          <Menu
            anchorEl={anchorElTag}
            open={openTagMenu}
            onClose={() => setAnchorElTag(null)}
          >
            {tagOptions.map((tag) => (
              <MenuItem key={tag} onClick={() => handleTagToggle(tag)}>
                <Checkbox checked={selectedTags.includes(tag)} />
                <ListItemText primary={tag} />
              </MenuItem>
            ))}
          </Menu>
        </FilterItemWrapper>

        {/* SINGLE-SELECT TECHNOLOGY DROPDOWN */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={400} color="black" fontSize={14}>
            By Technology
          </Typography>
          <DropdownBox onClick={(e) => setAnchorElTech(e.currentTarget)}>
            <Typography fontSize={10}>{selectedTech}</Typography>
            <Icon
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/42810ee322064081dbafb4b6974f487d2ed70b22?placeholderIfAbsent=true"
              alt="dropdown"
            />
          </DropdownBox>
          <Menu
            anchorEl={anchorElTech}
            open={openTechMenu}
            onClose={() => setAnchorElTech(null)}
          >
            {techOptions.map((tech) => (
              <MenuItem
                key={tech}
                onClick={() => {
                  setSelectedTech(tech);
                  setAnchorElTech(null);
                }}
              >
                {tech}
              </MenuItem>
            ))}
          </Menu>
        </FilterItemWrapper>

        {/* VIEW TOGGLE BUTTONS */}

        <FilterItemWrapper>
  <Typography variant="body2" fontWeight={500} color="transparent">
    Placeholder
  </Typography>
  <Stack direction="row" spacing={1} alignItems="center" minHeight={46}>
    
  <Stack direction="row" spacing={0} alignItems="center" minHeight={46}>
    <Box
      sx={{
        bgcolor: 'white',
        border: '1px solid #ccc',
        borderRadius: '8px 0 0 8px', // Round left corners of the first button
        width: 60,  // Set width to ensure a square shape
        height: 46, // Set height to ensure a square shape
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
      }}
    >
      <GridViewIcon fontSize="small" color="action" />
    </Box>

    <Box
      sx={{
        bgcolor: 'white',
        border: '1px solid #ccc',
        borderRadius: '0 8px 8px 0', // Round right corners of the second button
        width: 60,  // Set width to ensure a square shape
        height: 46, // Set height to ensure a square shape
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer', // Optional: make it look like a button
      }}
    >
      <ViewListIcon fontSize="small" color="action" />
    </Box>
    </Stack>
    <Box
      sx={{
        bgcolor: 'white',
        border: '1px solid #ccc',
        borderRadius: '8px', // Fully rounded corners for the third button
        width: 40,  // Set width to ensure a square shape
        height: 46, // Set height to ensure a square shape
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer', // Optional: make it look like a button
      }}
    >
      <FilterListIcon fontSize="small" color="primary" />
      </Box>

  </Stack>
</FilterItemWrapper>






        {/* STATIC LABEL */}
        <FilterItemWrapper>
  <Typography variant="body2" fontWeight={500} color="transparent">
    Placeholder
  </Typography>
  <LabelButton
    sx={{
      bgcolor: 'white',
      border: '1px solid #ccc',
      borderRadius: '8px', // Apply rounded borders to the button
      display: 'flex',
      alignItems: 'center',
      padding: '8px 16px', // Adjust padding for spacing around text and icons
      cursor: 'pointer', // Make it look interactive
      height:'46px',
    }}
  >
    {/* Filter Icon with border */}
    <Box
      sx={{
        bgcolor: 'white',
        border: 'none',
        padding: '2px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '8px', // Add spacing between icons and text
      }}
    >
      <LanguageIcon fontSize="small" color="action" />
      </Box>

    {/* Label/Text */}
    <span style={{ marginRight: '2px',fontSize:'10px' }}>Data and analytics LOB</span>

    {/* Dropdown Icon with border */}
    <Box
      sx={{
        bgcolor: 'white',
        border: 'none',
        padding: '2px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <ArrowDropDownIcon fontSize="small" color="action" />
    </Box>
  </LabelButton>
</FilterItemWrapper>

      </FilterRow>
    </FilterContainer>
  );
};
