import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';

import {
  Paper,
  Stack,
} from '@mui/material';

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

//pdfjs.GlobalWorkerOptions.workerSrc = '/cdnjs/pdf.worker.min.js';

type DocumentLoadSuccess = {
  numPages: number;
};

const PdfDetail = () => {

  const fileUrl = '/SupabaseDocument.pdf';
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState(1);

const onDocumentLoadSuccess = ({ numPages }: DocumentLoadSuccess) => {
  setNumPages(numPages);
};


  return (
    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', p: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
  <div>
      <Document file={fileUrl} onLoadSuccess={onDocumentLoadSuccess}>
        <Page pageNumber={pageNumber} />
      </Document>
      <p>
        Page {pageNumber} of {numPages}
      </p>
      <button onClick={() => setPageNumber(prev => Math.max(prev - 1, 1))}>Previous</button>
    <button
      onClick={() =>
        setPageNumber(prev =>
          Math.min(prev + 1, numPages ?? prev + 1) 
        )
      }
    >
      Next
    </button>
    </div>
      </Stack>
    </Paper>
  );
};

export default PdfDetail;