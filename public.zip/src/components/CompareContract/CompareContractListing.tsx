import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Paper,
  TextField,
  Typography,
  Button,
  Stack,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Menu,
  MenuItem,
  LinearProgress,
  InputLabel,
} from '@mui/material';
import { useDropzone } from 'react-dropzone';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from '@mui/icons-material/Replay';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

const initialData = [
  {
    hospital: 'Frankfort Regional Medical Center',
    serviceType:'OB Services',
    solution_version: 'CCG 1',
    contract: 'Hospital',
    apex_id: 'ACV-0001',
    referral: 'Ref-7',
    apex_worksite: '62424',
    cis_id: 'CSID-123',
    cis_type: 'Pricer',
    start_date: '2025-01-03',
    term_date: '2025-01-03',
    tax_id: 'Single',
    lob: '123',
    description: 'Parent contract',
    status: 'Completed'
  },
    {
    hospital: 'Frankfort',
    serviceType:'ICU/CCU',
    solution_version: 'CCG 1',
    contract: 'Hospital',
    apex_id: 'ACV-0001',
    referral: 'Ref-7',
    apex_worksite: '62424',
    cis_id: 'CSID-123',
    cis_type: 'Pricer',
    start_date: '2025-01-03',
    term_date: '2025-01-03',
    tax_id: 'Single',
    lob: '123',
    description: 'Parent contract',
    status: 'Completed'
  },
];

const CompareContractListing = () => {

  const [data, setData] = useState(initialData);
  const [search, setSearch] = useState('');
  const [selectType, setSelectType] = React.useState('');
  const [actionType, setActionType] = React.useState('');

  const handleChange = (event: SelectChangeEvent) => {
    setSelectType(event.target.value);
  };

  const handleActionType = (event: SelectChangeEvent) => {
    setActionType(event.target.value);
  };


  const filteredData = useMemo(() => {
    return data.filter(row =>
      row.hospital.toLowerCase().includes(search.toLowerCase()) ||
      row.contract.toLowerCase().includes(search.toLowerCase()) ||
      row.apex_id.toLowerCase().includes(search.toLowerCase())
    );
  }, [search, data]);

  

  return (
    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', p: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        
   <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">Select Type</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={selectType}
        label="Select Type"
        onChange={handleChange}
      >
      <MenuItem value="">
      <em>None</em>
      </MenuItem>
      <MenuItem value={10}>OB Services</MenuItem>
      <MenuItem value={20}>ICU/CCU</MenuItem>
      <MenuItem value={30}>Medical/Surgical</MenuItem>
      </Select>
      </FormControl>
        <Button variant="contained" size="small">+</Button>
      </Stack>

      <TableContainer component={Paper}>
        <Table size="small">

          <TableHead sx={{ bgcolor: '#0F4977' }}>
          <TableRow>
          <TableCell
          colSpan={11}
          sx={{ color: 'white', fontSize: '14px', textAlign: 'center', width: '100%' }}
          >
          Values
          </TableCell>
          </TableRow>
          </TableHead>

          <TableHead sx={{ bgcolor: '#0F4977' }}>
            <TableRow>
              {['S.No', 'Service Type', 'Document Name', 'Contract Type', 'CIS ID', 'CIS ID Type', 'Start Date', 'Term Date', 'Tax ID', 'Description', 'Action'].map((heading, i) => (
                <TableCell key={i} sx={{ color: 'white', fontSize: '14px' }}>{heading}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredData.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{idx + 1}.</TableCell>
                <TableCell>{row.serviceType}</TableCell>
                <TableCell>{row.hospital}</TableCell>
                <TableCell>
                  <Chip label={row.contract} size="small" sx={{ bgcolor: '#EAF2F7', color: '#0F4977' }} />
                </TableCell>
                <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black' }} /></TableCell>
                <TableCell>{row.cis_type}</TableCell>
                <TableCell>{row.start_date}</TableCell>
                <TableCell>{row.term_date}</TableCell>
                <TableCell>{row.tax_id}</TableCell>
                <TableCell>{row.description}</TableCell>
                <TableCell>
                <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                      <InputLabel id="demo-select-small-label">Action</InputLabel>
                      <Select
                        labelId="demo-select-small-label"
                        id="demo-select-small"
                        value={actionType}
                        label="Action"
                        onChange={handleActionType}
                      >
                        <MenuItem value="">
                          <em>None</em>
                        </MenuItem>
                        <MenuItem value={10}>Yes</MenuItem>
                        <MenuItem value={20}>No</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                      </Select>
                    </FormControl>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

    </Paper>
  );
};

export default CompareContractListing;