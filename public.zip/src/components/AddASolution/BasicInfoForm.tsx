import React, { useState, useCallback } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  IconButton
} from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";
import { useDropzone } from "react-dropzone";

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}

export const BasicInfoForm: React.FC<BasicInfoFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDrop = useCallback((acceptedFiles: File[]) => {
    const newImages = acceptedFiles.map(file => URL.createObjectURL(file));
    setFormData(prev => ({ ...prev, images: [...prev.images, ...newImages] }));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    accept: { "image/*": [] },
    multiple: true,
  });

  const handleSave = () => {
    if (onSave) {
      onSave(formData);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 1,
        minHeight: "382px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Start Your Story</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
            width:'580px' 
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ flex: 1}}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Name of the Solution
              </Typography>
              <TextField
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter name of the solution"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Client Name / Account Name
              </Typography>
              <TextField
                id="clientName"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter client name"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">Short Decription</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter Short Decription"
                variant="outlined"
                multiline
                rows={8}
                maxRows={8}
                style={{ width: 270 }}
              />
            </Box>
          </Stack>

          {/* Right Column */}
          <Box sx={{ flex: 1 }}>
            <Typography variant="body2" gutterBottom>
              Upload Card images.
            </Typography>
            <Box
              {...getRootProps()}
              sx={{
                border: "2px dashed rgba(15,73,119,0.5)",
                padding: 2,
                borderRadius: 2,
                textAlign: "center",
                cursor: "pointer",
                mt: 2,
                minHeight: "100px", // Optional: setting a height for the drop area
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >


         <Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap" }}>
              {formData.images.map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`Upload preview ${idx}`}
                  style={{
                    width: "50px",
                    minHeight: "50px", 
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                     justifyContent: "center",
                     borderRadius: "10px",
                    padding: 2,
                  }}
                />
              ))}
            </Box>

              <input {...getInputProps()} />
              {isDragActive ? (
                <Typography variant="body2">Drop the files here ...</Typography>
              ) : (
                <img
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2795b546826f0beba01eb465fbf8eb2f193955c9?placeholderIfAbsent=true"
                alt="Card image 2"
                style={{
                  width: "66px",
                  height: "auto",
                }}
              />              )}
            </Box>


            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">Tags</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter Tags"
                fullWidth
                variant="outlined"
                size="small"
              />
              <Typography variant="caption" sx={{ mt: 1, display: "block" }}>
                Use(,) to provide multiple values
              </Typography>
            </Box>

            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">Technologies</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter Technologies"
                fullWidth
                variant="outlined"
                size="small"
              />
              <Typography variant="caption" sx={{ mt: 1, display: "block" }}>
                Use(,) to provide multiple values
              </Typography>
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Demo Video / Walkthrough Link
              </Typography>
              <TextField
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter Demo Video/Walkthrough Link"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>


          </Box>
        </Box>
      </Stack>

      <Stack spacing={2} mt={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="body2" color="text.secondary">Resources & Opportunity</Typography>
        </Box>

       <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
            width:'580px' 
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ flex: 1}}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Supporting Materials and Link
              </Typography>
              <TextField
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter Supporting Materials and Link"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Category / Domain
              </Typography>
              <TextField
                id="clientName"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter Category / Domain"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">IMU Value Chain Tags</Typography>
              </Box>
              <TextField
                id="clientName"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter IMU Value Chain Tags"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>
          </Stack>

          {/* Right Column */}
          <Box sx={{ flex: 1 }}>
          <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">SGU Value Chain Tags</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter SGU Value Chain Tags"
                fullWidth
                variant="outlined"
                size="small"
              />
           </Box>

           <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mt: 1,
                }}
              >
                <Typography variant="body2">Solution Proposed</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter Solution Proposed"
                variant="outlined"
                multiline
                rows={6}
                maxRows={6}
                style={{ width: 270 }}
                sx={{
                  "& input::placeholder":{fontSize:'14',fontWeight:400}
                }}
              />
            </Box>


          </Box>
        </Box>
      </Stack>


    </Paper>
  );
};
