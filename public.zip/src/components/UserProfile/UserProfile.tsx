import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";

import { Box, Button, FormControl, FormLabel, MenuItem, Paper, Select, SelectChangeEvent } from "@mui/material";
import ProfileHeader from "./ProfileHeader";
import ProfileFormField from "./ProfileFormField";
import ProfilePicture from "./ProfilePicture";
import { mainPageStore } from "../../stores/MainPageStore";


interface UserProfileProps {
  initialData?: {
    name: string;
    contact: string;
    email: string;
    profilePicture: string;
  };
}

interface dropDownItems {
  id:string;
  name:string;
}

 const UserProfile: React.FC<UserProfileProps> = ({
  initialData = {
    name: "Dr.Anil",
    contact: "98217836",
    email: "abcd@gmail.com",
    profilePicture: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a12264b35f1b63095e4f5d76a1ef582c1253aaee?placeholderIfAbsent=true"
  }
}) => {
  const [userData, setUserData] = useState(initialData);
  const [selectedSgu, setSelectedSgu] = useState<string>("");
  const [selectedImu, setSelectedImu] = useState<string>("");
  const [sguList, setSguList] = useState<dropDownItems[]>([]);
  const [imuList, setImuList] = useState<dropDownItems[]>([]);

  const {
    fetchFillerListData,
   }  = mainPageStore;


  useEffect(()=>{
    const loadSguData = async() =>{
      const data =  await fetchFillerListData('sgu');
      setSguList(data);
    }
    loadSguData();
   },[]);

   //Load IMU Dropdown Data

   useEffect(()=>{
    const loadImuData = async() =>{
      const data =  await fetchFillerListData('imu');
      setImuList(data);
    }
    loadImuData();
   },[]);


  const handleImuChange = (event: SelectChangeEvent<string>) => {
    setSelectedImu(event.target.value);
  };

  const handleSguChange = (event: SelectChangeEvent<string>) => {
    setSelectedSgu(event.target.value);
  };

  const handleEditPhoto = () => {
    // In a real application, this would open a file picker or modal
    console.log("Edit photo clicked");
  };

  const handleUpdate = () => {
    console.log("Update clicked");
  };

  return (
    <Paper 
      elevation={1}
      sx={{ 
        maxWidth: "100%",
        pb: "20px",
        px: 1,
        borderRadius: 1
      }}
    >
      <ProfileHeader title="User Profile" />
      
      <Box 
        sx={{ 
          display: "flex",
          width: "100%", 
          gap: 4,
          flexWrap: "wrap",
          alignItems: "stretch"
        }}
      >
        <Box 
          sx={{ 
            display: "flex",
            flexDirection: "column",
            minWidth: 300,
            width: "340px",
            justifyContent: "center",
            whiteSpace: "nowrap"
          }}
        >
          <ProfileFormField label="Name" value={userData.name} />
          <ProfileFormField label="Contact" value={userData.contact} />
          <ProfileFormField label="Email" value={userData.email} />

          <Button
            variant="contained"
            sx={{ mt: 2, alignSelf: "flex-start" }}
            onClick={handleUpdate}
          >
            Update
          </Button>
        </Box>
       <Box> 
       <FormControl fullWidth sx={{ mb: 2 }}>
          <FormLabel sx={{ fontSize: 14, mb: 1 ,mt:1,fontWeight:"bold",color: "#1d1b20", 
          lineHeight: 1.2 }}>IMU</FormLabel>
          <Select
          value={selectedImu}
          onChange={handleImuChange}
          displayEmpty
          size="small"
          sx={{
          height: 36,
          fontSize: 13,
          bgcolor: "#EAF2F7",
          }}
          >
          <MenuItem value="">
          <em>Select IMU</em> {/* Or "Clear Selection" */}
          </MenuItem>
          {imuList.map((opt) => (
          <MenuItem key={opt.id} value={opt.id}>
          {opt.name}
          </MenuItem>
          ))}
          </Select>

          </FormControl>

          <FormControl fullWidth sx={{ mb: 2 }}>
          <FormLabel sx={{ fontSize: 14, mb: 1,mt:2,fontWeight:"bold",color: "#1d1b20", 
          lineHeight: 1.2 }}>SGU</FormLabel>
          <Select
          value={selectedSgu}
          onChange={handleSguChange}
          displayEmpty
          size="small"
          sx={{
          height: 36,
          fontSize: 13,
          bgcolor: "#EAF2F7",
          }}
          >
          <MenuItem value="">
          <em>Select SGU</em> {/* Or "Clear Selection" */}
          </MenuItem>
          {sguList.map((opt) => (
          <MenuItem key={opt.id} value={opt.id}>
          {opt.name}
          </MenuItem>
          ))}
          </Select>
          </FormControl>
        <ProfilePicture 
          imageUrl={userData.profilePicture} 
          onEditClick={handleEditPhoto} 
        />
        </Box>
      </Box>
    </Paper>
  );
};

export default observer(UserProfile);
