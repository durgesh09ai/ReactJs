import React from "react";
import { Box, Typography } from "@mui/material";

interface StatisticProps {
  change: string;
  label: string;
  value: string;
}

export const StatisticItem: React.FC<StatisticProps> = ({
  change,
  label,
  value,
}) => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="stretch"
      width="88px"
      mx="auto"
    >
      <Box
        minHeight="88px"
        textAlign="center"
        px="23px"
        py="31px"
        sx={{
          color: "rgba(21,23,24,1)",
          fontSize: "16px",
          fontWeight: 600,
        }}
      >
        {change}
      </Box>

      <Box mt="45px" textAlign="center" width="76px" mx="auto">
        <Typography
          variant="body2"
          sx={{ color: "rgba(91,97,118,1)", fontWeight: 500 }}
        >
          {label}
        </Typography>
        <Typography
          variant="body1"
          sx={{
            color: "rgba(21,23,24,1)",
            fontWeight: 600,
            mt: 1,
            fontSize: "16px",
          }}
        >
          {value}
        </Typography>
      </Box>
    </Box>
  );
};
