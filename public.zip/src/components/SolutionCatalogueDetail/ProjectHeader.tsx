import React from "react";
import { Box, Button, Typography } from "@mui/material";
import VisibilityIcon from "@mui/icons-material/Visibility";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";

interface ProjectHeaderProps {
  title: string;
}

export const ProjectHeader: React.FC<ProjectHeaderProps> = ({ title }) => {
  return (
    <Box
      sx={{
        backgroundColor: "white",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: { xs: "wrap", md: "nowrap" },
        padding: 2,
        borderRadius: "8px 8px 0 0",
        gap: 2,
      }}
    >
      <Typography
        variant="subtitle1"
        sx={{
          color: "#1F2633",
          fontWeight: 600,
          fontSize: "16px",
          lineHeight: 1.5,
          flexGrow: 1,
          minWidth: 200,
        }}
      >
        {title}
      </Typography>

      <Box
        sx={{
          display: "flex",
          gap: 1.5,
          alignItems: "center",
          minWidth: 180,
          textAlign: "center",
        }}
      >
        {/* Live Preview Button */}
        <Button
          variant="outlined"
          size="small"
          startIcon={
            <Box
              sx={{
                width: 24,
                height: 24,
                border: "2px solid #0F4977",
                borderRadius: "4px", // make it round
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <VisibilityIcon sx={{ fontSize: 16, color: "#0F4977" }} />
            </Box>
          }
          sx={{
            fontSize: "12",
            fontWeight:600,
            borderColor: "rgba(15, 73, 119, 1)",
            borderRadius: "3px",
            padding: "4px 12px",
            color: "rgba(15, 73, 119, 1)",
            whiteSpace: "nowrap",
            "&:hover": {
              backgroundColor: "rgba(15, 73, 119, 0.05)",
            },
          }}
        >
          Live Preview
        </Button>

        {/* Watch Demo Button */}
        <Button
          variant="outlined"
          size="small"
          startIcon={
            <Box
              sx={{
                width: 24,
                height: 24,
                border: "2px solid #0F4977",
                borderRadius: "4", // make it round
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <PlayCircleOutlineIcon sx={{ fontSize: 16, color: "#0F4977" }} />
            </Box>
          }
          sx={{
            fontSize: "12",
            fontWeight:600,
            borderColor: "rgba(15, 73, 119, 1)",
            borderRadius: "3px",
            padding: "4px 12px",
            color: "rgba(15, 73, 119, 1)",
            whiteSpace: "nowrap",
            "&:hover": {
              backgroundColor: "rgba(15, 73, 119, 0.05)",
            },
          }}
        >
          Watch Demo
        </Button>
      </Box>
    </Box>
  );
};
