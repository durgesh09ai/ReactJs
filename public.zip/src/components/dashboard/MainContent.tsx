
import React from "react";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import StatCard from "../ui/dashboard/StatCard";
import { useNavigate } from "react-router-dom";

const MainContent: React.FC = () => {

  const navigate = useNavigate();
  const addSolution = () => {
    navigate("/addasolution");
  };

  const stats = [
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff6cc1f225166896c3ec77701a605e5f45d627f?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2add0120e1baa4a531138968983acb2669c4b3f8?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9beeaec86cd1e7b5c710f1ecb71ad4a6175ad970?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9505216f116d2c3a9fb933127751f6c3819a3df?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/46fc2e06ce75b61a266e9dd154a6b05633195e55?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2add0120e1baa4a531138968983acb2669c4b3f8?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/61f6194650a7e18333448a643df76b2d3517ad88?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9505216f116d2c3a9fb933127751f6c3819a3df?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
  ];

  const data = [
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/0efa5fd251ccaae5fab2b7584ad2298d2f012733?placeholderIfAbsent=true", label: "Actuarial / Underwriting", value: "6" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a265057a2999feccdc4f73129584bdd8db69c093?placeholderIfAbsent=true", label: "Benefits Design", value: "8" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c76b37a02a8e6f5631985249aed357cc66a04af4?placeholderIfAbsent=true", label: "Claims/Ops", value: "2" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e2bb5b61a4e971e68a0d5d89ebc01e9ad9bbb1a4?placeholderIfAbsent=true", label: "Clinical Management", value: "12" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/89515736e9af01f21a37ba2fb67e01cb6728e80b?placeholderIfAbsent=true", label: "Clinical Services", value: "1" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/1b2e577d6930e00f91d28d2df0a43f5581cf7193?placeholderIfAbsent=true", label: "Customer Services", value: "13" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5a2c022ec6e6595368f6e29fe1b8f51f0491c857?placeholderIfAbsent=true", label: "Medical Cost Management", value: "14" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae4b2de60bd17b824b506d78f5662e8af2c7b63d?placeholderIfAbsent=true", label: "Network Management", value: "7" }
  ];
  
  
  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px',
      gap: '16px',
    }}>
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'flex-end'
      }}>
        <Button 
          variant="outlined" 
          startIcon={<AddIcon />} 
          onClick={addSolution}
          sx={{ 
            color: '#0F4977', 
            borderColor: '#0F4977',
            boxShadow: '0px 1px 3px 0px rgba(96,108,128,0.05)',
            '&:hover': {
              borderColor: '#0F4977',
              backgroundColor: 'rgba(15, 73, 119, 0.04)'
            }
          }}
        >
          Add New Solution
        </Button>
      </Box>

      <Box
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    gap: '40px',
    alignSelf: 'stretch',
  }}
>  <Stack direction="row" flexWrap="wrap" spacing={2} useFlexGap>
    {stats.map((stat, index) => (
      <Box
        key={index}
        sx={{ width: { xs: '100%', md: 'calc(50% - 8px)' } }}
      >
        <StatCard
          value={stat.value}
          label={stat.label}
          icon={stat.icon}
          trend={stat.trend}
          trendIcon={stat.trendIcon}
          trendText={stat.trendText}
        />
      </Box>
    ))}
  </Stack>
</Box>


      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>


          <Box sx={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '48px'
          }}>
            <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
              Value Delivered Across the Payer Value Chain.
            </Typography>
          </Box>


          <Paper
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: '16px',
    gap: '32px',
    alignSelf: 'stretch',
    borderRadius: '8px',
    backgroundColor: '#FFF',
    border: 'none',
    boxShadow: 'none',
    mt: 2,
  }}
>
<Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
>    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Type</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="by Type" />
      </FormControl>
    </Box>
    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By technology</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="by technology" />
      </FormControl>
    </Box>
  </Stack>
  <Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
>    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Client</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="By Client" />
      </FormControl>
    </Box>
    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Digital & Analytics</FormLabel> {/* Reduced font size */}
        <FilterDropdown label="By Digital & Analytics" />
      </FormControl>
    </Box>
  </Stack>
</Paper>


<Box sx={{ mt: 2 }}>
  <Box
    sx={{
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      gap: 2, // horizontal and vertical spacing
    }}
  >
    {data.map((item, index) => (
      <Box 
        key={index} 
        sx={{ 
          width: 'calc(50% - 8px)', // two items per row with 16px total spacing
        }}
      >
        <DataCard 
          icon={item.icon} 
          label={item.label} 
          value={item.value} 
          labelSx={{ fontWeight: 'bold', fontSize: '0.9rem' }}
        />
      </Box>
    ))}
  </Box>
</Box>

        </Box>
      </Box>
    </Box>
  );
};

export default MainContent;
