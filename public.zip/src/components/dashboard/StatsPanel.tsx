import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";
import UserProfile from "../ui/dashboard/UserProfile";
import LeaderboardItem from "../ui/dashboard/LeaderboardItem";
import LeaderboardFilterDropdown from "../ui/dashboard/LeaderboardFilterDropdown";
import { useNavigate } from "react-router-dom";


export interface Category {
  id: string;
  name: string;
}

export interface UserInterface{
name:string;
designation:string;
points:number;
}

const StatsPanel = () => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };



  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "365px",
        p: 1,
      }}
    >
 
     

      <Box
        sx={{
          display: "flex",
          padding: "0px 8px 16px 8px",
          flexDirection: "column",
          alignItems: "center",
          overflow: "hidden",
          alignSelf: "stretch",
          borderRadius: "12px",
          backgroundColor: "#FFF",
        }}
      >
        <Box
          sx={{
            backgroundColor: "white",
            borderTopLeftRadius: 1,
            px: 2,
            py: 1,
          }}
        >
          <Typography variant="h6" fontSize={16} fontWeight={600}>
            Leaderboard Filter
          </Typography>
        </Box>

        <Box sx={{ width: "100%", py: 2 }}>
          <Stack spacing={2}>
        
          </Stack>

          <Box mt={4}>
            <Typography
              variant="h6"
              fontSize={16}
              fontWeight={600}
              align="center"
              mb={2}
            >
              Top 3 Contributors
            </Typography>

         
          </Box>

          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            <Button
              variant="outlined"
              sx={{
                fontSize: "0.75rem",
                textTransform: "none",
                borderColor: "#0F4977",
                color: "#0F4977",
                borderRadius: 2,
                px: 2,
                py: 1.2,
                boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
                borderWidth: "1px",
              }}
              onClick={() => navigate("/topcontributorstable")}
            >
              View Top contributors
            </Button>
          </Box>
        </Box>
      </Box>
    </Paper>
  );
};

export default StatsPanel;
