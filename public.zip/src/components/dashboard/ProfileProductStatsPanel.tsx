import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";
import UserProfile from "../ui/dashboard/UserProfile";
import { observer } from "mobx-react-lite";
import LeaderboardItem from "../ui/dashboard/LeaderboardItem";
import LeaderboardFilterDropdown from "../ui/dashboard/LeaderboardFilterDropdown";

import { useNavigate } from "react-router-dom";
import { Category, UserInterface } from "./StatsPanel";
import { mainPageStore } from "@/stores/MainPageStore";


interface ProfileProductStatsPanel{
   name:string;
   role:string;
   avatar:string;
   points:number;   
   imuLabel:string;
   sguLabel:string;
}





const ProfileProductStatsPanel = ({name,role,avatar,points,imuLabel,sguLabel}:ProfileProductStatsPanel) => {
 const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };



  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "100%",
        p: 1,
      }}
    >
      
       
        <UserProfile
        name={name}
        role={role}
        avatar={avatar}
        points={points}
        profileproducts="profileproducts"
        imuLabel={imuLabel}
        sguLabel={sguLabel}
      />
      

    
    </Paper>
  );
}

export default observer(ProfileProductStatsPanel)