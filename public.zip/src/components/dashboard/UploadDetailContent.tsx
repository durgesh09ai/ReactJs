// DetailContent.tsx
import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import {
  Box,
  Button,
  Typography,
  Paper,
  Stack,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { mainPageStore } from "../../stores/MainPageStore";
import DetailStatCard from "../ui/dashboard/DetailStatCard";
import { ProductCard } from "./ProductCard";
import HospitalIcon from '@mui/icons-material/LocalHospital';
import AssignmentIcon from '@mui/icons-material/Assignment';
import NumbersIcon from '@mui/icons-material/Pin';
import UploadDetailStatCard from "../ui/dashboard/UploadDetailStatCard";

interface dropDownItems {
  id: string;
  name: string;
}

interface statItems {
  solution_type: string;
  count: number;
}


const summaryData = [
  { icon: <HospitalIcon fontSize="large" />, label: 'Total no of files', value: 50 },
  { icon: <AssignmentIcon fontSize="large" />, label: 'Total no of uploaded files', value: 30 },
];


const UploadDetailContent = () => {
  const navigate = useNavigate();
 


  return (
  
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
       <Paper
                elevation={0}
                sx={{
                  backgroundColor: "white",
                 
                  borderRadius: "10px",
                  width: "100%",
                  p: 1,
                  mt:2,
                }}
              >
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography sx={{  fontSize: "14px", mb: 1 }}>Uploading  Documents</Typography>
      </Box>

      <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: "wrap" }}>
      {summaryData.map((item, idx) => (
            <Box
             key={idx}
              sx={{
                minWidth: "224px" ,
                maxWidth: "224px",
              }}
            >
              <UploadDetailStatCard
                value={item.value}
                label={item.label}
              />
            </Box>
      ))}
      </Stack>
     </Paper>

    </Box>
   
  );
};

export default UploadDetailContent;
