import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Paper,
  TextField,
  Typography,
  Button,
  Stack,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Menu,
  MenuItem,
  LinearProgress,
} from '@mui/material';
import { useDropzone } from 'react-dropzone';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from '@mui/icons-material/Replay';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';




const initialData = [
  {
    hospital: 'Frankfort Regional Medical Center',
    solution_version: 'CCG 1',
    contract: 'Hospital',
    apex_id: 'ACV-0001',
    referral: 'Ref-7',
    apex_worksite: '62424',
    cis_id: 'CSID-123',
    cis_type: 'Pricer',
    start_date: '2025-01-03',
    term_date: '2025-01-03',
    tax_id: 'Single',
    lob: '123',
    description: 'Parent contract',
    status: 'Completed'
  },
];

const UploadContractListing = () => {

  const filesToUploadRef = useRef<File[]>([]);

  const [data, setData] = useState(initialData);
  const [search, setSearch] = useState('');
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [pdfDialogOpen, setPdfDialogOpen] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState<number | null>(null);

  const isMenuOpen = Boolean(anchorEl);
  const isUploadingRef = useRef(false);

  const onDrop = (acceptedFiles: File[]) => {
    const pdfFiles = acceptedFiles.filter(file => file.type === "application/pdf");
    setUploadedFiles(prev => [...prev, ...pdfFiles]);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
    accept: { "application/pdf": [] }
  });

  const handleUploadAll = () => {
    if (isUploadingRef.current) return; // prevent double trigger
    if (uploadedFiles.length === 0) return;
  
    isUploadingRef.current = true;
    filesToUploadRef.current = [...uploadedFiles]; // store files here
  
    setUploading(true);
    setUploadProgress(0);
  };

  useEffect(() => {
    if (!uploading) return;
  
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
  
          const dummyEntries = filesToUploadRef.current.map((file, index) => ({
            hospital: file.name.replace('.pdf', ''),
            solution_version: index % 2 === 0 ? 'CCG 1' : 'CCG 2',
            contract: index % 2 === 0 ? 'Hospital' : 'Physician',
            apex_id: `ACV-UP-${Date.now()}-${index}`,
            referral: `Ref-${Math.floor(Math.random() * 10)}`,
            apex_worksite: `${90000 + index}`,
            cis_id: `CSID-UP-${index}`,
            cis_type: index % 2 === 0 ? 'Pricer' : 'DRG',
            start_date: '2025-08-17',
            term_date: '2025-08-17',
            tax_id: `Tax-${index}`,
            lob: `${100 + index}`,
            description: 'Uploaded via PDF drop',
            status: 'Processing...'
          }));
  
          setData(prev => [...prev, ...dummyEntries]);
          setUploadedFiles([]); 
          setTimeout(() => {
            setUploading(false);
            setPdfDialogOpen(false);
            isUploadingRef.current = false;
            filesToUploadRef.current = [];
          }, 800);
  
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  
    return () => clearInterval(interval);
  }, [uploading]);

  const filteredData = useMemo(() => {
    return data.filter(row =>
      row.hospital.toLowerCase().includes(search.toLowerCase()) ||
      row.contract.toLowerCase().includes(search.toLowerCase()) ||
      row.apex_id.toLowerCase().includes(search.toLowerCase())
    );
  }, [search, data]);

  return (
    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', p: 2 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <TextField
          size="small"
          placeholder="Quick Search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

          <Stack direction="row" alignItems="center" spacing={2}>
            <Box display="flex" alignItems="center" gap={1}>
              <Box sx={{ width: 16, height: 20, borderRadius: 16, bgcolor: '#f45d20de' }} />
              <Typography variant="body2">CCG 1</Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <Box sx={{ width: 16, height: 20, borderRadius: 16, bgcolor: '#87CEEB' }} />
              <Typography variant="body2">CCG 2</Typography>
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <Box sx={{ width: 16, height: 20, borderRadius: 16, bgcolor: '#2476B7' }} />
              <Typography variant="body2">CCG Unified</Typography>
            </Box>
          </Stack>

        <Button
          variant="contained"
          startIcon={<CloudUploadIcon />}
          size="small"
          onClick={() => setPdfDialogOpen(true)}
        >
          Upload PDF
        </Button>
      </Stack>

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead sx={{ bgcolor: '#0F4977' }}>
            <TableRow>
              {['S.No', 'Solution Version', 'Document Name', 'Contract Type', 'CIS ID', 'CIS ID Type', 'Start Date', 'Term Date', 'Tax ID', 'Description', 'Status', 'Action'].map((heading, i) => (
                <TableCell key={i} sx={{ color: 'white', fontSize: '14px' }}>{heading}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredData.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{idx + 1}.</TableCell>
                <TableCell>
                  <Box sx={{
                    width: 16, height: 20, borderRadius:16,
                    bgcolor: row.solution_version === 'CCG 1' ? '#f45d20de' : '#87CEEB'
                  }} />
                </TableCell>
                <TableCell>{row.hospital}</TableCell>
                <TableCell>
                  <Chip label={row.contract} size="small" sx={{ bgcolor: '#EAF2F7', color: '#0F4977' }} />
                </TableCell>
                <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black' }} /></TableCell>
                <TableCell>{row.cis_type}</TableCell>
                <TableCell>{row.start_date}</TableCell>
                <TableCell>{row.term_date}</TableCell>
                <TableCell>{row.tax_id}</TableCell>
                <TableCell>{row.description}</TableCell>
                <TableCell>
                  <Chip
                  onClick={()=>{console.log('click!')}}
                    label={row.status}
                    size="small"
                    sx={{
                      bgcolor: 'white',
                      color:
                        row.status === 'Completed' ? '#4CAF50' :
                          row.status === 'Processing...' ? '#604F4F' : '#B3261E',
                      border: `1px solid ${
                        row.status === 'Completed' ? '#4CAF50' :
                        row.status === 'Processing...' ? '#604F4F' : '#B3261E'}`
                    }}
                  />
                </TableCell>
                <TableCell>
                  <IconButton size="small" onClick={(e) => setAnchorEl(e.currentTarget)}>
                    <MoreVertIcon sx={{ fontSize: 14 }} />
                  </IconButton>

                  <Menu
              anchorEl={anchorEl}
              open={isMenuOpen}
              onClose={() => setAnchorEl(null)}
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              transformOrigin={{ vertical: "top", horizontal: "right" }}
              PaperProps={{
                elevation: 1, 
                sx: {
                  boxShadow: 'none', 
                  border: '1px solid #ccc', 
                  mt: 0.2 
                }
              }}
            >
            <MenuItem onClick={() => setAnchorEl(null)} sx={{ fontSize: 12 }}>
              <ReplayIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Retry
            </MenuItem>
            <MenuItem
              onClick={() => {
                setDeleteConfirmOpen(true);
                setRowToDelete(idx);  // Pass the row index
                setAnchorEl(null);
              }}
              sx={{ fontSize: 12 }}
            >
              <DeleteIcon fontSize="small" sx={{ mr: 1, fontSize: 12 }} /> Delete
            </MenuItem>
          </Menu>


                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Upload PDF Dialog */}
      <Dialog open={pdfDialogOpen} onClose={() => setPdfDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontSize: 14 }}>Upload PDF</DialogTitle>
        <DialogContent sx={{ bgcolor: "#EAF2F7", py: 2 }}>
          <Box
            {...getRootProps()}
            sx={{
              border: '2px dashed #aaa',
              borderRadius: 2,
              padding: 2,
              mt:2,
              textAlign: 'center',
              cursor: 'pointer',
              backgroundColor: isDragActive ? '#ddd' : '#F7FBFF',
              transition: '0.3s'
            }}
          >
            <input {...getInputProps()} />
            <CloudUploadIcon sx={{ fontSize: 48, mb: 1, color: '#0F4977' }} />
            <Typography variant="body1" gutterBottom>
              Drag & drop PDF files or <span style={{ color: '#0F4977', textDecoration: 'underline' }}>Browse</span>
            </Typography>
            <Typography variant="caption">Supported format: PDF <br/>Max size: 10MB</Typography>

          </Box>

          {uploadedFiles && uploadedFiles.length>0 && (
          <Typography variant="caption">Selected PDF Files</Typography>
          )}

          {uploadedFiles.map((file, idx) => (
            <Stack key={idx} direction="row" alignItems="center" spacing={1} mt={1}>
              <PictureAsPdfIcon fontSize="small" sx={{ color: '#B71C1C' }} />
              <Typography variant="body2" sx={{fontSize:12}}>{file.name}</Typography>
            </Stack>
          ))}
          

          {uploading && (
            <Box mt={3}>
              <Typography variant="body2" gutterBottom>Uploading... {uploadProgress}%</Typography>
              <LinearProgress variant="determinate" value={uploadProgress} />
            </Box>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setPdfDialogOpen(false)} disabled={uploading}>Cancel</Button>
          <Button variant="contained" onClick={handleUploadAll} disabled={uploadedFiles.length === 0 || uploading}>
            Upload All
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete */}

  <Dialog
      open={deleteConfirmOpen}
      onClose={() => setDeleteConfirmOpen(false)}
      maxWidth="xs"
      fullWidth
    >
  <DialogTitle sx={{ fontSize: 16 }}>Confirm Deletion</DialogTitle>
  <DialogContent>
    <Typography variant="body2">
      Are you sure you want to delete this contract entry?
    </Typography>
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
    <Button
      variant="contained"
      color="error"
      startIcon={<DeleteIcon />}
      onClick={() => {
        if (rowToDelete !== null) {
          const newData = [...data];
          newData.splice(rowToDelete, 1);
          setData(newData);
        }
        setDeleteConfirmOpen(false);
        setRowToDelete(null);
      }}
    >
      Delete
    </Button>
  </DialogActions>
</Dialog>


    </Paper>
  );
};

export default UploadContractListing;