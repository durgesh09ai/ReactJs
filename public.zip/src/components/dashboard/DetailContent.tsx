// DetailContent.tsx
import React, { useEffect } from "react";
import { observer } from 'mobx-react-lite';
import { summaryStore } from '../../stores/DetailContentStore';
import {
  Box, Typography,
  Paper,
  Stack, CircularProgress
} from "@mui/material";
import { useNavigate } from "react-router-dom";

import DetailStatCard from "../ui/dashboard/DetailStatCard";

import HospitalIcon from '@mui/icons-material/LocalHospital';
import AssignmentIcon from '@mui/icons-material/Assignment';
import NumbersIcon from '@mui/icons-material/Pin';



interface dropDownItems {
  id: string;
  name: string;
}

interface statItems {
  solution_type: string;
  count: number;
}



const iconMap:{[label:string]:React.ReactNode}={
  "Total Hospital Name":<HospitalIcon fontSize="large" />,
  "Total Contract Type":<AssignmentIcon fontSize="large" />,
  "Total Apex Cover ID":<NumbersIcon fontSize="large" />,
  "Total CIS ID":<NumbersIcon fontSize="large" />,
}


const DetailContent = () => {
  const navigate = useNavigate();
 
  useEffect(()=>{
    summaryStore.fetchSummaryData();
  },[])

 



  return (
  
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
       <Paper
                elevation={0}
                sx={{
                  backgroundColor: "white",
                 
                  borderRadius: "10px",
                  width: "100%",
                  p: 1,
                  mt:2,
                }}
              >
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography sx={{  fontSize: "14px", mb: 1 }}>Summary</Typography>
      </Box>

      {summaryStore.loading ? (
          <Box display="flex" justifyContent="center" py={4}>
            <CircularProgress />
          </Box>
        ) :(
 <Stack direction="row" spacing={1} sx={{ mt: 1, flexWrap: "wrap" }}>
      {summaryStore.summaryData.map((item, idx) => (
            <Box
             key={idx}
              sx={{
                minWidth: "200px" ,
                maxWidth: "200px",
              }}
            >
              <DetailStatCard
                value={item.value}
                label={item.label}
                 icon="./stat_icon.png"
                trend="+12%"
                trendIcon="./arrow.svg"
                trendText="Since last month"
              />
            </Box>
      ))}
      </Stack>
        )}


     
     </Paper>
      
      
      
      {/* <Box sx={{ width: "100%", mt: 4 }}>
        <Paper
          elevation={1}
          sx={{ borderRadius: "8px", border: "1px solid rgba(15,73,119,0.1)", overflow: "hidden" }}
        >
       
        </Paper>
      </Box> */}
    </Box>
   
  );
};

export default observer(DetailContent);
