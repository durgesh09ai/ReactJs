
import React from "react";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import DetailStatCard from "../ui/dashboard/DetailStatCard";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import { useNavigate } from "react-router-dom";

const DetailContent = () => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/");
  };


  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px'
    }}>

<Box 
  sx={{ 
    display: "flex", 
    justifyContent: "flex-end", 
    gap: 2 // Adjust the spacing between buttons
  }}
>
  <Button 
    variant="outlined" 
    startIcon={<AddIcon />} 
    sx={{ 
      color: "#0F4977", 
      borderColor: "#0F4977",
      fontSize: "12px", // Smaller text
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
      height:'40px',
      borderRadius: '8px',
      "&:hover": {
        borderColor: "#0F4977",
        backgroundColor: "rgba(15, 73, 119, 0.04)"
      }
    }}
  >
    Add New Solution
  </Button>

  <Button 
  onClick={handleClick}
    variant="contained" 
    startIcon={<EmojiEventsIcon />} // Champion icon for "My Stat and Rank"
    sx={{ 
      color: "#FFF", 
      borderColor: "#0F4977",
      fontSize: "14px", 
      borderRadius: '8px',
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
    }}
  >
    My Stat and Rank
  </Button>
</Box>


<Stack
  direction="row"
  spacing={2}
  sx={{
    mt: 2,
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  }}
>
  {[1, 2, 3, 4].map((_, idx) => (
    <Box
      key={idx}
      sx={{
        flex: '1 1 22%', // allows shrinking a bit to fit 4
        minWidth: '200px', // fallback for mobile
        maxWidth: '25%',
      }}
    >
      <DetailStatCard
        value="125"
        label={`Label ${idx + 1}`}
        icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff6cc1f225166896c3ec77701a605e5f45d627f?placeholderIfAbsent=true"
        trend="+12%"
        trendIcon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2add0120e1baa4a531138968983acb2669c4b3f8?placeholderIfAbsent=true"
        trendText="Since last month"
      />
    </Box>
  ))}
</Stack>



      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>
          <Box sx={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '48px'
          }}>
            
            <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
              Value Delivered Across the Payer Value Chain.
            </Typography>
          </Box>

<Paper
  sx={{
    p: 3,
    mt: 2,
    borderRadius: 2,
    border: 'none',
    boxShadow: 'none',
  }}
>
  <Stack
    direction="row"
    spacing={2}
    sx={{
      flexWrap: 'nowrap',
      minWidth: '100%',
    }}
  >
    {[ 'By Type', 'By Technology', 'By Client', 'By Digital & Analytics' ].map((label) => (
      <Box
        key={label}
        sx={{
          flex: '1 1 22%', // responsive width
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
        <FormControl fullWidth>
<FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>            {label}
          </FormLabel>
          <FilterDropdown label={label} />
        </FormControl>
      </Box>
    ))}
  </Stack>
</Paper>


        {/* Cards Section */}
    <Box sx={{ mt: 2 }}>
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, 1fr)',
            md: 'repeat(3, 1fr)',
            lg: 'repeat(4, 1fr)',
          },
          gap: 2,
        }}
      >
        {[
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/0efa5fd251ccaae5fab2b7584ad2298d2f012733?placeholderIfAbsent=true",
            label: "Actuarial / Underwriting",
            value: "6",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a265057a2999feccdc4f73129584bdd8db69c093?placeholderIfAbsent=true",
            label: "Benefits Design",
            value: "8",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c76b37a02a8e6f5631985249aed357cc66a04af4?placeholderIfAbsent=true",
            label: "Claims/Ops",
            value: "2",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e2bb5b61a4e971e68a0d5d89ebc01e9ad9bbb1a4?placeholderIfAbsent=true",
            label: "Clinical Management",
            value: "12",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/89515736e9af01f21a37ba2fb67e01cb6728e80b?placeholderIfAbsent=true",
            label: "Clinical Services",
            value: "1",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/1b2e577d6930e00f91d28d2df0a43f5581cf7193?placeholderIfAbsent=true",
            label: "Customer Services",
            value: "13",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5a2c022ec6e6595368f6e29fe1b8f51f0491c857?placeholderIfAbsent=true",
            label: "Medical Cost Management",
            value: "14",
          },
          {
            icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae4b2de60bd17b824b506d78f5662e8af2c7b63d?placeholderIfAbsent=true",
            label: "Network Management",
            value: "7",
          },
        ].map(({ icon, label, value }) => (
          <Box key={label}>
            <DataCard
              icon={icon}
              label={label}
              value={value}
              labelSx={{ fontWeight: 'bold', fontSize: '0.9rem' }}
            />
          </Box>
        ))}
      </Box>
    </Box>



        
        </Box>
      </Box>
    </Box>
  );
};

export default DetailContent;
