// ContractListing.tsx
import { useState, useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { contractStore } from '../../stores/ContractStore';
import { useNavigate } from "react-router-dom";

import {
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Paper,
  TextField,
  Checkbox,
  Typography,
  Button,
  Select,
  MenuItem,
  Stack,
  Drawer,
  Chip,
  InputLabel,
  FormControl,
  IconButton,
  CircularProgress,
  Menu,
  Tabs,
  Tab,
} from '@mui/material';
import { Pagination } from '../SolutionCatalogue/Pagination';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import DeleteIcon from "@mui/icons-material/Delete";
import ReplayIcon from '@mui/icons-material/Replay';
import MoreVertIcon from "@mui/icons-material/MoreVert";
import EditNoteIcon from '@mui/icons-material/EditNote';
import OpenInBrowserIcon from '@mui/icons-material/OpenInBrowser';
import RestoreIcon from '@mui/icons-material/Restore';
import NoteAddIcon from '@mui/icons-material/NoteAdd';
import DownloadIcon from '@mui/icons-material/Download';

const rowsPerPage = 5;

    const chat_thinking =  [
        {
            "step": "searching",
            "details": {
                "query": "\"type 2 diabetes\" AND (real-world evidence OR RWE) AND (age OR gender OR \"clinical characteristics\") AND (glycemic control OR HbA1c) AND (hospitalization rates)",
                "query_index": 2,
                "total_queries": 4
            },
            "progress": 6.25
        },
        {
            "step": "searching",
            "details": {
                "query": "\"diabetes mellitus\" AND \"treatment patterns\" AND (age OR gender OR comorbidities) AND (EHR OR claims data OR registry) AND (propensity score matching)",
                "query_index": 3,
                "total_queries": 4
            },
            "progress": 12.5
        },
        {
            "step": "searching",
            "details": {
                "query": "\"type 2 diabetes\" AND \"healthcare utilization\" AND (age OR comorbidities) AND (observational study OR retrospective study)",
                "query_index": 4,
                "total_queries": 4
            },
            "progress": 18.75
        },
        {
            "step": "analyzing_paper",
            "details": {
                "paper": "Type 2 diabetes mellitus as a predictor of severe outcomes in COVID-19 - a systematic review and meta-analyses.",
                "index": 1,
                "total": 1,
                "source": "EuropePMC"
            },
            "progress": 30
        },
        {
            "step": "synthesizing_research",
            "details": {
                "papers_analyzed": 1
            },
            "progress": 70
        },
        {
            "step": "searching",
            "details": {
                "query": "\"Type 2 Diabetes Mellitus\" AND (\"claims data\" OR \"electronic health records\" OR \"registry data\") AND \"observational study\" AND (\"age\" OR \"gender\" OR \"comorbidities\" OR \"medication\") AND \"glycemic control\" AND \"healthcare utilization\" AND (adult OR adults)",
                "query_index": 5,
                "total_queries": 7
            },
            "progress": 14.285714285714285
        },
        {
            "step": "searching",
            "details": {
                "query": "\"Type 2 Diabetes Mellitus\" AND (\"real-world data\" OR \"routine clinical practice\") AND \"observational study\" AND (\"HbA1c\" OR \"hospitalization\" OR \"healthcare costs\") AND (\"treatment patterns\" OR \"medication adherence\") AND (adult OR adults)",
                "query_index": 6,
                "total_queries": 7
            },
            "progress": 17.857142857142858
        },
        {
            "step": "analyzing_paper",
            "details": {
                "paper": "Type 2 diabetes mellitus as a predictor of severe outcomes in COVID-19 - a systematic review and meta-analyses.",
                "index": 1,
                "total": 1,
                "source": "EuropePMC"
            },
            "progress": 30
        },
        {
            "step": "synthesizing_research",
            "details": {
                "papers_analyzed": 2
            },
            "progress": 70
        },
        {
            "step": "generating_report",
            "details": {},
            "progress": 90
        },
        {
            "step": "completed",
            "details": {
                "report_available": true
            },
            "progress": 100
        }
    ];


const ProcessingScreenTab = () => {
    const navigate = useNavigate();
   const historyPageClick = () => navigate("/rate-history");

   useEffect(()=>{
    contractStore.fetchContractListing();
   },[])

  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const isMenuOpen = Boolean(anchorEl);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState<number | null>(null);
  const [selectedTab, setSelectedTab] = useState(0);

  const handleTabChange = (_event: any, newValue: React.SetStateAction<number>) => {
    setSelectedTab(newValue);
  };


  const [filterValues, setFilterValues] = useState({
    hospital: '',
    contract: '',
    cisType: '',
    cdgType: '',
    taxId: '',
    date: '',
    
    ccgCategory:'',
  });

  
// Filtered data directly reactive via MobX
const filteredData = contractStore.contracts
  .filter((row) => {
    const matchesDate =
      !filterValues.date ||
      new Date(row.start_date).toISOString().split('T')[0] === filterValues.date;

    return (
      (!filterValues.hospital ||
        row.hospital.toLowerCase().includes(filterValues.hospital.toLowerCase())) &&
      (!filterValues.contract || row.contract === filterValues.contract) &&
      (!filterValues.cisType || row.cis_type === filterValues.cisType) &&
      (!filterValues.cdgType || row.cis_type === filterValues.cdgType) 
    );
  })
  .filter(
    (row) =>
      row.hospital.toLowerCase().includes(search.toLowerCase()) ||
      row.contract.toLowerCase().includes(search.toLowerCase()) 
  );

// Paginate directly, reactive via MobX
const paginatedData = filteredData.slice(
  (currentPage - 1) * rowsPerPage,
  currentPage * rowsPerPage
);


  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
  };

const STEP_LABELS: Record<string, string> = {
  searching: "Researching in Progress",
  selecting_papers: "Selecting Papers",
  analyzing_paper: "Analyzing Papers",
  synthesizing_research: "Synthesizing Research",
  generating_report: "Generating Report",
  completed: "Completed",
  error: "Error",
};

  const ORDERED_STEPS = [
  "searching",
  "selecting_papers",
  "analyzing_paper",
  "synthesizing_research",
  "generating_report",
  "completed",
  "error",
];

    const transformedData = ORDERED_STEPS.map((stepKey) => {
    const filtered = chat_thinking.filter((item) => item.step === stepKey);
    if (filtered.length === 0) return null;

    const sectionItems = filtered.map((item) => {
      let message = "", sub = "", percentageText = "Progress";

      switch (stepKey) {
        case "searching":
          percentageText = "Searching the Queries";
          message = "Searching...";
          break;
        case "selecting_papers":
          message = "Selecting relevant papers...";
          break;
        case "analyzing_paper":
          percentageText = "Analyzing Paper";
          message =  "Analyzing paper...";
          break;
        case "synthesizing_research":
          message = "Synthesizing research...";
          break;
        case "generating_report":
          message = "Creating final research report...";
          break;
        case "completed":
          message = "Research completed successfully!";
          break;
        case "error":
          message = "An error occurred.";
          break;
        default:
          message = "Processing...";
      }

      return {
        percent: Math.round(item.progress || 0),
        percentageText,
        message,
        sub,
      };
    });

    return {
      section: STEP_LABELS[stepKey] || stepKey,
      items: sectionItems,
    };
  }).filter(Boolean);



  return (
    <Paper elevation={0} sx={{ backgroundColor: 'white', borderRadius: '10px', width: '100%',height:'100%', p: 0}}>
        {contractStore.isLoading?(
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
        ):(
       <Box>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={1}>
          <TextField
            size="small"
            placeholder="Quick Search"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
          />

          <Stack direction="row" spacing={1}>
         
            <Button
              variant="outlined"
              startIcon={<FilterAltIcon />}
              size="small"
              onClick={() => setFilterDrawerOpen(true)}
            >
              Filter
            </Button>
          </Stack>
        </Stack>

<Stack
  direction="row"
  justifyContent="space-between"
  alignItems="center"
  mb={2}
  mt={2}
  sx={{ width: '100%', border:"1px solid #ccc", borderRadius:1 }}
>
  <Tabs value={selectedTab} onChange={handleTabChange} sx={{ width: '100%',textAlign: 'center' }}>
    <Tab label="Show Fetched Data" sx={{width:"33%" , textTransform: 'none' }}/>
    <Tab label="Show Excluded Data" sx={{width:"33%" , textTransform: 'none' }} />
    <Tab label="Show Result" sx={{width:"33%",textTransform: 'none' }}/>
  </Tabs>
</Stack>


{selectedTab === 0 && (      
  <Stack direction="row" spacing={1}>
    <Box sx={{ flex: 1,width:"70%" }}>

      <TableContainer component={Paper}>
          <Table size="small">
            <TableHead sx={{ bgcolor: '#0F4977' }}>
              <TableRow>
                {['Query Id', 'Contract Definition', 'Service Definition','IP Payment Method','0P Payment Method ',
                'Coverage Start','Coverage End','IP Payment Value','OP Payment Value','Recoupment Period','Description','Action'].map((heading, i) => (
                  <TableCell key={i} sx={{ color: 'white',fontSize:'14px' }}>{heading}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, idx) => {
                const isSelected = selectedRows.includes(idx);
                return (
                  <TableRow key={idx} sx={{ bgcolor: isSelected ? '#e3f2fd' : 'inherit' }}>
                   
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                     <TableCell>

                    </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
      </TableContainer> 

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>
      <Box>
        {transformedData.map((section, sIndex) => (
              <Box key={sIndex} sx={{ mb: 3 }}>
                <Typography
                  variant="subtitle2"
                  sx={{
                    display: "inline-block",
                    backgroundColor: "rgba(18, 18, 21, 0.30)",
                    color: "#fff",
                    px: 1.5,
                    py: 0.5,
                    borderRadius: "0 8px 8px 0",
                    fontWeight: 600,
                    fontSize: "0.75rem",
                    mb: 1,
                  }}
                >
                  {section.section}
                </Typography>

                <Stack spacing={1}>
                  {section.items.map((item, index) => (
                    <Box
                      key={index}
                      sx={{
                        borderLeft: "2px solid #ccc",
                        backgroundColor: "#e4e4e533",
                        p: 1,
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "flex-start" }}>
                        <Box
                          sx={{
                            width: 24,
                            height: 24,
                            position: "relative",
                            flexShrink: 0,
                            mt: 1,
                          }}
                        >
                          <Box
                            sx={{
                              position: "absolute",
                              top: "50%",
                              right: "-15%",
                              transform: "translate(-50%, -50%)",
                              width: 8,
                              height: 8,
                              borderRadius: "50%",
                              backgroundColor: "#ccc",
                              zIndex: 1,
                            }}
                          />
                          <Box
                            sx={{
                              position: "absolute",
                              top: "50%",
                              right: "35%",
                              height: 2,
                              width: "100%",
                              backgroundColor: "#B0BEC5",
                              transform: "translateY(-50%)",
                              zIndex: 0,
                            }}
                          />
                        </Box>

                        <Box sx={{ flex: 1, ml: 1 }}>
                          <Typography
                            variant="subtitle2"
                            sx={{
                              fontSize: "0.8rem",
                              color: "#636262",
                              fontWeight: 500,
                              mb: 0.5,
                              pt: 1,
                            }}
                          >
                            {item.percentageText}: ({item.percent}%)
                          </Typography>

                          <Paper elevation={0} sx={{ p: 1.5, backgroundColor: "#fff" }}>
                            <Typography variant="body2" sx={{ fontSize: "0.85rem" }}>
                              {item.message}
                            </Typography>
                            {item.sub && (
                              <Typography variant="caption" sx={{ color: "#999", display: "block", mt: 0.5 }}>
                                {item.sub}
                              </Typography>
                            )}
                          </Paper>
                        </Box>
                      </Box>
                    </Box>
                  ))}
                </Stack>
              </Box>
            ))}
      </Box>


    </Box>

  </Stack>
)}

{selectedTab === 1 && (      
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1,width:"70%" }}>


 <TableContainer component={Paper}>
          <Table size="small">
            <TableHead sx={{ bgcolor: '#0F4977' }}>
              <TableRow>
                {['Query Id', 'Contract Definition', 'Service Definition','IP Payment Method','0P Payment Method ',
                'Coverage Start','Coverage End','IP Payment Value','OP Payment Value','Recoupment Period','Description','Action'].map((heading, i) => (
                  <TableCell key={i} sx={{ color: 'white',fontSize:'14px' }}>{heading}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, idx) => {
                const isSelected = selectedRows.includes(idx);
                return (
                  <TableRow key={idx} sx={{ bgcolor: isSelected ? '#e3f2fd' : 'inherit' }}>
                   
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                     <TableCell>

                    </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
      </TableContainer> 

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>

    </Box>

  </Stack>
)}

{selectedTab === 2 && (      
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1,width:"70%" }}>

 <TableContainer component={Paper}>
          <Table size="small">
            <TableHead sx={{ bgcolor: '#0F4977' }}>
              <TableRow>
                {['Query Id', 'Contract Definition', 'Service Definition','IP Payment Method','0P Payment Method ',
                'Coverage Start','Coverage End','IP Payment Value','OP Payment Value','Recoupment Period','Description','Action'].map((heading, i) => (
                  <TableCell key={i} sx={{ color: 'white',fontSize:'14px' }}>{heading}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, idx) => {
                const isSelected = selectedRows.includes(idx);
                return (
                  <TableRow key={idx} sx={{ bgcolor: isSelected ? '#e3f2fd' : 'inherit' }}>
                   
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell>{row.cis_type}</TableCell>
                    <TableCell><Chip label={row.cis_id} size="small" sx={{ bgcolor: '#E4E4E5', color: 'black',fontSize:'12px' }} /></TableCell>
                     <TableCell>

                    </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
      </TableContainer> 

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>

    </Box>

  </Stack>
)}



        




      {/*   Filter Drawer */}
        <Drawer anchor="right" open={filterDrawerOpen} onClose={() => setFilterDrawerOpen(false)}>
          <Box sx={{ width: 320, p: 3 }}>
            <Stack direction="row" alignItems="center" mb={2} spacing={1}>
                <IconButton onClick={() => setFilterDrawerOpen(false)} size='small'>
                <ChevronRightIcon />
              </IconButton>
              <Typography variant="h6" sx={{fontSize:14}}>Filter</Typography>
            
            </Stack>
            <Stack spacing={2}>
              <TextField  size="small" label="Hospital/Physician Name" fullWidth value={filterValues.hospital} onChange={(e) => handleFilterChange('hospital', e.target.value)}  InputLabelProps={{sx:{fontSize:14}}} inputProps={{style:{fontSize:14}}}/>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>Contract Type</InputLabel>
                <Select label="Contract Type" value={filterValues.contract} onChange={(e) => handleFilterChange('contract', e.target.value)} sx={{fontSize:14}}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Hospital">Hospital</MenuItem>
                  <MenuItem value="Physician">Physician</MenuItem>
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>CIS Type</InputLabel>
                <Select sx={{fontSize:14}} label="CIS Type" value={filterValues.cisType} onChange={(e) => handleFilterChange('cisType', e.target.value)}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Pricer">Pricer</MenuItem>
                  <MenuItem value="DRG">DRG</MenuItem>
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <InputLabel sx={{fontSize:14}}>CDG Type</InputLabel>
                <Select sx={{fontSize:14}} label="CDG Type" value={filterValues.cdgType} onChange={(e) => handleFilterChange('cdgType', e.target.value)}>
                  <MenuItem value="">All</MenuItem>
                  <MenuItem value="Pricer">Pricer</MenuItem>
                  <MenuItem value="DRG">DRG</MenuItem>
                </Select>
              </FormControl>
     
              <Button variant="contained" fullWidth sx={{ bgcolor: '#003366', mt: 2,fontSize:14}} onClick={() => setFilterDrawerOpen(false)}>
                Save
              </Button>
            </Stack>
          </Box>
        </Drawer>

      </Box>

        )}
       
    </Paper>
  );
};

export default observer(ProcessingScreenTab);
