import React, { useEffect } from "react";
import { observer } from 'mobx-react-lite';
import { summaryStore } from '../../stores/DetailContentStore';
import {
  Box, Typography,
  Paper, Stack,
  Button, TextField,
  MenuItem
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Breadcrumb } from "./Breadcrumb";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const breadcrumbItems = [
  { label: "Home", href: "/" },
  { label: "Set Rate List" },
  { label: "Add Rate" },
];

const ccgTypes = [
  { value: "Type A", label: "Type A" },
  { value: "Type B", label: "Type B" },
  { value: "Type C", label: "Type C" }
];

const AddRate = () => {
  const navigate = useNavigate();
  const RateListPageClick = () => navigate("/rate-listing");
  const providerPageClick = () => navigate("/contract-provider");

  useEffect(() => {
    summaryStore.fetchSummaryData();
  }, []);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px" }}>
      <Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 2 }}>
        <Breadcrumb items={breadcrumbItems} />

        {/* 🔹 Title Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "16px", fontWeight: "bold",mt:3 }}>
            Add Rate
          </Typography>
        </Box>

        {/* 🔹 Basic Info Row */}
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "14px", fontWeight: "normal", color: '#888' }}>
            Basic Information
          </Typography>
        </Box>

{/* 📝 Form Fields - 2 per row using Stack */}
<Paper elevation={0} sx={{ backgroundColor: "white", borderRadius: "10px", width: "100%", p: 1 }}>
  <Box sx={{ maxWidth: 720, ml: 0 }}>

<Stack spacing={2} sx={{ mb: 2 }}>
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Name
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter name"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        OP payment Value
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter OP payment Value"
      />
    </Box>
  </Stack>

  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Query ID
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter Query ID"
      />
    </Box>

    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>
        Min Overpaid Amount
      </Typography>
      <TextField
        variant="outlined"
        fullWidth
        size="small"
        placeholder="Enter Min Overpaid Amount"
      />
    </Box>
  </Stack>
</Stack>


<Stack spacing={2} sx={{ mb: 2 }}>
  {/* Row 1 - Coverage Start / Coverage End (dates stay as is) */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Coverage Start</Typography>
      <TextField type="date" variant="outlined" fullWidth size="small" />
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Coverage End</Typography>
      <TextField type="date" variant="outlined" fullWidth size="small" />
    </Box>
  </Stack>

  {/* Row 2 - Contract Definition (Select) / Description */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Contract Definition</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="def1">Definition 1</MenuItem>
        <MenuItem value="def2">Definition 2</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Description</Typography>
      <TextField multiline minRows={2} variant="outlined" fullWidth size="small" placeholder="Enter description" />
    </Box>
  </Stack>

  {/* Row 3 - Service Definition (Select) / Min Overpaid Amount */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Service Definition</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="svc1">Service 1</MenuItem>
        <MenuItem value="svc2">Service 2</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Min Overpaid Amount</Typography>
      <TextField variant="outlined" fullWidth size="small" placeholder="Enter amount" />
    </Box>
  </Stack>

  {/* Row 4 - IP Payment Method (Select) / Custom Fetch SQL */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>IP Payment Method</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="methodA">Method A</MenuItem>
        <MenuItem value="methodB">Method B</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Custom Fetch SQL</Typography>
      <TextField multiline minRows={2} variant="outlined" fullWidth size="small" placeholder="Enter SQL query" />
    </Box>
  </Stack>

  {/* Row 5 - OP Payment Method (Select) / Custom LV Exclusion SQL */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>OP Payment Method</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="methodX">Method X</MenuItem>
        <MenuItem value="methodY">Method Y</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Custom LV Exclusion SQL</Typography>
      <TextField multiline minRows={2} variant="outlined" fullWidth size="small" placeholder="Enter SQL query" />
    </Box>
  </Stack>

  {/* Row 6 - IP Payment Value (Select) / Custom LV Exclusion SQL */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>IP Payment Value</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="value1">Value 1</MenuItem>
        <MenuItem value="value2">Value 2</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Custom LV Exclusion SQL</Typography>
      <TextField multiline minRows={2} variant="outlined" fullWidth size="small" placeholder="Enter SQL query" />
    </Box>
  </Stack>

  {/* Row 7 - IP Payment Value (Select) / Custom EM Exclusion SQL */}
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>IP Payment Value</Typography>
      <TextField select variant="outlined" fullWidth size="small">
        <MenuItem value="valueA">Value A</MenuItem>
        <MenuItem value="valueB">Value B</MenuItem>
      </TextField>
    </Box>
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ mb: 0.5 }}>Custom EM Exclusion SQL</Typography>
      <TextField multiline minRows={2} variant="outlined" fullWidth size="small" placeholder="Enter SQL query" />
    </Box>
  </Stack>
</Stack>



{/* ✅ Save / Cancel Buttons */}
<Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mb: 3 }}>
  <Button variant="outlined" size="small" sx={{ textTransform: "none" }}>
    Cancel
  </Button>
  <Button variant="contained" size="small" sx={{ textTransform: "none" }}>
    Save
  </Button>
</Stack>

</Box>
</Paper>

{/* 🟢 Status Message */}

<Box sx={{ backgroundColor: '#F3FAFF', borderRadius: '10px', p: 2, mb: 2 }}>
  {/* ✅ Icon + Bold Status Message */}
  <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
    <CheckCircleIcon sx={{ color: 'green' }} />
    <Typography sx={{ fontSize: "14px", fontWeight: "bold" }}>
      Nice! Your Providers and Services are successfully linked.
    </Typography>
  </Stack>

  {/* 📝 Instruction + Buttons in Same Row */}
  <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
    <Typography sx={{ fontSize: "14px", fontWeight: "normal",paddingLeft:4 }}>
      Paper contract Rates—ready for use or further configuration
    </Typography>
    <Stack direction="row" spacing={2}>
      <Button variant="outlined" size="small" sx={{ textTransform: "none" }}
       onClick={RateListPageClick}
      >
       Back
      </Button>
      <Button variant="contained" size="small" sx={{ textTransform: "none" }}
      >
        Save & Next
      </Button>
    </Stack>
  </Stack>
</Box>

      </Paper>
    </Box>
  );
};

export default observer(AddRate);
