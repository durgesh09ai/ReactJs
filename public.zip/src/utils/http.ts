export async function fetchJson(url: string) {
  const res = await fetch(url);

  const contentType = res.headers.get("content-type");
  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Fetch failed`);
  }
  if (!contentType?.includes("application/json")) {
    const html = await res.text();
    throw new Error(`Expected JSON but got HTML`);
  }

  return res.json();
}


export const sliceToWords = (text: string, wordLimit: number = 40): string => {
  if (!text) return "";

  const words = text.trim().split(/\s+/);
  if (words.length <= wordLimit) return text;

  return words.slice(0, wordLimit).join(" ") + "...";
};
