import {  Routes, Route } from "react-router-dom";

import DashboardDetail from "../pages/DashboardDetail";

import ReconLayout from "../layout/ReconLayout/Layout";



import UploadContract from "../pages/UploadContract";
import CompareContract from "../pages/CompareContract";
import HomePage from "../pages/HomePage";
import ContractWorkFlow from "../pages/ContractWorkFlow";
import ContractBuilder from "../pages/ContractBuilder";
import ContractProvider from "../pages/ContractProvider";
import AddContract from "../components/ContractBuilder/AddContract";
import AddProvider from "../components/ContractProvider/AddProvider";
import RateListing from "../pages/RateListing";
import AddRate from "../components/RateListing/AddRate";
import RateHistoryListing from "../components/RateHistory/RateHistoryListing";
import ProcessingScreen from "../pages/ProcessingScreen";

export const AppRoutes = () => (
   <Routes>
    <Route
      element={<ReconLayout /> }> 
       <Route path="/" element={<DashboardDetail />} /> 
        <Route path="/home" element={<HomePage/>} /> 
        <Route path="/workflow" element={<ContractWorkFlow/>} /> 
        <Route path="/contract-builder" element={<ContractBuilder />} />
        <Route path="/add-contract" element={<AddContract />} />
        <Route path="/upload-contract" element={<UploadContract />} />
        <Route path="/contract-provider" element={<ContractProvider />} />
        <Route path="/add-provider" element={<AddProvider />} />
       <Route path="/compare-contract" element={<CompareContract />} />
       <Route path="/rate-listing" element={<RateListing />} />
       <Route path="/add-rate" element={<AddRate />} />
       <Route path="/rate-history" element={<RateHistoryListing />} />
       <Route path="/processing-screen" element={<ProcessingScreen />} />


    </Route>
   </Routes>
);
