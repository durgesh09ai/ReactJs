import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import {
  AppBar,
  Toolbar,
  Box,
  Button,

} from "@mui/material";

import {  useNavigate } from "react-router-dom";

const Header = () => {
  const [value, setValue] = useState(0);
  const navigate = useNavigate();
  const handleClick = () => navigate("/upload-contract");
  const location = useLocation();

  return (
    <AppBar
      position="static"
      color="transparent"
      elevation={0}
      sx={{ borderBottom: 1, borderColor: "rgba(0, 0, 0, 0.12)",backgroundColor:'#fff', height: 48 }}
    >
      <Toolbar
        variant="dense"
        sx={{ justifyContent: "space-between", py: 0.5, minHeight: 48 }}
      >
        {/* Left section: Logo + Search */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <img src="/EXL_Service_logo.png" alt="Logo" style={{ width:80 }} />

        </Box>

        {/* Middle section: Tabs */}
        <Box sx={{ flexGrow: 1, mx: 4 }}>
    
        </Box>

        {/* Right section: Buttons */}
        <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}>

        {location.pathname !== "/upload-contract" && (
          <Button
            onClick={handleClick}
            variant="contained"
            startIcon={<CloudUploadIcon />}
            sx={{
              color: "#FFF",
              borderColor: "#0F4977",
              fontSize: "14px",
              borderRadius: "8px",
              boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
            }}
          >
          Upload Contract
          </Button>
        )}

        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;