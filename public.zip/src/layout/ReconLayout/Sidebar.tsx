import React from "react";
import { observer } from "mobx-react-lite";
import { Box, Avatar, ListItem, ListItemText } from "@mui/material";

import { Link } from "react-router-dom";
import NavItem from "./NavItem";
import { mainPageStore } from "../../stores/MainPageStore";
import SettingsIcon from "@mui/icons-material/Settings";
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';

const Sidebar = observer(() => { 
  
  const {
    sidebarCollapsed,
    setSidebarCollapsed  } = mainPageStore; 
    const collapsed = sidebarCollapsed;
  const toggleSidebar = () => {
    setSidebarCollapsed();
  };  

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh"
      px={!collapsed ? 0 : 0}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
    >
      {/* Top Section */}
      <Box flexGrow={1}>

        {/* Expanded Sidebar Navigation */}
          <Box display="flex" flexDirection="column" sx={{ mt: 2 }}>
            
          <Box display="flex"  sx={{textAlign: "center",mb:1,ml:1.8,color:'#000' }}>
            <Avatar
            src={!collapsed ? "/menu_Close.svg" : "/menu_open.svg"}
            alt="Logo"
            sx={{ width: 24, height: 24, cursor: "pointer" }}
            variant="square"
            onClick={toggleSidebar}
          /> 
            </Box>

            {/* Dynamic Sections */}
                <Link to="/home" style={{textDecoration:"none",color:"inherit"}}>
                 <NavItem
                  key="Home"
                  icon="/Home.svg"
                  label="Home"
                  collapsed={collapsed}
                />
                </Link>

                <Link to="/workflow" style={{textDecoration:"none",color:"inherit"}}>
                <NavItem
                  key="IMU"
                  icon="/IMU-icon.svg"
                  label="Workflow"
                  collapsed={collapsed}
                  subItems={undefined}
                />
                </Link>

                <Link to="/contract-builder" style={{textDecoration:"none",color:"inherit"}}>
                <NavItem
                  key="SGU"
                  icon="/SGU-ICON.svg"
                  label="Contract Builder"
                  collapsed={collapsed}
                  subItems={undefined}
                />
               </Link>

               <Link to="/contract-provider" style={{textDecoration:"none",color:"inherit"}}>
                <NavItem
                  key="IMU"
                  icon="/IMU-icon.svg"
                  label="Contract Provider"
                  collapsed={collapsed}
                  subItems={undefined}
                />
                </Link>

               <Link to="/rate-listing" style={{textDecoration:"none",color:"inherit"}}>
                <NavItem
                  key="IMU"
                  icon="/SGU-ICON.svg"
                  label="Rate Listing"
                  collapsed={collapsed}
                  subItems={undefined}
                />
                </Link>

              <Link to="/processing-screen" style={{textDecoration:"none",color:"inherit"}}>
                <NavItem
                  key="IMU"
                  icon="/IMU-icon.svg"
                  label="Processing Screen"
                  collapsed={collapsed}
                  subItems={undefined}
                />
                </Link>
               
  
            
          </Box>
       
      </Box>

      {/* Footer Items pinned to bottom */}
        <Box mt={2}>
        <ListItem
          component={Link}
          to="/settings"
          sx={{
            textDecoration: "none",
            color: "inherit",
            py: 1,
            borderRadius: 1,
            "&:hover": { backgroundColor: "#f5f5f5" },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 }} />
          {!collapsed && (
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
          )}
        </ListItem>


        <ListItem
          component={Link}
          to="/logout"
          sx={{
            textDecoration: "none",
            color: "inherit",
            py: 1,
            borderRadius: 1,
            "&:hover": { backgroundColor: "#f5f5f5" },
          }}
        >
          <PowerSettingsNewIcon fontSize="small" sx={{ mr: 1 }} />
          {!collapsed && (
          <ListItemText primary="Logout" primaryTypographyProps={{ fontSize: "14px" }} />
          )}
        </ListItem>

       </Box>
      
    </Box>
  );
});

export default Sidebar;