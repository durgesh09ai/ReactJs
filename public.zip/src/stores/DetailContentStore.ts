import { makeAutoObservable, runInAction } from 'mobx';

interface SummaryDataItem {
  label:string;
  value:number;
}

export class SummaryStore {
    summaryData:SummaryDataItem[]=[];
    loading:boolean=false;

    constructor(){
        makeAutoObservable(this);
    }

    async fetchSummaryData(){
        try{
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
        const responseData:SummaryDataItem[]=[
            { label: 'Total Hospital Name', value: 1234 },
            { label: 'Total Contract Type', value: 234 },
            { label: 'Total Apex Cover ID', value: 234 },
            { label: 'Total CIS ID', value: 134 },
        ]
        runInAction(()=>{
 this.summaryData=responseData;
 this.loading=false;
});
    }
catch(error){
    runInAction(()=>{
     this.loading=false;
    });
}


}

}

export const summaryStore=new SummaryStore();