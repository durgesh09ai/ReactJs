// stores/ContractStore.ts
import { makeAutoObservable, runInAction } from 'mobx';

interface Contract {
  hospital: string;
  solution_version: string;
  contract: string;
  apex_id: string;
  referral: string;
  apex_worksite: string;
  cis_id: string;
  cis_type: string;
  start_date: string;
  term_date: string;
  tax_id: string;
  lob: string;
  description: string;
}

export class ContractStore {
  contracts: Contract[] = [];
  isLoading = false;

  constructor() {
    makeAutoObservable(this);
  }

  async fetchContractListing() {
    this.isLoading = true;

    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay

    const simulatedData: Contract[] = [
      {
        hospital: 'Frankfort Regional Medical Center',
        solution_version: 'CCG 1',
        contract: 'Hospital',
        apex_id: 'ACV-0001',
        referral: 'Ref-7',
        apex_worksite: '62424',
        cis_id: 'CSID-123',
        cis_type: 'Pricer',
        start_date: '2025-01-03',
        term_date: '2025-12-03',
        tax_id: 'Single',
        lob: '123',
        description: 'Parent contract',
      },
      {
        hospital: 'Mindstate Clinic',
        solution_version: 'CCG 2',
        contract: 'Physician',
        apex_id: 'ACV-0002',
        referral: 'Ref-2',
        apex_worksite: '63001',
        cis_id: 'CSID-9876',
        cis_type: 'DRG',
        start_date: '2025-02-15',
        term_date: '2025-12-15',
        tax_id: 'Multiple',
        lob: '456',
        description: 'Morning contract',
      },
      {
        hospital: 'Riverdale Health',
        solution_version: 'CCG Unified',
        contract: 'Hospital',
        apex_id: 'ACV-0003',
        referral: 'Ref-5',
        apex_worksite: '64001',
        cis_id: 'CSID-5678',
        cis_type: 'Pricer',
        start_date: '2025-03-20',
        term_date: '2025-12-20',
        tax_id: 'Single',
        lob: '789',
        description: 'Unified care contract',
      },
        {
    hospital: 'Frankfort Regional Medical Center',
    solution_version: 'CCG 1',
    contract: 'Hospital',
    apex_id: 'ACV-0001',
    referral: 'Ref-7',
    apex_worksite: '62424',
    cis_id: 'CSID-123',
    cis_type: 'Pricer',
    start_date: '2025-01-03',
    term_date: '2025-01-03',
    tax_id: 'Single',
    lob: '123',
    description: 'Parent contract'
   
  },
  {
    hospital: 'Mindstate',
    solution_version: 'CCG 2',
    contract: 'Physician',
    apex_id: 'ACV-0002',
    referral: 'Ref-2',
    apex_worksite: '63001',
    cis_id: 'CSID-9876',
    cis_type: 'DRG',
    start_date: '2025-01-26',
    term_date: '2025-01-26',
    tax_id: 'Multiple',
    lob: '876',
    description: 'Morning contract',
   
  },
   {
    hospital: 'Mindstate',
    solution_version: 'CCG 2',
    contract: 'Physician',
    apex_id: 'ACV-0002',
    referral: 'Ref-2',
    apex_worksite: '63001',
    cis_id: 'CSID-9876',
    cis_type: 'DRG',
    start_date: '2025-01-26',
    term_date: '2025-01-26',
    tax_id: 'Multiple',
    lob: '876',
    description: 'Morning contract',
   
  },
   {
    hospital: 'Mindstate',
    solution_version: 'CCG 2',
    contract: 'Physician',
    apex_id: 'ACV-0002',
    referral: 'Ref-2',
    apex_worksite: '63001',
    cis_id: 'CSID-9876',
    cis_type: 'DRG',
    start_date: '2025-01-26',
    term_date: '2025-01-26',
    tax_id: 'Multiple',
    lob: '876',
    description: 'Morning contract',
   
  },
   {
    hospital: 'Mindstate',
    solution_version: 'CCG 2',
    contract: 'Physician',
    apex_id: 'ACV-0002',
    referral: 'Ref-2',
    apex_worksite: '63001',
    cis_id: 'CSID-9876',
    cis_type: 'DRG',
    start_date: '2025-01-26',
    term_date: '2025-01-26',
    tax_id: 'Multiple',
    lob: '876',
    description: 'Morning contract',
   
  },
   {
    hospital: 'Mindstate',
    solution_version: 'CCG 2',
    contract: 'Physician',
    apex_id: 'ACV-0002',
    referral: 'Ref-2',
    apex_worksite: '63001',
    cis_id: 'CSID-9876',
    cis_type: 'DRG',
    start_date: '2025-01-26',
    term_date: '2025-01-26',
    tax_id: 'Multiple',
    lob: '876',
    description: 'Morning contract',
   
  },
    ];

    runInAction(() => {
      this.contracts = simulatedData;
      this.isLoading = false;
    });
  }
}

export const contractStore = new ContractStore();
