import { ContractStore } from "./ContractStore";
import { MainPageStore } from "./MainPageStore";

import { SummaryStore } from "./DetailContentStore";

export class RootStore { 
  contractStore:ContractStore;
  summaryStore:SummaryStore;
  mainPageStore:MainPageStore;

  constructor() {    
    this.contractStore= new ContractStore();
    this.summaryStore=new SummaryStore();
    this.mainPageStore=new MainPageStore();
  }
}

const rootStore = new RootStore();
export default rootStore;
