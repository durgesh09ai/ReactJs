import React, { useState } from "react";
import { Box, Button, Stack, Tab, Tabs, TextField, Typography } from "@mui/material";
import ProcessingScreenTab from "../components/ProcessingScreen/ProcessingScreenTab";
import ProcessingScreenDetailContent from "../components/ProcessingScreen/ProcessingScreenDetailContent";
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import DownloadIcon from '@mui/icons-material/Download';

const ProcessingScreen = () => {
  return (
<Box
  sx={{
    backgroundColor: 'white',
    display: "flex",
    flexDirection: "column",
    width: "100%",
    overflow: "hidden",
    px: { xs: 2, sm: 3, md: 1 }, 
  }}
>
   <ProcessingScreenDetailContent/>
    <ProcessingScreenTab/>

{/* <Stack
  direction="row"
  justifyContent="space-between"
  alignItems="center"
  mb={2}
  mt={2}
  sx={{ width: '100%', border:"1px solid #ccc", borderRadius:1 }}
>
  <Tabs value={selectedTab} onChange={handleTabChange} sx={{ width: '100%',textAlign: 'center' }}>
    <Tab label="Show Fetched Data" sx={{width:"33%" , textTransform: 'none' }}/>
    <Tab label="Show Excluded Data" sx={{width:"33%" , textTransform: 'none' }} />
    <Tab label="Show Result" sx={{width:"33%",textTransform: 'none' }}/>
  </Tabs>
</Stack> */}


 {/* <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2} mt={2} sx={{ backgroundColor: '#F9FAF'}}>
          <TextField
            size="small"
            placeholder="Quick Search"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
          />

          <Stack direction="row" spacing={1}>
            <Button
              variant="outlined"
              startIcon={<FilterAltIcon />}
              size="small"
              onClick={() => setFilterDrawerOpen(true)}
            >
              Filter
            </Button>
          </Stack>
  </Stack> */}

        
{/* {selectedTab === 0 && (      
  <Stack direction="row" spacing={1}>
    <Box sx={{ flex: 1,width:"70%" }}>
    <ProcessingScreenTab/>

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>

    </Box>

  </Stack>
)}

{selectedTab === 1 && (      
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1,width:"70%" }}>
    <ProcessingScreenTab/>

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>

    </Box>

  </Stack>
)}

{selectedTab === 2 && (      
  <Stack direction="row" spacing={2}>
    <Box sx={{ flex: 1,width:"70%" }}>
    <ProcessingScreenTab/>

    </Box>

    <Box sx={{ flex: 1 ,width:"30%", border:"1px solid #ccc" ,borderRadius:1}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '1px solid #0F4977',
          pb: 1,
          mb: 2,
          p:1,
        }}
      >
        <Box>
          <Typography sx={{fontSize:14}}>LOGS</Typography>
        </Box>
        <DownloadIcon sx={{ color: '#0F4977', cursor: 'pointer' }} />
      </Box>

    </Box>

  </Stack>
)} */}

</Box>
  );
};

export default ProcessingScreen;
