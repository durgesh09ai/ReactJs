import React from "react";
import { Box } from "@mui/material";
import SetRateListing from "../components/RateListing/SetRateListing";
import RateDetailContent from "../components/RateListing/RateDetailContent";


const RateListing = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, 
      }}
    >
      <RateDetailContent/>
      <SetRateListing/>
    </Box>
  );
};

export default RateListing;
