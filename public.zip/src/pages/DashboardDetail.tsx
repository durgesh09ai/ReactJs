import React from "react";
import { Box } from "@mui/material";
import DetailContent from "../components/dashboard/DetailContent";
import ContractListing from "../components/dashboard/ContractListing";

const DashboardDetail = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, // padding for responsive spacing
      }}
    >
      <DetailContent />
      <ContractListing/>

    </Box>
  );
};

export default DashboardDetail;
