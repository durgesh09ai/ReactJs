import React from "react";
import { Box } from "@mui/material";
import ProviderListing from "../components/ContractProvider/ProviderListing";
import ProviderDetailContent from "../components/ContractProvider/ProviderDetailContent";


const ContractProvider = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, 
      }}
    >
      <ProviderDetailContent/>
      <ProviderListing/>
    </Box>
  );
};

export default ContractProvider;
