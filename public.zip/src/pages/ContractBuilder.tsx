import React from "react";
import { Box } from "@mui/material";
import ContractListing from "../components/ContractBuilder/ContractListing";
import DetailContent from "../components/ContractBuilder/DetailContent";


const ContractProvider = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, 
      }}
    >
      <DetailContent/>
      <ContractListing/>
    </Box>
  );
};

export default ContractProvider;
