import React from "react";
import { Box } from "@mui/material";
import UploadDetailContent from "../components/dashboard/UploadDetailContent";
import UploadContractListing from "../components/dashboard/UploadContractListing";

const UploadContract = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, // padding for responsive spacing
      }}
    >
      <UploadDetailContent />
      <UploadContractListing/>

    </Box>
  );
};

export default UploadContract;
