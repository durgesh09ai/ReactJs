import React, { useState } from 'react';
import { Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import { WelcomeHeader } from '../components/ContractWorkFlow/WelcomeHeader';
import { QuickAction } from '../components/ContractWorkFlow/QuickAction';
import { ContractFlow } from '../components/ContractWorkFlow/ContractFlow';


const MainContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: '16px',
  backgroundColor: 'white',
  padding: '12px 2px',
  height:'100%'
}));


const ContractWorkFlow = () => {
  return (
    <MainContainer>
      <WelcomeHeader userName="ABC" />
      <QuickAction/>
      <ContractFlow/> 
    </MainContainer>
  );
};

export default ContractWorkFlow;