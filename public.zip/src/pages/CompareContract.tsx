import React from "react";
import { Box, Paper, Typography } from "@mui/material";
import CompareContractListing from "../components/CompareContract/CompareContractListing";
import { Breadcrumb } from "../components/CompareContract/Breadcrumb";
import PdfDetail from "../components/CompareContract/PdfDetail";

  const breadcrumbItems = [
    { label: "Home", href: "/" },
    { label: "CIS ID- 123" },
    { label: "Comparision" },
  ];

const CompareContract = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, 
      }}
    >
    <Box sx={{ display: "flex", flexDirection: "column", flexGrow: 1, minWidth: "240px", mb:2 }}>
       <Paper
        elevation={0}
        sx={{
          backgroundColor: "white",
          borderRadius: "10px",
          width: "100%",
          p: 1,
          mt:2,
        }}
      >
      <Breadcrumb items={breadcrumbItems} />
        
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography sx={{  fontSize: "14px", mb: 1 }}>Comparision</Typography>
      </Box>
      </Paper>
      </Box>   

    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        width: "100%",
        overflow: "hidden",
        px: { xs: 2, sm: 3, md: 1 }, 
      }}
    >
      <Box sx={{width:"40%"}}>
        <PdfDetail/>
      </Box>
      <Box sx={{width:"60%"}}>
       <CompareContractListing/>
      </Box>

    </Box>

    </Box>
  );
};

export default CompareContract;
