import React from "react";
import { Typography, Divider, Box } from "@mui/material";

interface ProfileHeaderProps {
  title: string;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ title }) => {
  return (
    <Box sx={{ width: "100%", px: 2, display: "flex", justifyContent: "space-between" }}>
      <Box sx={{ width: "100%", py: 2 }}>
        <Typography variant="body1" sx={{ color: "#1d1b20" }}>
          {title}
        </Typography>
        <Divider sx={{ mt: 1 }} />
      </Box>
    </Box>
  );
};

export default ProfileHeader;
