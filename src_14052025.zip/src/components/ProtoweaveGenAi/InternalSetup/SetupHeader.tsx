import React from 'react';
import { Box, Button, Typography } from '@mui/material';

interface SetupHeaderProps {
  onAddClick: () => void;
}

export const SetupHeader: React.FC<SetupHeaderProps> = ({ onAddClick }) => {
  return (
    <Box sx={{
      display: 'flex',
      width: '100%',
      alignItems: 'center',
      gap: '16px',
      flexWrap: 'wrap',
      fontSize: '14px',
    }}>
      <Typography sx={{
        color: '#1d1b20',
        fontWeight: "bold",
        fontSize:14,
        lineHeight: 1.2,
        alignSelf: 'stretch',
        my: 'auto'
      }}>
        Add the Internal Site Agent
      </Typography>
      <Box sx={{
        alignSelf: 'stretch',
        display: 'flex',
        gap: '8px',
        color: '#0F4977',
        fontWeight: 700,
        lineHeight: 1,
        my: 'auto'
      }}>

        <Button
        onClick={onAddClick}
        variant="outlined"
        sx={{
        color: "#0F4977",
        borderColor: "#0F4977",
        textTransform: "none",
        borderRadius: 1,
        py: 0.5,
        px: 2,
        fontWeight:'bold'
        }}
        aria-label="Cancel"
        >
        Add
        </Button>

      </Box>
    </Box>
  );
};
