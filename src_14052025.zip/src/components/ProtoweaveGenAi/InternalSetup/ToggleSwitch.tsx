import React from 'react';
import { Switch, FormControlLabel, Box } from '@mui/material';
import { styled } from '@mui/material/styles';

interface ToggleSwitchProps {
  enabled: boolean;
  onChange: (enabled: boolean) => void;
  label?: string;
}

const GreenSwitch = styled(Switch)(({ theme }) => ({
  '& .MuiSwitch-switchBase.Mui-checked': {
    color: '#34C759',
    '&:hover': {
      backgroundColor: 'rgba(52, 199, 89, 0.08)',
    },
  },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
    backgroundColor: '#34C759',
  },
  '& .MuiSwitch-track': {
    borderRadius: 80.645,
  },
  '& .MuiSwitch-thumb': {
    boxShadow: '0px 0px 0px 1px rgba(0,0,0,0.04)',
    width: 22,
    height: 22,
    margin: 1,
  },
}));

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({
  enabled,
  onChange,
  label
}) => {
  return (
    <Box sx={{ 
      display: 'flex', 
      alignItems: 'center', 
      gap: '10px',
      minHeight: '32px', 
      padding: '4px 8px', 
      borderRadius: '8px', 
      backgroundColor: 'white'
    }}>
      {label && (
        <Box component="span" sx={{ 
          fontSize: '14px', 
          fontWeight: 'normal',
          color: 'black',
          lineHeight: 'normal'
        }}>
          {label}
        </Box>
      )}
      <GreenSwitch
        checked={enabled}
        onChange={(e) => onChange(e.target.checked)}
        size="small"
      />
    </Box>
  );
};
