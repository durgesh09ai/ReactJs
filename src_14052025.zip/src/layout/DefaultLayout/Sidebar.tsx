import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Collapse,
  Avatar,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import SettingsIcon from "@mui/icons-material/Settings";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { observer } from "mobx-react-lite";
import { v4 as uuidv4 } from 'uuid';
import { dataProtoweaveGenAiStore } from "../../stores/cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";

const Sidebar = () => {
  
  const navLinks = [{ label: "Home", to: "/" }];
  const [expanded, setExpanded] = useState({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({ title: "", description: "" });
  const [formErrors, setFormErrors] = useState({ title: false });
  const [currentSection, setCurrentSection] = useState<{ researchname?: string; id?: string } | null>(null);

  const navigate = useNavigate();

  const { sidebarData ,fetchSideMenuData,addResearchItem } = dataProtoweaveGenAiStore;

  useEffect(() => {
    fetchSideMenuData();
  }, []);

  const experimentConfig = () => {
    navigate("/protoweave/experiment");
  };

  const toggleExpand = (key: string) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleOpenDialog = (section: { researchname?: string; id?: string }) => {
    setCurrentSection(section);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setFormData({ title: "", description: "" });
    setCurrentSection(null);
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.title.trim()) {
      setFormErrors({ title: true });
      return;
    }
   setFormErrors({ title: false }); // Clear error
   if (!currentSection?.id) return;
    try {
      await dataProtoweaveGenAiStore.addResearchItem({
        id:uuidv4(),
        title: formData.title,
        description: formData.description,
        researchId: currentSection.id,
      });
  
      handleCloseDialog();
    } catch (e) {
      console.error("Error submitting form", e);
    }
  };
  


  
  const getItemRoute = (sectionTitle: string, id: number) => {
    const lower = sectionTitle.toLowerCase();
    if (lower.includes("experiment")) return `/protoweave/experiment/${id}`;
    if (lower.includes("research")) return `/protoweave/research/${id}`;
    return `/`; 
  };
  

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="100vh"
      px={2}
      py={1}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      bgcolor="#fff"
      maxWidth="300px"
      width="100%"
      boxShadow="1px 0 4px rgba(0,0,0,0.1)"
    >
      {/* Header */}
      <Box display="flex" alignItems="center" justifyContent="space-between" px={1} py={1}>
        <Typography variant="h6" sx={{ fontSize: "28px", fontWeight: 600, color: "#0F4977" }}>
          EXL
        </Typography>
        <Avatar
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9df66a2e096fffaa4eec49ff70db980f5326516a?placeholderIfAbsent=true"
          sx={{ width: 24, height: 24 }}
          variant="square"
        />
      </Box>

      {/* Nav Links */}
      <Box mt={2}>
        <List disablePadding>
          {navLinks.map(({ label, to }, i) => (
            <ListItem
              key={i}
              component={Link}
              to={to}
              disablePadding
              sx={{
                textDecoration: "none",
                color: "inherit",
                px: 1,
                py: 1,
                "&:hover": {
                  backgroundColor: "#f5f5f5",
                },
              }}
            >
              <ListItemText primary={label} primaryTypographyProps={{ fontSize: "14px" }} />
            </ListItem>
          ))}
        </List>
      </Box>

      {/* Workspaces */}
      {sidebarData && sidebarData.workspacelist.map((workspace, wi) => {
        const workspaceKey = `workspace-${wi}`;
        return (
          <Box key={workspaceKey} sx={{ mt: 2 }}>
          <Paper
           sx={{
              bgcolor: expanded[workspaceKey] ? "#fff" : "#F3FAFF",
              borderRadius: 2,
              p: 1,
              mx: expanded[workspaceKey] ? "2px" : 0,
              transition: "background-color 0.3s, margin 0.3s",
            }}
            elevation={expanded[workspaceKey] ? 0.2 : 0}
          >
            {/* Workspace Header */}
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              onClick={() => toggleExpand(workspaceKey)}
              sx={{ cursor: "pointer", py: 0.5 }}
            >
              <Typography fontSize="14px" fontWeight={600} color="#343434">
                {workspace.title}
              </Typography>
              <IconButton size="small">
                <ExpandMoreIcon
                  fontSize="small"
                  sx={{
                    transform: expanded[workspaceKey] ? "rotate(180deg)" : "rotate(0deg)",
                    transition: "0.2s",
                  }}
                />
              </IconButton>
            </Box>
        
            <Collapse in={expanded[workspaceKey]}>
              {workspace.items.map((section, si) => {
                const sectionTitle =
                  section.researchname || section.experimentname || "Untitled";
                const sectionData = section.data || [];
                return (
                  <Box key={si} mt={1}>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                      sx={{ py: 0.5 }}
                    >
                      <Typography fontSize="14px" fontWeight={500} color="#0F4977">
                        {sectionTitle}
                      </Typography>
                      <IconButton
                        size="small"
                        onClick={() =>
                          sectionTitle.toLowerCase() === "experiment"
                            ? experimentConfig()
                            : handleOpenDialog({ researchname: section.researchname, id: section.id })
                        }
                      >
                        <AddIcon fontSize="small" />
                      </IconButton>

                    </Box>
                  <List dense disablePadding>
                    {sectionData.map((item) => (
                      <ListItem
                        key={item.id}
                        sx={{ pl: 2, cursor: "pointer" }}
                        onClick={() => navigate(getItemRoute(sectionTitle, item.id))}
                      >
                        <ListItemText
                          primary={item.title}
                          primaryTypographyProps={{ fontSize: "13px" }}
                        />
                      </ListItem>
                    ))}
                  </List>
                  </Box>
                );
              })}
            </Collapse>
          </Paper>
        </Box>
        
        );
      })}

      {/* Settings Link */}
      <Box mt="auto" px={1} py={2}>
        <ListItem
          component={Link}
          to="/protoweave/settings"
          sx={{
            textDecoration: "none",
            color: "inherit",
            px: 1,
            py: 1,
            borderRadius: 1,
            "&:hover": {
              backgroundColor: "#f5f5f5",
            },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 }} />
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
        </ListItem>
      </Box>

      {/* Dialog Form */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} fullWidth maxWidth="sm">
        <DialogTitle sx={{ textAlign: "center", fontWeight: "bold", fontSize:'14px'}}>Let's Start Your Research !!</DialogTitle>
        <DialogContent>
        <TextField
            margin="dense"
            label="Give your research a name:"
            name="title"
            required
            fullWidth
            value={formData.title}
            onChange={handleFormChange}
            error={formErrors.title}
            helperText={formErrors.title ? "Research name is required!" : ""}
          />
          <TextField
            margin="dense"
            label="What is it about? (Optional)"
            name="description"
            fullWidth
            value={formData.description}
            onChange={handleFormChange}
            sx={{
              marginBottom: 0,
              '& .MuiInputBase-input': {
                fontSize: "14px",
              },
            }}
          />
          <Box>
            <Typography variant="body2" sx={{ fontWeight: "bold", fontSize: 12,mt:1 }}>
              No experiments yet?
            </Typography>
            <Typography variant="body2" sx={{ fontSize: 14 }}>
              You can add experiments to this research after creation.
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} variant="outlined" color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default observer(Sidebar);
