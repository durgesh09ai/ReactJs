import { useState, useEffect } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";

interface ThinkingProcessProps {
  data: any[];
  isResearching: boolean;
  report: { markdown: string; docx: string } | null;
}

// Add source badge component
// const SourceBadge = ({ source }: { source: string }) => {
//   const bgColor =
//     source === "PubMed"
//       ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
//       : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100";

//   return (
//     <span className={`text-xs font-medium px-2 py-1 rounded-full ${bgColor}`}>
//       {source}
//     </span>
//   );
// };

export default function ThinkingProcess({
  data,
  isResearching,
  report,
}: ThinkingProcessProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [loadingDots, setLoadingDots] = useState("");

  useEffect(() => {
    if (isResearching) {
      const intervalId = setInterval(() => {
        setLoadingDots((prevDots) => {
          if (prevDots.length < 3) {
            return prevDots + ".";
          } else {
            return "";
          }
        });
      }, 500);

      return () => clearInterval(intervalId); // Cleanup on unmount or when isResearching changes
    } else {
      setLoadingDots(""); // Reset loading dots when research is not in progress
    }
  }, [isResearching]);

  // Format the thinking process data for display
  const formatThinkingStep = (step: string) => {
    return step
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="flex justify-between items-center mb-4 p-4 text-foreground">
        <div className="text-xl font-semibold">
          {isResearching
            ? `Research in Progress${loadingDots}`
            : report
              ? "Research Complete"
              : "Thinking Process"}
        </div>
        {(data.length > 0 || report) && (
          <button
            className="text-sm px-2 py-1 rounded hover:bg-muted flex items-center text-foreground hover:cursor-pointer"
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? (
              <>
                Expand <FaChevronDown className="ml-1" />
              </>
            ) : (
              <>
                Collapse <FaChevronUp className="ml-1" />
              </>
            )}
          </button>
        )}
      </div>

      {!isCollapsed && (
        <div className="flex-1 overflow-y-auto space-y-4 p-4">
          {data.length === 0 && !report && !isResearching && (
            <div className="text-muted-foreground italic">
              The research process will be shown here once started.
            </div>
          )}

          {isResearching && data.length === 0 && (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          )}

          {data.map((item, index) => (
            <div
              key={index}
              className="border border-border rounded-lg p-4 shadow-sm bg-card"
            >
              <div className="font-medium text-blue-600 dark:text-blue-400 mb-2">
                {formatThinkingStep(item.step)}
                {item.progress !== null && (
                  <span className="ml-2 text-sm text-muted-foreground">
                    ({Math.round(item.progress)}%)
                  </span>
                )}
              </div>

              {item.details && (
                <div className="text-sm text-foreground">
                  {item.step === "searching" && (
                    <div>
                      <div>
                        Query:{" "}
                        <span className="font-mono">{item.details.query}</span>
                      </div>
                      <div>
                        Progress: {item.details.query_index} of{" "}
                        {item.details.total_queries}
                      </div>

                      {/* Add source counts if available */}
                      {/* {item.details.source_counts && (
                        <div className="mt-2">
                          <p className="text-sm font-medium">Sources found:</p>
                          <div className="flex gap-2 mt-1">
                            {Object.entries(item.details.source_counts).map(
                              ([source, count]) => (
                                <div
                                  key={source}
                                  className="flex items-center gap-1"
                                >
                                  <SourceBadge source={source} />
                                  <span className="text-xs">
                                    {count as number}
                                  </span>
                                </div>
                              ),
                            )}
                          </div>
                        </div>
                      )} */}
                    </div>
                  )}

                  {item.step === "selecting_papers" && (
                    <div>
                      <div>
                        Found {item.details.total_results} papers to analyze
                      </div>

                      {/* Add source distribution if available */}
                      {/* {item.details.source_distribution && (
                        <div className="mt-2">
                          <p className="text-sm font-medium">
                            Selected papers by source:
                          </p>
                          <div className="flex gap-2 mt-1">
                            {Object.entries(
                              item.details.source_distribution,
                            ).map(([source, count]) => (
                              <div
                                key={source}
                                className="flex items-center gap-1"
                              >
                                <SourceBadge source={source} />
                                <span className="text-xs">
                                  {count as number}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )} */}
                    </div>
                  )}

                  {item.step === "analyzing_paper" && (
                    <div>
                      <div className="flex items-center gap-2">
                        Analyzing:{" "}
                        <span className="font-mono">{item.details.paper}</span>
                        {/* Add source badge if available */}
                        {/* {item.details.source && (
                          <SourceBadge source={item.details.source} />
                        )}
                        {item.details.paper_data?.source &&
                          !item.details.source && (
                            <SourceBadge
                              source={item.details.paper_data.source}
                            />
                          )} */}
                      </div>
                      <div>
                        Paper {item.details.index} of {item.details.total}
                      </div>
                    </div>
                  )}

                  {item.step === "synthesizing_research" && (
                    <div>
                      Synthesizing findings from {item.details.papers_analyzed}{" "}
                      papers
                    </div>
                  )}

                  {item.step === "generating_report" && (
                    <div>Creating final research report...</div>
                  )}

                  {item.step === "completed" && (
                    <div className="text-green-600 dark:text-green-400 font-medium">
                      Research completed successfully!
                    </div>
                  )}

                  {item.step === "error" && (
                    <div className="text-red-600 dark:text-red-400">
                      Error: {item.details.error}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
