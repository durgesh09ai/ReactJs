"use client";

import { MoonIcon, SunIcon } from "@radix-ui/react-icons";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const { theme, setTheme } = useTheme();

  return (
    <nav className="sticky top-0 bg-background p-4 text-foreground shadow-md z-10">
      <div className="container mx-auto flex items-center justify-between">
        <span className="text-xl font-semibold">
          <span className="text-[#FF5B35]">EXL</span> ProtoWeave.AI
        </span>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="hover:cursor-pointer"
        >
          {theme === "dark" ? <SunIcon /> : <MoonIcon />}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </div>
    </nav>
  );
}
