import { useState, useRef, useEffect } from "react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { toast } from "react-toastify";

interface ChatInterfaceProps {
  messages: any[];
  onSendTopic: (topic: string) => void;
  onSubmitAnswers: (answers: Record<string, string>, approved: boolean) => void;
  report: { markdown: string; docx: string } | null;
  isResearching: boolean;
}

export default function ChatInterface({
  messages,
  onSendTopic,
  onSubmitAnswers,
  report,
  isResearching,
}: ChatInterfaceProps) {
  const [input, setInput] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.questions) {
      return lastMessage.questions.reduce((acc: any, question: string) => {
        if (lastMessage.answers && lastMessage.answers[question]) {
          acc[question] = lastMessage.answers[question];
          return acc;
        }
        acc[question] = "";
      }, {});
    }
    return {};
  });
  const [planDecided, setPlanDecided] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (input.trim()) {
      onSendTopic(input.trim());
      setInput("");
    }
  };

  const handleAnswerChange = (question: string, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [question]: answer,
    }));
  };

  const handleSubmitAnswers = (approved: boolean) => {
    onSubmitAnswers(answers, approved);
    setPlanDecided(true);
  };

  const handleCopyToClipboard = () => {
    if (report?.markdown) {
      navigator.clipboard.writeText(report.markdown).then(() => {
        toast.success("Report copied to clipboard!");
      });
    }
  };

  const handleDownloadReport = () => {
    if (report?.docx) {
      // Convert base64 docx to blob
      const binaryContent = atob(report.docx);
      const byteArray = new Uint8Array(binaryContent.length);
      for (let i = 0; i < binaryContent.length; i++) {
        byteArray[i] = binaryContent.charCodeAt(i);
      }
      const blob = new Blob([byteArray], {
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "research_report.docx";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      toast.error("DOCX version not available!");
    }
  };

  return (
    <div className="flex flex-col h-full bg-background shadow-sm">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && !report && (
          <div className="flex items-center justify-center h-full italic text-foreground">
            Enter a healthcare research topic to begin
          </div>
        )}

        {messages.map((message, index) => (
          <div
            key={index}
            className={`p-4 rounded-3xl shadow-sm ${
              message.role === "user"
                ? "bg-blue-100 dark:bg-blue-900 ml-auto max-w-[80%] text-white"
                : "bg-accent mr-auto max-w-[80%] text-accent-foreground"
            }`}
          >
            <div className="whitespace-pre-wrap">{message.content}</div>

            {message.questions && (
              <div className="mt-4 space-y-3 bg-card p-4 rounded-3xl border border-border">
                {message.questions.map((question: string, qIndex: number) => (
                  <div key={qIndex} className="space-y-1">
                    <div className="font-medium text-foreground">
                      {question}
                    </div>
                    <input
                      type="text"
                      className="w-full p-2 border border-border rounded-lg text-foreground bg-muted focus:ring-2 focus:ring-blue-300 focus:border-blue-300 outline-none transition"
                      placeholder="Your answer..."
                      value={answers[question] || ""}
                      onChange={(e) =>
                        handleAnswerChange(question, e.target.value)
                      }
                      disabled={isResearching || planDecided}
                    />
                  </div>
                ))}

                <div className="flex space-x-2 mt-3">
                  <button
                    className="px-4 py-2 bg-green-500 dark:bg-green-600 text-white rounded-full hover:bg-green-600 dark:hover:bg-green-700 disabled:opacity-50 transition hover:cursor-pointer"
                    onClick={() => handleSubmitAnswers(true)}
                    disabled={
                      isResearching ||
                      planDecided ||
                      !message.questions.every((q: string) =>
                        answers[q]?.trim(),
                      )
                    }
                  >
                    Approve Plan
                  </button>
                  <button
                    className="px-4 py-2 bg-yellow-500 dark:bg-yellow-600 text-white rounded-full hover:bg-yellow-600 dark:hover:bg-yellow-700 disabled:opacity-50 transition hover:cursor-pointer"
                    onClick={() => handleSubmitAnswers(false)}
                    disabled={
                      isResearching ||
                      planDecided ||
                      !message.questions.every((q: string) =>
                        answers[q]?.trim(),
                      )
                    }
                  >
                    Request Changes
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}

        {report && (
          <div className="bg-card p-4 border border-border rounded-3xl shadow-sm text-foreground overflow-x-auto">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-xl font-bold text-foreground">
                Research Report
              </h2>
              <div className="flex space-x-2">
                <button
                  className="px-3 py-1 bg-green-500 text-white rounded-full hover:bg-green-600 transition hover:cursor-pointer"
                  onClick={handleDownloadReport}
                >
                  Download
                </button>
                <button
                  className="px-3 py-1 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition hover:cursor-pointer"
                  onClick={handleCopyToClipboard}
                >
                  Copy
                </button>
              </div>
            </div>
            <div>
              <Markdown remarkPlugins={[remarkGfm]}>{report.markdown}</Markdown>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 rounded-b-lg bg-muted">
        <div className="flex space-x-2">
          <input
            type="text"
            className="flex-1 p-3 border border-border rounded-full focus:ring-2 focus:ring-blue-300 focus:border-blue-300 outline-none transition text-foreground bg-background"
            placeholder={
              messages.length > 0 || isResearching
                ? "Chat is in progress..."
                : "Enter a healthcare research topic..."
            }
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyUp={(e) => e.key === "Enter" && handleSend()}
            disabled={messages.length > 0 || isResearching}
          />
          <button
            className="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:opacity-50 transition flex items-center hover:cursor-pointer"
            onClick={handleSend}
            disabled={!input.trim() || messages.length > 0 || isResearching}
          >
            <span>Start Research</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5 ml-1"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
