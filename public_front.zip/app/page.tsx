"use client";

import { useState, useEffect, useRef } from "react";
import ChatInterface from "@/components/ChatInterface";
import ThinkingProcess from "@/components/ThinkingProcess";

export default function Home() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [thinkingData, setThinkingData] = useState<any[]>([]);
  const [isResearching, setIsResearching] = useState(false);
  const [report, setReport] = useState<{ markdown: string; docx: string } | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

   // Get the API URL from environment variables
   const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

  // Connect to WebSocket when sessionId is available
  useEffect(() => {
    if (sessionId && isResearching) {
      const ws = new WebSocket(`${apiUrl.replace('http', 'ws')}/ws/research/${sessionId}`);

      ws.onopen = () => {
        console.log("WebSocket connected");
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        setThinkingData((prev) => [...prev, data]);

        // Check if research is completed
        if (data.step === "completed") {
          fetchReport();
        }
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
      };

      ws.onclose = () => {
        console.log("WebSocket disconnected");
      };

      wsRef.current = ws;

      return () => {
        ws.close();
      };
    }
  }, [sessionId, isResearching]);

  // Fetch the final report when research is completed
  const fetchReport = async () => {
    try {
      const response = await fetch(
        `${apiUrl}/research/report/${sessionId}`,
      );
      const data = await response.json();
      setReport({
        markdown: data.report,
        docx: data.docx
      });
      setIsResearching(false);
    } catch (error) {
      console.error("Error fetching report:", error);
    }
  };

  // Handle sending the initial research topic
  const handleSendTopic = async (topic: string) => {
    try {
      const response = await fetch(`${apiUrl}/research/plan`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      });

      const data = await response.json();
      setSessionId(data.plan_id);

      // Add the clarification questions to the chat
      setMessages([
        { role: "user", content: topic },
        {
          role: "assistant",
          content:
            "I need some clarification to better understand your research needs:",
          questions: data.questions,
        },
      ]);
    } catch (error) {
      console.error("Error creating research plan:", error);
    }
  };

  // Handle submitting answers to clarification questions
  const handleSubmitAnswers = async (
    answers: Record<string, string>,
    approved: boolean,
  ) => {
    try {
      const response = await fetch(
        `${apiUrl}/research/plan/feedback`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            plan_id: sessionId,
            answers,
            approved,
            feedback: approved
              ? null
              : "Please revise the plan based on my answers.",
          }),
        },
      );

      const data = await response.json();

      if (approved) {
        // Plan was approved, research is starting
        setIsResearching(true);
        setMessages((prev) => [
          ...prev,
          { role: "user", content: "I approve this research plan." },
          {
            role: "assistant",
            content:
              "Thank you! I'll start the research process now. You can see my progress on the right panel.",
          },
        ]);
      } else {
        // Plan needs revision, show new questions
        setMessages((prev) => [
          ...prev,
          { role: "user", content: "I need some adjustments to the plan." },
          {
            role: "assistant",
            content: "I've revised the plan. Please provide more information:",
            questions: data.questions,
          },
        ]);
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
  };

  return (
    <main
      className="flex w-screen flex-col md:flex-row bg-background overflow-hidden"
      style={{ height: "calc(100vh - 64px)" }}
    >
      <div className="flex-1 flex flex-col shadow-xl overflow-auto">
        <ChatInterface
          messages={messages}
          onSendTopic={handleSendTopic}
          onSubmitAnswers={handleSubmitAnswers}
          report={report}
          isResearching={isResearching}
        />
      </div>
      <div className="flex-1 flex flex-col overflow-auto">
        <ThinkingProcess
          data={thinkingData}
          isResearching={isResearching}
          report={report}
        />
      </div>
    </main>
  );
}
