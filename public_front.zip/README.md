# EXL ProtoWeave.ai Frontend

This is the frontend of the **EXL ProtoWeave.ai** project, built with [Next.js](https://nextjs.org). It serves as the user interface for interacting with the platform's features.

## Getting Started

Follow these steps to set up the frontend locally:

### Prerequisites

Ensure you have the following installed on your system:
- [Node.js](https://nodejs.org/) 
- [npm](https://www.npmjs.com/) or [yarn](https://yarnpkg.com/)

### Installation

1. Clone the repository:
   ```bash
   git clone https://EXLUCAnalytics@dev.azure.com/EXLUCAnalytics/HCTitan/_git/protoweave_genai_frt
   cd protoweave_genai_frt
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

### Running the Development Server

Start the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser to view the application.

### Environment Variables

Create a `.env.local` file in the `frontend` directory to configure environment variables. Use `.env.example` as a reference.

### Building for Production

To build the application for production:

```bash
npm run build
# or
yarn build
```

Then, start the production server:

```bash
npm start
# or
yarn start
```

## Learn More

To learn more about Next.js and its features, check out the following resources:
- [Next.js Documentation](https://nextjs.org/docs) - Comprehensive documentation for Next.js.
- [Learn Next.js](https://nextjs.org/learn) - Interactive tutorial for Next.js.

## Deployment

The frontend can be deployed using platforms like [Vercel](https://vercel.com) or any other hosting service that supports Next.js. Refer to the [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.