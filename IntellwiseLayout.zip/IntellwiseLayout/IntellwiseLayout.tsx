import React from 'react';
import { Box, AppBar, Toolbar, Avatar, IconButton } from '@mui/material';
import { Menu as MenuIcon, Settings as SettingsIcon } from '@mui/icons-material';
import { ReflexContainer, ReflexSplitter, ReflexElement } from 'react-reflex';
import 'react-reflex/styles.css';

import { FileExplorer } from './FileExplorer';
import { CodeEditor } from './CodeEditor';
import { AssessmentPanel } from './AssessmentPanel';
import { TipsTooltip } from './TipsTooltip';

export const IntellwiseLayout: React.FC = () => {
  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', bgcolor: '#fff' }}>
      {/* Header */}
      <AppBar 
        position="static" 
        elevation={0} 
        sx={{ 
          bgcolor: 'white', 
          borderBottom: '1px solid #E9EBF0',
          boxShadow: 'none'
        }}
      >
        <Toolbar sx={{ minHeight: '50px !important', px: 2, gap: 2 }}>
          <IconButton size="small" sx={{ color: '#000' }}>
            <MenuIcon />
          </IconButton>
          <IconButton size="small" sx={{ color: '#000' }}>
            <SettingsIcon />
          </IconButton>
          <Avatar 
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/6d52b79fd3531aa382b63551280764dcc2ab6a1b?placeholderIfAbsent=true"
            sx={{ width: 32, height: 32 }}
          />
        </Toolbar>
      </AppBar>

      {/* Main Layout */}
      <Box sx={{ flexGrow: 1 }}>
        <ReflexContainer orientation="vertical">
          
          {/* Left: File Explorer */}
          <ReflexElement minSize={200} maxSize={400}>
            <Box sx={{ height: '100%', p: 1, bgcolor: '#f9f9f9', overflow: 'auto' }}>
              <FileExplorer />
            </Box>
          </ReflexElement>

          <ReflexSplitter propagate />

          {/* Right: Editor + Assessment Panel */}
          <ReflexElement>
            <ReflexContainer orientation="horizontal">
              
              {/* Code Editor */}
              <ReflexElement flex={0.7} minSize={150}>
                <Box sx={{ height: '100%', p: 1, overflow: 'auto' }}>
                  <CodeEditor />
                </Box>
              </ReflexElement>

              <ReflexSplitter propagate />

              {/* Assessment Panel */}
              <ReflexElement flex={0.3} minSize={100}>
                <Box sx={{ height: '100%', p: 1, bgcolor: '#f5f5f5', overflow: 'auto' }}>
                  <AssessmentPanel />
                </Box>
              </ReflexElement>

            </ReflexContainer>
          </ReflexElement>

        </ReflexContainer>
      </Box>

      <TipsTooltip />
    </Box>
  );
};
