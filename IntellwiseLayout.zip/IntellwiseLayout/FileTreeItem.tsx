import React from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import { ExpandMore, ChevronRight } from '@mui/icons-material';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  isExpanded?: boolean;
}

interface FileTreeItemProps {
  file: FileNode;
  level: number;
  onToggle: (id: string) => void;
}

export const FileTreeItem: React.FC<FileTreeItemProps> = ({ file, level, onToggle }) => {
  const isMainFile = file.name === 'main.py';
  const borderColor = isMainFile ? 'rgba(15,73,119,1)' : 'rgba(228,228,229,1)';
  const textColor = isMainFile ? '#0F4977' : 'black';

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, minHeight: '37px' }}>
          {level > 0 && (
            <Box 
              sx={{ 
                width: '1px',
                height: '37px',
                borderLeft: `1px solid ${borderColor}`
              }} 
            />
          )}
          
          {file.type === 'folder' && (
            <IconButton 
              size="small"
              onClick={() => onToggle(file.id)}
              sx={{ p: 0.5 }}
            >
              {file.isExpanded ? <ExpandMore sx={{ fontSize: 16 }} /> : <ChevronRight sx={{ fontSize: 16 }} />}
            </IconButton>
          )}
          
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            minHeight: '37px',
            bgcolor: 'white',
            borderRadius: 1,
            px: 1,
            py: 1
          }}>
            <Typography 
              variant="body2" 
              sx={{ color: textColor, fontSize: '14px' }}
            >
              {file.name}
            </Typography>
          </Box>
        </Box>
        
        {file.type === 'folder' && (
          <img
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e4cf3363908c6be17da073b3f1cfa1517d24647e?placeholderIfAbsent=true"
            style={{ width: 16, height: 16 }}
            alt="Folder options"
          />
        )}
      </Box>
      
      {file.type === 'folder' && file.isExpanded && file.children && (
        <Box sx={{ pl: 1 }}>
          {file.children.map((child) => (
            <Box key={child.id} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, pl: 1 }}>
                <Box 
                  sx={{ 
                    width: '1px',
                    height: '37px',
                    borderLeft: `1px solid ${borderColor}`
                  }} 
                />
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  minHeight: '37px',
                  bgcolor: 'white',
                  borderRadius: 1,
                  px: 1,
                  py: 1
                }}>
                  <Typography variant="body2" sx={{ fontSize: '14px' }}>
                    {child.name}
                  </Typography>
                </Box>
              </Box>
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
};
