import React, { useState } from 'react';
import { Box, Paper, Tabs, Tab, Typography, List, ListItem, ListItemText } from '@mui/material';

type TabType = 'assessment' | 'metrics' | 'generation' | 'debug' | 'reasoning';

export const AssessmentPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('assessment');

  const handleTabChange = (event: React.SyntheticEvent, newValue: TabType) => {
    setActiveTab(newValue);
  };

  return (
    <Paper 
      elevation={0}
      sx={{ 
        height: '300px',
        bgcolor: '#f5f5f5',
        border: '1px solid #e4e4e5',
        borderRadius: 1,
        overflow: 'hidden'
      }}
    >
      <Paper elevation={0} sx={{ bgcolor: 'white', height: '100%', borderRadius: 1 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            borderBottom: '1px solid #e0e0e0',
            minHeight: '40px',
            '& .MuiTab-root': {
              minHeight: '40px',
              textTransform: 'none',
              fontSize: '12px',
              color: '#000',
              fontWeight: 500,
              px: 2,
              '&.Mui-selected': {
                color: '#0F4977',
                bgcolor: '#F3FAFF'
              }
            },
            '& .MuiTabs-indicator': {
              display: 'none'
            }
          }}
        >
          <Tab label="Assessment" value="assessment" />
          <Tab label="Advance Metrics" value="metrics" />
          <Tab label="Code Generation" value="generation" />
          <Tab label="Debug" value="debug" />
          <Tab label="Reasoning" value="reasoning" />
        </Tabs>
        
        <Box sx={{ p: 2, height: 'calc(100% - 40px)', overflow: 'auto' }}>
          {activeTab === 'assessment' && (
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1.5, fontSize: '14px' }}>
                Suggested Fixes:
              </Typography>
              <List dense sx={{ py: 0 }}>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Wrap `requests.get()` in try-except." 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Extract API URL to a constant." 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Refactor: Split fetch and logging into two separate functions" 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
              </List>
              
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1.5, mt: 2, fontSize: '14px' }}>
                Static Analysis Summary:
              </Typography>
              <List dense sx={{ py: 0 }}>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Missing error handling in function `api_call()`" 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Consider using f-strings instead of string concatenation" 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Unused import: `requests` can be moved to top-level" 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
                <ListItem sx={{ px: 0, py: 0.5 }}>
                  <ListItemText 
                    primary="• Code smell: Function `fetch_user_data` has mixed concerns (API + printing)" 
                    sx={{ '& .MuiListItemText-primary': { fontSize: '13px' } }}
                  />
                </ListItem>
              </List>
            </Box>
          )}
          
          {activeTab === 'metrics' && (
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, fontSize: '14px' }}>
                Advanced Metrics
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography sx={{ fontSize: '13px' }}>Code Complexity:</Typography>
                  <Typography sx={{ fontWeight: 500, color: '#ff9800', fontSize: '13px' }}>Medium</Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography sx={{ fontSize: '13px' }}>Maintainability Index:</Typography>
                  <Typography sx={{ fontWeight: 500, color: '#4caf50', fontSize: '13px' }}>78/100</Typography>
                </Box>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography sx={{ fontSize: '13px' }}>Test Coverage:</Typography>
                  <Typography sx={{ fontWeight: 500, color: '#f44336', fontSize: '13px' }}>0%</Typography>
                </Box>
              </Box>
            </Box>
          )}
          
          {activeTab === 'generation' && (
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, fontSize: '14px' }}>
                Code Generation
              </Typography>
              <Typography sx={{ fontSize: '13px' }}>AI-powered code generation features will be displayed here.</Typography>
            </Box>
          )}
          
          {activeTab === 'debug' && (
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, fontSize: '14px' }}>
                Debug Information
              </Typography>
              <Typography sx={{ fontSize: '13px' }}>Debug tools and information will be displayed here.</Typography>
            </Box>
          )}
          
          {activeTab === 'reasoning' && (
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 2, fontSize: '14px' }}>
                AI Reasoning
              </Typography>
              <Typography sx={{ fontSize: '13px' }}>AI reasoning and explanation will be displayed here.</Typography>
            </Box>
          )}
        </Box>
      </Paper>
    </Paper>
  );
};
