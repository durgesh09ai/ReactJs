import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Typography, Avatar, ListItem, ListItemText } from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import { Link } from "react-router-dom";
import NavItem from "./NavItem";
import { mainPageStore } from "../../stores/MainPageStore";
import SettingsIcon from "@mui/icons-material/Settings";

// Define the shape of sidebarData
type SidebarData = Record<
  string,
  {
    id: string;
    SubCategoryList: Record<
      string,
      {
        id: string;
        count: number;
      }
    >;
  }
>;

interface dropDownItems {
  id:string;
  name:string;
}

const Sidebar = observer(() => {
  const loggedInUserId = "admin@gmail.com";
  const [sguList, setSguList] = useState<dropDownItems[]>([]);
  const [imuList, setImuList] = useState<dropDownItems[]>([]);
  
  const {
    sidebarCollapsed,
    setSidebarCollapsed,
    sidebarData,
    fetchSideMenuData,
    sidemenuloading,
    fetchFillerListData
  } = mainPageStore;

  // useEffect(() => {
  //   fetchSideMenuData();
  // }, [fetchSideMenuData]);


  useEffect(()=>{
    const loadSguData = async() =>{
      const data =  await fetchFillerListData('sgu');
      setSguList(data);
    }
    loadSguData();
   },[]);

   //Load IMU Dropdown Data

   useEffect(()=>{
    const loadImuData = async() =>{
      const data =  await fetchFillerListData('imu');
      setImuList(data);
    }
    loadImuData();
   },[]);

  const collapsed = sidebarCollapsed;
  const toggleSidebar = () => {
    setSidebarCollapsed();
  };

  const sguListItems = sguList && sguList.map((items, index) => ({
    label: items.name,
    count: 10,
    href: `/solutioncatalogue/sgu/${items.id}`,
  }));

  const imuListItems = imuList && imuList.map((items, index) => ({
    label: items.name,
    count: 10,
    href: `/solutioncatalogue/imu/${items.id}`,
  }));

 // const typedSidebarData = sguList as dropDownItems;

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh"
      px={!collapsed ? 2 : 1}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
    >
      {/* Top Section */}
      <Box flexGrow={1}>
        {/* Header */}
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          py={0.8}
          borderBottom="1px solid rgba(0,0,0,0.1)"
        >
          <Typography
            variant="h6"
            sx={{
              fontSize: "28px",
              fontWeight: 600,
              color: "#e7552b",
              whiteSpace: "nowrap",
              mr: "4px",
            }}
          >
            EXL
          </Typography>
          {!collapsed && (
          <Avatar
            src={!collapsed ? "/resize.svg" : "/openIcon.svg"}
            alt="Logo"
            sx={{ width: 24, height: 24, cursor: "pointer" }}
            variant="square"
            onClick={toggleSidebar}
          />
          )}
        </Box>

        {/* Collapsed Home Icon */}
        {collapsed && (
          <Box display="flex" flexDirection="column" sx={{ mt: 2, textAlign: "center" }}>
            <Box display="flex"  sx={{textAlign: "center",mb:1,ml:1.8,color:'#000' }}>
            <Avatar
            src={!collapsed ? "/resize.svg" : "/openIcon.svg"}
            alt="Logo"
            sx={{ width: 24, height: 24, cursor: "pointer" }}
            variant="square"
            onClick={toggleSidebar}
          />
            </Box>
            <Link to="/" style={{ textDecoration: "none" }}>
              <HomeIcon sx={{ color: "#888", fontSize: 20 }} />
            </Link>
          </Box>
        )}

        {/* Expanded Sidebar Navigation */}
          <Box display="flex" flexDirection="column" sx={{ mt: 2 }}>
            {/* Static Home Section */}

            {!collapsed && (
            <Typography
              sx={{
                fontSize: "12px",
                textTransform: "uppercase",
                color: "#888",
                px: 2,
                py: 1,
              }}
            >
              Home
            </Typography>
            )}

            {/* Dynamic Sections */}
                <NavItem
                  key="SGU"
                  icon="/menuIcon.svg"
                  label="SGU"
                  collapsed={collapsed}
                  subItems={sguListItems}
                />

             <NavItem
                  key="IMU"
                  icon="/menuIcon.svg"
                  label="IMU"
                  collapsed={collapsed}
                  subItems={imuListItems}
                />
            
          </Box>
       
      </Box>

      {/* Footer Items pinned to bottom */}
        <Box mt={2}>
        <ListItem
          component={Link}
          to="/settings"
          sx={{
            textDecoration: "none",
            color: "inherit",
            px: 1,
            py: 1,
            borderRadius: 1,
            "&:hover": { backgroundColor: "#f5f5f5" },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 }} />
          {!collapsed && (
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
          )}
        </ListItem>
       </Box>
      
    </Box>
  );
});

export default Sidebar;