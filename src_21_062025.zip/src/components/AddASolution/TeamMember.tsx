import React from "react";
import { Box, Typography, Avatar } from "@mui/material";
import { TechnologyBadge } from "../SolutionCatalogueDetail/TechnologyBadge";

interface TeamMemberProps {
  name: string;
  role: string;
  avatar: string;
  badge?: {
    label: string;
    variant?: "blue" | "yellow" | "orange";
  };
  isActive?: boolean;
}

export const TeamMember: React.FC<TeamMemberProps> = ({
  name,
  role,
  avatar,
  badge,
  isActive = false,
}) => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      width="100%"
      gap={2}
    >
      {/* Left side: avatar + info */}
      <Box display="flex" alignItems="center" gap={2}>
        <Avatar
          src={avatar}
          alt={`${name}'s avatar`}
          sx={{
            width: 50,
            height: 50,
            objectFit: "contain",
          }}
        />

        <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
          <Typography fontSize="15px" fontWeight={600} color="black">
            {name}
          </Typography>
          <Typography fontSize="13px" fontWeight={500} color="gray">
            ({role})
          </Typography>
          {badge && (
            <TechnologyBadge
              label={badge.label}
              variant={badge.variant || "orange"}
              size="sm"
            />
          )}
        </Box>
      </Box>

      {/* Right side: icons */}
      <Box display="flex" alignItems="center" gap={2}>
        <Box
          component="img"
          src="./messeageIcon1.png"
          alt="Message"
          sx={{
            width: 17,
            height: 17,
            objectFit: "contain",
            cursor: "pointer",
            "&:hover": { opacity: 0.8 },
          }}
        />
        <Box
          component="img"
          src={
            isActive
              ? "./threedot.svg"
              : "./threedot.svg"
          }
          alt={isActive ? "Active" : "Inactive"}
          sx={{
            width: 24,
            height: 24,
            objectFit: "contain",
            cursor: "pointer",
            "&:hover": { opacity: 0.8 },
          }}
        />
      </Box>
    </Box>
  );
};
