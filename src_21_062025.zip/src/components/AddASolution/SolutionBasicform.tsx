import React, { useCallback, useEffect, useState } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
  IconButton,
} from "@mui/material";
import { useDropzone } from "react-dropzone";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CloseIcon from "@mui/icons-material/Close";
import { mainPageStore } from "../../stores/MainPageStore";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export interface BasicInfoFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

interface dropDownItems {
  id: string;
  name: string;
}

export const SolutionBasicform: React.FC<BasicInfoFormProps> = ({
  data,
  onDataChange,
}) => {
  const [clientList, setClientList] = useState<dropDownItems[]>([]);

  const {
    fetchFillerListData,
    fetchByTechnologyOptions,
    technologyOptionsList,
  } = mainPageStore;

  useEffect(() => {
    const loadClientData = async () => {
      const data = await fetchFillerListData("client");
      setClientList(data);
    };
    loadClientData();
  }, []);

  useEffect(() => {
    fetchByTechnologyOptions();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onDataChange({ ...data, [name]: value });
  };

  const handleDrop = useCallback((acceptedFiles: File[]) => {
    const newImages = acceptedFiles.map((file) =>
      URL.createObjectURL(file)
    );
    onDataChange({
      ...data,
      images: [...(data.images || []), ...newImages],
    });
  }, [data, onDataChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    accept: { "image/*": [] },
    multiple: true,
  });

  const handleDeleteImage = (index: number) => {
    const updatedImages = data.images.filter((_: any, i: number) => i !== index);
    onDataChange({ ...data, images: updatedImages });
  };

  const handleDeleteChip = (listKey: string, idToDelete: string) => {
    onDataChange({
      ...data,
      [listKey]: (data[listKey] || []).filter((item: any) => item.id !== idToDelete),
    });
  };

  return (
    <Paper elevation={0} sx={{ width: { xs: "100%", md: "704px" }, p: 1 }}>
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" width={20} height={20} />
          <Typography variant="subtitle1">Start Your Story</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
            width: "100%",
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ flex: 1 }}>
            {/* Solution Name */}
            <Box>
              <Typography variant="body2" gutterBottom>
                Solution Name
              </Typography>
              <TextField
                required
                name="solutionName"
                value={data.solutionName || ""}
                onChange={handleChange}
                placeholder="Enter name of Solution"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            {/* Client Name */}
            <Box sx={{ width: 400 }}>
              <Typography variant="body2" gutterBottom>
                Client Name
              </Typography>
              <Autocomplete
                multiple
                options={clientList}
                disableCloseOnSelect
                value={data.clients || []}
                getOptionLabel={(option) => option.name}
                onChange={(_, newValue) =>
                  onDataChange({ ...data, clients: newValue })
                }
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      icon={icon}
                      checkedIcon={checkedIcon}
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option.name}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Clients"
                    placeholder="Select Clients"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.clients || []).map((item: any) => (
                  <Chip
                    key={item.id}
                    label={item.name}
                    onDelete={() => handleDeleteChip("clients", item.id)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>

            {/* Smart Tags */}
            <Box sx={{ width: 400 }}>
              <Typography variant="body2" gutterBottom>
                Smart Tags
              </Typography>
              <Autocomplete
                multiple
                options={technologyOptionsList}
                disableCloseOnSelect
                value={data.smartTags || []}
                getOptionLabel={(option) => option.name}
                onChange={(_, newValue) =>
                  onDataChange({ ...data, smartTags: newValue })
                }
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      icon={icon}
                      checkedIcon={checkedIcon}
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option.name}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Smart Tags"
                    placeholder="Select Smart Tags"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.smartTags || []).map((item: any) => (
                  <Chip
                    key={item.id}
                    label={item.name}
                    onDelete={() => handleDeleteChip("smartTags", item.id)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>

            {/* Year of Implementation */}
            <Box>
              <Typography variant="body2" gutterBottom>
                Year of Implementation
              </Typography>
              <TextField
                required
                name="year"
                value={data.year || ""}
                onChange={handleChange}
                placeholder="Enter Year of Implementation"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>
          </Stack>

          {/* Right Column - Image Upload */}
          <Box sx={{ flex: 1, minWidth: "50%" }}>
            <Typography variant="body2" gutterBottom>
              Upload Card images.
            </Typography>
            <Box
              {...getRootProps()}
              sx={{
                border: "2px dashed rgba(15,73,119,0.5)",
                p: 2,
                borderRadius: 2,
                textAlign: "center",
                cursor: "pointer",
                mt: 2,
                minHeight: "100px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
              }}
            >
              <input {...getInputProps()} />
              {isDragActive ? (
                <Typography variant="body2">Drop the files here ...</Typography>
              ) : (
                <img
                  src="./add_file.svg"
                  alt="Upload"
                  style={{ width: "66px", height: "auto" }}
                />
              )}
            </Box>

            <Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap" }}>
              {(data.images || []).map((img: string, idx: number) => (
                <Box
                  key={idx}
                  sx={{
                    position: "relative",
                    width: 40,
                    height: 40,
                    borderRadius: 1,
                    overflow: "hidden",
                    border: "1px solid #ccc",
                  }}
                >
                  <img
                    src={img}
                    alt={`img-${idx}`}
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                  <IconButton
                    size="small"
                    sx={{
                      position: "absolute",
                      top: -4,
                      right: -4,
                      backgroundColor: "#fff",
                      border: "1px solid #ccc",
                      "&:hover": { backgroundColor: "#f5f5f5" },
                    }}
                    onClick={() => handleDeleteImage(idx)}
                  >
                    <CloseIcon sx={{ fontSize: 12 }} />
                  </IconButton>
                </Box>
              ))}
            </Box>
          </Box>
        </Box>
      </Stack>
    </Paper>
  );
};
