import React, { useState, useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Button,
} from "@mui/material";
import { TeamMember } from "./TeamMember";

interface Member {
  name: string;
  role: string;
  avatar: string;
  badge: {
    label: string;
    variant: "blue" | "green" | "red";
  };
  isActive: boolean;
}

interface BasicInfoFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

export const CaseStudyTeamMemeber: React.FC<BasicInfoFormProps> = ({
  data,
  onDataChange,
}) => {
  const [formData, setFormData] = useState<any>(data || {});
  const [memberInput, setMemberInput] = useState("");

  // Sync with parent updates
  useEffect(() => {
    setFormData(data || {});
  }, [data]);

  // Push changes to parent
  useEffect(() => {
    onDataChange(formData);
  }, [formData, onDataChange]);

  const handleAddMember = () => {
    if (!memberInput.trim()) return;

    const newMember: Member = {
      name: memberInput.trim(),
      role: "Contributor",
      avatar: "./proimage.png",
      badge: {
        label: "Member",
        variant: "blue",
      },
      isActive: true,
    };

    const updatedTeam = [...(formData.teamMembers || []), newMember];
    setFormData((prev: any) => ({
      ...prev,
      teamMembers: updatedTeam,
    }));

    setMemberInput("");
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "282px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./startIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Add Team Members</Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
          }}
        >
          <Stack spacing={3} sx={{ flex: 1 }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Add your Team
              </Typography>
              <Box sx={{ p: 2, display: "flex", gap: 1 }}>
                <TextField
                  id="members"
                  name="member"
                  value={memberInput}
                  onChange={(e) => setMemberInput(e.target.value)}
                  placeholder="Enter Team Member Name"
                  fullWidth
                  variant="outlined"
                  size="small"
                />
                <Button
                  variant="contained"
                  size="small"
                  onClick={handleAddMember}
                  sx={{
                    height: 38,
                    backgroundColor: "#0F4977",
                    textTransform: "none",
                    fontSize: "0.75rem",
                    "&:hover": {
                      backgroundColor: "#0c3b61",
                    },
                  }}
                >
                  Add
                </Button>
              </Box>
            </Box>

            <Box
              sx={{
                backgroundColor: "white",
                border: "1px solid rgba(0,0,0,0.2)",
                borderRadius: 1,
                p: 2,
              }}
            >
              <Typography
                fontWeight={600}
                fontSize="1rem"
                color="rgba(21,23,24,1)"
                sx={{ pb: 1, borderBottom: "1px solid rgba(0,0,0,0.2)" }}
              >
                Team Created
              </Typography>

              <Box mt={2}>
                {(formData.teamMembers || []).map((member: Member, index: number) => (
                  <Box mt={index > 0 ? 2 : 0} key={index}>
                    <TeamMember
                      name={member.name}
                      role={member.role}
                      avatar={member.avatar}
                      isActive={member.isActive}
                    />
                  </Box>
                ))}
              </Box>
            </Box>
          </Stack>
        </Box>
      </Stack>
    </Paper>
  );
};
