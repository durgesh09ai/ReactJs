import React, { useCallback, useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
  IconButton,
} from "@mui/material";
import { useDropzone } from "react-dropzone";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CloseIcon from '@mui/icons-material/Close';
import { mainPageStore } from "../../stores/MainPageStore";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface RFIRFPFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

const submissionType = [
  { key: "client-RFP", label: "Client RFP" },
  { key: "client-RFI", label: "Client RFI" },
  { key: "analyst-RFI", label: "Analyst RFI" },
  { key: "others", label: "Others" },
];

export const RFIRFPsBasicform: React.FC<RFIRFPFormProps> = ({ data, onDataChange }) => {
  const {
    fetchByTechnologyOptions,
    technologyOptionsList,
  } = mainPageStore;

  useEffect(() => {
    fetchByTechnologyOptions();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onDataChange({ ...data, [name]: value });
  };

  const handleDrop = useCallback((acceptedFiles: File[]) => {
    const newImages = acceptedFiles.map(file => URL.createObjectURL(file));
    onDataChange({ ...data, images: [...(data.images || []), ...newImages] });
  }, [data, onDataChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    accept: { "image/*": [] },
    multiple: true,
  });

  const handleDeleteChip = (field: string, key: string | number) => {
    const updated = (data[field] || []).filter((item: any) => item.key !== key && item.id !== key);
    onDataChange({ ...data, [field]: updated });
  };

  return (
    <Paper elevation={0} sx={{ width: { xs: "100%", md: "704px" }, flexGrow: 1, p: 1, minHeight: "382px" }}>
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" style={{ width: "20px", height: "20px" }} />
          <Typography variant="subtitle1">Start Your Story</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">General Information</Typography>

        <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, gap: 4, width: '580px' }}>
          <Stack spacing={2} sx={{ flex: 1 }}>
            <Box>
              <Typography variant="body2" gutterBottom>RFI/RFP Title</Typography>
              <TextField
                required
                name="solutionName"
                value={data.solutionName || ""}
                onChange={handleChange}
                placeholder="Enter RFI/RFP Title"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>Date of Submission</Typography>
              <TextField
                required
                name="submissionDate"
                value={data.submissionDate || ""}
                onChange={handleChange}
                placeholder="Enter Date of Submission"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box sx={{ width: 400 }}>
              <Typography variant="body2" gutterBottom>Submission Type</Typography>
              <Autocomplete
                multiple
                options={submissionType}
                disableCloseOnSelect
                value={data.subTypeClient || []}
                getOptionLabel={(option) => option.label}
                onChange={(_, newValue) => onDataChange({ ...data, subTypeClient: newValue })}
                isOptionEqualToValue={(option, value) => option.key === value.key}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Submission Type"
                    placeholder="Select Submission Type"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.subTypeClient || []).map((item: any) => (
                  <Chip
                    key={item.key}
                    label={item.label}
                    onDelete={() => handleDeleteChip("subTypeClient", item.key)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>

            <Box sx={{ width: 400 }}>
              <Typography variant="body2" gutterBottom>Smart Tags</Typography>
              <Autocomplete
                multiple
                options={technologyOptionsList}
                disableCloseOnSelect
                value={data.selectedSTag || []}
                getOptionLabel={(option) => option.name}
                onChange={(_, newValue) => onDataChange({ ...data, selectedSTag: newValue })}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.name}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Smart Tags"
                    placeholder="Select Smart Tags"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.selectedSTag || []).map((item: any) => (
                  <Chip
                    key={item.id}
                    label={item.name}
                    onDelete={() => handleDeleteChip("selectedSTag", item.id)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>
          </Stack>

          <Box sx={{ flex: 1, minWidth: "50%" }}>
            <Typography variant="body2" gutterBottom>Upload Card images.</Typography>
            <Box
              {...getRootProps()}
              sx={{
                border: "2px dashed rgba(15,73,119,0.5)",
                padding: 2,
                borderRadius: 2,
                textAlign: "center",
                cursor: "pointer",
                mt: 2,
                minHeight: "100px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap" }}>
                {(data.images || []).map((img: string, idx: number) => (
                  <Box
                    key={idx}
                    sx={{
                      position: "relative",
                      width: "40px",
                      height: "40px",
                      borderRadius: "10px",
                      overflow: "hidden",
                      border: "1px solid #ccc",
                    }}
                  >
                    <img
                      src={img}
                      alt={`Upload preview ${idx}`}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                    <IconButton
                      size="small"
                      sx={{
                        position: "absolute",
                        top: -4,
                        right: -4,
                        backgroundColor: "#fff",
                        border: "1px solid #ccc",
                        "&:hover": { backgroundColor: "#f5f5f5" },
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        const updated = data.images.filter((_: any, i: number) => i !== idx);
                        onDataChange({ ...data, images: updated });
                      }}
                    >
                      <CloseIcon sx={{ fontSize: 12 }} />
                    </IconButton>
                  </Box>
                ))}
              </Box>

              <input {...getInputProps()} />
              {isDragActive ? (
                <Typography variant="body2">Drop the files here ...</Typography>
              ) : (
                <img src="./add_file.svg" alt="Card image 2" style={{ width: "66px", height: "auto" }} />
              )}
            </Box>
          </Box>
        </Box>
      </Stack>
    </Paper>
  );
};
