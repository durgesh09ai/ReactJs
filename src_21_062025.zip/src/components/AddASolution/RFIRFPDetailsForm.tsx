import React from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface RFIRFPDetailsFormProps {
  data: {
    dealSize?: string;
    description?: string;
    rfpDescription?: string;
    valuePropositionDescription?: string;
    exlDifferentiator: { key: string; label: string }[];
    valueProposition: { key: string; label: string }[];
  };
  onDataChange: (key: string, value: any) => void;
}

const exlDifferentiator = [
  { key: "reporting", label: "Reporting/MI" },
  { key: "strategy", label: "Strategy" },
  { key: "analytics", label: "Analytics Data Management" },
  { key: "modeling", label: "Modeling" },
  { key: "management", label: "Model Risk Management" },
  { key: "monitoring", label: "Model Monitoring" },
  { key: "engineering", label: "Data Engineering" },
  { key: "software", label: "Software Engineering" },
  { key: "others", label: "others" },
];

const valueProposition = [
  { key: "supplying-talent", label: "Supplying Talent" },
  { key: "influence-analytics-output", label: "Influence Analytics Output" },
  { key: "influence-business-outcomes", label: "Influence Business Outcomes" },
];

export const RFIRFPDetailsForm: React.FC<RFIRFPDetailsFormProps> = ({ data, onDataChange }) => {
  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "220px",
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "522px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" style={{ width: "20px", height: "20px" }} />
          <Typography variant="subtitle1">Product Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
          <Box sx={{ width: "100%" }}>
            <Typography variant="body2" gutterBottom>
              EXL Differentiator
            </Typography>
            <Autocomplete
              multiple
              options={exlDifferentiator}
              disableCloseOnSelect
              value={data.exlDifferentiator}
              getOptionLabel={(option) => option.label}
              onChange={(event, newValue) => onDataChange("exlDifferentiator", newValue)}
              isOptionEqualToValue={(option, value) => option.key === value.key}
              renderTags={() => null}
              renderOption={(props, option, { selected }) => (
                <li {...props} style={{ fontSize: 14 }}>
                  <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                  {option.label}
                </li>
              )}
              renderInput={(params) => (
                <TextField
                  {...params}
                  variant="outlined"
                  label="Select EXL Differentiator"
                  placeholder="Select EXL Differentiator"
                  size="small"
                  InputLabelProps={{ sx: { fontSize: 14 } }}
                />
              )}
            />
            <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
              {data.exlDifferentiator.map((item) => (
                <Chip
                  key={item.key}
                  label={item.label}
                  onDelete={() =>
                    onDataChange(
                      "exlDifferentiator",
                      data.exlDifferentiator.filter((tag) => tag.key !== item.key)
                    )
                  }
                  color="primary"
                  variant="outlined"
                  size="small"
                />
              ))}
            </Box>
          </Box>
        </Stack>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            columnGap: 2,
            rowGap: 2,
            justifyContent: "flex-start",
            alignItems: "flex-start",
            width: "100%",
          }}
        >
          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Deal Size($)
              </Typography>
              <TextField
                name="dealSize"
                value={data.dealSize || ""}
                onChange={(e) => onDataChange("dealSize", e.target.value)}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Deal Size($)"
                multiline
                rows={4}
                maxRows={4}
                style={{ width: "320px" }}
              />
            </Box>

            <Box sx={{ width: 260 }}>
              <Typography variant="body2" gutterBottom>
                Value Proposition
              </Typography>
              <Autocomplete
                multiple
                options={valueProposition}
                disableCloseOnSelect
                value={data.valueProposition}
                getOptionLabel={(option) => option.label}
                onChange={(event, newValue) => onDataChange("valueProposition", newValue)}
                isOptionEqualToValue={(option, value) => option.key === value.key}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Value Proposition"
                    placeholder="Select Value Proposition"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {data.valueProposition.map((item) => (
                  <Chip
                    key={item.key}
                    label={item.label}
                    onDelete={() =>
                      onDataChange(
                        "valueProposition",
                        data.valueProposition.filter((tag) => tag.key !== item.key)
                      )
                    }
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>
          </Stack>

          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                RFI / RFP Description
              </Typography>
              <TextField
                name="rfpDescription"
                value={data.rfpDescription || ""}
                onChange={(e) => onDataChange("rfpDescription", e.target.value)}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter RFI / RFP Description"
                multiline
                rows={4}
                maxRows={4}
                style={{ width: "320px" }}
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Value Proposition Description
              </Typography>
              <TextField
                name="valuePropositionDescription"
                value={data.valuePropositionDescription || ""}
                onChange={(e) => onDataChange("valuePropositionDescription", e.target.value)}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Value Proposition Description"
                multiline
                rows={4}
                maxRows={4}
                style={{ width: "320px" }}
              />
            </Box>
          </Stack>
        </Box>

        <Box>
          <Typography variant="body2" gutterBottom>
            Description
          </Typography>
          <TextField
            name="description"
            value={data.description || ""}
            onChange={(e) => onDataChange("description", e.target.value)}
            variant="outlined"
            size="small"
            sx={textFieldStyle}
            InputProps={{ sx: inputStyle }}
            placeholder="Enter Detail"
            multiline
            rows={4}
            maxRows={4}
            style={{ width: "680px" }}
          />
        </Box>
      </Stack>
    </Paper>
  );
};
