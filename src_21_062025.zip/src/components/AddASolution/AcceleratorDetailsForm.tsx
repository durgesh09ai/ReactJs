import React, { useCallback, useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
  IconButton,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import { mainPageStore } from "../../stores/MainPageStore";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface AcceleratorDetailsFormProps {
  data: any;
  onDataChange: (data: any) => void;
}

const exlDifferentiator = [
  { key: "reporting", label: "Reporting/MI" },
  { key: "strategy", label: "Strategy" },
  { key: "analytics", label: "Analytics Data Management" },
  { key: "modeling", label: "Modeling" },
  { key: "management", label: "Model Risk Management" },
  { key: "monitoring", label: "Model Monitoring" },
  { key: "engineering", label: "Data Engineering" },
  { key: "software", label: "Software Engineering" },
  { key: "others", label: "others" },
];

const valueProposition = [
  { key: "supplying-talent", label: "Supplying Talent" },
  { key: "influence-analytics-output", label: "Influence Analytics Output" },
  { key: "influence-business-outcomes", label: "Influence Business Outcomes" },
];

export const AcceleratorDetailsForm: React.FC<AcceleratorDetailsFormProps> = ({ data, onDataChange }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onDataChange({ ...data, [name]: value });
  };

  const handleDeleteChip = (field: string, key: string | number) => {
    const updated = (data[field] || []).filter((item: any) => item.key !== key && item.id !== key);
    onDataChange({ ...data, [field]: updated });
  };

  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "320px",
  };

  return (
    <Paper elevation={0} sx={{ width: { xs: "100%", md: "704px" }, flexGrow: 1, p: 2, minHeight: "522px" }}>
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img src="./formIcon.png" alt="Start icon" style={{ width: "20px", height: "20px" }} />
          <Typography variant="subtitle1">Accelerator Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">General Information</Typography>

        <Box>
          <Typography variant="body2" gutterBottom>EXL Differentiator</Typography>
          <Autocomplete
            multiple
            options={exlDifferentiator}
            disableCloseOnSelect
            value={data.exlDifferentiator || []}
            getOptionLabel={(option) => option.label}
            onChange={(_, newValue) => onDataChange({ ...data, exlDifferentiator: newValue })}
            isOptionEqualToValue={(option, value) => option.key === value.key}
            renderTags={() => null}
            renderOption={(props, option, { selected }) => (
              <li {...props} style={{ fontSize: 14 }}>
                <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                {option.label}
              </li>
            )}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="outlined"
                label="Select EXL Differentiator"
                placeholder="Select EXL Differentiator"
                size="small"
                InputLabelProps={{ sx: { fontSize: 14 } }}
              />
            )}
          />
          <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
            {(data.exlDifferentiator || []).map((item: any) => (
              <Chip
                key={item.key}
                label={item.label}
                onDelete={() => handleDeleteChip("exlDifferentiator", item.key)}
                color="primary"
                variant="outlined"
                size="small"
              />
            ))}
          </Box>
        </Box>

        <Box sx={{ display: "flex", flexDirection: { xs: "column", md: "row" }, columnGap: 2, rowGap: 2, justifyContent: "flex-start", alignItems: "flex-start", width: "100%" }}>
          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box sx={{ width: 260 }}>
              <Typography variant="body2" gutterBottom>Value Proposition</Typography>
              <Autocomplete
                multiple
                options={valueProposition}
                disableCloseOnSelect
                value={data.valueProposition || []}
                getOptionLabel={(option) => option.label}
                onChange={(_, newValue) => onDataChange({ ...data, valueProposition: newValue })}
                isOptionEqualToValue={(option, value) => option.key === value.key}
                renderTags={() => null}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.label}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    label="Select Value Proposition"
                    placeholder="Select Value Proposition"
                    size="small"
                    InputLabelProps={{ sx: { fontSize: 14 } }}
                  />
                )}
              />
              <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
                {(data.valueProposition || []).map((item: any) => (
                  <Chip
                    key={item.key}
                    label={item.label}
                    onDelete={() => handleDeleteChip("valueProposition", item.key)}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                ))}
              </Box>
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>Accelerator Description</Typography>
              <TextField
                name="acceleratorDescription"
                value={data.acceleratorDescription || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Accelerator Detail"
                multiline
                rows={4}
                maxRows={4}
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>Time Saved or Benefits</Typography>
              <TextField
                name="timeSaved"
                value={data.timeSaved || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Time Saved or Benefits"
                multiline
                rows={4}
                maxRows={4}
              />
            </Box>
          </Stack>

          <Stack spacing={2} sx={{ width: "100%", fontSize: 12 }}>
            <Box>
              <Typography variant="body2" gutterBottom>Value Proposition Description</Typography>
              <TextField
                name="valuePropositionDesc"
                value={data.valuePropositionDesc || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Value Proposition Description"
                multiline
                rows={4}
                maxRows={4}
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>Use Case / Problem it Accelerates</Typography>
              <TextField
                name="useCase"
                value={data.useCase || ""}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Use Case / Problem Accelerates"
                multiline
                rows={4}
                maxRows={4}
              />
            </Box>
          </Stack>
        </Box>
      </Stack>
    </Paper>
  );
};
