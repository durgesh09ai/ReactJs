import React from "react";
import { 
  Card, 
  CardContent, 
  Box, 
  Typography, 
  Avatar,
  Stack
} from "@mui/material";

interface StatCardProps {
  value: number;
  label: string;
  icon: string;
  trend: string;
  trendIcon: string;
  trendText: string;
}

const StatCard: React.FC<StatCardProps> = ({
  value,
  label,
  icon,
  trend,
  trendIcon,
  trendText,
}) => {
  return (
    <Card sx={{ 
      border:'1px solid',
      borderColor: '#E4E4E5',
      borderRadius: '16px',
      backgroundColor: '#FFF',
      p: '16px',
      height: '121px',
      boxShadow: 'none' // 👈 Removed the shadow
    }}>
      <CardContent sx={{ p: 1.0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="h4" component="div" sx={{ fontWeight: 500, fontSize: '24px' }}>
              {value}
            </Typography>
            <Typography variant="body1" color="text.secondary">
              {label}
            </Typography>
          </Box>
          <Avatar
                src={icon}
                alt={label}
                sx={{
                width: 44,
                height: 44,
                p: '10px',
                borderRadius: '12px',
                backgroundColor: '#FFF',
                boxShadow: '0px 2px 10px 0px rgba(124, 141, 181, 0.12)',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '10px'
                }}
                />
        </Box>
        
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 2, color: '#7C8DB5' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box component="img" src={trendIcon} alt="Trend" sx={{ width: 20, height: 20, mr: 1 }} />
            <Typography variant="body2">{trend}</Typography>
          </Box>
          <Typography variant="body2" sx={{ flexGrow: 1 }}>{trendText}</Typography>
        </Stack>
      </CardContent>
    </Card>
  );
};

export default StatCard;
