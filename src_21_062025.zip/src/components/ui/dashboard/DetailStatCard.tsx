import React from "react";
import { 
  Card, 
  CardContent, 
  Box, 
  Typography, 
  Avatar,
  Stack
} from "@mui/material";

interface StatCardProps {
  value: string;
  label: string;
  icon: string;
  trend: string;
  trendIcon: string;
  trendText: string;
}

const DetailStatCard: React.FC<StatCardProps> = ({
  value,
  label,
  icon,
  trend,
  trendIcon,
  trendText,
}) => {
  return (
<Card sx={{ 
      border:'1px solid',
      borderColor:'#E4E4E5',
      borderRadius: '16px',
      backgroundColor: '#FFF',
      p: '2px',
      height: '80px',
      boxShadow: 'none' 
    }}>


      <CardContent sx={{ p: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
        <Box
        sx={{
          width: 28,
          height: 28,
          border:"1px solid",
          borderColor:"#FDF4EE",
          bgcolor: "#fff",
          p: 3,
          pt:4,
          borderRadius: "8px", 
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Avatar
         src={icon}
         alt={label}
         sx={{
         width: 44,
         height: 44,
         p: '10px',
         }}
         />
         </Box>
          <Box sx={{ml:"8px"}}>
            <Typography variant="h4" component="div" sx={{ fontWeight: "bold", fontSize: '24px' }}>
              {value}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem',color:"#000" }}>
              {label}
            </Typography>
          </Box>
         
        </Box>

        {/* <Stack
          direction="row"
          spacing={1}
          alignItems="center"
          sx={{ mt: 1.5, color: '#7C8DB5' }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box
              component="img"
              src={trendIcon}
              alt="Trend"
              sx={{ width: 16, height: 16, mr: 0.5 }}
            />
            <Typography variant="caption">{trend}</Typography>
          </Box>
          <Typography variant="caption">{trendText}</Typography>
        </Stack> */}
      </CardContent>
    </Card>
  );
};

export default DetailStatCard;
