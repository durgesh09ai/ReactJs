
import React, { JSX, useEffect, useState } from "react";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack,
  ListSubheader,
  MenuItem,
  Select
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import StatCard from "../ui/dashboard/StatCard";
import { useNavigate } from "react-router-dom";
import { mainPageStore } from "../../stores/MainPageStore";
import { SelectChangeEvent } from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

interface dropDownItems {
  id:string;
  name:string;
}

interface statItems {
  solution_type:string;
  count:number;
}

type typeData = Record<
string,
{
  id: string;
  SubCategoryList: Record<
    string,
    {
      SubCategoryTypeList: any;
      id: string;
      count: number;
    }
  >;
}
>;


const MainContent: React.FC = () => {

  const [selectedType, setSelectedType] = useState<string>("");
  const [selectedSgu, setSelectedSgu] = useState<string>("");
  const [selectedClient, setSelectedClient] = useState<string>("");
  const [selectedImu, setSelectedImu] = useState<string>("");

  const [statDataList, setStatDataList] = useState<statItems[]>([]);
  const [clientList, setClientList] = useState<dropDownItems[]>([]);
  const [sguList, setSguList] = useState<dropDownItems[]>([]);
  const [imuList, setImuList] = useState<dropDownItems[]>([]);

  const userId = "admin@gmail.com";
  const {
    fetchStatData,
    statData,
    fetchByTypeOptions,
    fetchFillerListData,
    typeOptionsList,
   }  = mainPageStore;

  useEffect(() => {
    fetchByTypeOptions();
  }, [userId]);

  useEffect(()=>{
    const loadStatData = async() =>{
      const data =  await fetchStatData(2);
      setStatDataList(data);
    }
    loadStatData();
   },[]);

  useEffect(()=>{
   const loadClientData = async() =>{
    const data = await fetchFillerListData('client');
    setClientList(data);
   }
   loadClientData();
  },[]);


  useEffect(()=>{
    const loadSguData = async() =>{
      const data =  await fetchFillerListData('sgu');
      setSguList(data);
    }
    loadSguData();
   },[]);


   useEffect(()=>{
    const loadImuData = async() =>{
      const data =  await fetchFillerListData('imu');
      setImuList(data);
    }
    loadImuData();
   },[]);

  
  const handleTypeChange = (event: SelectChangeEvent<string>) => {
    setSelectedType(event.target.value);
  };

 const handleSGUChange = (event: SelectChangeEvent<string>) => {
  setSelectedSgu(event.target.value);
 };

 const handleClientChange = (event: SelectChangeEvent<string>) => {
  setSelectedClient(event.target.value);
};

const handleImuChange = (event: SelectChangeEvent<string>) => {
  setSelectedImu(event.target.value);
};

const typedData = typeOptionsList as typeData;


const renderTypeOptionsDropdown = () => {
  const options: JSX.Element[] = [];

  if (!typeOptionsList || typeof typeOptionsList !== "object") {
    return options;
  }

  Object.entries(typedData).forEach(([lobName, lobData]) => {
    if (!lobData?.SubCategoryList) return;

    Object.entries(lobData.SubCategoryList).forEach(
      ([subCatName, subCatData]) => {
        if (!subCatData?.id) return;
        options.push(
          <ListSubheader key={`${lobName}-${subCatName}`}>
           <b> {subCatName}</b>
          </ListSubheader>
        );
        subCatData.SubCategoryTypeList.forEach((type:any) => {
        options.push(
          <MenuItem key={type.id} value={type.id} sx={{fontSize:"14px"}}>
          {type.name}
        </MenuItem>
        );
      });
      }
    );
   
  });
  return options;
};



  const navigate = useNavigate();
  const addSolution = () => {
    navigate("/addasolution");
  };
  

  const stats = [
    {
      value: "89",
      label: "Team",
      icon: "./team1.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Total Demos",
      icon: "./team2.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Total Active Projects",
      icon: "./team3.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Most liked",
      icon: "team4.svg",
      trend: "10.2",
      trendIcon: "./arrow.svg",
      trendText: "+1.01% this week",
    },
  ];

  const data = [
    { icon: "./actual.svg", label: "Actuarial / Underwriting", value: "6" },
    { icon: "./benefits.svg", label: "Benefits Design", value: "8" },
    { icon: "./claim.svg", label: "Claims/Ops", value: "2" },
    { icon: "./clinical.svg", label: "Clinical Management", value: "12" },
    { icon: "./cservices.svg", label: "Clinical Services", value: "1" },
    { icon: "./custservices.svg", label: "Customer Services", value: "13" },
    { icon: "./medicalcost.svg", label: "Medical Cost Management", value: "14" },
    { icon: "./medicalcost.svg", label: "Network Management", value: "7" }
  ];
  
  
  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px',
      gap: '16px',
    }}>
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'flex-end'
      }}>
        <Button 
          variant="outlined" 
          startIcon={<AddIcon />} 
          onClick={addSolution}
          sx={{ 
            color: '#0F4977', 
            borderColor: '#0F4977',
            boxShadow: '0px 1px 3px 0px rgba(96,108,128,0.05)',
            '&:hover': {
              borderColor: '#0F4977',
              backgroundColor: 'rgba(15, 73, 119, 0.04)'
            }
          }}
        >
          Add New Solution
        </Button>
      </Box>

      <Box
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    gap: '40px',
    alignSelf: 'stretch',
  }}
>  <Stack direction="row" flexWrap="wrap" spacing={2} useFlexGap>
    {statDataList && statDataList.map((stat, index) => (
      <Box
        key={index}
        sx={{ width: { xs: '100%', md: 'calc(50% - 8px)' } }}
      >
        <StatCard
          value={stat.count}
          label={stat.solution_type}
          icon="./team1.svg"
          trend="+12%"
          trendIcon="./arrow.svg"
          trendText="Since last month"
        />
      </Box>
    ))}
  </Stack>
</Box>


      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>


          <Box sx={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '48px'
          }}>
            <Typography variant="h6" component="h2" sx={{ fontWeight: 600 }}>
              Value Delivered Across the Payer Value Chain.
            </Typography>
          </Box>


          <Paper
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: '16px',
    gap: '32px',
    alignSelf: 'stretch',
    borderRadius: '8px',
    backgroundColor: '#FFF',
    border: 'none',
    boxShadow: 'none',
    mt: 2,
  }}
>
<Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
> 
   <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
      <FormLabel  sx={{ 
                mb: 1, 
                color: '#000', 
                fontSize: '14px', 
                fontStyle: 'normal', 
                fontWeight: 400, 
                lineHeight: 'normal'
                
         }}>By Solution Type</FormLabel>
      <Select
        value={selectedType}
        onChange={handleTypeChange}
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '8px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value="" disabled>
          Select Type
        </MenuItem>
       {renderTypeOptionsDropdown()}
      </Select>

      </FormControl>
    </Box>

    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By SGU</FormLabel> 
 <Select
        value={selectedSgu}
        onChange={handleSGUChange}
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '8px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value="" disabled>
          Select SGU
        </MenuItem>
        {sguList.map(opt => (
          <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
            {opt.name}
          </MenuItem>
        ))}
      </Select>

      </FormControl>
    </Box>
  </Stack>


  <Stack
  direction={{ xs: 'column', md: 'row' }}
  sx={{
    display: 'flex',
    flexDirection: { xs: 'column', md: 'row' },
    alignItems: 'flex-start',
    gap: '16px',
    alignSelf: 'stretch',
  }}
>    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By Client</FormLabel>

<Select
      value={selectedClient}
      onChange={handleClientChange}
      displayEmpty
      IconComponent={KeyboardArrowDownIcon}
      sx={{
        bgcolor: 'background.paper',
        borderRadius: '8px',
        '.MuiOutlinedInput-notchedOutline': {
          borderColor: 'rgba(211,209,209,0.4)',
        },
        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
          borderColor: 'rgba(211,209,209,0.6)',
        },
        '& .MuiSelect-select': {
          backgroundColor: 'white',
        },
        '& .MuiPaper-root': {
          backgroundColor: 'white',
          zIndex: 9999,
        }
      }}
      MenuProps={{
        PaperProps: {
          sx: {
            bgcolor: 'white',
            zIndex: 9999,
          }
        }
      }}
    >
      <MenuItem value="" disabled>
        Select Client
      </MenuItem>
      {clientList.map(opt => (
        <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
          {opt.name}
        </MenuItem>
      ))}
    </Select>
  </FormControl>
  </Box>

    <Box sx={{ width: { xs: '100%', md: '50%' } }}>
      <FormControl fullWidth>
          <FormLabel  sx={{ 
    mb: 1, 
    color: '#000', 
    fontSize: '14px', 
    fontStyle: 'normal', 
    fontWeight: 400, 
    lineHeight: 'normal'
  }}>By IMU</FormLabel>

<Select
  value={selectedImu}
  onChange={handleImuChange}
  displayEmpty
  IconComponent={KeyboardArrowDownIcon}
  sx={{
    bgcolor: 'background.paper',
    borderRadius: '8px',
    '.MuiOutlinedInput-notchedOutline': {
      borderColor: 'rgba(211,209,209,0.4)',
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: 'rgba(211,209,209,0.6)',
    },
    '& .MuiSelect-select': {
      backgroundColor: 'white',
    },
    '& .MuiPaper-root': {
      backgroundColor: 'white',
      zIndex: 9999,
    }
  }}
  MenuProps={{
    PaperProps: {
      sx: {
        bgcolor: 'white',
        zIndex: 9999,
      }
    }
  }}
>
  <MenuItem value="" disabled>
    Select IMU
  </MenuItem>
  {imuList.map(opt => (
    <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
      {opt.name}
    </MenuItem>
  ))}
 </Select>
   </FormControl>
    </Box>
  </Stack>
</Paper>


<Box sx={{ mt: 2 }}>
  <Box
    sx={{
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
      gap: 2, // horizontal and vertical spacing
    }}
  >
    {data.map((item, index) => (
      <Box 
        key={index} 
        sx={{ 
          width: 'calc(50% - 8px)', // two items per row with 16px total spacing
        }}
      >
        <DataCard 
          icon={item.icon} 
          label={item.label} 
          value={item.value} 
          labelSx={{ fontWeight: 'bold', fontSize: '0.9rem' }}
        />
      </Box>
    ))}
  </Box>
</Box>

        </Box>
      </Box>
    </Box>
  );
};

export default MainContent;
