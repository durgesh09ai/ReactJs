
import React, { JSX, useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack,
  MenuItem,
  Select,
  ListSubheader,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';
import FilterDropdown from "../ui/dashboard/FilterDropdown";
import DataCard from "../ui/dashboard/DataCard";
import DetailStatCard from "../ui/dashboard/DetailStatCard";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import { useNavigate } from "react-router-dom";
import { mainPageStore } from "../../stores/MainPageStore";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { SelectChangeEvent } from '@mui/material';
import { ProductCard } from "./ProductCard";
import { Tabs, Tab } from "@mui/material";
import { TabContext, TabPanel } from "@mui/lab";

interface dropDownItems {
  id:string;
  name:string;
}

interface statItems {
  solution_type:string;
  count:number;
}

type typeData = Record<
string,
{
  id: string;
  SubCategoryList: Record<
    string,
    {
      SubCategoryTypeList: any;
      id: string;
      count: number;
    }
  >;
}
>;

interface ProductProps {
  id: string;
  name: string;
  description: string;
  tags:string[];
  profile_img: string;
  views:number;
}

const DetailContent = () => {
  const navigate = useNavigate();
  // const [selectedType, setSelectedType] = useState<string>("");
  // const [selectedSgu, setSelectedSgu] = useState<string>("");
  // const [selectedClient, setSelectedClient] = useState<string>("");
  // const [selectedImu, setSelectedImu] = useState<string>("");

   const [statDataList, setStatDataList] = useState<statItems[]>([]);
  // const [solutionType, setSolutionType] = useState<dropDownItems[]>([]);
  // const [clientList, setClientList] = useState<dropDownItems[]>([]);
  // const [sguList, setSguList] = useState<dropDownItems[]>([]);
  // const [imuList, setImuList] = useState<dropDownItems[]>([]);

  const [activeTab, setActiveTab] = useState('57c79385-4c91-4be2-891a-cef8b89567eb');
  const [activeSidebarItem, setActiveSidebarItem] = useState('57c79385-4c91-4be2-891a-cef8239567eb');

  const userId = "admin@gmail.com";
  const {
    fetchStatData,
    loading,
    statData,
    fetchFillerListData,
    fetchBussinessUnitListData,
    bussinessUnitListData,
    bussinessunitloading
   }  = mainPageStore;

   //Load Stat Data
 
    useEffect(()=>{
        const loadStatData = async() =>{
          const data =  await fetchStatData();
          setStatDataList(data);
        }
        loadStatData();
       },[]);

       useEffect(()=>{
        fetchBussinessUnitListData(activeTab,activeSidebarItem);
       },[activeTab,activeSidebarItem]);


   //Load Solution Type Dropdown Data

  // useEffect(()=>{
  //   const loadSolutionTypeData = async() =>{
  //    const data = await fetchFillerListData('type');
  //    setSolutionType(data);
  //   }
  //   loadSolutionTypeData();
  //  },[]);


 //Load Client Dropdown Data

  // useEffect(()=>{
  //  const loadClientData = async() =>{
  //   const data = await fetchFillerListData('client');
  //   setClientList(data);
  //  }
  //  loadClientData();
  // },[]);

   //Load SGU Dropdown Data

  // useEffect(()=>{
  //   const loadSguData = async() =>{
  //     const data =  await fetchFillerListData('sgu');
  //     setSguList(data);
  //   }
  //   loadSguData();
  //  },[]);

   //Load IMU Dropdown Data

  //  useEffect(()=>{
  //   const loadImuData = async() =>{
  //     const data =  await fetchFillerListData('imu');
  //     setImuList(data);
  //   }
  //   loadImuData();
  //  },[]);

//   const handleTypeChange = (event: SelectChangeEvent<string>) => {
//     setSelectedType(event.target.value);
//   };

//  const handleSGUChange = (event: SelectChangeEvent<string>) => {
//   setSelectedSgu(event.target.value);
//  };

//  const handleClientChange = (event: SelectChangeEvent<string>) => {
//   setSelectedClient(event.target.value);
// };

// const handleImuChange = (event: SelectChangeEvent<string>) => {
//   setSelectedImu(event.target.value);
// };

  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  const addSolution = () => {
    navigate("/addasolution");
  };


  const tabs = [
    { id: '57c79385-4c91-4be2-891a-cef8b89567eb', label: 'Insurance' },
    { id: '70064e6f-7f10-4924-b86a-51d97dd89de7', label: 'Healthcare & Lifescience' },
    { id: '04fc86e0-071a-4705-9ae5-5d6eb80f7ea1', label: 'Banking & Capital Mkts' },
    { id: 'de97a4c7-277e-445e-b897-1acf67cac94d', label: 'Diversified Industries' },
    { id: '5ca161e6-5370-4c75-a609-aa34d172c735', label: 'Growth Mkts' }
  ];
  
  const sidebarItems = [
    { id: '57c79385-4c91-4be2-891a-cef8239567eb', label: 'Domain Ops' },
    { id: '70064e6f-7f10-4924-b86a-51d23dd89de7', label: 'F&A Ops' },
    { id: '04fc86e0-071a-4705-9ae5-523eb80f7ea1', label: 'Payment Integrity' },
    { id: 'vde97a4c7-277e-445e-b897-1acf23cac94d', label: 'Analytics & AI' },
    { id: '5ca161e6-5370-4c75-a609-aa323172c735', label: 'Platform' },
    { id: '5ca161e6-5370-4c75-a609-aa34d232c735', label: 'Data Mgt' },
    { id: '5ca161e6-5370-4c75-a609-aa23d172c735', label: 'DE & AI' }
  ];


 // console.log('bissiness Unit',bussinessUnitListData);
  const products = bussinessUnitListData?.result;
  const productsCount = bussinessUnitListData?.remain_count;


  // Assuming 8 sample products
// const products1 = new Array(8).fill(0).map((_, index) => ({
//   id: `${index}`,
//   title: `Product ${index + 1}`,
//   description: 'Streamline collection, validation, and maintenance of provider information effortlessly.',
//   imageUrl: 'https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/fdc9969fa4e85a1de72dd5366fd09b6f86b9ea0a?placeholderIfAbsent=true',
//   badges: [
//     { text: 'Payer', variant: 'primary' as const },
//     { text: 'Underwriting', variant: 'secondary' as const }
//   ]
// }));

  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px'
    }}>

  <Box sx={{ 
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    }}>
   <Typography  sx={{ fontWeight: "bold",fontSize:"14px", mb:1 }}>
    Solutions Summery
    </Typography>
  </Box>

<Stack
  direction="row"
  spacing={1}
  sx={{
    mt: 1,
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
  }}
>
  {loading &&
   <Box>Loading..</Box>
  }
  {statDataList && statDataList.map((items, idx) => (
    <Box
      key={idx}
      sx={{
        minWidth: '150px', 
        maxWidth: '150px',
      }}
    >
      <DetailStatCard
        value={`${items.count}`}
        label={`${items.solution_type}`}
        icon="./stat_icon.png"
        trend="+12%"
        trendIcon="./arrow.svg"
        trendText="Since last month"
      />
    </Box>
  ))}
</Stack>
<Box sx={{ width: '100%', mt: 4 }}>
  <Box sx={{ width: '100%' }}>
    <Box sx={{ 
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      height: '28px'
    }}>
      
      <Typography  sx={{ fontWeight: "bold",fontSize:"14px", mb:4 }}>
      Explore Solutions Across Business Units
      </Typography>
    </Box>

{/* <Paper
  sx={{
    mt: 2,
    mb:2,
    borderRadius: 2,
    border: 'none',
    boxShadow: 'none',
  }}
>
  <Stack
    direction="row"
    spacing={2}
    sx={{
      flexWrap: 'nowrap',
      minWidth: '100%',
    }}
  >
   
    <Box
        key="By Type"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By Solution Type
        </FormLabel>
      <Select
        value={selectedType}
        onChange={handleTypeChange}
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '8px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value="" disabled>
          Select Type
        </MenuItem>
        {solutionType.map(opt => (
          <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
            {opt.name}
          </MenuItem>
        ))}
      </Select> 
      </FormControl>
      </Box>

      <Box
        key="By Technology"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}> By SGU
        </FormLabel>
      <Select
        value={selectedSgu}
        onChange={handleSGUChange}
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '8px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value="" disabled>
          Select SGU
        </MenuItem>
        {sguList.map(opt => (
          <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
            {opt.name}
          </MenuItem>
        ))}
      </Select>
   
      </FormControl>
      </Box>

    <Box
      key="By Client"
      sx={{
        flex: '1 1 22%',
        minWidth: '200px',
        maxWidth: '25%',
      }}
    >
    <FormControl fullWidth>
    <FormLabel  sx={{ 
        mb: 1, 
        color: '#000', 
        fontSize: '14px', 
        fontStyle: 'normal', 
        fontWeight: 400, 
        lineHeight: 'normal'
      }}> By Client
      </FormLabel>
    <Select
      value={selectedClient}
      onChange={handleClientChange}
      displayEmpty
      IconComponent={KeyboardArrowDownIcon}
      sx={{
        bgcolor: 'background.paper',
        borderRadius: '8px',
        '.MuiOutlinedInput-notchedOutline': {
          borderColor: 'rgba(211,209,209,0.4)',
        },
        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
          borderColor: 'rgba(211,209,209,0.6)',
        },
        '& .MuiSelect-select': {
          backgroundColor: 'white',
        },
        '& .MuiPaper-root': {
          backgroundColor: 'white',
          zIndex: 9999,
        }
      }}
      MenuProps={{
        PaperProps: {
          sx: {
            bgcolor: 'white',
            zIndex: 9999,
          }
        }
      }}
    >
      <MenuItem value="" disabled>
        Select Client
      </MenuItem>
      {clientList.map(opt => (
        <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
          {opt.name}
        </MenuItem>
      ))}
    </Select>
    </FormControl>
    </Box>

  <Box
        key="By Digital & Analytics"
        sx={{
          flex: '1 1 22%',
          minWidth: '200px',
          maxWidth: '25%',
        }}
      >
      <FormControl fullWidth>
      <FormLabel  sx={{ 
          mb: 1, 
          color: '#000', 
          fontSize: '14px', 
          fontStyle: 'normal', 
          fontWeight: 400, 
          lineHeight: 'normal'
        }}>By IMU
        </FormLabel>
  <Select
  value={selectedImu}
  onChange={handleImuChange}
  displayEmpty
  IconComponent={KeyboardArrowDownIcon}
  sx={{
    bgcolor: 'background.paper',
    borderRadius: '8px',
    '.MuiOutlinedInput-notchedOutline': {
      borderColor: 'rgba(211,209,209,0.4)',
    },
    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
      borderColor: 'rgba(211,209,209,0.6)',
    },
    '& .MuiSelect-select': {
      backgroundColor: 'white',
    },
    '& .MuiPaper-root': {
      backgroundColor: 'white',
      zIndex: 9999,
    }
  }}
  MenuProps={{
    PaperProps: {
      sx: {
        bgcolor: 'white',
        zIndex: 9999,
      }
    }
  }}
>
  <MenuItem value="" disabled>
    Select IMU
  </MenuItem>
  {imuList.map(opt => (
    <MenuItem key={opt.id} value={opt.id} sx={{fontSize:"14px"}}>
      {opt.name}
    </MenuItem>
  ))}
 </Select>
 </FormControl>
</Box>
 </Stack>
</Paper> */}


  {/* Cards Section */}

  <Paper
      elevation={1}
      sx={{ borderRadius: '8px', border: '1px solid rgba(15,73,119,0.1)', overflow: 'hidden' }}
    >
      <Tabs
        value={activeTab}
        onChange={(e, val) => setActiveTab(val)}
        variant="scrollable"
        scrollButtons="auto"
        sx={{ borderBottom: 1, borderColor: 'divider' }}
      >
        {tabs.map((tab) => (
          <Tab
            key={tab.id}
            label={tab.label}
            value={tab.id}
            sx={{ textTransform: 'none', fontWeight: 500, fontSize: '14px',minWidth:"18%" }}
          />
        ))}
      </Tabs>

    <Box sx={{ display: 'flex', minHeight: 500 }}>
  {/* Sidebar */}
  <Box
    sx={{
      width: 215,
      borderRight: '1px solid rgba(0, 0, 0, 0.1)',
      flexShrink: 0,
    }}
  >
    <List>
      {sidebarItems.map((item) => (
        <ListItem key={item.id} disablePadding sx={{mb:2,mt:1}}>
          <ListItemButton
            selected={item.id === activeSidebarItem}
            onClick={() => setActiveSidebarItem(item.id)}
            sx={{
                  minHeight: "37",
                  textAlign:"center",
                  px: 1,
                  py: '9px',
                  m:1,
                  borderRadius: '8px',
                  '&.Mui-selected': {
                    backgroundColor: '#EAF2F7',
                   '& .MuiListItemText-primary': {
                      color: 'black',
                      fontWeight: 500,
                    },
                  },
                  '&:hover': {
                    backgroundColor: '#EAF2F7',
                  },
                  '& .MuiListItemText-primary': {
                    fontSize: '14px',
                    color: '#604F4F',
                  },
                }}
          >
            <ListItemText primary={item.label} />
          </ListItemButton>
        </ListItem>
      ))}
    </List>
  </Box>

  {/* Product Grid with margin from sidebar */}
  <Box sx={{ flexGrow: 1, p: 1, ml: 0.5 }}>

  {bussinessunitloading &&
  <Box sx={{display:"flex", justifyContent:"center", alignItems:"center", width:"60%", height:25}}>Loading<img src="/loader3.gif"/></Box>    
  }

    <Box
      display="flex"
      flexWrap="wrap"
      gap={2}
      justifyContent="flex-start"
    >
      {products && products.map((product:ProductProps) => (
        <Box
          key={product.id}
          sx={{
            flex: '1 1 calc(50% - 16px)',
            minWidth: 300,
            maxWidth: '100%',
          }}
        >
          <ProductCard {...product} />
        </Box>
      ))}
    </Box>

   { productsCount>0 && 
    <Box sx={{ mt: 2 }}>
      <Button
        onClick={() => console.log('View More')}
        sx={{ textTransform: 'none', fontWeight: 500, fontSize: '14px' }}
      >
        {productsCount}+ View More
      </Button>
    </Box>
    }

  </Box>
</Box>

 </Paper>



        </Box>
      </Box>
    </Box>
  );
};

export default observer(DetailContent);
