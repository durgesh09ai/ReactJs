import styled from "styled-components";
import { Box, IconButton, TextField } from "@mui/material";

export const StyledContainer = styled(Box)<{ backgroundColor: string }>`
  width: 400px;
  padding: 16px;
  background-color: ${(props) => props.backgroundColor};
  color: #fff;
  height: calc(100vh - 64px);
  display: flex;
  flex-direction: column;
  position: relative;
`;

export const StyledMessages = styled(Box)<{ backgroundColor: string }>`
  flex-grow: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding-right: 8px;

  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    background: ${(props) => (props.backgroundColor === "#121212" ? "#1e1e1e" : "#f0f0f0")};
  }

  &::-webkit-scrollbar-thumb {
    background: ${(props) => (props.backgroundColor === "#121212" ? "#555" : "#aaa")};
    border-radius: 4px;
  }

  scrollbar-width: thin;
  scrollbar-color: ${(props) =>
    props.backgroundColor === "#121212" ? "#555 #1e1e1e" : "#aaa #f0f0f0"};
`;

export const MessageBubble = styled(Box)`
  align-self: flex-end;
  background: #1e1e1e;
  color: #ececf1;
  border-radius: 16px;
  padding: 8px 16px;
  max-width: 85%;
  word-break: break-word;
  font-size: 12px;
  cursor: pointer;
`;

export const InputWrapper = styled(Box)`
  margin-top: 16px;
  position: relative;
`;

export const StyledTextField = styled(TextField)<{ backgroundColor: string }>`
  width: 100%;
  background-color: ${(props) => (props.backgroundColor === "#121212" ? "#343541" : "#e0e0e0")};
  border-radius: 16px;

  & .MuiOutlinedInput-root {
    color: #fff;

    & fieldset {
      border: none;
    }

    &:hover fieldset {
      border: none;
    }

    &.Mui-focused fieldset {
      border: none;
    }
  }

  & .MuiInputBase-input {
    color: #ececf1;
    font-size: 12px;
    overflow: hidden;
  }
`;

export const StyledSendButton = styled(IconButton)<{ backgroundColor: string }>`
  position: absolute;
  bottom: 32px;
  right: 20px;
  z-index: 10;
  background-color: ${({ backgroundColor }) =>
    backgroundColor === "#121212" ? "#343541" : "#e0e0e0"};
  color: #fff;
  border-radius: 16px;
  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);

  &:hover {
    background-color: ${({ backgroundColor }) =>
      backgroundColor === "#121212" ? "#444" : "#ccc"};
  }
`;

