import React, { useState, useRef, useEffect } from "react";
import { IconButton } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import {
  StyledContainer,
  StyledMessages,
  MessageBubble,
  InputWrapper,
  StyledTextField,
} from "./ProgressBar.styles";

interface Message {
  user: string;
}

interface ProgressBarProps {
  backgroundColor: string;
  messages: Message[];
  inputValue: string;
  setInputValue: (val: string) => void;
  handleSend: () => void;
}

export const ProgressBar = ({
  backgroundColor,
  messages,
  inputValue,
  setInputValue,
  handleSend,
}: ProgressBarProps) => {
  const textFieldRef = useRef<HTMLTextAreaElement | null>(null);
  const [expandedMsgIndex, setExpandedMsgIndex] = useState<number | null>(null);

  useEffect(() => {
    if (textFieldRef.current) {
      textFieldRef.current.style.height = "auto";
      textFieldRef.current.style.height = `${textFieldRef.current.scrollHeight}px`;
    }
  }, [inputValue]);

  const handleLocalSend = () => {
    handleSend();
    if (textFieldRef.current) {
      textFieldRef.current.style.height = "96px";
    }
  };

  return (
    <StyledContainer backgroundColor={backgroundColor}>
      <StyledMessages backgroundColor={backgroundColor}>
        {messages.map((msg, index) => {
          const isExpanded = expandedMsgIndex === index;
          const previewText =
            msg.user.split(" ").slice(0, 20).join(" ") +
            (msg.user.split(" ").length > 20 ? "..." : "");

          return (
            <MessageBubble
              key={index}
              onClick={() => setExpandedMsgIndex(isExpanded ? null : index)}
            >
              {isExpanded ? msg.user : previewText}
            </MessageBubble>
          );
        })}
      </StyledMessages>

      <InputWrapper>
        <StyledTextField
          inputRef={(el) => (textFieldRef.current = el)}
          variant="outlined"
          placeholder="Type your message..."
          multiline
          maxRows={10}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          backgroundColor={backgroundColor}
        />
      </InputWrapper>

      <IconButton
        sx={{
          position: "absolute",
          bottom: 32,
          right: 20,
          zIndex: 10,
          backgroundColor: backgroundColor === "#121212" ? "#343541" : "#e0e0e0",
          color: "#fff",
          borderRadius: 2,
          boxShadow: 3,
          '&:hover': {
            backgroundColor: backgroundColor === "#121212" ? "#444" : "#ccc",
          }
        }}
        onClick={handleLocalSend}
      >
        <SendIcon />
      </IconButton>
    </StyledContainer>
  );
};
