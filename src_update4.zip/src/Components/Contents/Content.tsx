import React, { useState } from "react";
import { Box, Toolbar, Typography, Container } from "@mui/material";

interface ContentProps {
  backgroundColor: string;
  messages: { user: string; model: string }[];
}

export const Content = ({ backgroundColor,messages }: ContentProps) => {
 return (
    <Box sx={{ flexGrow: 1, p: 3, color: "#fff", backgroundColor: backgroundColor , minHeight: "calc(100vh - 64px)", display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
      <Container >
          <>
            <Typography variant="h5">Topic Analysis & Selection</Typography>
            <Typography variant="body1">
              Explore topics extracted from the filtered papers and select one for deeper analysis.
            </Typography>
            {messages.map((msg, index) => (
            <>
            <Toolbar/>
           <Typography variant="body2" key={index}>
               Model Response {index + 1}: {msg.model}
            </Typography>
           </>
            ))}
        </>
           
      </Container>
    </Box>
  );
};
