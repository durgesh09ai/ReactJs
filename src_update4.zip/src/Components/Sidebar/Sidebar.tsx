import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch, ListItemButton } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";

const drawerWidth = 240;
interface SidebarProps {
  open: boolean;
  handleToggle: () => void;
  darkMode: boolean;
  handleThemeToggle: () => void;
}

export const Sidebar = ({ open, handleToggle, darkMode, handleThemeToggle }: SidebarProps) => (

    <Drawer
      variant="permanent"
      sx={{
        width: open ? drawerWidth : 60,
        flexShrink: 0,
        transition: "width 0.3s",
        [`& .MuiDrawer-paper`]: { width: open ? drawerWidth : 60, boxSizing: "border-box", background: darkMode ? "#222" : "#888", color: "#fff", transition: "width 0.3s" },
      }}
    >
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <IconButton onClick={handleToggle} sx={{ color: "#fff" }}>
          <MenuIcon />
        </IconButton>
      </Toolbar>
      <Box sx={{ textAlign: "center", p: 2 }}>
      <img
        src="./EXL_Service_logo.png"
        alt="Logo"
        style={{ width: open ? "120px" : "40px", transition: "width 0.3s" }}
      />
    </Box>
      <List>
        <ListItem>
          <Typography variant="body1" sx={{ display: open ? "block" : "none", mr: 2,fontSize: "12px", }}>Theme Setting
          <Switch checked={darkMode} onChange={handleThemeToggle} />
          </Typography>
        </ListItem>
        <Typography variant="body1" sx={{ display: open ? "block" : "none" ,textAlign: "center" }}>
          <Button variant="contained" sx={{ mt: 2 }}>Logout</Button>
        </Typography>

      </List>

    </Drawer>
  );