
import React from "react";
import { Typography, Box } from "@mui/material";

interface NavSectionProps {
  title: string;
}

const NavSection: React.FC<NavSectionProps> = ({ title }) => {
  return (
    <Box sx={{ p: 1 }}>
      <Typography 
        variant="subtitle2"
        sx={{ 
          fontWeight: 500, 
          color: 'text.primary',
          whiteSpace: 'nowrap'
        }}
      >
        {title}
      </Typography>
    </Box>
  );
};

export default NavSection;
