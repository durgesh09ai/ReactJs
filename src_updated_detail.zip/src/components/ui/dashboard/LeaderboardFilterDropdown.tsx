
import React, { useState } from "react";
import { 
  Box, 
  MenuItem, 
  Select, 
  FormControl,
  SelectChangeEvent
} from "@mui/material";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

interface FilterDropdownProps {
  label: string;
}

const FilterDropdown: React.FC<FilterDropdownProps> = ({ label }) => {
  const [value, setValue] = useState(label);

  const handleChange = (event: SelectChangeEvent) => {
    setValue(event.target.value);
  };

  return (
    <FormControl fullWidth>
      <Select
        value={value}
        onChange={handleChange}
        displayEmpty
        IconComponent={KeyboardArrowDownIcon}
        sx={{
          bgcolor: 'background.paper',
          borderRadius: '12px',
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.4)',
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'rgba(211,209,209,0.6)',
          },
          '& .MuiSelect-select': {
            backgroundColor: 'white',
          },
          '& .MuiPaper-root': {
            backgroundColor: 'white',
            zIndex: 9999,
          }
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              bgcolor: 'white',
              zIndex: 9999,
            }
          }
        }}
      >
        <MenuItem value={label} sx={{ mb: 1, color: 'black', fontSize: '0.775rem' }}>{label}</MenuItem>
        <MenuItem value="Option 1">Option 1</MenuItem>
        <MenuItem value="Option 2">Option 2</MenuItem>
        <MenuItem value="Option 3">Option 3</MenuItem>
      </Select>
    </FormControl>
  );
};

export default FilterDropdown;
