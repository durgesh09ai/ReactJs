import React from "react";
import { 
  Card, 
  CardContent, 
  Box, 
  Typography, 
  Avatar,
  Stack
} from "@mui/material";

interface StatCardProps {
  value: string;
  label: string;
  icon: string;
  trend: string;
  trendIcon: string;
  trendText: string;
}

const DetailStatCard: React.FC<StatCardProps> = ({
  value,
  label,
  icon,
  trend,
  trendIcon,
  trendText,
}) => {
  return (
    <Card
      sx={{
        borderRadius: 3,
        p: 1,
        height: '100%',
        backgroundColor: 'rgba(243,250,255,1)',
        boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.05)'
      }}
    >
      <CardContent sx={{ p: 1 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Box>
            <Typography variant="h6" component="div" sx={{ fontWeight: 600, fontSize: '1rem' }}>
              {value}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem' }}>
              {label}
            </Typography>
          </Box>
          <Avatar
            src={icon}
            alt={label}
            sx={{
              width: 36,
              height: 36,
              p: 1,
              bgcolor: 'background.paper',
              boxShadow: '0px 2px 10px 0px rgba(124,141,181,0.12)'
            }}
          />
        </Box>

        <Stack
          direction="row"
          spacing={1}
          alignItems="center"
          sx={{ mt: 1.5, color: '#7C8DB5' }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box
              component="img"
              src={trendIcon}
              alt="Trend"
              sx={{ width: 16, height: 16, mr: 0.5 }}
            />
            <Typography variant="caption">{trend}</Typography>
          </Box>
          <Typography variant="caption">{trendText}</Typography>
        </Stack>
      </CardContent>
    </Card>
  );
};

export default DetailStatCard;
