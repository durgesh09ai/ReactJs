import React, { useState } from "react";
import { Box, Button, Typography } from "@mui/material";

interface TabItem {
  id: string;
  label: string;
}

interface ProjectTabsProps {
  tabs: TabItem[];
  activeTab?: string;
  onTabChange?: (tabId: string) => void;
  children: React.ReactNode;
}

export const ProjectTabs: React.FC<ProjectTabsProps> = ({
  tabs,
  activeTab: externalActiveTab,
  onTabChange,
  children,
}) => {
  const [internalActiveTab, setInternalActiveTab] = useState(
    externalActiveTab || tabs[0]?.id
  );

  const activeTabId = externalActiveTab || internalActiveTab;

  const handleTabClick = (tabId: string) => {
    if (onTabChange) {
      onTabChange(tabId);
    } else {
      setInternalActiveTab(tabId);
    }
  };

  return (
    <Box display="flex" flexDirection="column" width="100%">
      <Box
        display="flex"
        gap={4}
        flexWrap="wrap"
        fontWeight="bold"
        fontSize="15px"
        color="#98A2B2"
      >
        {tabs.map((tab) => {
          const isActive = activeTabId === tab.id;
          return (
            <Box
              key={tab.id}
              sx={{
                width: `${tab.label.length * 9}px`,
                color: isActive ? "rgba(15,73,119,1)" : "#98A2B2",
              }}
            >
              <Button
                fullWidth
                onClick={() => handleTabClick(tab.id)}
                sx={{
                  display: "flex",
                  justifyContent: "flex-start",
                  textTransform: "none",
                  fontWeight: "bold",
                  padding: 0,
                  minHeight: "auto",
                  color: "inherit",
                }}
              >
                <Typography>{tab.label}</Typography>
              </Button>
              <Box
                sx={{
                  mt: "8px",
                  height: "2px",
                  width: "100%",
                  borderRadius: "1px",
                  backgroundColor: isActive ? "rgba(15,73,119,1)" : "transparent",
                }}
              />
            </Box>
          );
        })}
      </Box>

      <Box mt={3}>{children}</Box>
    </Box>
  );
};
