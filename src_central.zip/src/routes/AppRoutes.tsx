import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "../layout/Layout";
import Main from "../pages/Main/Main";
import CIP from "../pages/CIP/CIP";

// Demo1
import DatagenAiSynthetic from "../pages/CIP/Demos/DatagenAiSynthetic/DatagenAiSynthetic";
import DetailPage from "../pages/CIP/Demos/DatagenAiSynthetic/DetailPage";
import AboutUs from "../pages/CIP/Demos/DatagenAiSynthetic/AboutUs";

// Demo2 (similar structure, not repeated here)
import AdverseeventGenaiClinical from "../pages/CIP/Demos/AdverseeventGenaiClinical/AdverseeventGenaiClinical";
import DatagenAiSyntheticLayout from "../pages/CIP/Demos/DatagenAiSynthetic/Layout";

export const AppRoutes = () => (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Main />} />
        <Route path="/cip" element={<CIP />} />

        {/* Nested Demo1 */}
        <Route path="/cip/datagenaisynthetic" element={<DatagenAiSyntheticLayout />}>
          <Route index element={<DatagenAiSynthetic />} />
          <Route path="aboutus" element={<AboutUs />} />
          <Route path="detailpage" element={<DetailPage />} />
        </Route>

        {/* If needed: Nested Demo2 as well */}
        <Route path="/cip/adverseeventgenaiclinical" element={<AdverseeventGenaiClinical />} />
      </Route>
    </Routes>
);
