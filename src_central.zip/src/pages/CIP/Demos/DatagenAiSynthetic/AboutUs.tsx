import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";

const AboutUs = observer(() => {
  return (
    <div>
      <h2>DatagenAi Synthetic Detail Data</h2>
      <p>Welcome to our real REST API, where your data is securely stored in a real database, ensuring that your created data will be preserved and not lost. Our resource schema provides you with remarkable flexibility, allowing you to create custom objects with various attributes of different types. These attributes are stored as part of a "data" field, forming a customizable JSON object. This unique feature enables you to simulate a wide range of real-world application scenarios, from storing and retrieving prices, dates, and image URLs to simple text fields and beyond.</p>
    </div>
  );
});

export default AboutUs;
