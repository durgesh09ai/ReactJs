import React from "react";
import { Link, Outlet } from "react-router-dom";

const CIP = () => {
  const boxStyle: React.CSSProperties = {
    display: "inline-block",
    padding: "1rem",
    border: "1px solid #ccc",
    borderRadius: "8px",
    marginRight: "1rem",
    marginBottom: "1rem",
    textDecoration: "none",
    color: "#333",
    backgroundColor: "#f9f9f9",
    transition: "all 0.2s",
  };

  const boxHoverStyle: React.CSSProperties = {
    ...boxStyle,
    backgroundColor: "#eaeaea",
    cursor: "pointer",
  };

  return (
    <div>
      <h2>CIP Page</h2>
      <nav style={{ marginBottom: "1rem", display: "flex", gap: "1rem", flexWrap: "wrap" }}>
        <Link to="/cip/datagenaisynthetic" style={boxStyle}>
          DatagenAi Synthetic
        </Link>
        <Link to="/cip/adverseeventgenaiclinical" style={boxStyle}>
          Adverseevent GenAi Clinical
        </Link>
        {/* Add more demo boxes here */}
      </nav>

      {/* Nested routes render here */}
      <Outlet />
    </div>
  );
};

export default CIP;
