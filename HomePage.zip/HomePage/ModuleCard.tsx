import React from 'react';
import { Box, Typography, Card } from '@mui/material';
import { styled } from '@mui/material/styles';

interface ModuleCardProps {
  iconUrl: string;
  title: string;
  description: string;
  isHighlighted?: boolean;
  onClick?: () => void;
}

const StyledCard = styled(Card)(({ theme }) => ({
  height: '149px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-start',
  gap: '12px',
  flex: '1 0 0',
  position: 'relative',
  backgroundColor: 'white',
  padding: '16px',
  borderRadius: '17px',
}));

const HeaderBox = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  alignSelf: 'stretch',
  position: 'relative',
  padding: '8px 0',
  borderBottom: '1px solid rgba(0, 0, 0, 0.3)',
});

const TitleBox = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '15px',
  position: 'relative',
});

const IconImage = styled('img')({
  width: '32px',
  height: '32px',
  position: 'relative',
});

const ContentBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-start',
  alignSelf: 'stretch',
  position: 'relative',
});

const DescriptionBox = styled(Box)({
  height: '52px',
  alignSelf: 'stretch',
  position: 'relative',
});

const DescriptionText = styled(Typography)(({ theme }) => ({
  width: '578px',
  color: '#61646B',
  fontSize: '0.875rem',
  fontWeight: 400,
  lineHeight: '26px',
  letterSpacing: '0.14px',
  position: 'absolute',
  height: '52px',
  left: 0,
  top: 0,
}));

export const ModuleCard: React.FC<ModuleCardProps> = ({
  iconUrl,
  title,
  description,
  isHighlighted = false,
  onClick
}) => {
  const arrowColor = isHighlighted ? "#448DF2" : "#0F4977";

  return (
    <StyledCard elevation={0}>
      <HeaderBox>
        <TitleBox>
          <IconImage src={iconUrl} alt={`${title} icon`} />
          <Typography
            variant="h6"
            sx={{
              color: 'black',
              fontSize: '1rem',
              fontWeight: 600,
              cursor: 'pointer',
            }}
            onClick={onClick}
          >
            {title}
          </Typography>
        </TitleBox>
        <Box>
          <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            style={{ width: '20px', height: '20px', position: 'relative' }}
          >
            <path d="M3.125 10H16.875" stroke={arrowColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke={arrowColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </Box>
      </HeaderBox>
      <ContentBox>
        <DescriptionBox>
          <DescriptionText>{description}</DescriptionText>
        </DescriptionBox>
      </ContentBox>
    </StyledCard>
  );
};
