import React, { useState } from 'react';
import { Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import { WelcomeHeader } from '../components/HomePage/WelcomeHeader';
import { FeatureCard } from '../components/HomePage/FeatureCard';
import { SolutionsGrid } from '../components/HomePage/SolutionsGrid';



const MainContainer = styled(Box)(({ theme }) => ({
  maxWidth: 'none',
  display: 'flex',
  height: '100%',
  flexDirection: 'column',
  alignItems: 'flex-start',
  gap: '16px',
  flex: '1 0 0',
  position: 'relative',
  backgroundColor: 'white',
  margin: '0 auto',
  padding: '12px 8px',

}));

const FeaturesSection = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: '40px',
  alignSelf: 'stretch',
  position: 'relative',
  [theme.breakpoints.down('md')]: {
    flexDirection: 'column',
    gap: '20px',
  },
  [theme.breakpoints.down('sm')]: {
    gap: '16px',
  },
}));

const HomePage = () => {
    
  const [selectedModule, setSelectedModule] = useState<any | null>(null);


  const handleFeatureExplore = (featureTitle: string) => {
    console.log(`Exploring ${featureTitle}`);
    // Add navigation logic here
  };


  const handleModuleClick = (moduleId: string) => {
    const module = modules.find((m) => m.id === moduleId);
    if (module) setSelectedModule(module);
  };

  const legacyPricingFeatures = [
    {
      title: "Provider Shell Builder",
      description: "Initializes provider-specific configurations"
    },
    {
      title: "Service Config Rates",
      description: "Defines fixed pricing rules for services"
    },
    {
      title: "Rate Matching Logics",
      description: "Supports mapping of services to providers"
    }
  ];

  const providerBenefitsFeatures = [
    {
      title: "Data Extraction & Highlighting",
      description: "Automatically extracts benefit-related data from source files"
    },
    {
      title: "Contract Comparison Engine",
      description: "Compares annotated data"
    },
    {
      title: "Role-Based Assignment",
      description: "Entries can be routed to Subject Matter Experts"
    }
  ];

  const modules = [
    {
      id: "module-3",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/ad00d47eacb058428ef92f194d8d38676bc70dc5?width=64",
      title: "Module 3",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: false
    },
    {
      id: "module-4",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/18f8ec028429ff54440a575ef75b8bd618977a8d?width=64",
      title: "Module 4",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: false
    },
    {
      id: "module-5",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/d38a8ec99a7f11ebb6527afc205a830a200ccd80?width=64",
      title: "Module 5",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: true
    },
    {
      id: "module-6",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/18f8ec028429ff54440a575ef75b8bd618977a8d?width=64",
      title: "Module 6",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: false
    },
    {
      id: "module-7",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/3f2cd4c518f1f17a20cd82d17070349abc70fdd1?width=64",
      title: "Module 7",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: false
    },
    {
      id: "explore",
      iconUrl: "https://api.builder.io/api/v1/image/assets/TEMP/984a7ef1aa2e237def2a95a89c7e6d6d6775614d?width=64",
      title: "Explore",
      description: "CreateWith (SEO-Friendly Website, Self-Managed, Social Media Integrations) Emark-IT (360° Email & WhatsApp Marketing Tool)",
      isHighlighted: false
    }
  ];

  return (
    <MainContainer>
      <Box sx={{width:"100%"}}>
        <WelcomeHeader userName="Rajat" />
      </Box>  
      
      <FeaturesSection aria-label="Main features">
        <FeatureCard
          cardNumber="01"
          title="Legacy Pricing Logic"
          description="CCG1 represents the Legacy Pricing Logic used in earlier phases of the Recon Stream project. It likely includes static or rule-based configurations."
          features={legacyPricingFeatures}
          imageUrl="https://api.builder.io/api/v1/image/assets/TEMP/8ce2a30fe662fb6d38565ab3aaa6e20f5a015801?width=723"
          onExplore={() => handleFeatureExplore("Legacy Pricing Logic")}
        />
        
        <FeatureCard
          cardNumber="02"
          title="Provider Benefits Audit"
          description="This designed to audit and validate extracted provider benefit data. After annotation and review, the data is compared against contractual configurations using an external comparison system."
          features={providerBenefitsFeatures}
          imageUrl="https://api.builder.io/api/v1/image/assets/TEMP/a5b9fec369999a85e52185e05b49e484f3f7dc07?width=723"
          onExplore={() => handleFeatureExplore("Provider Benefits Audit")}
        />
      </FeaturesSection>

       {selectedModule ? (
        <FeatureCard
          cardNumber="99"
          title={selectedModule.title}
          description={selectedModule.description}
          features={providerBenefitsFeatures}
          imageUrl={selectedModule.iconUrl}
          onExplore={() => handleFeatureExplore("Provider Benefits Audit")}
        />
      ) : (
        <SolutionsGrid modules={modules} onModuleClick={handleModuleClick} />
      )}
    </MainContainer>
  );
};

export default HomePage;
