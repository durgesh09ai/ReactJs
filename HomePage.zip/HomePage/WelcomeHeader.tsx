import React from 'react';
import { Box, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';

interface WelcomeHeaderProps {
  userName?: string;
}

const StyledHeaderBox = styled(Box)(({ theme }) => ({
  width: '100%',
  height: '163px',
  position: 'relative',
  borderRadius: '16.386px',
  background: 'linear-gradient(to right, #0F4977, #1a5a8a)',
  overflow: 'hidden',
}));

const ContentBox = styled(Box)({
  position: 'absolute',
  bottom: '16px', // distance from bottom
  left: '27px',   // distance from left
});

const WelcomeTitle = styled(Typography)(({ theme }) => ({
  color: 'white',
  fontSize: '2.25rem',
  fontWeight: 600,
  lineHeight: '2.75rem',
}));

const WelcomeSubtext = styled(Typography)(({ theme }) => ({
  color: 'white',
  fontSize: '0.875rem',
  fontWeight: 500,
  marginTop: '4px',
}));

export const WelcomeHeader: React.FC<WelcomeHeaderProps> = ({ userName = "Rajat" }) => {
  return (
    <StyledHeaderBox>
      <ContentBox>
        <WelcomeTitle>Welcome,</WelcomeTitle>
        <WelcomeSubtext>
          Hi {userName}, let's explore the solutions categories.
        </WelcomeSubtext>
      </ContentBox>
    </StyledHeaderBox>
  );
};
