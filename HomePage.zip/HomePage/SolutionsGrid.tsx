import React from 'react';
import { Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import { ModuleCard } from './ModuleCard';

interface Module {
  id: string;
  iconUrl: string;
  title: string;
  description: string;
  isHighlighted?: boolean;
}

interface SolutionsGridProps {
  modules: Module[];
  onModuleClick?: (moduleId: string) => void;
}

const GridContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: '18px',
  alignSelf: 'stretch',
  position: 'relative',
  [theme.breakpoints.down('md')]: {
    gap: '12px',
  },
}));

const GridRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'flex-start',
  gap: '18px',
  alignSelf: 'stretch',
  position: 'relative',
  [theme.breakpoints.down('md')]: {
    flexDirection: 'column',
    gap: '12px',
  },
}));

export const SolutionsGrid: React.FC<SolutionsGridProps> = ({ modules, onModuleClick }) => {
  const handleModuleClick = (moduleId: string) => {
    if (onModuleClick) {
      onModuleClick(moduleId);
    }
  };

  return (
    <GridContainer aria-label="Solutions modules">
      {/* First row */}
      <GridRow>
        {modules.slice(0, 2).map((module) => (
          <ModuleCard
            key={module.id}
            iconUrl={module.iconUrl}
            title={module.title}
            description={module.description}
            isHighlighted={module.isHighlighted}
            onClick={() => handleModuleClick(module.id)}
          />
        ))}
      </GridRow>
      
      {/* Second row */}
      <GridRow>
        {modules.slice(2, 4).map((module) => (
          <ModuleCard
            key={module.id}
            iconUrl={module.iconUrl}
            title={module.title}
            description={module.description}
            isHighlighted={module.isHighlighted}
            onClick={() => handleModuleClick(module.id)}
          />
        ))}
      </GridRow>
      
      {/* Third row */}
      <GridRow>
        {modules.slice(4, 6).map((module) => (
          <ModuleCard
            key={module.id}
            iconUrl={module.iconUrl}
            title={module.title}
            description={module.description}
            isHighlighted={module.isHighlighted}
            onClick={() => handleModuleClick(module.id)}
          />
        ))}
      </GridRow>
    </GridContainer>
  );
};
