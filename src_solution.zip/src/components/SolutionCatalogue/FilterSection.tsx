import React, { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Stack,
  Menu,
  MenuItem,
  Checkbox,
  ListItemText,
} from '@mui/material';
import { styled } from '@mui/material/styles';

const FilterContainer = styled(Paper)`
  padding: 16px;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  width: 100%;
  background-color: white;
`;

const FilterRow = styled(Box)`
  display: flex;
  align-items: flex-end;
  flex-wrap: wrap;
  gap: 24px;
  width: 100%;
`;

const FilterItemWrapper = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: flex-end;
  flex: 1;
  min-width: 200px;
`;

const DropdownBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 46px;
  padding: 0 15px;
  border: 1px solid rgba(211, 209, 209, 0.4);
  border-radius: 8px;
  background-color: white;
  width: 100%;
  cursor: pointer;
  flex-wrap: wrap;
  gap: 8px;
`;

const TagLabel = styled(Box)`
  background-color: rgba(15, 73, 119, 0.1);
  color: rgba(15, 73, 119, 1);
  font-size: 12px;
  font-weight: 500;
  padding: 4px 8px;
  border-radius: 16px;
`;

const Icon = styled('img')`
  width: 9px;
`;

const ViewButton = styled(Button)<{ active?: boolean }>`
  background-color: ${({ active }) => (active ? '#0F4977' : 'white')} !important;
  min-height: 40px;
  width: 56px;
  padding: 8px;
  border: 1px solid rgba(211, 209, 209, 0.4);
  border-radius: ${({ active }) => (active ? '8px' : '8px 0 0 8px')} !important;

  img {
    width: 24px;
  }
`;

const LabelButton = styled(Box)`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  background-color: white;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
  color: black;

  img {
    width: 24px;
  }
`;

export const FilterSection: React.FC = () => {
  const tagOptions = ['Underwriting', 'Risk', 'Claims', 'Policy'];
  const techOptions = ['React', 'Angular', 'Vue', 'Next.js'];

  const [selectedTags, setSelectedTags] = useState<string[]>(['Underwriting']);
  const [selectedTech, setSelectedTech] = useState<string>('React');

  const [anchorElTag, setAnchorElTag] = useState<null | HTMLElement>(null);
  const [anchorElTech, setAnchorElTech] = useState<null | HTMLElement>(null);

  const openTagMenu = Boolean(anchorElTag);
  const openTechMenu = Boolean(anchorElTech);

  const handleTagToggle = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <FilterContainer elevation={1}>
      <FilterRow>
        {/* MULTI-SELECT TAG DROPDOWN */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={500} color="black">
            By tags
          </Typography>
          <DropdownBox onClick={(e) => setAnchorElTag(e.currentTarget)}>
            <Box display="flex" gap="6px" flexWrap="wrap" flex="1">
              {selectedTags.map((tag) => (
                <TagLabel key={tag}>{tag}</TagLabel>
              ))}
            </Box>
            <Icon
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/42810ee322064081dbafb4b6974f487d2ed70b22?placeholderIfAbsent=true"
              alt="dropdown"
            />
          </DropdownBox>
          <Menu
            anchorEl={anchorElTag}
            open={openTagMenu}
            onClose={() => setAnchorElTag(null)}
          >
            {tagOptions.map((tag) => (
              <MenuItem key={tag} onClick={() => handleTagToggle(tag)}>
                <Checkbox checked={selectedTags.includes(tag)} />
                <ListItemText primary={tag} />
              </MenuItem>
            ))}
          </Menu>
        </FilterItemWrapper>

        {/* SINGLE-SELECT TECHNOLOGY DROPDOWN */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={500} color="black">
            By Technology
          </Typography>
          <DropdownBox onClick={(e) => setAnchorElTech(e.currentTarget)}>
            <Typography fontSize={12}>{selectedTech}</Typography>
            <Icon
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/42810ee322064081dbafb4b6974f487d2ed70b22?placeholderIfAbsent=true"
              alt="dropdown"
            />
          </DropdownBox>
          <Menu
            anchorEl={anchorElTech}
            open={openTechMenu}
            onClose={() => setAnchorElTech(null)}
          >
            {techOptions.map((tech) => (
              <MenuItem
                key={tech}
                onClick={() => {
                  setSelectedTech(tech);
                  setAnchorElTech(null);
                }}
              >
                {tech}
              </MenuItem>
            ))}
          </Menu>
        </FilterItemWrapper>

        {/* VIEW TOGGLE BUTTONS */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={500} color="transparent">
            Placeholder
          </Typography>
          <Stack direction="row" spacing={1} alignItems="center" minHeight={46}>
            <ViewButton>
              <img
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a34c9988ec2bfc4aba6a83c6398475e3868dd1de?placeholderIfAbsent=true"
                alt="list"
              />
            </ViewButton>
            <ViewButton>
              <img
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/86dd486faa79ebd8fb90ffb1ab96097278ff39ad?placeholderIfAbsent=true"
                alt="grid"
              />
            </ViewButton>
            <ViewButton active>
              <img
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/caebbf5dbfa47212092a1c969b026b09582b30b7?placeholderIfAbsent=true"
                alt="card"
              />
            </ViewButton>
          </Stack>
        </FilterItemWrapper>

        {/* STATIC LABEL */}
        <FilterItemWrapper>
          <Typography variant="body2" fontWeight={500} color="transparent">
            Placeholder
          </Typography>
          <LabelButton>
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9f489a5850c84c1a2fd062664a0d5989cc204b22?placeholderIfAbsent=true"
              alt="filter icon"
            />
            <span>Data and analytics LOB</span>
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/3acbc5c85d133359a82249f8cf6fd72e2f9f65a3?placeholderIfAbsent=true"
              alt="dropdown"
              style={{ width: '11px' }}
            />
          </LabelButton>
        </FilterItemWrapper>
      </FilterRow>
    </FilterContainer>
  );
};
