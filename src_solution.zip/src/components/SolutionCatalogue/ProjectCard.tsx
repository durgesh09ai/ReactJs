import React from "react";
import {
  Box,
  Typography,
  Chip,
  Card,
  CardMedia,
  Button,
  Stack,
  Avatar,
} from "@mui/material";

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  imageSrc: string;
  commentCount: number;
  contributorCount: string;
  badgeIconSrc: string;
  likeIconSrc: string;
  starIconSrc: string;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  title,
  description,
  tags,
  imageSrc,
  commentCount,
  contributorCount,
  badgeIconSrc,
  likeIconSrc,
  starIconSrc,
}) => {
  return (
    <Card
      elevation={0}
      sx={{
        width: 257,
        borderRadius: 4,
        border: "1px solid rgba(172,172,172,0.2)",
        p: 2,
        position: "relative",
        bgcolor: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Star and Like Icons */}
      <Stack direction="row" spacing={1} alignItems="center" sx={{ minHeight: 24 }}>
        <Avatar src={starIconSrc} alt="star icon" sx={{ width: 16, height: 16 }} />
        <Avatar src={likeIconSrc} alt="like icon" sx={{ width: 16, height: 16 }} />
      </Stack>

      {/* Tags */}
      <Stack direction="row" spacing={1} mt={1} flexWrap="wrap">
        {tags.map((tag, index) => (
          <Chip
            key={index}
            label={tag}
            size="small"
            sx={{
              fontSize: 8,
              bgcolor:
                index === 0 ? "rgba(233,243,249,1)" : "rgba(15,73,119,0.1)",
              color: "rgba(15,73,119,1)",
              borderRadius: "999px",
              height: 20,
            }}
          />
        ))}
      </Stack>

      {/* Image with Floating Badge */}
      <Box sx={{ position: "relative", mt: 2,cursor: "pointer",
      overflow: "hidden", }}
      onClick={() => console.log("Image clicked!")}
      >
        <CardMedia
          component="img"
          image={imageSrc}
          alt={title}
          sx={{ aspectRatio: "1.91", borderRadius: 2 }}
        />
        <Avatar
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e797be27b400fbd4f0c6ce9e1342717a160306af?placeholderIfAbsent=true"
          alt="floating badge"
          sx={{
            position: "absolute",
            top: 8,
            left: 2,
            width: 25,
            height: 25,
            zIndex: 2,
          }}
        />
      </Box>

      {/* Title and Description */}
      <Box mt={2}>
        <Typography variant="subtitle2" fontWeight="500">
          {title}
        </Typography>
        <Typography
          variant="body2"
          color="text.secondary"
          mt={0.5}
          sx={{ fontSize: 12 }}
        >
          {description}
        </Typography>
      </Box>

      {/* Contributors and Comments */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mt={2}
      >
        <Stack direction="row" spacing={1} alignItems="center">
          <Avatar
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/fdda61289f7003f8cb0ec854aba59f3a0145ce2d?placeholderIfAbsent=true"
            alt="contributor icon"
            sx={{ width: 17, height: 17 }}
          />
          <Typography variant="caption" color="#676767">
            {contributorCount}
          </Typography>
        </Stack>
        <Typography variant="caption" color="#676767">
          {commentCount} Comments
        </Typography>
      </Stack>

      {/* Comment Button and Badge Icon */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mt={2}
      >
        <Button
          variant="contained"
          sx={{
            bgcolor: "rgba(15,73,119,0.1)",
            color: "rgba(15,73,119,1)",
            borderRadius: "999px",
            px: 2,
            py: 1,
            textTransform: "none",
            fontSize: 10,
            ":hover": {
              bgcolor: "rgba(15,73,119,0.2)",
            },
          }}
        >
          Add a Comment
        </Button>
        <Avatar src={badgeIconSrc} alt="badge icon" sx={{ width: 24, height: 24 }} />
      </Stack>
    </Card>
  );
};
