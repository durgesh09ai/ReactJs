import React from "react";
import { Box, Container } from "@mui/material";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import Sidebar from "../components/WorkspaceSetup/Sidebar";

const WorkspaceSetup: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleSelect = (label: string) => {
    const path = label.toLowerCase().replace(/\s/g, '-'); // e.g., "User Profile" -> "user-profile"
    navigate(`/settings/${path}`);
  };

  // Extract last part of path to highlight the selected label
  const selectedItem = location.pathname.split("/").pop()?.replace(/-/g, ' ') || "User Profile";

  return (
    <Container maxWidth="xl" sx={{ m: 0, p: 0 }}>
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          bgcolor: '#fff',
          p: 0,
          borderRadius: 2,
          justifyContent: 'center',
          alignItems: 'flex-start',
          my: 1,
        }}
      >
        <Sidebar selectedLabel={selectedItem} onSelect={handleSelect} />
        <Box sx={{ flexGrow: 1, minWidth: "82%" }}>
          <Outlet /> {/* This is where routed components render */}
        </Box>
      </Box>
    </Container>
  );
};

export default WorkspaceSetup;
