import React from "react";
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
} from "@mui/material";
import { useLocation } from "react-router-dom";

interface SidebarItemProps {
  icon: string;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

interface SidebarProps {
  selectedLabel: string;
  onSelect: (label: string) => void;
}


const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  // isActive = false,
  onClick,
}) => {
  const location = useLocation();
  const path = label.toLowerCase().replace(/\s/g,'-');
  const isActive=location.pathname.includes(path);
  return (
    <ListItem disablePadding sx={{ mt: 1 }}>
      <ListItemButton
        onClick={onClick}
        sx={{
          // bgcolor: isActive ? "#FFF" : "white",
          bgcolor: isActive ? "#E0F0FF" : "white",
          borderRadius: 1,
          py: 0.75,
          minHeight: "41px",
          color:isActive?"#1976d2":"inherit",
          fontWeight:isActive?600:400,
          "&:hover": {
            backgroundColor: "#E0F0FF",
          },
        }}
      >
        <ListItemIcon sx={{ minWidth: 40 }}>
          <Box
            component="img"
            src={icon}
            alt={label}
            sx={{ width: 24, height: 24 }}
          />
        </ListItemIcon>
        <ListItemText
          primary={label}
          primaryTypographyProps={{ variant: "body2" }}
        />
      </ListItemButton>
    </ListItem>
  );
};


const Sidebar: React.FC<SidebarProps> = ({ selectedLabel, onSelect }) => {
  const items = [
    {
      icon: "/userIcon.svg",
      label: "User Profile",
    },
    // {
    //   icon: "/solutionIcon.svg",
    //   label: "Source",
    // },
    // {
    //   icon: "/solutionIcon.svg",
    //   label: "Target",
    // },
    {
      icon: "/solutionIcon.svg",
      label: "WorkSpace",
    },
    {
      icon: "/solutionIcon.svg",
      label: "LLM Setting",
    },
    {
      icon: "/solutionIcon.svg",
      label: "Languages",
    },
    // {
    //   icon: "/logout.svg",
    //   label: "Logout",
    // },
  ];

  return (
    <Paper
      sx={{
        width: "220px",
        height:"440px",
        minWidth: "220px",
        borderRadius: 1,
        p: 1,
        fontSize: "0.875rem",
        fontWeight: "normal",
        lineHeight: 1.2,
      }}
    >
      <Typography
        sx={{
          borderBottom: "1px solid #E4E4E5",
          p: 1,
          color: "black",
          fontSize: 14,
          fontWeight: 400,
          textAlign: "center",
        }}
      >
        Settings
      </Typography>

      <List sx={{ p: 0 }}>
        {items.map((item) => {
         
          return (
          <SidebarItem
            key={item.label}
            icon={item.icon}
            label={item.label}
            isActive={selectedLabel === item.label}
            onClick={() => onSelect(item.label)}
            
          />
        )})}
      </List>
    </Paper>
  );
};

export default Sidebar;
