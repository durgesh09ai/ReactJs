import React from 'react';
import { Box } from '@mui/material';
import { ReflexContainer, ReflexSplitter, ReflexElement } from 'react-reflex';
import 'react-reflex/styles.css';

import { FileExplorer } from './FileExplorer';
import { CodeEditor } from './CodeEditor';
import { AssessmentPanel } from './AssessmentPanel';
import { TipsTooltip } from './TipsTooltip';

export const Dashboard: React.FC = () => {
  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', bgcolor: '#fff' }}>
      {/* Header */}
      {/* Main Layout */}
      <Box sx={{ flexGrow: 1 }}>
        <ReflexContainer orientation="vertical">
          
          {/* Left: File Explorer */}
          <ReflexElement minSize={200} maxSize={400}>
            <Box sx={{ height: '100%', p: 1, bgcolor: '#f9f9f9', overflow: 'auto' }}>
              <FileExplorer />
            </Box>
          </ReflexElement>

          <ReflexSplitter propagate />

          {/* Right: Editor + Assessment Panel */}
          <ReflexElement>
            <ReflexContainer orientation="horizontal">
              
              {/* Code Editor */}
              <ReflexElement flex={0.7} minSize={150}>
                <Box sx={{ height: '100%', p: 1, overflow: 'auto' }}>
                  <CodeEditor />
                </Box>
              </ReflexElement>

              <ReflexSplitter propagate />

              {/* Assessment Panel */}
              <ReflexElement flex={0.3} minSize={100}>
                <Box sx={{ height: '100%', p: 1, bgcolor: '#f5f5f5', overflow: 'auto' }}>
                  <AssessmentPanel />
                </Box>
              </ReflexElement>

            </ReflexContainer>
          </ReflexElement>

        </ReflexContainer>
      </Box>

      <TipsTooltip />
    </Box>
  );
};
