import React from "react";
import { Box, Typography, Button, Stack, Divider } from "@mui/material";
import { LanguageData } from "./EditLanguageForm";
import { LanguageItem } from "./LanguageItem";


interface ExistingLanguageSectionProps {
  language: LanguageData[];
  onAddModel: () => void;
  onEditModel: (id: string) => void;
  onDeleteModel: (id: string) => void;
}

export const ExistingLanguageSection: React.FC<ExistingLanguageSectionProps> = ({
  language,
  onAddModel,
  onEditModel,
  onDeleteModel
}) => {
  return (
    <Box sx={{ width: "100%", maxWidth: "100%", minHeight:250 }}>
      {/* <Typography
        variant="body1"
        sx={{
          color: "#1d1b20",
          fontSize:14,
          fontWeight: 'bold',
          lineHeight: 1.2,
          textAlign:'center'
        }}
      >
        Language Name 
      </Typography> */}

      <Box sx={{ mt: 0 }}>
        <Stack
          direction="row"
          spacing={2}
          justifyContent="space-between"
          flexWrap="wrap"
          alignItems="center"
          borderBottom="1px solid"
          borderTop="1px solid"
          padding={1}
        >
          <Typography
            variant="body1"
            sx={{ color: "#1d1b20", fontWeight: 'bold', lineHeight: 1.2,fontSize:14 }}
          >
            Language Name
          </Typography>
        <Button
          onClick={onAddModel}
          variant="contained"
          sx={{
            backgroundColor: "#0F4977",
            borderColor: "#0F4977",
            color: "#fff",
            textTransform: "none",
            borderRadius: 1,
            py: 0.5,
            px: 2,
            opacity: 1,
            cursor: "pointer",
          }}
          aria-label="Save"
        >
          Add Language
        </Button>


        </Stack>

        <Box sx={{ mt: "25px", display: "flex", flexDirection: "column" }}>
        {language.map((lang,index) => (
          <Box key={lang.id}>
            <LanguageItem
              indexno= {index}
              id={lang.id}
              name={lang.name}
              onEdit={onEditModel}
              onDelete={onDeleteModel}
            />
          <Divider />
          </Box>
        ))}

        </Box>
      </Box>
    </Box>
  );
};
