import React, { useState, useEffect } from "react";
import { Box, TextField, Typography, Paper } from "@mui/material";
import { ActionButtons } from "./ActionButtons";

export interface LanguageData {
  id: string;
  name: string;
}

interface EditLanguageProps {
  language: LanguageData | null;
  onUpdate: (language: LanguageData) => void;
  handleCancel: () => void;
  handleSave: () => void;
}

export const EditLanguageForm: React.FC<EditLanguageProps> = ({
  language,
  onUpdate,
  handleCancel,
  handleSave
}) => {
  const [formData, setFormData] = useState<LanguageData>({
    id: '',
    name: '',
  });

  useEffect(() => {
    if (language) {
      setFormData(language);
    } else {
      setFormData({
        id: '',
        name: '',
      });
    }
  }, [language]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData);
  };

  return (
    <Paper
      component="form"
      onSubmit={handleSubmit}
      elevation={1}
      sx={{
        width: '100%',
        p: 3,
        border: '1px solid #E4E4E5',
        borderRadius: 1,
        boxShadow: 'none',
      }}
    >
        <Typography
        variant="body1"
        sx={{ color: "#1d1b20", fontWeight: 'bold', lineHeight: 1.2,fontSize:14 }}
      >
        {language ? "Edit Language" : "Add Language"}
      </Typography>

      <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3, gap: 1 }}>
         <Box>
          <TextField
            fullWidth
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter Language"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <ActionButtons
          onCancel={handleCancel}
          onSave={handleSave}
        />
      </Box>
    </Paper>
  );
};
