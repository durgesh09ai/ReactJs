import React from "react";
import { Box, Typography, IconButton } from "@mui/material";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";

export interface LanguageItemProps {
  indexno:number;
  id: string;
  name: string;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export const LanguageItem: React.FC<LanguageItemProps> = ({
  indexno,
  id,
  name,
  onEdit,
  onDelete
}) => {
  return (
    <Box display="flex" alignItems="center" justifyContent="space-between" width="100%" flexWrap="wrap">
     
     <Box>
        <Typography variant="body2">{ indexno +1 }. </Typography>
      </Box>
      <Box flex="3" minWidth={50}>
        <Typography variant="body2">{name}</Typography>
      </Box>
      <Box flex="0 0 auto" display="flex" alignItems="center" gap={1}>
        <IconButton aria-label={`Edit ${name}`} onClick={() => onEdit(id)}>
          <Box
            component="img"
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ed8ddb289907d235e70955598ebfc3fc43c56f1d"
            alt="Edit"
            sx={{ width: 20, height: 20 }}
          />
        </IconButton>
        <IconButton aria-label={`Delete ${name}`} onClick={() => onDelete(id)}>
          <DeleteOutlineOutlinedIcon fontSize="small" />
        </IconButton>
      </Box>
    </Box>
  );
};

