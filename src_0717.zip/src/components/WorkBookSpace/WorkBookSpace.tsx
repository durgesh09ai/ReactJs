import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Paper } from "@mui/material";
import { mainPageStore } from "../../stores/MainPageStore";
import AddWorkSpaceName from "./AddWorkSpaceName";
import ProfileHeader from "../UserProfile/ProfileHeader";
import WorkSpaceTable from "./WorkSpaceTable";


const WorkBookSpace: React.FC = observer(() => {
 
  const [search, setSearch] = useState('');
  const {
    fetchWorkSpaceSetUp }  = mainPageStore;


  useEffect(() => {
    fetchWorkSpaceSetUp();
  }, []);



  

  return (
    // <Paper sx={{ width: "605px", p: 2, borderRadius: 1 }}>
      <Paper sx={{ width: "100%", p: 2, borderRadius: 1 }}>
      {/* <Typography
        variant="body1"
        sx={{
          py: 1,
          borderBottom: "1px solid rgba(18,18,21,0.30)",
          color: "#1d1b20",
        }}
        fontSize={14}
      >
       

       My WorkSpaces
      </Typography> */}

       <ProfileHeader title="My WorkSpaces" />

      <Box sx={{ display: "flex", gap: 4 }}>
         <Box>

       
       
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
          <AddWorkSpaceName  setSearch={setSearch} search={search}/>        
          <WorkSpaceTable search={search}/>
        </Box>
      </Box>
    </Paper>
  );
});

export default WorkBookSpace;
