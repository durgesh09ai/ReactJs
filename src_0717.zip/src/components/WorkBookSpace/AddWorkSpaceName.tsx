import React, { useState } from "react";
import { Box, Button, alpha, InputBase, styled } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { Link } from "react-router-dom";


interface Props {
 
  setSearch:(query:string)=>void;
  search:string;
}

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.95),
  boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
  width: "100%",
  maxWidth: "100%",
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "#98A2B2",
  width: "100%",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1),
    paddingLeft: theme.spacing(6),
    transition: theme.transitions.create("width"),
    fontSize: "0.75rem",
  },
}));

const AddWorkSpaceName: React.FC<Props> = ({ setSearch,search }) => {
  return (
   
      <Box sx={{ width: '100%', maxWidth: '100%' }}>    
      <Box sx={{ display: "flex", alignItems: "center", gap: 2, justifyContent:"space-between" }}>         
          <Search
            sx={{
                width: 220, 
                minWidth: 220,
                maxWidth: 500,
                display: "flex",
                alignItems: "center",
                border: "1px solid #D0D5DD",
                borderRadius: "8px",
                paddingLeft: 1,
                paddingRight: 1,
                backgroundColor: "#fff",
                flexShrink: 0, 
              }}
            >
            <SearchIconWrapper>
              <SearchIcon sx={{ color: "#98A2B2" }} />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Quick Search"
              inputProps={{ "aria-label": "search" }}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Box
              sx={{
                position: "absolute",
                right: 8,
                top: "50%",
                transform: "translateY(-50%)",
              }}
            >
             
            </Box>
          </Search>
              {/* <Button
          type="submit"
          variant="outlined"
          sx={{
            color: '#0F4977',
            borderColor: '#0F4977',
            textTransform: 'none',
            fontWeight: 'bold',
            height: '40px',
          }}
        >
          Add WorkSpace
        </Button> */}
        <Link to="/settings/add-workspace" style={{textDecoration:'none'}}>
        <Button         
          variant="outlined"
          sx={{
            color: '#0F4977',
            borderColor: '#0F4977',
            textTransform: 'none',
            fontWeight: 'bold',
            height: '40px',
            fontSize:'12px',
          }}
          
        >
          Add WorkSpace
        </Button>
        </Link>
        </Box>     
    </Box>
  );
};

export default AddWorkSpaceName;
