import { useEffect, useState } from 'react';
import {
  Box, Paper,
  Chip,
  Link,
  Stack
} from '@mui/material';
import { Pagination } from '../Pagination';

interface WorkSpaceRow {
  name: string;
  sourceTech: string[];
  targetTech: string[];
  createdOn: string;
  modifiedOn: string;
  href: string;
}

const dummyData: WorkSpaceRow[] = [
  {
    name: 'AI Automation Engine',
    sourceTech: ['Python', 'TensorFlow'],
    targetTech: ['ONNX', 'C++'],
    createdOn: '2024-12-01',
    modifiedOn: '2025-07-01',
    href: '/WorkSpace/ai-automation-engine',
  },
  {
    name: 'Cloud Migration Tool',
    sourceTech: ['Java', 'Spring Boot'],
    targetTech: ['AWS Lambda'],
    createdOn: '2025-01-15',
    modifiedOn: '2025-07-06',
    href: '/WorkSpace/cloud-migration-tool',
  },
  {
    name: 'Legacy to Microservices',
    sourceTech: ['.NET Framework'],
    targetTech: ['Docker', 'Kubernetes', 'Go'],
    createdOn: '2025-02-10',
    modifiedOn: '2025-06-20',
    href: '/WorkSpace/legacy-to-microservices',
  },
  {
    name: 'Data Sync Platform',
    sourceTech: ['Node.js'],
    targetTech: ['Kafka', 'PostgreSQL'],
    createdOn: '2025-03-18',
    modifiedOn: '2025-07-01',
    href: '/WorkSpace/data-sync-platform',
  },
  {
    name: 'DevOps Automation',
    sourceTech: ['Ansible', 'Python'],
    targetTech: ['Azure DevOps'],
    createdOn: '2025-04-05',
    modifiedOn: '2025-07-02',
    href: '/WorkSpace/devops-automation',
  },
  {
    name: 'ML Deployment Toolkit',
    sourceTech: ['Scikit-learn'],
    targetTech: ['SageMaker'],
    createdOn: '2025-04-22',
    modifiedOn: '2025-06-30',
    href: '/WorkSpace/ml-deployment-toolkit',
  },
];

interface Props{
    search:string;
}

const WorkSpaceTable = ({search}:Props) => {
//   const [search, setSearch] = useState('');
  const [filtered, setFiltered] = useState<WorkSpaceRow[]>([]);
  const [page, setPage] = useState(1);
  const rowsPerPage = 5;

  useEffect(() => {
    setFiltered(dummyData);
  }, []);

  useEffect(() => {
    const lowerSearch = search.toLowerCase();
    const filteredData = dummyData.filter(WorkSpace =>
      WorkSpace.name.toLowerCase().includes(lowerSearch)
    );
    setFiltered(filteredData);
    setPage(1); // reset to page 1 on new search
  }, [search]);

  const paginatedData = filtered.slice(
    (page - 1) * rowsPerPage,
    page * rowsPerPage
  );

  const handlePageChange = (value: number) => {
    setPage(value);
  };

  const columnStyle = {
    padding: '12px 16px',
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    minWidth: 100,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    
  };

  const columns = ['WorkSpace Name', 'Source Tech', 'Target Tech', 'Created On', 'Last Modified'];

  return (
    <Box>     

      <Paper elevation={2} sx={{ borderRadius: 1,mt:2 }}>
        {/* Header */}
        <Box sx={{ display: 'flex', backgroundColor: '#0F4977', color: 'white' }} fontSize={12}>
          {columns.map((col) => (
            <Box key={col} sx={{ ...columnStyle, fontWeight: 600, backgroundColor: '#0F4977' }}>
              {col}
            </Box>
          ))}
        </Box>

        {/* Rows */}
        {paginatedData.map((WorkSpace, index) => (
          <Box
            key={index}
            sx={{
              display: 'flex',
              backgroundColor: index % 2 === 0 ? '#fafafa' : 'white',
              borderBottom: '1px solid #eee',
            }}
          >
            <Box sx={columnStyle} fontSize={12}>
              <Link href="/settings/workspace-detail" underline="hover" sx={{ color: '#1976d2', fontWeight: 500 }}>
                {WorkSpace.name}
              </Link>
            </Box>

            <Box sx={{ ...columnStyle, flexWrap: 'wrap' }} fontSize={12}>
              {WorkSpace.sourceTech.join(', ')}
            </Box>

            <Box sx={{ ...columnStyle, flexWrap: 'wrap', gap: '4px' }}>
              <Stack direction="row" spacing={1} flexWrap="wrap">
                {WorkSpace.targetTech.slice(0, 2).map((tech, i) => (
                  <Chip
                    key={i}
                    label={tech}
                    sx={{
                      backgroundColor: '#E3F2FD',
                      fontSize: '12px',
                      height: 24,
                      borderRadius: '15px',
                    }}
                  />
                ))}
              </Stack>
            </Box>

            <Box sx={columnStyle} fontSize={12}>{WorkSpace.createdOn}</Box>
            <Box sx={columnStyle} fontSize={12}>{WorkSpace.modifiedOn}</Box>
          </Box>
        ))}
      </Paper>     

         <Box mt={2}>
                  {Math.ceil(filtered.length / rowsPerPage) > 0 && (
                    <Pagination
                      currentPage={page}
                      totalPages={Math.ceil(filtered.length / rowsPerPage)}
                      onPageChange={handlePageChange}
                    />
                  )}
                </Box>
    </Box>
  );
};

export default WorkSpaceTable;
