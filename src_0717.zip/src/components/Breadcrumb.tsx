import React from "react";
import { Breadcrumbs, Typography, Link as MuiLink, Stack, Divider } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <Stack sx={{ bgcolor: "#FFF", py: 1 }}>
      <Breadcrumbs 
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
      >
        {items.map((item, index) => (
          item.href ? (
            <MuiLink
              key={index}
              underline="hover"
              color="text.secondary"
              href={item.href}
              sx={{fontSize:14}}
            >
              {item.label}
            </MuiLink>
          ) : (
            <Typography key={index} color="text.primary" sx={{fontSize:14}}>
              {item.label}
            </Typography>     


          )
          
        ))}
      </Breadcrumbs>
      
    </Stack>
  );
};
