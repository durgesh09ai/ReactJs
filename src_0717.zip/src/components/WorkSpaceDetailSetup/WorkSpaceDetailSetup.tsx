import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import { Box, Paper, Typography } from "@mui/material";
import { mainPageStore } from "../../stores/MainPageStore";
import WorkSpaceSetupCard from "./WorkSpaceSetupCard";

const WorkSpaceDetailSetup: React.FC = observer(() => {
  
  const {
    fetchTargetSetUp,
    targetList,
    loading
   }  = mainPageStore;


  useEffect(() => {
    fetchTargetSetUp();
  }, []);



  return (
    <Paper sx={{ width: "100%", p: 2, borderRadius: 1 }}>
      <Typography
        variant="body1"
        sx={{
          py: 1,
          borderBottom: "1px solid rgba(18,18,21,0.30)",
          color: "#1d1b20",
        }}
      >
        WorkSpace Setup
      </Typography>

      <Box sx={{ display: "flex", gap: 4, mt: 2 }}>
        <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
          {/* <AddTargetName onAddTargetName={handleAddTargetSetup} /> */}
          {loading && ( 
            <Box textAlign={"center"}><img src="../contentloader.gif" width={100} height={100} alt="contentloader"/></Box>
          )}
          
          {/* {localNewTargetSetup && localNewTargetSetup.map((ws, index) => (
            <AddTargetCard
              key={`new-${index}`}
              {...ws}
              onSubmit={(updatedSR) => submitTarget(updatedSR, index)}
            />
          ))} */}
          
          {targetList && targetList.map((ws, index) => (
            <WorkSpaceSetupCard key={`ws-${index}`} {...ws} />
          ))}
        </Box>
      </Box>
    </Paper>
  );
});

export default WorkSpaceDetailSetup;
