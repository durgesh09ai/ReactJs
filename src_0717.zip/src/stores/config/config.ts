// export const API_BASE_URL = process.env.BACKEND_API_URL || "http://localhost:8000";

export const API_BASE_URL = process.env.BACKEND_API_URL || "https://intelliwise-bck-crgeegdcdsdwf0f2.canadacentral-01.azurewebsites.net";

