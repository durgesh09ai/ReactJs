import { makeAutoObservable, runInAction, toJS } from "mobx";
import { API_BASE_URL } from "./config/config";

export class SolutionFormStore {
  apiUrl: string = API_BASE_URL;
  formData: Record<string, any> = {};
  error: any;

  constructor() {
    makeAutoObservable(this);
  }

  // Merge any new form data into the global formData object
  updateFormData(data: Record<string, any>) {
    this.formData = { ...this.formData, ...data };
  }

  // Get the entire form data
  getFormData() {
    return this.formData;
  }

  // Submit form data
  // async submit() {
  //   console.log("Submitting", toJS(this.formData));
  //   // Example API call:
  //   // await axios.post(`${API_BASE_URL}/submit`, this.formData);
  // }

  submit = async () => {

  console.log("Submitting", toJS(this.formData));

    try {
      const data = {
        name: this.formData.solutionName,
        description: this.formData.description,
        imu: this.formData.imuTags,
        sgu: this.formData.sguTags,
        documents_url: this.formData.docsUrl,
        client: this.formData.clients,
        technology: this.formData.smartTags,
        teamids: this.formData.teamMembers,
        solution_type: this.formData.solutiontype,
        images: this.formData.images,
        year: this.formData.yearofimplementation,
        work_type: this.formData.workType,
        scope_complexity: this.formData.scopeComplexity,
        value_prop: this.formData.valueProposition,
        ai_ml_penet: this.formData.AIMLPenetration,
        degree_client_advoc: this.formData.degreeofClient,
        outcome: this.formData.outcome,
        problem: this.formData.problem,
        solution: this.formData.solution,
        exl_diff: this.formData.exlDifferentiator,
        license_model: this.formData.licensingModel,
        framework_type: this.formData.frameworkType,
        accelerator_type: this.formData.acceleratorType,
        accelerator_benefits: this.formData.timeSaved,
        accelerator_usecase: this.formData.useCase,
        opportunity: this.formData.opportunity,
        story_editor: this.formData.storyline,
        solution_involved: this.formData.solutionsInvolved,
        date_submission: this.formData.storyYear,
        submission_type: this.formData.subType,
        dealSize: this.formData.dealSize,
        win_themes: this.formData.winTag,

      };
     const res = await fetch(`${this.apiUrl}/user/create_soln`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add Solution");
      }
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };

 


  // Reset the entire form
  reset() {
    this.formData = {};
  }
}

export const solutionFormStore = new SolutionFormStore();



