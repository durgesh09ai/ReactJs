import React from "react";
import {
  Box,
  List,
  ListItem,
  ListItemText,
  Avatar,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import { Link } from "react-router-dom";
import { observer } from "mobx-react-lite";

const DefaultSidebar = () => {
  const navLinks = [{ label: "Home", to: "/" },{ label: "Page1", to: "/" },{ label: "Page2", to: "/" }];

  const thinScrollbarStyles = {
    "&::-webkit-scrollbar": { width: "6px" },
    "&::-webkit-scrollbar-track": { backgroundColor: "#f1f1f1" },
    "&::-webkit-scrollbar-thumb": { backgroundColor: "#c1c1c1", borderRadius: "3px" },
    scrollbarWidth: "thin",
    scrollbarColor: "#c1c1c1 #f1f1f1",
  };


  return (
    <Box
      display="flex"
      flexDirection="column"
      height="100vh"
      px={2}
      py={1}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      bgcolor="#fff"
      maxWidth="300px"
      width="100%"
      boxShadow="1px 0 2px rgba(0,0,0,0.1)"
    >
      {/* Header */}
      <Box display="flex" alignItems="center" justifyContent="space-between" height={55} borderBottom="1px solid rgba(0,0,0,0.1)">
        <Box sx={{ marginLeft: "15px" }}>
          <img width={70} src="/EXL_Service_logo.png"  alt="Logo"/>
        </Box>
        <Avatar src="/minimize.svg" sx={{ width: 24, height: 24 }} variant="square" />
      </Box>

      {/* Scrollable Section */}
      <Box sx={{ flexGrow: 1, overflow: "auto", mt: 2, pr: 1, ...thinScrollbarStyles }}>
        <List disablePadding>
          {navLinks.map(({ label, to }, i) => (
            <ListItem
              key={i}
              component={Link}
              to={to}
              disablePadding
              sx={{
                textDecoration: "none",
                color: "inherit",
                px: 1,
                py: 1,
                "&:hover": { backgroundColor: "#f5f5f5" },
              }}
            >
              <ListItemText primary={label} primaryTypographyProps={{ fontSize: "14px" }} />
            </ListItem>
          ))}
        </List>

   
      </Box>

      {/* Fixed Bottom Settings Link */}
      <Box px={1} py={2}>
        <ListItem
          component={Link}
          to="#"
          sx={{
            textDecoration: "none",
            color: "inherit",
            px: 1,
            py: 1,
            borderRadius: 1,
            "&:hover": { backgroundColor: "#f5f5f5" },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 }} />
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
        </ListItem>
      </Box>
   
    </Box>
  );
};

export default observer(DefaultSidebar);