import React from "react";
import {
  AppBar,
  Toolbar,
  Box,
  IconButton,
  Avatar,
} from "@mui/material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import ChatIcon from "@mui/icons-material/Chat";

const DefaultHeader = () => {
  return (
    <AppBar
      position="static"
      color="transparent"
      elevation={0}
      sx={{ borderBottom: 1, borderColor: "rgba(0, 0, 0, 0.12)" }}
    >
      <Toolbar sx={{ justifyContent: "space-between", py: 0.5 }}>
        {/* Left side */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
       </Box>

        {/* Right side */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <IconButton size="medium" aria-label="Notifications">
            <NotificationsIcon />
          </IconButton>
          <IconButton size="medium" aria-label="Messages">
            <ChatIcon />
          </IconButton>
          <IconButton size="medium" aria-label="Profile">
            <Avatar
              alt="Profile"
              sx={{ width: 32, height: 32 }}
            />
          </IconButton>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default DefaultHeader;
