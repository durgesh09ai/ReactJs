import React from "react";
import {
  ListItemIcon,
  ListItemText,
  Box, 
  ListItemButton,
  Typography,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";


interface SubItem {
  label: string;
  count?: number;
  href?: string;
}

interface NavItemProps {
  icon: string;
  label: string;
  collapsed?: boolean;
  subItems?: SubItem[];
  showCount?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({
  icon,
  label,
  collapsed,
  subItems = [],
  showCount = false,
}) => {
  const [open, setOpen] = React.useState(false);


  return (
    <Box>
      <ListItemButton onClick={() => setOpen(!open)}>
        <ListItemIcon sx={{ minWidth: 32, mr: 1 }}>
          <img src={icon} alt={label} width={20} height={20} />
        </ListItemIcon>
        {!collapsed && (
          <>
            <ListItemText
              primary={
                <Typography sx={{ fontSize: "14px" }}>
                  {label}
                </Typography>
              }
            />
            {subItems.length > 0 &&
              (open ? (
                <KeyboardArrowUpIcon fontSize="small" />
              ) : (
                <KeyboardArrowDownIcon fontSize="small" />
              ))}
          </>
        )}
      </ListItemButton>
    </Box>
  );
};

export default NavItem;