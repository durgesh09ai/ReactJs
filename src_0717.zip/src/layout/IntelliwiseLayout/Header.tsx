import React from "react";
import {
  AppBar,
  Toolbar,
  InputBase,
  Box,
  IconButton,

  alpha,
  styled,

} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import FilterListIcon from "@mui/icons-material/FilterList";



const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.95),
  boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
  width: "100%",
  maxWidth: "100%",
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "#98A2B2",
  width: "100%",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1),
    paddingLeft: theme.spacing(6),
    transition: theme.transitions.create("width"),
    fontSize: "0.75rem",
  },
}));


const Header = () => {
 



  return (
    <AppBar
      position="static"
      color="transparent"
      elevation={0}
      sx={{ borderBottom: 1, borderColor: "rgba(0, 0, 0, 0.12)", height: 48 }}
    >
      <Toolbar
        variant="dense"
        sx={{ justifyContent: "space-between", py: 0.5, minHeight: 48 }}
      >
        {/* Left section: Logo + Search */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <img src="/EXL_Service_logo.png" alt="Logo" style={{ height: 28 }} />
          <Search
            sx={{
                width: 220, 
                minWidth: 220,
                maxWidth: 500,
                display: "flex",
                alignItems: "center",
                border: "1px solid #D0D5DD",
                borderRadius: "8px",
                paddingLeft: 1,
                paddingRight: 1,
                backgroundColor: "#fff",
                flexShrink: 0, 
              }}
            >
            <SearchIconWrapper>
              <SearchIcon sx={{ color: "#98A2B2" }} />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search Solutions"
              inputProps={{ "aria-label": "search" }}
            />
            <Box
              sx={{
                position: "absolute",
                right: 8,
                top: "50%",
                transform: "translateY(-50%)",
              }}
            >
              <IconButton size="small">
                <FilterListIcon sx={{ fontSize: 20, color: "#98A2B2" }} />
              </IconButton>
            </Box>
          </Search>
        </Box>

      
        {/* Right section: Buttons */}
        <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;