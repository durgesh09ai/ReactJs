import React from "react";
import BaseLayout from "../DefaultLayout/BaseLayout";
import Sidebar from "./Sidebar";
import Header from "./Header";

const Layout = () => {
  return<BaseLayout header={<Header/>} sidebar={<Sidebar/>}/>;
};

export default Layout;
