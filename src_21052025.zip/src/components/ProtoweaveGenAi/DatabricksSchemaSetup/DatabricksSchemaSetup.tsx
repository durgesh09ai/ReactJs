import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Button, Paper, Typography, Link, CircularProgress } from "@mui/material";
import SetupHeader from "./SetupHeader";
import SetupFormField from "./SetupFormField";
import { databricksStore } from "../../../stores/cip/ProtoweaveGenAiStore/DatabricksStore";

const DatabricksSchemaSetup: React.FC = () => {
  const { databricksData, fetchDatabricksData, updateDatabricksData, loading } = databricksStore;
  const [editedData, setEditedData] = useState(databricksData);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    fetchDatabricksData();
  }, []);

  useEffect(() => {
    setEditedData(databricksData?.[0]); 
  }, [databricksData]);

  const handleEditClick = () => setIsEditing(true);
  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleUpdate = async () => {
    await updateDatabricksData(editedData);
    setEditedData(editedData);
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditedData(prev => ({ ...prev, [name]: value }));
  };


  return (
    <Paper elevation={1} sx={{ maxWidth: "820px", pb: 2, px: 1, borderRadius: 2 }}>
      <SetupHeader title="Databricks Schema Setup" />

      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mt: 1, mb: 2, px: 1, width: 450 }}>
        <Typography variant="h6" sx={{ fontSize: 14, fontWeight: "bold" }}>
          Databricks Schema Setup
        </Typography>
        { loading && (<CircularProgress /> )}

        {!isEditing && (
          <Link component="button" onClick={handleEditClick} underline="hover" sx={{ fontSize: 14, fontWeight: "bold" }}>
            Edit
          </Link>
        )}
      </Box>

      <Box sx={{ display: "flex", width: "100%", gap: 4, flexWrap: "wrap", alignItems: "stretch", px: 1 }}>
        <Box sx={{ display: "flex", flexDirection: "column", minWidth: 300, width: "400px" }}>
          <SetupFormField
            label="Service Credentials (API Key)"
            value={editedData?.api_key}
            name="api_key"
            onChange={handleChange}
            readOnly={!isEditing}
            type="password"
          />
          <SetupFormField
            label="Databricks URL"
            value={editedData?.databricks_url}
            name="databricks_url"
            onChange={handleChange}
            readOnly={!isEditing}
          />
          <SetupFormField
            label="Catalog Name"
            value={editedData?.catalog_name}
            name="catalog_name"
            onChange={handleChange}
            readOnly={!isEditing}
          />
          <SetupFormField
            label="Schema Name"
            value={editedData?.schema_name}
            name="schema_name"
            onChange={handleChange}
            readOnly={!isEditing}
          />

          {isEditing && (
            <Box sx={{ display: "flex", gap: 2, mt: 2 }}>
              <Button variant="contained" onClick={handleUpdate}>Update</Button>
              <Button variant="outlined" onClick={handleCancel}>Cancel</Button>
            </Box>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default observer(DatabricksSchemaSetup);