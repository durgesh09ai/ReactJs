import React, { useState } from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography,
  Box,
} from "@mui/material";
import FileDownloadIcon from "@mui/icons-material/FileDownload";

interface ExportButtonWithDialogProps {
  onExport: (format: string) => void;
}

const ExportButtonWithDialog: React.FC<ExportButtonWithDialogProps> = ({ onExport }) => {
  const [open, setOpen] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState("word");

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleExport = () => {
    onExport(selectedFormat);
    handleClose();
  };

  return (
    <>
      <Button
        size="small"
        variant="outlined"
        startIcon={<FileDownloadIcon fontSize="small" />}
        onClick={handleOpen}
        sx={{
          textTransform: "none",
          fontSize: "12px",
          fontWeight: "bold",
          py: 0.5,
          px: 1.5,
          borderRadius: 1,
        }}
      >
        Export
      </Button>

      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="xs"
        fullWidth
        sx={{
          "& .MuiDialog-paper": {
            width: "600px",
            padding: 1,
            borderRadius: 2,
          },
        }}
      >
        <DialogTitle sx={{ p: 1, pb: 0 }}>
          <Typography fontSize={13} fontWeight="bold" textAlign="center">
            Download Export File
          </Typography>
          <Typography
            fontSize={12}
            fontWeight={400}
            color="text.secondary"
            textAlign="center"
            mt={0.5}
          >
            Please choose the format you'd like to export
          </Typography>
        </DialogTitle>

            <DialogContent>
            <FormControl>
            <RadioGroup
            value={selectedFormat}
            onChange={(e) => setSelectedFormat(e.target.value)}
            sx={{
            gap: 0, // no gap between items
            }}
            >
            {[ "word","json", "excel"].map((value) => (
            <FormControlLabel
            key={value}
            value={value}
            control={<Radio size="small" />}
            label={
            <Typography fontSize={12} fontWeight={400}>
            {value.toUpperCase()}
            </Typography>
            }
            sx={{ my: 0, py: 0 }} // tighter vertical spacing
            />
            ))}
            </RadioGroup>
            </FormControl>
            </DialogContent>

        <DialogActions>
          <Button variant="outlined" onClick={handleClose} sx={{ fontSize: 12, minWidth: 70 }}>
            Cancel
          </Button>
          <Button variant="contained" onClick={handleExport} sx={{ fontSize: 12, minWidth: 70 }}>
            Export
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ExportButtonWithDialog;
