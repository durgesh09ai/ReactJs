import { makeAutoObservable, runInAction } from "mobx";

export class DatabricksStore {
  databricksData = {
    id:"",
    userId:"",
    api_key: "",
    databricks_url: "",
    catalog_name: "",
    schema_name: "",
  };

  loading:boolean = false;
  error: string | null = null;
  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8002";

  constructor() {
    makeAutoObservable(this);
  }

    fetchDatabricksData = async () => {
    this.loading = true;
    try {
      const res = await fetch(`${this.apiUrl}/databricksDB/databricks`);
      const data = await res.json();
      runInAction(() => {
        this.databricksData = data;
        this.loading = false;
      });
    } catch (err: any) {
      runInAction(() => {
        this.error = err.message || "Failed to fetch data";
        this.loading = false;
      });
    }
  }

  updateDatabricksData = async (updatedData: typeof this.databricksData) => {
    try {
      const res = await fetch(`${this.apiUrl}/databricksDB/databricks_update`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      });
  
      if (!res.ok) throw new Error("Failed to update workspace");
      runInAction(() => {
        this.databricksData = updatedData;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


}

export const databricksStore = new DatabricksStore();
