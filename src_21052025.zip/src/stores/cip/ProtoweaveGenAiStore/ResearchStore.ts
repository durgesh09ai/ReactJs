import { makeAutoObservable, runInAction } from "mobx";

class ResearchStore {
  sessionId: string | null = null;
  messages: any[] = [];
  thinkingData: any[] = [];
  isResearching: boolean = false;
  report: { markdown: string; docx: string } | null = null;
  ws: WebSocket | null = null;
  currentEditableIndex: number | null = null;
  versionList: string[] = [];
  error: string | null = null;
  loading:boolean = false;
  versionOptions: { key: string; value: string }[] = [];

  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8002";


setMessages(newMessages: any[]) {
  this.messages = newMessages;
}

addMessage(newMessage: any) {
  this.messages.push(newMessage);
}


  constructor() {
    makeAutoObservable(this);
  }

  connectWebSocket() {
    if (!this.sessionId || !this.isResearching) return;

    this.ws = new WebSocket(`${this.apiUrl.replace("http", "ws")}/ws/research/${this.sessionId}`);

    this.ws.onopen = () => {
      console.log("WebSocket connected");
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log("WebSocket data");

      runInAction(() => {
        this.thinkingData.push(data);
        console.log("WebSocket data==>",this.thinkingData);

      });

      if (data.step === "completed") {
        this.fetchReport();
      }
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    this.ws.onclose = () => {
      console.log("WebSocket disconnected");
      this.ws = null;

    };
  }

  cleanup() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  async fetchReport() {
    try {
      const response = await fetch(`${this.apiUrl}/research/report/${this.sessionId}`);
      const data = await response.json();
      runInAction(() => {
        this.report = { markdown: data.report, docx: data.docx };
        this.isResearching = false;
      });
    } catch (error) {
      console.error("Error fetching report:", error);
    }
  }

  // Add inside the ResearchStore class

async handleSendTopic(topic: string) {
    try {
      const response = await fetch(`${this.apiUrl}/research/plan`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        this.sessionId = data.plan_id;
        this.messages = [
          { role: "user", content: topic },
          {
            role: "assistant",
            content: "I need some clarification to better understand your research needs:",
            questions: data.questions,
          },
        ];
        this.currentEditableIndex = 1;
      });
    } catch (error) {
      console.error("Error creating research plan:", error);
    }
  }
  
  async handleSubmitAnswers(answers: Record<string, string>, approved: boolean) {
    try {
      const response = await fetch(`${this.apiUrl}/research/plan/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan_id: this.sessionId,
          answers,
          approved,
          feedback: approved ? null : "Please revise the plan based on my answers.",
        }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        if (approved) {
          this.isResearching = true;
          this.messages.push(
            { role: "user", content: "I approve this research plan." },
            {
              role: "assistant",
              content:
                "Thank you! I'll start the research process now. You can see my progress on the right panel.",
            },
          );
          this.currentEditableIndex = null;
          this.connectWebSocket();
        } else {
          this.messages.push(
            { role: "user", content: "I need some adjustments to the plan." },
            {
              role: "assistant",
              content: "I've revised the plan. Please provide more information:",
              questions: data.questions,
            },
          );
          this.currentEditableIndex = this.messages.length - 1;
        }
      });
    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
  }


  handleDownloadReport = () => {
    if (this.report?.docx) {
      // Convert base64 docx to blob
      const binaryContent = atob(this.report.docx);
      const byteArray = new Uint8Array(binaryContent.length);
      for (let i = 0; i < binaryContent.length; i++) {
        byteArray[i] = binaryContent.charCodeAt(i);
      }
      const blob = new Blob([byteArray], {
        type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "research_report.docx";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      console.error("DOCX version not available!");
    }
  };

  fetchChatVersionList = async (researchId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_chats/research_chat_versions/${researchId}`);
      if (!res.ok) throw new Error("Failed to fetch versions");
      const data = await res.json();
  
      if (Array.isArray(data) && data.length > 0 && typeof data[0] === "object") {
        const parsed = Object.entries(data[0]).map(([key, value]) => ({
          key,
          value:String(value),
        }));
  
        runInAction(() => {
          this.versionOptions = parsed;
        });
      }
    } catch (error) {
      console.error("Error fetching version options:", error);
    }
  }


  insertChatHistory = async (research_id: string, version: string, messageArray: any[]) => {
    try {
      const response = await fetch(`${this.apiUrl}/research_chats/create_chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          research_id,
          version,
          chat_history: messageArray,
        }),
      });
  
      if (!response.ok) throw new Error("Failed to insert messages");
      const data = await response.json();
      console.log("Inserted messages:", data);
    } catch (error) {
      console.error("Error inserting messages:", error);
    }
  }

   updateChatHistoryFinalReport = async (chat_id:string,research_id: string, report:{}) => {
    try {
      const res = await fetch(`${this.apiUrl}/research_chats/update_freport/${chat_id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({research_id,report}),
      });
    if (!res.ok) throw new Error("Failed to update Final report");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };
 
}
export const researchStore = new ResearchStore();
