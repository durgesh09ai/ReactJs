import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import { Container } from "@mui/material";
import { ProjectsSection } from "../components/Dashboard/ProjectsSection";
import { BannerVideosSection } from "../components/Dashboard/BannerVideosSection";
import { mainPageStore } from "../stores/MainPageStore";
import { toJS } from "mobx";

const Dashboard: React.FC = observer(() => {
  useEffect(() => {
    mainPageStore.loadProjectsData();
  }, []);

  const filterBySGU = (arr: any[]) => {
    if (mainPageStore.selectedSGUs.size === 0) {
      return arr;
    }
    return arr.filter((p) => mainPageStore.selectedSGUs.has(p.SGU));
  };

  if (mainPageStore.projectsLoading) return <div>Loading projects...</div>;
  if (mainPageStore.projectsError) return <div>Error: {mainPageStore.projectsError}</div>;

  const filteredTop10 = filterBySGU(mainPageStore.projectsByCategory.Top10Products);
  const filteredNew = filterBySGU(mainPageStore.projectsByCategory.Top10NewProducts);
  const filteredMostUsed = filterBySGU(mainPageStore.projectsByCategory.Top10MostUsedProducts);

console.log('filteredNew',toJS(filteredNew));


  return (
    <Container>
      <BannerVideosSection />

      <ProjectsSection SectionName="Top 10 #Products" projectList={filteredTop10} />
      <ProjectsSection SectionName="Top 10 #New Products" projectList={filteredNew} />
      <ProjectsSection SectionName="Top 10 #MostUsed Products" projectList={filteredMostUsed} />
    </Container>
  );
});

export default Dashboard;
