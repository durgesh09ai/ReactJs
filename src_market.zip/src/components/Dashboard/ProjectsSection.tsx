import React from "react";
import { observer } from "mobx-react-lite";
import { Box, Typography, Stack } from "@mui/material";
import { ProjectCard } from "./ProjectCard";

type Project = {
  id: number;
  title: string;
  description: string;
  tags: string[];
  imageSrc: string;
  commentCount: number;
  contributorCount: string;
  badgeIconSrc: string;
  likeIconSrc: string;
  starIconSrc: string;
};

interface ProjectsSectionProps {
  SectionName: string;
  projectList: Project[];
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = observer(
  ({ SectionName, projectList }) => (
    <Box width="100%" mt={4}>
      {/* ----- header ----- */}
      <Stack direction="row" spacing={1} alignItems="center">
        <Typography
          variant="subtitle2"
          fontWeight={600}
          fontSize={14}
          color="#1F2633"
        >
          {SectionName}
        </Typography>

        <Box
          sx={{
            backgroundColor: "#E9F3F9",
            color: "#0F4977",
            fontSize: 10,
            fontWeight: 800,
            borderRadius: "8px",
            width: 25,
            height: 25,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {projectList.length}
        </Box>
      </Stack>

      {/* ----- cards grid ----- */}
      <Box
        display="flex"
        flexWrap="wrap"
        gap={2}
        mt={2}
        justifyContent={{ xs: "center", sm: "flex-start" }}
      >
        {projectList.map((project) => (
          <Box
            key={project.id}
            sx={{
              width: {
                xs: "100%", // 1 per row on xs
                sm: "48%",  // 2 per row on sm
                md: "31.5%",// 3 per row on md
                lg: "23.5%" // 4 per row on lg
              },
              flexGrow: 0,
              flexShrink: 0,
            }}
          >
            <ProjectCard {...project} />
          </Box>
        ))}
      </Box>
    </Box>
  )
);
