import React from 'react';
import { Box } from '@mui/material';

export const BannerVideosSection: React.FC = () => {
  return (
    <Box
      width="100%"
      display="flex"
      justifyContent="center"
      alignItems="center"
      mb={4}
    >
      <Box
        component="img"
        src="./vidos_frame.png"
        alt="Banner"
        sx={{
          maxWidth: '100%',
          height: 'auto',
          borderRadius: '8px', 
          boxShadow: 2 
        }}
      />
    </Box>
  );
};
