import React from "react";
import {
  Box,
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  Checkbox,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

export interface SubItem {
  label: string;
  count?: number;
  href?: string;
  /** ✅ NEW FOR CHECKBOX MODE */
  checked?: boolean;
  onToggle?: () => void;
}

export interface NavItemProps {
  icon: string;
  label: string;
  collapsed?: boolean;
  subItems?: SubItem[];
  showCount?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({
  icon,
  label,
  collapsed,
  subItems = [],
}) => {
  const [open, setOpen] = React.useState(false);

  return (
    <Box>
      {/* top-level item */}
      <ListItemButton onClick={() => setOpen(!open)}>
        <ListItemIcon sx={{ minWidth: 32, mr: 1 }}>
          <img src={icon} alt={label} width={20} height={20} />
        </ListItemIcon>
        {!collapsed && (
          <>
            <ListItemText
              primary={<Typography sx={{ fontSize: 14 }}>{label}</Typography>}
            />
            {subItems.length > 0 &&
              (open ? (
                <KeyboardArrowUpIcon fontSize="small" />
              ) : (
                <KeyboardArrowDownIcon fontSize="small" />
              ))}
          </>
        )}
      </ListItemButton>

      {/* sub-items */}
      {!collapsed && subItems.length > 0 && (
        <Collapse in={open} unmountOnExit>
          <List disablePadding>
            {subItems.map((item) => (
              <ListItemButton
                key={item.label}
                sx={{ pl: 4 }}
                component={item.href ? "a" : "button"}
                href={item.href}
                onClick={(
                  e: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>
                ) => {
                  if (item.onToggle) e.preventDefault();
                }}
              >
                {/* checkbox if this sub-item has the new fields */}
                {item.onToggle ? (
                  <Checkbox
                    size="small"
                    checked={item.checked}
                    onClick={(e) => e.stopPropagation()}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                      item.onToggle?.();
                    }}
                    sx={{ mr: 1 }}
                  />
                ) : null}

                <ListItemText
                  primary={<Typography sx={{ fontSize: 14 }}>{item.label}</Typography>}
                />

                {item.count !== undefined && (
                  <Typography
                    sx={{
                      ml: 1,
                      px: 1,
                      fontSize: 12,
                      fontWeight: 800,
                      bgcolor: "rgba(243,250,255,1)",
                      color: "#0F4977",
                      borderRadius: "4px",
                    }}
                  >
                    {item.count}
                  </Typography>
                )}
              </ListItemButton>
            ))}
          </List>
        </Collapse>
      )}
    </Box>
  );
};

export default NavItem;
