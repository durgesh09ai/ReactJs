// src/stores/cip/DatagenAiSyntheticStore.ts
import { makeAutoObservable, runInAction } from "mobx";

type ProjectItem = {
  id: number;
  title: string;
  description: string;
  tags: string[];
  imageSrc: string;
  SGU: string;
  badgeIconSrc: string;
  likeIconSrc: string;
  starIconSrc: string;
};

type ProjectCategoryMap = {
  Top10Products: ProjectItem[];
  Top10NewProducts: ProjectItem[];
  Top10MostUsedProducts: ProjectItem[];
};

export class MainPageStore {
  data: any = null;
  loading: boolean = false;
  error: string | null = null;

  selectedSGUs: Set<string> = new Set();

  // New state for projects data
  projectsByCategory: ProjectCategoryMap = {
    Top10Products: [],
    Top10NewProducts: [],
    Top10MostUsedProducts: [],
  };
  projectsLoading: boolean = false;
  projectsError: string | null = null;

  constructor() {
    makeAutoObservable(this);
  }

  toggleSGU = (sgu: string) => {
    if (this.selectedSGUs.has(sgu)) {
      this.selectedSGUs.delete(sgu);
    } else {
      this.selectedSGUs.add(sgu);
    }
    this.selectedSGUs = new Set(this.selectedSGUs);
  };

  // New method to load projects from JSON
  loadProjectsData = async () => {
    this.projectsLoading = true;
    this.projectsError = null;

    try {
      const response = await fetch("/projectsData.json");
      if (!response.ok) throw new Error(`Failed to load projects: ${response.statusText}`);
      const data: ProjectCategoryMap = await response.json();

      runInAction(() => {
        this.projectsByCategory = data;
        this.projectsLoading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.projectsError = e.message || "Unknown error";
        this.projectsLoading = false;
      });
    }
  };
}

export const mainPageStore = new MainPageStore();
