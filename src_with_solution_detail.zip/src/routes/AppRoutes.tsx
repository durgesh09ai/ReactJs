import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "../layout/Layout";
import DashBoard from "../pages/Dashboard";
import DashboardDetail from "../pages/DashboardDetail";
import SolutionCatalogue from "../pages/SolutionCatalogue";
import SolutionCatalogueDetail from "../pages/SolutionCatalogueDetail";

export const AppRoutes = () => (
   <Routes>
     <Route element={<Layout />}>
       <Route path="/" element={<DashBoard />} />
       <Route path="/dashboarddetail" element={<DashboardDetail />} />
       <Route path="/solutioncatalogue" element={<SolutionCatalogue />} />
       <Route path="/solutioncataloguedetail" element={<SolutionCatalogueDetail />} />
    </Route>
   </Routes>
);
