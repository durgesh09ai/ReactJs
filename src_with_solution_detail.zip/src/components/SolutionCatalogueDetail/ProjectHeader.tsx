import React from "react";
import { Box, Button, Typography } from "@mui/material";

interface ProjectHeaderProps {
  title: string;
}

export const ProjectHeader: React.FC<ProjectHeaderProps> = ({ title }) => {
  return (
    <Box
      sx={{
        backgroundColor: "white",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: { xs: "wrap", md: "nowrap" },
        padding: 2,
        borderRadius: "8px 8px 0 0",
        gap: 2,
      }}
    >
      <Typography
        variant="subtitle1"
        sx={{
          color: "#1F2633",
          fontWeight: 500,
          fontSize: { xs: "0.95rem", md: "1rem" },
          lineHeight: 1.5,
          flexGrow: 1,
          minWidth: 200,
        }}
      >
        {title}
      </Typography>

      <Box
        sx={{
          display: "flex",
          gap: 1.5,
          alignItems: "center",
          minWidth: 180,
          textAlign: "center",
        }}
      >
        <Button
          variant="outlined"
          size="small"
          sx={{
            fontSize: "0.75rem",
            borderColor: "rgba(15, 73, 119, 1)",
            borderRadius: "3px",
            padding: "4px 12px",
            color: "rgba(15, 73, 119, 1)",
            whiteSpace: "nowrap",
            "&:hover": {
              backgroundColor: "rgba(15, 73, 119, 0.05)",
            },
          }}
        >
          Live Preview
        </Button>
        <Button
          variant="outlined"
          size="small"
          sx={{
            fontSize: "0.75rem",
            borderColor: "rgba(15, 73, 119, 1)",
            borderRadius: "3px",
            padding: "4px 12px",
            color: "rgba(15, 73, 119, 1)",
            whiteSpace: "nowrap",
            "&:hover": {
              backgroundColor: "rgba(15, 73, 119, 0.05)",
            },
          }}
        >
          Watch Demo
        </Button>
      </Box>
    </Box>
  );
};
