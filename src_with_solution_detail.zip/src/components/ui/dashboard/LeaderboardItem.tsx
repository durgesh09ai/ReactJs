import React from "react";
import { Box, Typography, Avatar } from "@mui/material";

interface LeaderboardItemProps {
  image: string;
  rank: number;
  name: string;
}

const LeaderboardItem: React.FC<LeaderboardItemProps> = ({ image, rank, name }) => {
  return (
    <Box
      sx={{
        display: "flex",
        backgroundColor: "white",
        border: "1px solid rgba(253,244,238,1)",
        borderRadius: "16px 10px 10px 16px",
        minHeight: 103,
        width: "100%",
        mt: 2,
        overflow: "hidden",
      }}
    >
      {/* Left image section */}
      <Box
        component="img"
        src={image}
        alt={`Contributor ${rank}`}
        sx={{
          width: 170,
          objectFit: "contain",
          borderRadius: "0px",
        }}
      />

      {/* Right content section */}
      <Box sx={{ width: 179, display: "flex", flexDirection: "column" }}>
        {/* Top bar */}
        <Box
          sx={{
            backgroundColor: "rgba(15,73,119,1)",
            minHeight: 34,
            borderTopRightRadius: 9,
            px: 1.5,
            pl: "13px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Typography
            variant="body2"
            color="white"
            fontSize="0.875rem"
            fontWeight={600}
          >
            No.{rank} Contributor
          </Typography>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 22,
              height: 22,
              borderRadius: "4px",
              position: "relative",
              px: 1,
            }}
          >
            <Box
              sx={{
                backgroundColor: "white",
                width: 9,
                height: 9,
                fontSize: "0.625rem",
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10,
              }}
            >
              {rank}
            </Box>
          </Box>
        </Box>

        {/* Name section */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            px: 2,
          }}
        >
          <Typography
            variant="body2"
            sx={{ color: "rgba(52,52,52,1)", fontWeight: 500 }}
          >
            {name}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default LeaderboardItem;
