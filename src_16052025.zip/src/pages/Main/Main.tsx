import React from "react";

const Main = () => {
  return (
    <div>
      <h1>Welcome to the Main Page</h1>
    </div>
  );
};

export default Main;
