import React from 'react';
import { Box, Typography } from '@mui/material';
import { SetupCard, Setup } from './SetupCard';

interface SetupListProps {
  setup: Setup[];
  onEdit: (setup: Setup) => void;
  onDelete: (setup: Setup) => void;
  onToggleStatus: (setup: Setup, enabled: boolean) => void;
}

export const InternalSiteList: React.FC<SetupListProps> = ({
  setup,
  onEdit,
  onDelete,
  onToggleStatus,
}) => {
  return (
    <Box sx={{
      width: '100%',
      maxWidth: '495px',
      mt: 2
    }}>
      <Typography sx={{
        alignSelf: 'stretch',
        textAlign:'center',
        width: '100%',
        fontSize: '14px',
        color: '#1d1b20',
        fontWeight: "bold",
        lineHeight: 1.2,
        mb:2
      }}>
        Existing Sites
      </Typography>
      {setup.map((setup) => (
        <SetupCard
          key={setup.id}
          Setup={setup}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleStatus={onToggleStatus}
        />
      ))}
    </Box>
  );
};
