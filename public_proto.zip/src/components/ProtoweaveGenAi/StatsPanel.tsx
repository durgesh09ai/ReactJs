import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";

import { useNavigate } from "react-router-dom";
import UserProfile from "./ui/dashboard/UserProfile";

const StatsPanel  = () => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "370x",
        p: 2,
      }}
    >
     <Button
  fullWidth
  sx={{
    backgroundColor: "white",
    borderRadius: "20px",
    px: 2,
    py: 1.5,
    textTransform: "none",
    fontWeight: 500,
    fontSize: "0.875rem",
    color: "black",
    display: "flex",
    alignItems: "center",
    gap: 2,
    justifyContent: "flex-start", // ✅ THIS makes it left-aligned
  }}
>
  <Avatar
    src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae9d15c00f2e9ae28f7d0d8c3b621bb745ab4cbe?placeholderIfAbsent=true"
    alt="Close"
    sx={{ width: 18, height: 18, borderRadius: "8px" }}
  />
<Typography
  sx={{
    my: "auto",
    color: "#000",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 500,
    lineHeight: "normal"
  }}
>
Left hand side
</Typography>
</Button>


      <UserProfile
        name="Umesh jain"
        role="Sales & info manager"
        avatar="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b522349175b734ad87f721737d0337e9eac00b6e?placeholderIfAbsent=true"
        points={453}
      />

    
    </Paper>
  );
};

export default StatsPanel;
