
import React from "react";
import { 
  Box, 
  Button, 
  Typography, 
  Paper,
  FormControl,
  FormLabel,
  Stack
} from "@mui/material";
import AddIcon from '@mui/icons-material/Add';

import { useNavigate } from "react-router-dom";
import StatCard from "./ui/dashboard/StatCard";
import FilterDropdown from "./ui/dashboard/FilterDropdown";
import DataCard from "./ui/dashboard/DataCard";

const MainContent: React.FC = () => {

  const navigate = useNavigate();
  const addSolution = () => {
    navigate("/addasolution");
  };

  const stats = [
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff6cc1f225166896c3ec77701a605e5f45d627f?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2add0120e1baa4a531138968983acb2669c4b3f8?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9beeaec86cd1e7b5c710f1ecb71ad4a6175ad970?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9505216f116d2c3a9fb933127751f6c3819a3df?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/46fc2e06ce75b61a266e9dd154a6b05633195e55?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2add0120e1baa4a531138968983acb2669c4b3f8?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
    {
      value: "89",
      label: "Team",
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/61f6194650a7e18333448a643df76b2d3517ad88?placeholderIfAbsent=true",
      trend: "10.2",
      trendIcon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9505216f116d2c3a9fb933127751f6c3819a3df?placeholderIfAbsent=true",
      trendText: "+1.01% this week",
    },
  ];

  const data = [
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/0efa5fd251ccaae5fab2b7584ad2298d2f012733?placeholderIfAbsent=true", label: "Actuarial / Underwriting", value: "6" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a265057a2999feccdc4f73129584bdd8db69c093?placeholderIfAbsent=true", label: "Benefits Design", value: "8" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/c76b37a02a8e6f5631985249aed357cc66a04af4?placeholderIfAbsent=true", label: "Claims/Ops", value: "2" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e2bb5b61a4e971e68a0d5d89ebc01e9ad9bbb1a4?placeholderIfAbsent=true", label: "Clinical Management", value: "12" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/89515736e9af01f21a37ba2fb67e01cb6728e80b?placeholderIfAbsent=true", label: "Clinical Services", value: "1" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/1b2e577d6930e00f91d28d2df0a43f5581cf7193?placeholderIfAbsent=true", label: "Customer Services", value: "13" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5a2c022ec6e6595368f6e29fe1b8f51f0491c857?placeholderIfAbsent=true", label: "Medical Cost Management", value: "14" },
    { icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae4b2de60bd17b824b506d78f5662e8af2c7b63d?placeholderIfAbsent=true", label: "Network Management", value: "7" }
  ];
  
  
  return (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      flexGrow: 1, 
      minWidth: '240px',
      gap: '16px',
    }}>
 

      <Box sx={{ width: '100%', mt: 4 }}>
        <Box sx={{ width: '100%' }}>



          <Paper
  sx={{
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    padding: '16px',
    gap: '32px',
    alignSelf: 'stretch',
    borderRadius: '8px',
    backgroundColor: '#FFF',
    border: 'none',
    boxShadow: 'none',
    mt: 2,
  }}
>

 Right Side
</Paper>


    </Box>
  </Box>
</Box>
  );
};

export default MainContent;
