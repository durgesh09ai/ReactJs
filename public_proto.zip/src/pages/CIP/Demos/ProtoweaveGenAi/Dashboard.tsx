import React from "react";

import { Box } from "@mui/material";
import MainContent from "../../../../components/ProtoweaveGenAi/MainContent";
import StatsPanel from "../../../../components/ProtoweaveGenAi/StatsPanel";

const DashBoard = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        gap: 2,
        width: "100%",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          flexGrow: 1,
          minWidth: 0, // 👈 Prevents overflow from flex child
        }}
      >
        <MainContent />
      </Box>

      <Box
        sx={{
          width: "397px",
          flexShrink: 0, // 👈 Prevents StatsPanel from shrinking
        }}
      >
        <StatsPanel />
      </Box>
    </Box>
  );
};

export default DashBoard;
