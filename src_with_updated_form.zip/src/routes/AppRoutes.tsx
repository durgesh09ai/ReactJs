import { Routes, Route } from "react-router-dom";
import DefaultLayout from "../layout/DefaultLayout/Layout";
import Demo1Layout from "../layout/Demo1Layout/Layout";

import Main from "../pages/Main/Main";
import CIP from "../pages/CIP/CIP";

// Demo1
import DatagenAiSynthetic from "../pages/CIP/Demos/DatagenAiSynthetic/DatagenAiSynthetic";
import DetailPage from "../pages/CIP/Demos/DatagenAiSynthetic/DetailPage";
import AboutUs from "../pages/CIP/Demos/DatagenAiSynthetic/AboutUs";

// Demo2 (similar structure, not repeated here)
import ProtoweaveGenAi from "../pages/CIP/Demos/ProtoweaveGenAi/Dashboard";
import ExperimentConfigration from "../pages/CIP/Demos/ProtoweaveGenAi/ExperimentConfigration";
import WorkspaceSetup from "../pages/CIP/Demos/ProtoweaveGenAi/WorkspaceSetup";
// import AdverseeventGenaiClinical from "../pages/CIP/Demos/AdverseeventGenaiClinical/AdverseeventGenaiClinical";

export const AppRoutes = () => (
    <Routes>
      <Route element={<DefaultLayout />}>
        <Route path="/" element={<Main />} />
        <Route path="/cip" element={<CIP />} />
        <Route path="/protoweave" element={<ProtoweaveGenAi />} />
        <Route path="/protoweave/experiment" element={<ExperimentConfigration />} />
        <Route path="/protoweave/workspacesetup" element={<WorkspaceSetup />} />

      </Route>

        {/* Nested Demo1 */}
        <Route path="/cip/datagenaisynthetic" element={<Demo1Layout />}>
          <Route index element={<DatagenAiSynthetic />} />
          <Route path="aboutus" element={<AboutUs />} />
          <Route path="detailpage" element={<DetailPage />} />
        </Route>

        {/* If needed: Nested Demo2 as well */}
        {/* <Route path="/cip/adverseeventgenaiclinical" element={<AdverseeventGenaiClinical />} /> */}
    </Routes>
);
