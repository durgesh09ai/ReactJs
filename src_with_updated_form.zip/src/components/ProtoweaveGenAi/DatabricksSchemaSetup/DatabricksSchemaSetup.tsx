import React, { useState } from "react";
import { Box, Button, Paper, Typography, Link } from "@mui/material";
import SetupHeader from "./SetupHeader";
import SetupFormField from "./SetupFormField";

interface DatabricksSchemaSetupProps {
  initialData?: {
    serviceCredential: string;
    databrickurl: string;
    catalogname: string;
    schemaname: string;
  };
}

const DatabricksSchemaSetup: React.FC<DatabricksSchemaSetupProps> = ({
  initialData = {
    serviceCredential: "DFR%^$$##HHFF",
    databrickurl: "https://<your-instance>.cloud.databricks.com",
    catalogname: "main_catalog ",
    schemaname: "experiment_results",
  }
}) => {
  const [databricksData, setDatabricksData] = useState(initialData);

  const handleUpdate = () => {
    console.log("Update clicked", databricksData);
  };

  const handleAddClick = () => {
    console.log("Add clicked");
  };

  const handleEditClick = () => {
    console.log("Edit clicked");
  };

  return (
    <Paper
      elevation={1}
      sx={{
        maxWidth: "820px",
        pb: "20px",
        px: 1,
        borderRadius: 2,
      }}
    >
      <SetupHeader title="Databricks Schema Setup" />

      {/* Title Row with Add and Edit */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mt: 1,
          mb: 2,
          px: 1,
        }}
      >
        <Typography variant="h6" sx={{ fontSize: 14, fontWeight: 'bold' }}>
          Databricks Schema Setup
        </Typography>

        <Box sx={{ display: "flex", gap: 2 }}>
              <Link
            component="button"
            onClick={handleEditClick}
            underline="hover"
            sx={{ fontSize: 14,fontWeight:'bold' }}
          >
            Edit
          </Link>
        </Box>
      </Box>

      <Box
        sx={{
          display: "flex",
          width: "100%",
          gap: 4,
          flexWrap: "wrap",
          alignItems: "stretch",
          px: 1,
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            minWidth: 300,
            width: "400px",
            justifyContent: "center",
            whiteSpace: "nowrap",
          }}
        >
          <SetupFormField label="Service Credentials (API Key)" value={databricksData.serviceCredential} />
          <SetupFormField label="Databricks URL" value={databricksData.databrickurl} />
          <SetupFormField label="Catalog Name" value={databricksData.catalogname} />
          <SetupFormField label="Schema Name" value={databricksData.schemaname} />

          <Button
            variant="contained"
            sx={{ mt: 2, alignSelf: "flex-start" }}
            onClick={handleUpdate}
          >
            Save Schema Setup
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default DatabricksSchemaSetup;
