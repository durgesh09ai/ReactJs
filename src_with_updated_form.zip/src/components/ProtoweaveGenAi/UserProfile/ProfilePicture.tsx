import React, { useRef } from "react";
import { Box, Typography, Button, Avatar } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";

interface ProfilePictureProps {
  imageUrl: string;
  onEditClick: (file: File) => void;
}

const ProfilePicture: React.FC<ProfilePictureProps> = ({ imageUrl, onEditClick }) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleButtonClick = () => {
    fileInputRef.current?.click(); // Open file picker
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onEditClick(file);
    }
  };

  return (
    <Box sx={{ width: 190, my: "auto" }}>
      <Typography
        variant="body1"
        sx={{
          color: "#1d1b20",
          lineHeight: 1.2,
          fontSize: 14,
          fontWeight: 400,
        }}
      >
        Profile picture
      </Typography>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "100%",
          mt: 2,
          color: "#0F4977",
        }}
      >
        <Avatar
          src={imageUrl}
          alt="Profile"
          sx={{
            width: 80,
            height: 80,
            borderRadius: "56px",
          }}
        />
        <Button
          onClick={handleButtonClick}
          variant="outlined"
          startIcon={<EditIcon />}
          sx={{
            mt: 1,
            px: 2,
            py: 0.5,
            borderRadius: 2,
            borderColor: "rgba(15,73,119,1)",
            color: "#0F4977",
            textTransform: "none",
          }}
        >
          Edit photo
        </Button>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
      </Box>
    </Box>
  );
};

export default ProfilePicture;
