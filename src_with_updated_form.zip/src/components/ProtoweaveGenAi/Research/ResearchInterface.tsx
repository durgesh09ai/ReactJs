import React, { useState } from "react";
import {
  Avatar,
  Box,
  Container,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import { ResearchReport } from "./ResearchReport";
import { ChatMessage } from "./ChatMessage";
import { QuestionForm } from "./QuestionForm";
import { ResearchInput } from "./ResearchInput";

export const ResearchInterface: React.FC = () => {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [userMessage, setUserMessage] = useState("");
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSaveAnswers = (newAnswers: Record<string, string>) => {
    setAnswers((prev) => ({ ...prev, ...newAnswers }));
    setFormSubmitted(true); 
    console.log("Answers saved:", newAnswers);
  };
  
  const handleStartSimulation = () => {
    alert("Simulation would start here");
  };

  const diabetesQuestions = [
    {
      id: "outcomes",
      text: "What specific outcomes related to type 2 diabetes management are of most interest (e.g., HbA1c reduction, hypoglycemia events, patient-reported outcomes)?",
    },
    {
      id: "audience",
      text: "Is the target audience for this research primarily healthcare professionals, patients, or both? If patients, are there specific demographics or subgroups of interest (e.g., age, duration of diabetes, insulin use)?",
    },
    {
      id: "detail",
      text: "What level of detail is needed for the proposed research protocols? Should they be fully developed and ready for immediate implementation, or more conceptual?",
    },
  ];

  return (
    <Container
      maxWidth="md"
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "90vh",
        paddingBottom: "20px", // Optional: for spacing at the bottom
      }}
    >
      <Stack spacing={4} sx={{ flexGrow: 1, overflow: "auto" }}>
        {/* Chat Section */}
        <Stack spacing={3} maxWidth={398}>
          <ChatMessage
            content="I need some clarification to better understand your research needs:"
            sender="assistant"
          />
          
          {hasSubmitted && (
            <ChatMessage content={userMessage} sender="user" />
          )}

          {hasSubmitted && (
            <QuestionForm
              questions={diabetesQuestions}
              onSave={handleSaveAnswers}
            />
          )}
        </Stack>

        {/* Research Report Section */}
        {formSubmitted && (
          <ResearchReport
            title="The Impact of a Low-Carbohydrate Diet on Blood Glucose Levels in Type 2 Diabetes Patients
            This study investigates the effect of a low-carbohydrate diet on fasting blood glucose levels in patients with Type 2 diabetes over a 12-week period. 60 participants were randomly assigned to either a low-carb diet group or a standard diet group. The study found a statistically significant reduction in fasting blood glucose levels in the low-carb group compared to the control group.
           Sample size: 60 individuals with diagnosed Type 2 diabetes
Groups:
Group A (Low-carb): n=30
Group B (Standard diet): n=30
Duration: 12 weeks
Measurement: Fasting blood glucose (mg/dL) measured weekly`}
            Participants in the low-carb group showed a significantly greater reduction in fasting glucose levels (mean reduction of 39.8 mg/dL) than those in the standard diet group (8.7 mg/dL). The difference was statistically significant (p < 0.001), suggesting that dietary carbohydrate restriction could be an effective strategy for glycemic control in Type 2 diabetes."
            onStartSimulation={handleStartSimulation}
            iconSrc="./chaticon.png"
          />
        )}
      </Stack>

      {/* Input Section (Search Box at the bottom) */}
      <Box sx={{ position: "sticky", bottom: 0, width: "100%" }}>
        <ResearchInput
          onSubmit={(content) => {
            setUserMessage(content);
            setHasSubmitted(true);
          }}
        />
      </Box>
    </Container>
  );
};
