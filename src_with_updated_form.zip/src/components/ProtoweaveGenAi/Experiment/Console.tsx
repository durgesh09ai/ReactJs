import React from "react";
import { Box, Typography, Stack, Paper } from "@mui/material";

const Console = () => {
  return (
   <>
<Box
  sx={{
    borderRadius: "16px 16px 0 0",
    backgroundColor: "#D9EDFF",
    p: 0.6,
    width: "100%",
    maxWidth: 500,
    mx: "auto",
    mb: "1px",
  }}
>
  <Box
    sx={{
      borderRadius: "16px 16px 0 0",
      backgroundColor: "#fff",
      width: "100%",
      p:1
    }}
  >
    <Typography variant="h6" align="center" fontSize={14} fontWeight={400}>
      Console
    </Typography>
  </Box>
</Box>

    <Box
      sx={{
        border: "1px solid #CFE3F3",
        borderRadius: "0 0 16px 16px",
        backgroundColor: "#D9EDFF",
        p: 2,
        width: "100%",
        maxWidth: 500,
        mx: "auto",
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "row", position: "relative" , border: "1px solid #fff",
        borderRadius: "16px",
        backgroundColor: "#fff",p:2,}}>

        {/* Content */}
        <Box sx={{ flex: 1,height:750, }}>
        <Typography variant="h6" align="center" fontSize={14} fontWeight={400}>
      Output will be come here
    </Typography>
        </Box>
      </Box>
    </Box>
    </>
  );
};




export default Console;
