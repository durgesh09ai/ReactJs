import { DatagenAiSyntheticStore } from "./cip/DatagenAiSyntheticStore";

export class RootStore {
  datagenAiSyntheticStore: DatagenAiSyntheticStore;

  constructor() {
    this.datagenAiSyntheticStore = new DatagenAiSyntheticStore(); // ✅ match the property name
  }
}

const rootStore = new RootStore();
export default rootStore;
