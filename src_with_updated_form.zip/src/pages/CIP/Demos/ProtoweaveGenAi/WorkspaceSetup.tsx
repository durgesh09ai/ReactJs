import React, { useState } from "react";
import { Box, Container } from "@mui/material";
import Sidebar from "../../../../components/ProtoweaveGenAi/WorkspaceSetup/Sidebar";
import WorkspaceContent from "../../../../components/ProtoweaveGenAi/WorkspaceSetup/WorkspaceContent";
import UserProfile from "../../../../components/ProtoweaveGenAi/UserProfile/UserProfile";
import DatabricksSchemaSetup from "../../../../components/ProtoweaveGenAi/DatabricksSchemaSetup/DatabricksSchemaSetup";

const WorkspaceSetup: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState("User Profile");

  const renderContent = () => {
    switch (selectedItem) {
      case "Workspace Setup":
        return <WorkspaceContent />;
      case "User Profile":
        return <UserProfile />;
      case "Databricks Schema Setup":
         return <DatabricksSchemaSetup />;
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="xl">
      <Box
        sx={{
          display: 'flex',
          gap: 2,
          bgcolor: '#F3FAFF',
          p: 2,
          borderRadius: 2,
          justifyContent: 'center',
          alignItems: 'flex-start',
          my: 2
        }}
      >
        <Sidebar selectedLabel={selectedItem} onSelect={setSelectedItem} />
        <Box sx={{ flexGrow: 1, minWidth: 480 }}>
          {renderContent()}
        </Box>
      </Box>
    </Container>
  );
};

export default WorkspaceSetup;
