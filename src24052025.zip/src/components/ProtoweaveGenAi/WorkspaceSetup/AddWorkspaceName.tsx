import React, { useState } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";

interface Props {
  onAddWorkspace: (name: string) => void;
}

const AddWorkspaceName: React.FC<Props> = ({ onAddWorkspace }) => {
  const [workspaceName, setWorkspaceName] = useState("");

  const SubmitWorkspaceName = (e: React.FormEvent) => {
    e.preventDefault();
    if (workspaceName.trim()) {
      onAddWorkspace(workspaceName.trim());
      setWorkspaceName("");
    }
  };

  return (
    <Box sx={{ width: '100%', maxWidth: '527px' }}>
      <Typography variant="body2" sx={{ color: '#1d1b20', fontWeight: 'medium', lineHeight: 1.2 }}>
        <Box component="span" sx={{ fontWeight: 'bold' }}>Add a Workspace</Box>
      </Typography>

      <Box component="form" onSubmit={SubmitWorkspaceName} sx={{ display: 'flex', gap: 1, mt: 1, flexWrap: 'wrap' }}>
        <TextField
          value={workspaceName}
          onChange={(e) => setWorkspaceName(e.target.value)}
          placeholder="Name workspace"
          required
          variant="outlined"
          size="small"
          sx={{ flexGrow: 1, minWidth: '240px' }}
        />
        <Button
          type="submit"
          variant="outlined"
          sx={{
            color: '#0F4977',
            borderColor: '#0F4977',
            textTransform: 'none',
            fontWeight: 'bold',
            height: '40px',
          }}
        >
          Add Workspace
        </Button>
      </Box>
    </Box>
  );
};

export default AddWorkspaceName;
