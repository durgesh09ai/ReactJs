import React, { useState } from "react";
import { Box, Paper } from "@mui/material";
import FormHeader from "./FormHeader";
import ResearchInfo from "./ResearchInfo";
import CriteriaSection from "./CriteriaSection";
import MedicalCodingSection from "./MedicalCodingSection";
import ParametersSection from "./ParametersSection";
import UploadSection from "./UploadSection";
import ActionButtons from "./ActionButtons";
import { databricksStore } from "../../../stores/cip/ProtoweaveGenAiStore/DatabricksStore";
import { observer } from "mobx-react-lite";

const ExperimentInterface: React.FC = () => {
  const [activeTab, setActiveTab] = useState("Configuration Form 1");
  const dataresult = "";
  databricksStore.setDatabrickResult(dataresult);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleUploadProtocol = () => {
    console.log("Upload protocol clicked");
    // Implement protocol upload functionality
  };

  const handleUploadData = () => {
    console.log("Upload data clicked");
    // Implement data upload functionality
  };

  const handleDuplicate = () => {
    console.log("Duplicate clicked");
    // Implement duplication functionality
  };

  const handleRunExperiment = () => {
    const dataresult1 = "test";
    databricksStore.setDatabrickResult(dataresult1);
    console.log("Run experiment clicked");
  };

  return (
    <Box sx={{ maxWidth: "684px", fontSize: "0.875rem" }}>
      <FormHeader
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onUploadProtocol={handleUploadProtocol}
      />
      
      <Box 
        sx={{ 
          width: "100%", 
          bgcolor: "#D9EDFF", 
          borderRadius: "0px 12px 12px 12px",
          p: 2,
          overflow: "hidden"
        }}
      >
        <ResearchInfo
          researchName="Diabetes type1"
          experimentName="Config 1"
          createdDate="May 24, 2025"
          ownerName="@dr.meera"
        />
        
        <Paper 
          elevation={0}
          sx={{ 
            mt: 2, 
            p: 2, 
            borderRadius: 2,
            width: "100%"
          }}
        >
          <CriteriaSection />
          
          <MedicalCodingSection />
          
          <Box sx={{ mt: 2, width: "100%" }}>
            <ParametersSection />
            {/* <UploadSection onUploadData={handleUploadData} /> */}
          </Box>
          
          <ActionButtons
            onDuplicate={handleDuplicate}
            onRunExperiment={handleRunExperiment}
          />
        </Paper>
      </Box>
    </Box>
  );
};

export default observer(ExperimentInterface);
