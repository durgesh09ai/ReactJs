import React from "react";
import { observer } from "mobx-react-lite";
import { Box, Typography, Stack, Paper } from "@mui/material";
import { databricksStore } from "../../../stores/cip/ProtoweaveGenAiStore/DatabricksStore";

const Console = () => {
  return (
   <>
<Box
  sx={{
    borderRadius: "16px 16px 0 0",
    backgroundColor: "#D9EDFF",
    p: 0.6,
    width: "100%",
    maxWidth: 500,
    mx: "auto",
    mb: "1px",
  }}
>
  <Box
    sx={{
      borderRadius: "16px 16px 0 0",
      backgroundColor: "#fff",
      width: "100%",
      p:1
    }}
  >
    <Typography variant="h6" align="center" fontSize={14} fontWeight={400}>
      Console
    </Typography>
  </Box>
</Box>

    <Box
      sx={{
        border: "1px solid #CFE3F3",
        borderRadius: "0 0 16px 16px",
        backgroundColor: "#D9EDFF",
        p: 2,
        width: "100%",
        maxWidth: 500,
        mx: "auto",
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "row", position: "relative" , border: "1px solid #fff",
        borderRadius: "16px",
        backgroundColor: "#fff",p:2,}}>

        {/* Content */}
        <Box sx={{ flex: 1,height:750,fontSize:14 ,fontWeight:400  }}>
         { databricksStore.databrickResult && databricksStore.databrickResult.length>2 ? (
          <Box>
          <h4> Findings</h4>
         <p>This report is based on a comprehensive, albeit limited, review of existing literature, 
          including randomized controlled trials, observational studies, meta-analyses, 
          and real-world evidence, focusing on the use of Farxiga in elderly patients with T2DM. 
          Due to limitations in the provided paper analyses, a full PRISMA-guided systematic
           review was not possible. Data extraction, where available, focused on efficacy outcomes
            (HbA1c, cardiovascular events, renal function) and safety outcomes (adverse events,
             hospitalizations). The methodological rigor of the reviewed studies could not be 
             fully assessed due to the lack of detailed information on study design, sample size,
              patient selection, and statistical analyses.</p>
         <p> <b>Impact of Farxiga on Renal Function and Diabetic Kidney Disease in the Elderly</b></p>
        <p> There is currently insufficient evidence to determine the effects of Farxiga on renal outcomes, including eGFR changes, albuminuria progression, and incidence of end-stage renal disease, specifically in senior patients with T2DM. No information in the analyzed papers addressed this research question.</p>
        </Box>
         ):(
          <Typography variant="h6" align="center" fontSize={14} fontWeight={400}>
          Output will be come here
         </Typography>
         )
        }
        </Box>
      </Box>
    </Box>
    </>
  );
};




export default observer(Console);
