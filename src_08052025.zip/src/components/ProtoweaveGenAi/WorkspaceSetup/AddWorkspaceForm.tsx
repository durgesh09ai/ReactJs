import React, { useState } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";

const AddWorkspaceForm: React.FC = () => {
  const [workspaceName, setWorkspaceName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (workspaceName.trim()) {
      console.log("Adding workspace:", workspaceName);
      // Here you would typically call an API to add the workspace
      setWorkspaceName("");
    }
  };

  return (
    <Box sx={{ width: '100%', maxWidth: '527px' }}>
      <Typography 
        variant="body2" 
        sx={{ 
          color: '#1d1b20', 
          fontWeight: 'medium',
          lineHeight: 1.2
        }}
      >
        <Box component="span" sx={{ fontWeight: 'bold' }}>Add a Workspace</Box>
      </Typography>
      
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{
          display: 'flex',
          width: '100%',
          gap: 1,
          mt: 1,
          flexWrap: 'wrap'
        }}
      >
        <TextField
          value={workspaceName}
          onChange={(e) => setWorkspaceName(e.target.value)}
          placeholder="Name workspace"
          required
          variant="outlined"
          size="small"
          sx={{
            flexGrow: 1,
            minWidth: '240px',
            '& .MuiOutlinedInput-root': {
              bgcolor: 'white',
              borderColor: 'rgba(18,18,21,0.30)',
            }
          }}
        />
        <Button
          type="submit"
          variant="outlined"
          sx={{
            color: '#0F4977',
            borderColor: '#0F4977',
            textTransform: 'none',
            fontWeight: 'bold',
            height: '40px',
          }}
        >
          Add Workspace
        </Button>
      </Box>
    </Box>
  );
};

export default AddWorkspaceForm;
