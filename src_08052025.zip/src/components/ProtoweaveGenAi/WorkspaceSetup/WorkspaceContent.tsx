import React from "react";
import { Box, Paper, Typography, Divider } from "@mui/material";
import AddWorkspaceForm from "./AddWorkspaceForm";
import WorkspaceCard from "./WorkspaceCard";

const WorkspaceContent: React.FC = () => {
  return (
    <Paper 
      sx={{
        width: '705px',
        minWidth: '240px',
        p: 1,
        pt: 2,
        pb: 2,
        borderRadius: 1
      }}
    >
      <Box sx={{ px: 1 }}>
        <Typography 
          variant="body1" 
          sx={{ 
            py: 1,
            borderBottom: '1px solid rgba(18,18,21,0.30)',
            color: '#1d1b20',
            fontWeight: 'normal'
          }}
        >
          Workspace Setup
        </Typography>
      </Box>
      
      <Box sx={{ display: 'flex', gap: 4, mt: 2 }}>
        <Box sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          minWidth: '240px',
          width: '527px'
        }}>
          <AddWorkspaceForm />
          
          <WorkspaceCard 
            name="Workspace 1"
            description="Diabetes Type 1"
            fullDescription="A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling."
            owner="admin65@gamil.com"
            members={[
              "gaurav34@gmail.cim",
              "gaurav34@gmail.cim",
              "gaurav34@gmail.cim"
            ]}
            isToggleOn={true}
          />
          
          <WorkspaceCard 
            name="Workspace 1"
            description="Diabetes Type 1"
            fullDescription="A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling."
            owner="admin65@gamil.com"
            members={[
              "gaurav34@gmail.cim",
              "gaurav34@gmail.cim",
              "gaurav34@gmail.cim"
            ]}
            isToggleOn={false}
          />
        </Box>
      </Box>
    </Paper>
  );
};

export default WorkspaceContent;
