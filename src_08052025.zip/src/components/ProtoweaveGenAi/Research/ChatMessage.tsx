import React from "react";
import { Avatar, Paper, Stack, Typography } from "@mui/material";

type SenderType = "assistant" | "user";

interface ChatMessageProps {
  content: string;
  sender: SenderType;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  content,
  sender,
}) => {
  const isAssistant = sender === "assistant";

  return (
    <Stack
      direction={isAssistant ? "row" : "row-reverse"}
      spacing={1}
      alignItems="flex-start"
    >
      <Avatar
        src={"./chaticon.png"}
        alt={isAssistant ? "Assistant" : "User"}
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      />

      <Paper
        elevation={0}
        sx={{
          minWidth: 240,
          maxWidth: 352,
          bgcolor: "#F3FAFF",
          p: 2.5,
          borderRadius: 2,
        }}
      >
        <Typography
          variant="body2"
          sx={{
            fontSize: "0.875rem",
            fontWeight: 400,
            color: "black",
            lineHeight: "17px",
          }}
        >
          {content}
        </Typography>
      </Paper>
    </Stack>
  );
};
