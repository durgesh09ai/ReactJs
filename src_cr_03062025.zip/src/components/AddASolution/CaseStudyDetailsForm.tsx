import React, { useState, useCallback } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  IconButton,
} from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}

export const CaseStudyDetailsForm: React.FC<BasicInfoFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "220px", // You can reduce this further if needed
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "582px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Case Study Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            columnGap: 2, // Reduce this gap even to 1 if needed
            rowGap: 2,
            justifyContent: "flex-start",
            alignItems: "flex-start",
            width:'580px' 
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ width: "50%" }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Year of Implementation:
              </Typography>
              <TextField
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter Year of Implementation"
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Timeframe of Implementation:
              </Typography>
              <TextField
                id="clientName"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter Timeframe"
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
              />
            </Box>

            <Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 1,
                }}
              >
                <Typography variant="body2">Problem Faced:</Typography>
              </Box>
              <TextField
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Enter Problem"
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
              />
            </Box>
          </Stack>

          {/* Right Column */}
          <Stack spacing={2} sx={{ width: "50%" }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Solution Proposed:
              </Typography>
              <TextField
                id="solutionName2"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter Solution"
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Results / Impact:
              </Typography>
              <TextField
                id="clientName2"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter Results"
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
              />
            </Box>
          </Stack>
        </Box>
      </Stack>
    </Paper>
  );
};
