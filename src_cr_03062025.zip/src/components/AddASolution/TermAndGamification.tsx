import React, { useState, useCallback } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  IconButton
} from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}

export const TermAndGamification: React.FC<BasicInfoFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (onSave) {
      onSave(formData);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "282px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/78e426345c95d8dc64de9f0a9eeb3c605e451e05?placeholderIfAbsent=true"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Term & Gamification</Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
          }}
        >
          {/* Left Column */}
          <Stack spacing={3} sx={{ flex: 1 }}>
            <Box>
              <Typography variant="body2" gutterBottom>
                Owner Name
              </Typography>
              <TextField
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter Owner Name"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
                Contact Email
              </Typography>
              <TextField
                id="clientName"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                placeholder="Enter Contact Email"
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

          </Stack>
       
        </Box>
      </Stack>
    </Paper>
  );
};
