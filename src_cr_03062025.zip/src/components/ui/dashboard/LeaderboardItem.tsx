import React from "react";
import { Box, Typography } from "@mui/material";
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';

interface LeaderboardItemProps {
  image: string;
  rank: number;
  name: string;
}

const LeaderboardItem: React.FC<LeaderboardItemProps> = ({ image, rank, name }) => {
  return (
    <Box
      sx={{
        display: "flex",
        backgroundColor: "white",
        border: "1px solid rgba(253,244,238,1)",
        borderRadius: "16px 10px 10px 16px",
        minHeight: 103,
        width: "100%",
        mt: 2,
        overflow: "hidden",
      }}
    >
      {/* Left image section */}
      <Box
        component="img"
        src={image}
        alt={`Contributor ${rank}`}
        sx={{
          width: 170,
          background: "#D9D9D9",
          borderRadius: "16px 0px 0px 16px",
        }}
      />

      {/* Right content section */}
      <Box sx={{ width: 179, display: "flex", flexDirection: "column" }}>
        {/* Top bar */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            width: "100%", // Use full width available
            height: "34px",
            padding: "6px 10px",
            borderRadius: "0px 9px 0px 0px",
            background: "#0F4977",
          }}
        >
          {/* No.{rank} Contributor and the batch */}
          <Typography
            variant="body2"
            color="#FFF"
            fontSize="12px"
            fontWeight={600}
            width={97}
            sx={{ flexGrow: 1 }}
          >
            No.{rank} Contributor:
          </Typography>

          {/* Workspace Premium Icon with rank */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
              width: "30px", // Add width to make space for the batch
            }}
          >
            <WorkspacePremiumIcon
              sx={{
                width: 30,
                height: 30,
                color: "#FFF", // Golden icon
              }}
            />
            <Box
              sx={{
                position: "absolute",
                top: "3px", // Adjust the position
                right: "6px", // Adjust the position
                backgroundColor: "white", // White background for the rank
                color: "#0F4977", // Rank number color matching the background
                fontSize: "0.75rem", // Adjust the font size
                fontWeight: 600,
                width: "18px",
                height: "18px",
                borderRadius: "50%", // Circle shape for the batch
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10,
                border: "2px solid #0F4977", // Border color matching the background
              }}
            >
              {rank}
            </Box>
          </Box>
        </Box>

        {/* Name section */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            px: 2,
          }}
        >
          <Typography
            variant="body2"
            sx={{ color: "rgba(52,52,52,1)", fontWeight: 500 }}
          >
            {name}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default LeaderboardItem;
