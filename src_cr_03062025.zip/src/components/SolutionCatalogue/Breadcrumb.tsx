import React from "react";
import { Box, Typography } from "@mui/material";

interface BreadcrumbItem {
  label: string;
  active?: boolean;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <Box display="flex" alignItems="center" gap={1}>
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && (
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/37ac8842124cea01052500be6c4824e11b43f41d?placeholderIfAbsent=true"
              alt="separator"
              style={{ width: 20 }}
            />
          )}
          <Typography
            sx={{
              color: '#0F4977',
              fontWeight: item.active ? 600 : 500,
              fontSize: '12px',
              whiteSpace: 'nowrap',
              height:'20px',
            }}
          >
            {item.label}
          </Typography>
        </React.Fragment>
      ))}
    </Box>
  );
};

export default Breadcrumb;
