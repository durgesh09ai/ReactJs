import React from "react";
import { Box, Typography, Avatar } from "@mui/material";
import NavItem from "./NavItem";
import NavSection from "./NavSection";

interface SidebarProps {
  collapsed?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed = false }) => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh" 
      px={2}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
    >
      {/* Top Section */}
      <Box flexGrow={1}>
        {/* Header */}
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          px={2}
          py={1.5}
          borderBottom="1px solid rgba(0,0,0,0.1)"
        >
          <Typography
            variant="h6"
            sx={{
              fontSize: "28px",
              fontWeight: 600,
              color: "#e7552b",
              whiteSpace: "nowrap",
            }}
          >
            {!collapsed && "EXL"}
          </Typography>
          {!collapsed && (
            <Avatar
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9df66a2e096fffaa4eec49ff70db980f5326516a?placeholderIfAbsent=true"
              alt="Logo"
              sx={{ width: 24, height: 24 }}
              variant="square"
            />
          )}
        </Box>

        {/* Navigation Items */}
        <Box display="flex" flexDirection="column" sx={{mt:2}}>
          <NavSection title={collapsed ? "" : "Home"}  />

          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b628d78a4baec2798a453ffd9a4bcf1d35c8e6d6?placeholderIfAbsent=true"
            label="Quality and Compliance"
            count={20}
            collapsed={collapsed}
            subItems={[
              { label: "Quality Reports" },
              { label: "Compliance Dashboard" },
              { label: "Audit Logs" },
            ]}
          />

          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/051c15b961652ad186fe0257c1a414a1ffc91dc0?placeholderIfAbsent=true"
            label="Data and analytics LOB"
            count={20}
            collapsed={collapsed}
            subItems={[
              { label: "Data Insights" },
              { label: "Analytics Dashboard" },
            ]}
          />

          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/4ef76a64142b66e6d38acbd0f1522f8f190fc5d1?placeholderIfAbsent=true"
            label="Life Science LOB"
            count={20}
            collapsed={collapsed}
          />

          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d90d47cac85a8af782e6618e8ecae6037f193310?placeholderIfAbsent=true"
            label="Risk Quality Measures"
            count={20}
            collapsed={collapsed}
          />
        </Box>
      </Box>

      {/* Footer Items pinned to bottom */}
      {!collapsed && (
        <Box mt={2}>
          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/3904791a901d558c2c5d7347a0090cb8906978c9?placeholderIfAbsent=true"
            label="Bookmarked"
            showCount={false}
            collapsed={collapsed}
          />
          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff595e8aeb1d76299e427e0b5390f825a7dd6d5?placeholderIfAbsent=true"
            label="Settings"
            showCount={false}
            collapsed={collapsed}
          />
        </Box>
      )}
    </Box>
  );
};

export default Sidebar;
