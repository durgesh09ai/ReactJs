// components/QuestionAnswerBlock.tsx
import React from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

interface QuestionAnswerBlockProps {
  questions: string[];
  answers: Record<string, string>;
  onChange: (question: string, answer: string) => void;
  onSubmit?: (approved: boolean) => void;
  showActions?: boolean;
}

const QuestionAnswerBlock: React.FC<QuestionAnswerBlockProps> = ({
  questions,
  answers,
  onChange,
  onSubmit,
  showActions = false,
}) => {
  return (
    <Stack direction="row" spacing={1} width="100%">
      <Avatar
        src="./chaticon.png"
        alt="Assistant"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": { width: 16, height: 16, objectFit: "contain" },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          flex: 1,
          p: 2.5,
          bgcolor: "#F3FAFF",
          borderRadius: 2,
        }}
      >
        <Stack spacing={2}>
          {questions.map((question) => (
            <Box key={question}>
              <Typography
                variant="body2"
                sx={{
                  color: "black",
                  lineHeight: "17px",
                  fontSize: "0.875rem",
                }}
              >
                {question}
              </Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Your answer"
                value={answers[question] || ""}
                onChange={(e) => onChange(question, e.target.value)}
                sx={{
                  mt: 1.25,
                  "& .MuiOutlinedInput-root": {
                    bgcolor: "white",
                    fontSize: "0.875rem",
                  },
                }}
              />
            </Box>
          ))}
          {showActions && (
            <Box display="flex" justifyContent="flex-end" gap={2}>
              <Button
                variant="outlined"
                onClick={() => onSubmit?.(false)}
              >
                Request Revision
              </Button>
              <Button
                variant="contained"
                onClick={() => onSubmit?.(true)}
              >
                Approve Plan
              </Button>
            </Box>
          )}
        </Stack>
      </Paper>
    </Stack>
  );
};

export default QuestionAnswerBlock;
