import React from "react";
import MainContent from "../components/dashboard/MainContent";
import StatsPanel from "../components/dashboard/StatsPanel";

const DashBoard = () => {
    return (
      <>
      <MainContent />
      <StatsPanel />
      </>
    );
  };
  
  export default DashBoard;

          