// src/stores/cip/DatagenAiSyntheticStore.ts

import { makeAutoObservable, runInAction } from "mobx";
import { fetchJson } from "../utils/http";

export class MainPageStore {
  data: any = null;
  loading: boolean = false;
  error: string | null = null;

  constructor() {
    makeAutoObservable(this);
  }

  loadData = async () => {
    this.loading = true;
    this.error = null;

    try {
      const result = await fetchJson("https://jsonplaceholder.typicode.com/users");
      runInAction(() => {
        this.data = result;
        this.loading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
        this.loading = false;
      });
    }
  };
}

export const mainPageStore = new MainPageStore();
