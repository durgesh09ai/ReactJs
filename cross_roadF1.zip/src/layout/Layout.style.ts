import { Box, createTheme, Paper, styled } from "@mui/material";

export const theme = createTheme({
    palette: {
      primary: {
        main: "#0F4977",
      },
      secondary: {
        main: "#F3FAFF",
      },
      background: {
        default: "#F5F7FA",
        paper: "#FFFFFF",
      },
    },
    typography: {
      fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    },
    shape: {
      borderRadius: 8,
    },
  });
  
  // Styled Components
  export const RootBox = styled(Box)(({ theme }) => ({
    minHeight: "100vh",
    padding: theme.spacing(2),
    backgroundColor: theme.palette.background.default,
  }));
  
  export const ContentPaper = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.background.paper,
    overflow: "hidden",
    paddingBottom: theme.spacing(2),
    borderRadius: theme.shape.borderRadius * 2,
  }));
  
  interface SidebarContainerProps {
    sidebarCollapsed: boolean;
  }
  
  export const SidebarContainer = styled(Box, {
    shouldForwardProp: (prop) => prop !== "sidebarCollapsed",
  })<SidebarContainerProps>(({ sidebarCollapsed }) => ({
    width: sidebarCollapsed ? "80px" : "280px",
    flexShrink: 0,
    transition: "width 0.3s ease",
  }));
  
  export const CollapseToggleContainer = styled(Box)(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "50%",
    marginTop: theme.spacing(2),
    marginLeft: -theme.spacing(2),
    zIndex: 2,
  }));
  
  export const MainContent = styled(Box)(({ theme }) => ({
    width: "100%",
    flexGrow: 1,
  }));
  
  export const InnerContent = styled(Box)(({ theme }) => ({
    display: "flex",
    flexDirection: "column",
    padding: theme.spacing(4),
    [theme.breakpoints.down("md")]: {
      padding: theme.spacing(2),
    },
  }));
  
  export const OutletContainer = styled(Box)(({ theme }) => ({
    display: "flex",
    flexWrap: "wrap",
    gap: theme.spacing(2),
    height: "100%",
  }));