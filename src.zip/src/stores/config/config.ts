export const API_BASE_URL = process.env.BACKEND_API_URL || "http://localhost:8000";

//export const API_BASE_URL = process.env.BACKEND_API_URL || "https://navigator-bck-ehdvbgevdneybkga.canadacentral-01.azurewebsites.net";

