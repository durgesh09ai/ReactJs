import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import {
  Box,
  CssBaseline,
  ThemeProvider,
} from "@mui/material";
import DefaultSidebar from "./DefaultSidebar";
import DefaultHeader from "./DefaultHeader";
import { Outlet } from "react-router-dom";
import { ContentPaper, InnerContent, MainContent, OutletContainer, RootBox, SidebarContainer, theme } from "./BaseLayout.style";
import {mainPageStore } from "../../stores/MainPageStore"

interface BaseLayoutProps{
 header?:React.ReactNode;
 sidebar?: React.ReactNode;
}

const BaseLayout = observer((props?:BaseLayoutProps) => {

  const header = props?.header ?? <DefaultHeader/>
  const sidebar = props?.sidebar ?? <DefaultSidebar/>
  const { sidebarCollapsed }  = mainPageStore;

  //const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // const toggleSidebar = () => {
  //   setSidebarCollapsed(!sidebarCollapsed);
  // };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <RootBox>
        <ContentPaper>
          <Box sx={{ display: 'flex', height: '100%', width: '100%' }}>
            <SidebarContainer sidebarCollapsed={sidebarCollapsed}>
              {sidebar}
              </SidebarContainer>
            <MainContent sx={{borderLeft:"1px solid rgba(0,0,0,0.1)"}}>
              <Box sx={{ width: "100%" }}>
                {header}
                <InnerContent>
                  <OutletContainer>
                    <Outlet />
                  </OutletContainer>
                </InnerContent>
              </Box>
            </MainContent>
          </Box>
        </ContentPaper>
      </RootBox>
    </ThemeProvider>
  );
});

export default BaseLayout;
