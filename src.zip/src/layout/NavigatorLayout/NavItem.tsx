import React from "react";
import {
  ListItemIcon,
  ListItemText,
  Box,
  Collapse,
  List,
  ListItemButton,
  Typography,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import { useNavigate } from "react-router-dom";

interface SubItem {
  label: string;
  count?: number;
  href?: string;
}

interface NavItemProps {
  icon: string;
  label: string;
  collapsed?: boolean;
  subItems?: SubItem[];
  showCount?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({
  icon,
  label,
  collapsed,
  subItems = [],
  showCount = false,
}) => {
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate();

  const handleClick = (url?:string) => {
    navigate(`${url}`);
  };


  return (
    <Box>
      <ListItemButton onClick={() => setOpen(!open)}>
        <ListItemIcon sx={{ minWidth: 32, mr: 1 }}>
          <img src={icon} alt={label} width={20} height={20} />
        </ListItemIcon>
        {!collapsed && (
          <>
            <ListItemText
              primary={
                <Typography sx={{ fontSize: "14px" }}>
                  {label}
                </Typography>
              }
            />
            {subItems.length > 0 &&
              (open ? (
                <KeyboardArrowUpIcon fontSize="small" />
              ) : (
                <KeyboardArrowDownIcon fontSize="small" />
              ))}
          </>
        )}
      </ListItemButton>

      {/* Subitems */}
      {!collapsed && subItems.length > 0 && (
        <Collapse in={open} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {subItems.map((item, index) => (
              <ListItemButton
                key={index}
                sx={{ pl: 4 }}
                onClick={()=>handleClick(item.href)}
                // component="a"
                // href={item.href}
              >
                <ListItemText
                  primary={
                    <Typography sx={{ fontSize: "14px" }}>
                      {item.label}
                    </Typography>
                  }
                />
                {item.count !== undefined && (
                  <Typography
                    sx={{
                      bgcolor: "rgba(243,250,255,1)",
                      color: "#0F4977",
                      borderRadius: "4px",
                      px: 1,
                      ml: 1,
                      fontSize: "12px",
                      fontWeight: 800,
                    }}
                  >
                    {item.count}
                  </Typography>
                )}
              </ListItemButton>
            ))}
          </List>
        </Collapse>
      )}
    </Box>
  );
};

export default NavItem;