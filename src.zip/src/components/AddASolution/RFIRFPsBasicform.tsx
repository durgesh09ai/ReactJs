import React, { useState, useCallback, useEffect } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  Autocomplete,
  Checkbox,
  Chip,
  } from "@mui/material";
import { useDropzone } from "react-dropzone";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { mainPageStore } from "../../stores/MainPageStore";


const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}

interface dropDownItems {
  id:string;
  name:string;
}

const submissionType = [
  { key: "client-RFP", label: "Client RFP" },
  { key: "client-RFI", label: "Client RFI" },
  { key: "analyst-RFI", label: "Analyst RFI" },
  { key: "others", label: "Others" },
];

export const RFIRFPsBasicform: React.FC<BasicInfoFormProps> = ({ onSave }) => {

  const [clientList, setClientList] = useState<dropDownItems[]>([]);

  const [subTypeClient, setSubTypeClient] = useState<
  { key: string; label: string }[]
  >([]);
  
    const handleSubTypeDelete = (keyToDelete: string) => {
      setSubTypeClient((prev) => prev.filter((item) => item.key !== keyToDelete));
    };

  const {
    fetchByTechnologyOptions,
    technologyOptionsList,
   }  = mainPageStore;

   useEffect(()=>{
    fetchByTechnologyOptions();
   },[]);

   
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDrop = useCallback((acceptedFiles: File[]) => {
    const newImages = acceptedFiles.map(file => URL.createObjectURL(file));
    setFormData(prev => ({ ...prev, images: [...prev.images, ...newImages] }));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleDrop,
    accept: { "image/*": [] },
    multiple: true,
  });

  const handleSave = () => {
    if (onSave) {
      onSave(formData);
    }
  };
const [selectedClients, setSelectedClients] = useState<
    { id: string; name: string }[]
  >([]);

  const handleDelete = (keyToDelete: string) => {
    setSelectedClients((prev) => prev.filter((item) => item.id !== keyToDelete));
  };

  const [selectedSTag, setSelectedSTag] = useState<
  { id: string; name: string }[]
>([]);

const handleSTagDelete = (keyToDelete: string) => {
  setSelectedSTag((prev) => prev.filter((item) => item.id !== keyToDelete));
};

  
  const handleChipClick = () => {
  console.log("Chip clicked:");
};

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 1,
        minHeight: "382px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Start Your Story</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            gap: 4,
            width:'580px' 
          }}
        >
          {/* Left Column */}
          <Stack spacing={2} sx={{ flex: 1}}>
            <Box>
              <Typography variant="body2" gutterBottom>
               RFI/RFP Title 
              </Typography>
              <TextField
                required
                id="solutionName"
                name="solutionName"
                value={formData.solutionName}
                onChange={handleChange}
                placeholder="Enter RFI/RFP Title "
                fullWidth
                variant="outlined"
                size="small"
              />
            </Box>

        <Box>
            <Typography variant="body2" gutterBottom>
              Date of Submission  
            </Typography>
            <TextField
              required
              id="date-of-submission"
              name="date-of-submission"
              value={formData.solutionName}
              onChange={handleChange}
              placeholder="Enter Date of Submission"
              fullWidth
              variant="outlined"
              size="small"
            />
          </Box>

 <Box sx={{ width: 400 }}>
      <Typography variant="body2" gutterBottom>
      Submission Type 
      </Typography>

      <Autocomplete
        multiple
        options={submissionType}
        disableCloseOnSelect
        value={subTypeClient}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => setSubTypeClient(newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null} 
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select Submission Type"
            placeholder="Select Submission Type"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
          />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {subTypeClient.map((item) => (
          <Chip
            key={item.key}
            label={item.label}
            onClick={() => handleChipClick()}
            onDelete={() => handleSubTypeDelete(item.key)}
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>

    <Box sx={{ width: 400 }}>
      <Typography variant="body2" gutterBottom>
        Smart Tags
      </Typography>

      <Autocomplete
        multiple
        options={technologyOptionsList}
        disableCloseOnSelect
        value={selectedSTag}
        getOptionLabel={(option) => option.name}
        onChange={(event, newValue) => setSelectedSTag(newValue)}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        renderTags={() => null} // hide inline chips
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.name}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select Smart Tags"
            placeholder="Select Smart Tags"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
          />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {selectedSTag.map((item) => (
          <Chip
            key={item.id}
            label={item.name}
            onClick={() => handleChipClick()}
            onDelete={() => handleSTagDelete(item.id)}
            clickable={false} 
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>

          
          </Stack>

          {/* Right Column */}
          <Box sx={{ flex: 1,minWidth:"50%"}}>
            <Typography variant="body2" gutterBottom>
              Upload Card images.
            </Typography>
            <Box
              {...getRootProps()}
              sx={{
                border: "2px dashed rgba(15,73,119,0.5)",
                padding: 2,
                borderRadius: 2,
                textAlign: "center",
                cursor: "pointer",
                mt: 2,
                minHeight: "100px", // Optional: setting a height for the drop area
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >


<Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap" }}>
  {formData.images.map((img, idx) => (
    <Box
      key={idx}
      sx={{
        position: "relative",
        width: "40px",
        height: "40px",
        borderRadius: "10px",
        overflow: "hidden",
        border: "1px solid #ccc",
      }}
    >
      <img
        src={img}
        alt={`Upload preview ${idx}`}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
        }}
      />
      <IconButton
        size="small"
        sx={{
          position: "absolute",
          top: -4,
          right: -4,
          backgroundColor: "#fff",
          border: "1px solid #ccc",
          "&:hover": {
            backgroundColor: "#f5f5f5",
          },
        }}
        onClick={() => {
          setFormData((prev) => ({
            ...prev,
            images: prev.images.filter((_, i) => i !== idx),
          }));
        }}
      >
        <CloseIcon sx={{fontSize:12}}/>
      </IconButton>
    </Box>
  ))}
</Box>

              <input {...getInputProps()} />
              {isDragActive ? (
                <Typography variant="body2">Drop the files here ...</Typography>
              ) : (
                <img
                src="./add_file.svg"
                alt="Card image 2"
                style={{
                  width: "66px",
                  height: "auto",
                }}
              />              )}
            </Box>

          </Box>
        </Box>
      </Stack>


    </Paper>
  );
};