import React, { useState, useCallback } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  IconButton,
  Autocomplete,
  Checkbox,
  Chip,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CloseIcon from '@mui/icons-material/Close';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}


const exlDifferentiator = [
  { key: "reporting", label: "Reporting/MI" },
  { key: "strategy", label: "Strategy" },
  { key: "analytics", label: "Analytics Data Management" },
  { key: "modeling", label: "Modeling" },
  { key: "management", label: "Model Risk Management" },
  { key: "monitoring", label: "Model Monitoring" },
  { key: "engineering", label: "Data Engineering" },
  { key: "software", label: "Software Engineering" },
  { key: "others", label: "others" },
];

const valueProposition = [
  { key: "supplying-talent", label: "Supplying Talent" },
  { key: "influence-analytics-output", label: "Influence Analytics Output" },
  { key: "influence-business-outcomes", label: "Influence Business Outcomes" },
];

const licensingModel = [
  { key: "pmpm", label: "PMPM" },
  { key: "license-based", label: "License Based" },
  { key: "upfront-ongoing", label: "Upfront + Ongoing" },
  { key: "contingency-based ", label: "Contingency Based " },
];

const AIMLPenetration = [
  { key: "no-ai-ml", label: "No AI-ML" },
  { key: "basic-ml", label: "Basic ML" },
  { key: "advanced-ai-ml", label: "Advanced AI-ML" },
];

const degreeofClient = [
  { key: "no-advocacy", label: "No Advocacy" },
  { key: "internal-advocacy", label: "Internal Advocacy" },
  { key: "external-advocacy", label: "External Advocacy" },
];

export const AcceleratorDetailsForm: React.FC<BasicInfoFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

  const [selectedExlDiff, setSelectedExlDiff] = useState<
    { key: string; label: string }[]
  >([]);

  const [licenceModel, setLicenceModel] = useState<
    { key: string; label: string }[]
  >([]);

  const [valuePropos, setValuePropos] = useState<
    { key: string; label: string }[]
  >([]);

  const [AIPenetration, setAIPenetration] = useState<
  { key: string; label: string }[]
>([]);

const [degofClient, setDegofClient] = useState<
{ key: string; label: string }[]
>([]);

  const handleDelete = (keyToDelete: string) => {
    setSelectedExlDiff((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handleLicenceModelDelete = (keyToDelete: string) => {
    setLicenceModel((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handlesetValuePropDelete = (keyToDelete: string) => {
    setValuePropos((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handlesetAIPenetrationDelete = (keyToDelete: string) => {
    setAIPenetration((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handlesetDegofClientDelete = (keyToDelete: string) => {
    setDegofClient((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handleChipClick = () => {
    console.log("Chip clicked:");
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "220px", // You can reduce this further if needed
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "522px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Accelerator Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>


        <Stack spacing={2} sx={{ width: "100%",fontSize:12 }}>
      <Box sx={{ width: "100%" }}>
      <Typography variant="body2" gutterBottom>
       EXL Differentiator
      </Typography>

      <Autocomplete
        multiple
        options={exlDifferentiator}
        disableCloseOnSelect
        value={selectedExlDiff}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => setSelectedExlDiff(newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null} 
        renderOption={(props, option, { selected }) => (
          <li {...props} style={{fontSize:14}}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select EXL Differentiator"
            placeholder="Select EXL Differentiator"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
            />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {selectedExlDiff.map((item) => (
          <Chip
            key={item.key}
            label={item.label}
            onClick={() => handleChipClick()}
            onDelete={() => handleDelete(item.key)}
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>
    </Stack>


        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            columnGap: 2, // Reduce this gap even to 1 if needed
            rowGap: 2,
            justifyContent: "flex-start",
            alignItems: "flex-start",
            width:'100%' 
          }}
        >
          {/* Left Column */}

  <Stack spacing={2} sx={{ width: "100%",fontSize:12 }}>
    <Box sx={{ width: 260 }}>
      <Typography variant="body2" gutterBottom>
      Value Proposition
      </Typography>

      <Autocomplete
        multiple
        options={valueProposition}
        disableCloseOnSelect
        value={valuePropos}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => setValuePropos(newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null} 
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select Value Proposition"
            placeholder="Select Value Proposition"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
          />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {valuePropos.map((item) => (
          <Chip
            key={item.key}
            label={item.label}
            onClick={() => handleChipClick()}
            onDelete={() => handlesetValuePropDelete(item.key)}
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>

<Box>
<Typography variant="body2" gutterBottom>
Accelerator Description 
</Typography>
<TextField
id="clientName2"
name="clientName"
value={formData.clientName}
onChange={handleChange}
variant="outlined"
size="small"
sx={textFieldStyle}
InputProps={{ sx: inputStyle }}
placeholder="Enter Accelerator Detail"
multiline
rows={4}
maxRows={4}
style={{width:"320px"}}
/>
</Box>

<Box>
<Typography variant="body2" gutterBottom>
Time Saved or Benefits 
</Typography>
<TextField
id="clientName2"
name="clientName"
value={formData.clientName}
onChange={handleChange}
variant="outlined"
size="small"
sx={textFieldStyle}
InputProps={{ sx: inputStyle }}
placeholder="Enter Time Saved or Benefits"
multiline
rows={4}
maxRows={4}
style={{width:"320px"}}
/>
</Box>
 
  </Stack>

  {/* Right Column */}
    <Stack spacing={2} sx={{ width: "100%",fontSize:12  }}>
            <Box>
             
            </Box>

            <Box>
              <Typography variant="body2" gutterBottom>
              Value Proposition Description
              </Typography>
              <TextField
                id="clientName2"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Value Proposition Description"
                multiline
                rows={4}
                maxRows={4}
                style={{width:"320px"}}
              />
            </Box>

            <Box>
            <Typography variant="body2" gutterBottom>
            Use Case / Problem it Accelerates 
            </Typography>
            <TextField
            id="clientName2"
            name="clientName"
            value={formData.clientName}
            onChange={handleChange}
            variant="outlined"
            size="small"
            sx={textFieldStyle}
            InputProps={{ sx: inputStyle }}
            placeholder="Enter Use Case / Problem Accelerates"
            multiline
            rows={4}
            maxRows={4}
            style={{width:"320px"}}
            />
            </Box>

          </Stack>

         
        </Box>





      </Stack>
    </Paper>
  );
};
