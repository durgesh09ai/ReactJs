import React from "react";
import { Box, Button, Typography, Paper } from "@mui/material";

export const SuccessCard = () => {
  return (
    <Paper
      elevation={3}
      sx={{
        maxWidth: 408,
        mx: "auto",
        py: { xs: 6, md: 10 },
        px: { xs: 3, md: 6 },
        textAlign: "center",
        borderRadius: 4,
        backgroundImage: 'url("./thankyou.png")',
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <Box display="flex" flexDirection="column" alignItems="center">
        {/* Checked Image */}
        <Box
          component="img"
          src="./checked.png"
          alt="Checked"
          sx={{
            width: 114,
            height: 114,
            objectFit: "contain",
            borderRadius: "50%",
          }}
        />

        {/* Label Below the Checked Image */}
        <Typography
          variant="h6"
          fontWeight="medium"
          color="text.primary"
          sx={{ mt: 2 }}
        >
          Added a New Solution
        </Typography>

        {/* Confirmation Message */}
        <Typography
          variant="body1"
          sx={{ mt: 1, color: "#3A3A3A", opacity: 0.8 ,fontSize:"0.7rem"}}
        >
          Thank you! Solution added successfully.
        </Typography>

        {/* Continue Button */}
        <Button
          variant="contained"
          color="primary"
          sx={{
            mt: 4,
            textTransform: "none",
            width: 300, // Increased width
          }}
        >
          Continue
        </Button>
      </Box>
    </Paper>
  );
};
