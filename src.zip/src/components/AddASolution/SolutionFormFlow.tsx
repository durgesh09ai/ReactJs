import React, { useState } from "react";
import { Paper, Box } from "@mui/material";
import { SolutionTypeSelector } from "./SolutionTypeSelector";
import { ProgressStepper } from "./ProgressStepper";
import { BasicInfoForm } from "./BasicInfoForm";
import { CaseStudyDetailsForm } from "./CaseStudyDetailsForm";
import { TermAndGamification } from "./TermAndGamification";
import { ActionButtons } from "../ActionButtons";
import { TagSelector } from "./TagSelector";
import { AddUrlSection } from "./AddUrlSection";
import { Breadcrumb } from "./Breadcrumb";
import { SuccessCard } from "./SuccessCard";
import { SolutionBasicform } from "./SolutionBasicform";
import { CaseStudyTeamMemeber } from "./CaseStudyTeamMemeber";
import { ProductDetailsForm } from "./ProductDetailsForm";
import { FramworkBasicform } from "./FramworkBasicform";
import { AcceleratorBasicform } from "./AcceleratorBasicform";
import { AcceleratorDetailsForm } from "./AcceleratorDetailsForm";
import { ClientStoryBasicform } from "./ClientStoryBasicform";
import { ClientStoryDetailsForm } from "./ClientStoryDetailsForm";
import { RFIRFPsBasicform } from "./RFIRFPsBasicform";
import { RFIRFPDetailsForm } from "./RFIRFPDetailsForm";

interface Tag {
  id: string;
  label: string;
}

interface DocsUrl {
  id: string;
  label: string;
}

interface Category {
  id: string;
  label: string;
}

// Step config per solution type
const stepConfigMap: Record<
  string,
  { id: string; label: string; component: React.FC<{ onSave: () => void }> }[]
> = {
  "case-study": [
    { id: "basic", label: "Basic", component: SolutionBasicform },
    { id: "details", label: "Case Study Details", component: CaseStudyDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  "product": [
    { id: "basic", label: "Basic", component: SolutionBasicform },
    { id: "details", label: "Product Details", component: ProductDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  "framework": [
    { id: "basic", label: "Basic", component: FramworkBasicform },
    { id: "details", label: "Framework Details", component: ProductDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  "accelerator": [
    { id: "basic", label: "Basic", component: AcceleratorBasicform },
    { id: "details", label: "Accelerator Details", component: AcceleratorDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  "client-story": [
    { id: "basic", label: "Basic", component: ClientStoryBasicform },
    { id: "details", label: "Client-Story Details", component: ClientStoryDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  "RFI/RFPs": [
    { id: "basic", label: "Basic", component: RFIRFPsBasicform },
    { id: "details", label: "RFI/RFPs Details", component: RFIRFPDetailsForm },
    { id: "team", label: "Team Member Details", component: CaseStudyTeamMemeber },
  ],
  // Add other types as needed
};

const DocsUrls: DocsUrl[] = [];

const categories: Category[] = [
  { id: "23", label: "Insurance" },
  { id: "30", label: "Healthcare" },
  { id: "31", label: "Banking and Capital Markets" },
  { id: "32", label: "Growth Markets" },
];

export const SolutionFormFlow: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSolutionType, setSelectedSolutionType] = useState("case-study");
  const [selectedDocsUrl, setSelectedDocsUrl] = useState<DocsUrl[]>(DocsUrls);

  const breadcrumbItems = [
    { label: "Home", href: "/" },
    { label: "Add a project" },
  ];

  const handleSolutionTypeChange = (typeId: string) => {
    setSelectedSolutionType(typeId);
    setCurrentStep(1); // Reset step when solution type changes
  };

  const steps = stepConfigMap[selectedSolutionType] || [];
  const totalSteps = steps.length;
  const currentStepConfig = steps[currentStep - 1];

  const handleNext = () => {
    if (currentStep < totalSteps + 1) setCurrentStep((prev) => prev + 1);
  };

  const handlePrevious = () => {
    if (currentStep > 1) setCurrentStep((prev) => prev - 1);
  };

  const handleSave = () => {
    console.log("Saving...");
  };

  const handleDocUrlSelect = (docsUrl: DocsUrl) => {
    if (!selectedDocsUrl.some((t) => t.id === docsUrl.id)) {
      setSelectedDocsUrl([...selectedDocsUrl, docsUrl]);
    }
  };

  const handleDocUrlRemove = (docsUrlId: string) => {
    setSelectedDocsUrl(selectedDocsUrl.filter((d) => d.id !== docsUrlId));
  };

  // 🎉 Completed screen
  if (currentStep > totalSteps) {
    return (
      <Box sx={{ py: 1 }}>
        <Paper
          elevation={0}
          sx={{
            mt: 4,
            p: 4,
            bgcolor: "#0F4977",
            borderRadius: "20px",
            border: "1px solid rgba(15,73,119,1)",
          }}
        >
          <SuccessCard />
        </Paper>
      </Box>
    );
  }

  return (
    <Box sx={{ py: 1 }}>
      <Breadcrumb items={breadcrumbItems} />

      <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          bgcolor: "rgba(243,250,255,1)",
          borderRadius: "20px",
          border: "1px solid rgba(15,73,119,1)",
        }}
      >
        <SolutionTypeSelector
          options={Object.keys(stepConfigMap).map((id) => ({
            id,
            label: id.replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase()),
          }))}
          defaultSelected={selectedSolutionType}
          onChange={handleSolutionTypeChange}
          disabled={currentStep !== 1} 
        />

    <Paper
        elevation={0}
        sx={{
          mt: 2,
          p: 2,
          bgcolor: "#fff",
          borderRadius: "16px",
          border: "1px solid #fff",
        }}
      >
          <Box sx={{display: "flex",width: "100%", fontSize:12 }}>
          <img src="/image604.png" width="16px" height="16px"/>A proven solution implemented or currently an active engagement. It could be custom implementation, CoE, accelerators, products, frameworks deployed for customer. .
        </Box>
        </Paper>

        <Paper elevation={0} sx={{ mt: 1, p: 1, borderRadius: 2 }}>
          <ProgressStepper
            steps={steps.map((step, idx) => ({
              ...step,
              completed: idx < currentStep,
              active: idx === currentStep - 1,
            }))}
            currentStep={currentStep}
            totalSteps={totalSteps}
          />

          <Box
            sx={{
              display: "flex",
              flexDirection: { xs: "column", md: "row" },
              gap: 2,
              mt: 2,
              width: "100%",
            }}
          >
            {/* Left column */}
            <Box sx={{ flex: 7, minWidth: 0 }}>
              {currentStepConfig?.component && (
                <currentStepConfig.component onSave={handleSave} />
              )}

              <Box sx={{ mt: 1 }}>
                <ActionButtons
                  onPrevious={handlePrevious}
                  onSave={handleSave}
                  onNext={handleNext}
                  isPreviousDisabled={currentStep === 1}
                  isNextDisabled={currentStep > totalSteps}
                />
              </Box>
            </Box>

            {/* Right column */}
            <Box sx={{ flex: 3, minWidth: 0 }}>
              {currentStepConfig?.id === "basic" && (
                <TagSelector/>
              )}
              {currentStepConfig?.id === "details" && (
                <AddUrlSection
                  selectedDocsUrl={selectedDocsUrl}
                  onDocUrlSelect={handleDocUrlSelect}
                  onDocUrlRemove={handleDocUrlRemove}
                />
              )}
            </Box>
          </Box>
        </Paper>
      </Paper>
    </Box>
  );
};