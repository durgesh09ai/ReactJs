import React, { useState, useCallback } from "react";
import {
  Box,
  TextField,
  Typography,
  Paper,
  Stack,
  IconButton,
  Autocomplete,
  Checkbox,
  Chip,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CloseIcon from '@mui/icons-material/Close';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

interface BasicInfoFormProps {
  onSave?: (formData: FormData) => void;
}

interface FormData {
  solutionName: string;
  clientName: string;
  tags: string;
  images: string[];
}

const degreeofClientAdvocacy= [
  { key: "no-advocacy", label: "No Advocacy" },
  { key: "internal-advocacy", label: "Internal Advocacy" },
  { key: "external-advocacy", label: "External Advocacy" },
];

const solutionsInvolved  = [
  { key: "case-studies", label: "Case Studies" },
  { key: "accelerator", label: "Accelerator" },
  { key: "framework", label: "Framework" },
  { key: "product", label: "Product" },
  { key: "rfi-rfp", label: "RFI/RFP" },
];

export const ClientStoryDetailsForm: React.FC<BasicInfoFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<FormData>({
    solutionName: "",
    clientName: "",
    tags: "",
    images: [],
  });

const [degofClient, setDegofClient] = useState<
{ key: string; label: string }[]
>([]);

const [solInvolved, setSolInvolved] = useState<
{ key: string; label: string }[]
>([]);

  const handleSolInvolvedDelete = (keyToDelete: string) => {
    setSolInvolved((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handlesetDegofClientDelete = (keyToDelete: string) => {
    setDegofClient((prev) => prev.filter((item) => item.key !== keyToDelete));
  };

  const handleChipClick = () => {
    console.log("Chip clicked:");
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const inputStyle = {
    fontSize: "13px",
    "&::placeholder": {
      fontSize: "12px",
    },
  };

  const textFieldStyle = {
    width: "220px", // You can reduce this further if needed
  };

  return (
    <Paper
      elevation={0}
      sx={{
        width: { xs: "100%", md: "704px" },
        flexGrow: 1,
        p: 2,
        minHeight: "480px",
      }}
    >
      <Stack spacing={2}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <img
            src="./formIcon.png"
            alt="Start icon"
            style={{ width: "20px", height: "20px" }}
          />
          <Typography variant="subtitle1">Client Story Details</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          General Information
        </Typography>

        <Box
          sx={{
            display: "flex",
            flexDirection: { xs: "column", md: "row" },
            columnGap: 2, // Reduce this gap even to 1 if needed
            rowGap: 2,
            justifyContent: "flex-start",
            alignItems: "flex-start",
            width:'100%' 
          }}
        >
          {/* Left Column */}

  <Stack spacing={2} sx={{ width: "100%",fontSize:12 }}>
  
        <Box>
          <Typography variant="body2" gutterBottom>
          Opportunity
          </Typography>
          <TextField
            id="clientName2"
            name="clientName"
            value={formData.clientName}
            onChange={handleChange}
            variant="outlined"
            size="small"
            sx={textFieldStyle}
            InputProps={{ sx: inputStyle }}
            placeholder="Enter Opportunity Detail"
            multiline
            rows={4}
            maxRows={4}
            style={{width:"320px"}}
          />
        </Box>

    <Box sx={{ width: 320 }}>
      <Typography variant="body2" gutterBottom>
      Degree of client advocacy
      </Typography>

      <Autocomplete
        multiple
        options={degreeofClientAdvocacy}
        disableCloseOnSelect
        value={degofClient}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => setDegofClient(newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null} 
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select Licensing Model"
            placeholder="Select Licensing Model"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
          />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {degofClient.map((item) => (
          <Chip
            key={item.key}
            label={item.label}
            onClick={() => handleChipClick()}
            onDelete={() => handlesetDegofClientDelete(item.key)}
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>
 
  </Stack>

  {/* Right Column */}
    <Stack spacing={2} sx={{ width: "100%",fontSize:12  }}>

            <Box>
              <Typography variant="body2" gutterBottom>
              Storyline Editor
              </Typography>
              <TextField
                id="clientName2"
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                variant="outlined"
                size="small"
                sx={textFieldStyle}
                InputProps={{ sx: inputStyle }}
                placeholder="Enter Value Proposition Description"
                multiline
                rows={4}
                maxRows={4}
                style={{width:"320px"}}
              />
            </Box>

            <Box sx={{ width: 320 }}>
      <Typography variant="body2" gutterBottom>
      Solutions Involved 
      </Typography>

      <Autocomplete
        multiple
        options={solutionsInvolved}
        disableCloseOnSelect
        value={solInvolved}
        getOptionLabel={(option) => option.label}
        onChange={(event, newValue) => setSolInvolved(newValue)}
        isOptionEqualToValue={(option, value) => option.key === value.key}
        renderTags={() => null} 
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.label}
          </li>
        )}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label="Select Licensing Model"
            placeholder="Select Licensing Model"
            size="small"
            InputLabelProps={{
              sx:{fontSize:14},
            }}
          />
        )}
      />

      {/* Display selected items as chips */}
      <Box sx={{ mt: 1, display: "flex", gap: 1, flexWrap: "wrap" }}>
        {solInvolved.map((item) => (
          <Chip
            key={item.key}
            label={item.label}
            onClick={() => handleChipClick()}
            onDelete={() => handleSolInvolvedDelete(item.key)}
            color="primary"
            variant="outlined"
            size="small"
          />
        ))}
      </Box>
    </Box>


          </Stack>

         
        </Box>

        <Box>
    <Typography variant="body2" gutterBottom>
    Results / Outcomes
    </Typography>
    <TextField
      id="clientName2"
      name="clientName"
      value={formData.clientName}
      onChange={handleChange}
      variant="outlined"
      size="small"
      sx={textFieldStyle}
      InputProps={{ sx: inputStyle }}
      placeholder="Enter Results / Outcomes"
      multiline
      rows={4}
      maxRows={4}
      style={{width:"680px"}}
    />
  </Box>



      </Stack>
    </Paper>
  );
};
