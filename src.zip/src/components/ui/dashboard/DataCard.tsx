
import React from "react";
import { Box, Card, Typography, SxProps, Theme } from "@mui/material";

interface DataCardProps {
  icon: string;
  label: string;
  value: string;
  labelSx?: SxProps<Theme>;
}

const DataCard = ({ icon, label, value, labelSx }: DataCardProps) => {
  return (
    <Card 
    sx={{
      p: 2,
      display: 'flex',
      alignItems: 'center',
      gap: 2,
      borderRadius: 2,
      height: '100%',
      backgroundColor: 'rgba(243,250,255,1)', // keep or customize this
      border: 'none', // ⛔ removes the border
      boxShadow: 'none' // ⛔ removes the shadow
    }}
  >
  
      <Box
        sx={{
          width: 28,
          height: 28,
          border:"1px solid",
          borderColor:"#FDF4EE",
          bgcolor: "#fff",
          p: 3,
          pt:3.5,
          pb:3.5,  
          borderRadius: "8px", 
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
      <Box
        component="img"
        src={icon}
        alt={label}
        sx={{ width: 14, height: 14 }}
      />
    </Box>

      <Box sx={{ flex: 1 }}>
      <Typography 
  variant="body2"
  sx={{ 
    color: '#000',
    fontSize: '14px',
    fontStyle: 'normal',
    fontWeight: 500,
    lineHeight: 'normal',
    ...labelSx
  }}
>
  {label}
</Typography>
        <Typography 
          variant="h6" 
          sx={{
            fontSize: '24px',
            fontWeight: 500,
            color: '#000',
          }}
        >
          {value}
        </Typography>
      </Box>
    </Card>
  );
};

export default DataCard;
