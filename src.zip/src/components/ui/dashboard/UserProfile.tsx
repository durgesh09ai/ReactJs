import React from "react";
import { Box, Typography, Avatar, Paper } from "@mui/material";

interface UserProfileProps {
  name: string;
  role: string;
  avatar: string;
  points: number;
}

const UserProfile: React.FC<UserProfileProps> = ({
  name,
  role,
  avatar,
  points,
}) => {
  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "white",
        border: "1px solid #F5F5F5",
        borderRadius: 2,
        px: 2,
        py: 3,
        mt: "19px",
        mb: "19px",
        width: "100%",
      }}
    >
      {/* Profile section */}
      <Box display="flex" alignItems="center" gap={2.5} px={2}>
        <Box sx={{ width: 90 }}>
          <Avatar
            src={avatar}
            alt={name}
            sx={{
              width: 90,
              height: 90,
              borderRadius: 0,
              objectFit: "contain",
            }}
            variant="square"
          />
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            color: "rgba(52,52,52,1)",
            fontSize: "0.80rem",
            width: 155,
          }}
        >
          <Typography fontWeight={600} fontSize="0.8rem">
            {name}
          </Typography>
          <Typography fontWeight={500} mt={1} fontSize="0.80rem">
            {role}
          </Typography>

          <Box display="flex" alignItems="center" gap={1} mt={1}>
            <Box display="flex" alignItems="center" gap={0.5} fontWeight={600}>
              <Avatar
                src="./points.svg"
                alt="Points"
                sx={{
                  width: 14,
                  height: 14,
                  boxShadow: "0px 1px 4px rgba(110,116,134,0.12)",
                }}
              />
              <Typography fontSize="0.80rem">{points}</Typography>
            </Box>
            <Typography fontWeight={400} fontSize="0.80rem">
              Points
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Goals section */}
      <Box
        mt="30px"
        p={1.5}
        display="flex"
        alignItems="center"
        gap={1}
        bgcolor="rgba(243,250,255,1)"
        borderRadius={2}
        fontWeight={500}
        fontSize="0.80rem"
        color="black"
      >
        <Avatar
          src="./goal.png"
          alt="Goal"
          sx={{ width: 16, height: 16 }}
          variant="square"
        />
        <Typography fontSize="0.80rem" fontWeight={600}>Goals in a Month:</Typography>
        <Typography fontSize="0.80rem">Read 6 case studies</Typography>
      </Box>
    </Paper>
  );
};

export default UserProfile;
