import React, { useState, useEffect } from "react";
import {
  Paper,
  Box,
  Typography,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { observer } from "mobx-react-lite";
import { mainPageStore } from "../../stores/MainPageStore";
import SetupHeader from "./SetupHeader";

const columnWidths = [
  "30px", // S.NO
  "190px", // Solution Name
  "90px", // Type
  "125px", // IMU
  "125px", // SGU
  "150px", // Created On
  "70px", // Status
  "40px",  // Views
  "50px",  // Actions
];

const SolutionPanel: React.FC = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const productPerPage = 4;
  const start = (currentPage - 1) * productPerPage;

  const {
    fetchSolutionListData,
    solutionListData,
    solutionlistloading
  } = mainPageStore;

  useEffect(() => {
    fetchSolutionListData(start, productPerPage);
  }, [currentPage]);

  const isMenuOpen = Boolean(anchorEl);
  const solutionlist = solutionListData?.result ?? [];

  const columnTitles = [
    "S.No",
    "Solution Name",
    "Type",
    "IMU",
    "SGU",
    "Created On",
    "Status",
    "Views",
    "Actions",
  ];

  return (
    <Paper elevation={1} sx={{ maxWidth: "100%", pb: 2, px: 1, borderRadius: 1 }}>
      <SetupHeader title="My Solution" />

      <Paper
        elevation={0}
        sx={{
          border: "1px solid rgba(18,18,21,0.10)",
          borderRadius: 0,
          padding: 0,
          overflowX: "auto",
        }}
      >
        {/* Header Row */}
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: columnWidths.join(" "),
            alignItems: "center",
            backgroundColor: "#0F4977",
            color: "#fff",
            px: 2,
            py: 1,
            fontSize: 12,
            fontWeight: 400,
          }}
        >
          {columnTitles.map((title, index) => (
            <Typography
              key={index}
              sx={{ fontSize:12, textAlign: index === columnTitles.length - 1 ? "right" : "left" }}
            >
              {title}
            </Typography>
          ))}
        </Box>

        {solutionlistloading && solutionlist.length==0 && 
        <Box sx={{display:"flex", justifyContent:"center", alignItems:"center", width:"60%", height:55}}>Loading<img src="/loader3.gif"/></Box>    
        }

        {/* Data Rows */}
        {solutionlist.map((item: any,index:number) => (
          <Box
            key={item.id}
            sx={{
              display: "grid",
              gridTemplateColumns: columnWidths.join(" "),
              alignItems: "center",
              px: 2,
              py: 0.5,
              borderBottom: "1px solid #f0f0f0",
              fontSize: 12,
              fontWeight:400,
            }}
          >
           
          
            <Typography sx={{fontSize:12}}>{index + 1}.</Typography>
            <Typography sx={{fontSize:12}}>{item.name}</Typography>
            <Typography sx={{fontSize:12}}>{item.solution_type || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{item.imu[0]?.name || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{item.sgu[0]?.name || "—"}</Typography>
            <Typography sx={{fontSize:12}}>{item.createdDate || "—"}</Typography>
            <Typography sx={{fontSize:12}}>Active</Typography>
            <Typography sx={{fontSize:12}}>{item.views}</Typography>

            <Box sx={{ display: "flex", justifyContent: "flex-end"}}>
              <IconButton
                size="small"
                onClick={(e) => setAnchorEl(e.currentTarget)}
              >
                <MoreVertIcon  sx={{fontSize:14}} />
              </IconButton>
              <Menu
                anchorEl={anchorEl}
                open={isMenuOpen}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
              >
                <MenuItem onClick={() => setAnchorEl(null)} sx={{fontSize:12 }}>
                  <EditIcon fontSize="small" sx={{ mr: 1 ,fontSize:12 }} /> Edit
                </MenuItem>
                <MenuItem onClick={() => setAnchorEl(null)} sx={{fontSize:12 }}>
                  <DeleteIcon fontSize="small" sx={{ mr: 1,fontSize:12  }} /> Archive
                </MenuItem>
              </Menu>
            </Box>
          </Box>
        ))}
      </Paper>
    </Paper>
  );
};

export default observer(SolutionPanel);