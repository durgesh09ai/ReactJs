import React from "react";
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
} from "@mui/material";

interface SidebarItemProps {
  icon: string;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

interface SidebarProps {
  selectedLabel: string;
  onSelect: (label: string) => void;
}


const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  isActive = false,
  onClick,
}) => {
  return (
    <ListItem disablePadding sx={{ mt: 1 }}>
      <ListItemButton
        onClick={onClick}
        sx={{
          bgcolor: isActive ? "#FFF" : "white",
          borderRadius: 1,
          py: 0.75,
          minHeight: "41px",
          "&:hover": {
            backgroundColor: "#E0F0FF",
          },
        }}
      >
        <ListItemIcon sx={{ minWidth: 40 }}>
          <Box
            component="img"
            src={icon}
            alt={label}
            sx={{ width: 24, height: 24 }}
          />
        </ListItemIcon>
        <ListItemText
          primary={label}
          primaryTypographyProps={{ variant: "body2" }}
        />
      </ListItemButton>
    </ListItem>
  );
};


const Sidebar: React.FC<SidebarProps> = ({ selectedLabel, onSelect }) => {
  const items = [
    {
      icon: "/userIcon.svg",
      label: "User Profile",
    },
    {
      icon: "/solutionIcon.svg",
      label: "Manage Solutions",
    },
    {
      icon: "/logout.svg",
      label: "Logout",
    },
  ];

  return (
    <Paper
      sx={{
        width: "220px",
        height:"440px",
        minWidth: "220px",
        borderRadius: 1,
        p: 1,
        fontSize: "0.875rem",
        fontWeight: "normal",
        lineHeight: 1.2,
      }}
    >
      <Typography
        sx={{
          borderBottom: "1px solid #E4E4E5",
          p: 1,
          color: "black",
          fontSize: 14,
          fontWeight: 400,
          textAlign: "center",
        }}
      >
        Settings
      </Typography>

      <List sx={{ p: 0 }}>
        {items.map((item) => (
          <SidebarItem
            key={item.label}
            icon={item.icon}
            label={item.label}
            isActive={selectedLabel === item.label}
            onClick={() => onSelect(item.label)}
          />
        ))}
      </List>
    </Paper>
  );
};

export default Sidebar;
