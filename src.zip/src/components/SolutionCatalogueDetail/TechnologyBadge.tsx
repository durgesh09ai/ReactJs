import React from "react";
import Chip from "@mui/material/Chip";
import { SxProps, Theme } from "@mui/material/styles";

type BadgeVariant = "blue" | "yellow" | "orange";
type BadgeSize = "sm" | "md";

interface TechnologyBadgeProps {
  label: string;
  variant?: BadgeVariant;
  size?: BadgeSize;
}

// Variant styles: must be valid CSS props
const variantStyleMap: Record<BadgeVariant, React.CSSProperties> = {
  blue: {
    backgroundColor: "rgba(59,130,246,0.10)",
    color: "#0F4977",
    fontWeight: 400,
  },
  yellow: {
    backgroundColor: "rgba(234,179,8,0.10)",
    color: "#b45309",
    fontWeight: 600,
  },
  orange: {
    backgroundColor: "rgba(255,209,180,1)",
    color: "rgba(245,109,25,1)",
    fontWeight: 600,
  },
};

// Size styles: plain CSS values
const sizeStyleMap: Record<BadgeSize, React.CSSProperties> = {
  sm: {
    fontSize: "10px",
    height: 24,
    paddingLeft: 8,
    paddingRight: 8,
    fontWeight: "bold",
  },
  md: {
    fontSize: "14px",
    height: 32,
    fontWeight: 500,
  },
};

export const TechnologyBadge: React.FC<TechnologyBadgeProps> = ({
  label,
  variant = "blue",
  size = "md",
}) => {
  const combinedStyles: SxProps<Theme> = {
    borderRadius: "16px", // <- must be string or number
    textAlign: "center",
    fontSize:"10px",
    ...variantStyleMap[variant],
  };

  return <Chip label={label} sx={combinedStyles} />;
};
