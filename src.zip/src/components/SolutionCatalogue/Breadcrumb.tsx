import React from "react";
import { Box, Typography } from "@mui/material";

interface BreadcrumbItem {
  label: string;
  active?: boolean;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({ items }) => {
  return (
    <Box display="flex" alignItems="center" gap={1}>
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && (
            <img
              src="/breadcum_arrow.svg"
              alt="separator"
              style={{ width: 20 }}
            />
          )}
          <Typography
            sx={{
              color: '#0F4977',
              fontWeight: item.active ? 600 : 500,
              fontSize: '12px',
              whiteSpace: 'nowrap',
              height:'20px',
            }}
          >
            {item.label}
          </Typography>
        </React.Fragment>
      ))}
    </Box>
  );
};

export default Breadcrumb;
