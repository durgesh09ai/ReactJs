import React from "react";
import {
  Box,
  Typography,
  Chip,
  Card,
  CardMedia,
  Button,
  Stack,
  Avatar,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import ThumbUpAltOutlinedIcon from '@mui/icons-material/ThumbUpAltOutlined';

interface ProjectCardProps {
  id:string;
  name: string;
  description: string;
  tags?: string[];
  profile_img: string;
  likes_count?: number;
  comments_count?: string;
  // badgeIconSrc: string;
  // likeIconSrc: string;
  // starIconSrc: string;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  id,
  name,
  description,
  tags,
  profile_img,
  likes_count,
  comments_count,
  // badgeIconSrc,
  // likeIconSrc,
  // starIconSrc,
}) => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/solutioncataloguedetail");
  };


  const starIconSrc = '/threedot.svg';
  const likeIconSrc = '/bookmark.svg';
 // const tags = ['Underwriting','Payer'];
  const imageSrc = '/project_image.png';
  const contributorCount = 2;
  const commentCount = 2;

  return (
    <Card
      elevation={0}
      sx={{
        width: "100%", 
        borderRadius: 4,
        border: "1px solid rgba(172,172,172,0.2)",
        p: 2,
        position: "relative",
        bgcolor: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Star and Like Icons */}
      <Stack 
  direction="row" 
  spacing={1} 
  alignItems="center" 
  justifyContent="flex-end"  // <-- ADD THIS
  sx={{ minHeight: 24 }}
>
  <Avatar src={`${starIconSrc}`} alt="star icon" sx={{ width: 16, height: 16 }} />
  <Avatar src={`${likeIconSrc}`} alt="like icon" sx={{ width: 16, height: 16 }} />
</Stack>

      {/* Tags */}
      <Stack direction="row" spacing={1} mt={1} flexWrap="wrap">
        {tags && tags.map((tag, index) => (
          <Chip
            key={index}
            label={tag}
            size="small"
            sx={{
              fontSize: 12,
              fontWeight:500,
              bgcolor: index === 0 ? "rgba(233,243,249,1)" : "rgba(15,73,119,0.1)",
              color: "rgba(15,73,119,1)",
              borderRadius: "999px",
              height: 20,
            }}
          />
        ))}
      </Stack>

      {/* Image with Floating Badge */}
      <Box
        sx={{
          position: "relative",
          mt: 2,
          cursor: "pointer",
          overflow: "hidden",
        }}
        onClick={handleClick}
      >
        <CardMedia
          component="img"
          image={`${imageSrc}`}
          alt={name}
          sx={{ aspectRatio: "1.91", borderRadius: 2 }}
        />
        <Avatar
          src="/new_badge.png"
          alt="floating badge"
          sx={{
            position: "absolute",
            top: 8,
            left: 2,
            width: 25,
            height: 25,
            zIndex: 2,
          }}
        />
      </Box>

      {/* Title and Description */}
      <Box mt={2}>
        <Typography variant="subtitle2" fontWeight="500" fontSize={14}>
          {name}
        </Typography>
        <Typography
          variant="body2"
          color="text.secondary"
          mt={0.5}
          sx={{ fontSize: 12,fontWeight:400 }}
        >
          {description}
        </Typography>
      </Box>

      {/* Contributors and Comments */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mt={2}
      >
        <Stack direction="row" spacing={1} alignItems="center">
        <ThumbUpAltIcon sx={{ fontSize: 16, color: '#FB4E0B' }} />

          <Typography variant="caption" color="#676767">
            {likes_count ?? 0 }
          </Typography>
        </Stack>
        <Typography variant="caption" color="#676767">
          {comments_count ?? 0 } Comments
        </Typography>
      </Stack>

      {/* Comment Button and Badge Icon */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mt={2}
      >
        <Button
          variant="contained"
          sx={{
            boxShadow: "none",
            bgcolor: "rgba(15,73,119,0.1)",
            color: "#0F4977",
            borderRadius: "20px",
            px: 2,
            py: 1,
            textTransform: "none",
            fontSize: 14,
            fontWeight:400,
            ":hover": {
              bgcolor: "rgba(15,73,119,0.2)",
            },
          }}
        >
          Add a Comment
        </Button>
        <ThumbUpAltOutlinedIcon sx={{ fontSize: 16, color: '#000000' }} />

      </Stack>
    </Card>
  );
};
