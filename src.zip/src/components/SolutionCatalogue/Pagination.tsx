import React from "react";
import { Button, IconButton, Stack } from "@mui/material";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
}) => {
  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <Stack direction="row" spacing={1} alignItems="center" justifyContent="center" mt={4}>
      {/* Previous Button */}
      <IconButton
        onClick={handlePrevious}
        disabled={currentPage === 1}
        aria-label="Previous page"
        sx={{
          width: 32,
          height: 32,
          bgcolor: "white",
          border: "1px solid rgba(119, 122, 125, 0.5)",
          color: "#C4CDD5",
          borderRadius: 0, // 👈 no border radius = square button
          "&:hover": {
            bgcolor: "#f0f0f0",
          },
        }}
      >
        <NavigateBeforeIcon />
      </IconButton>

      {/* Page Buttons */}
      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
        const isActive = page === currentPage;

        return (
          <Button
            key={page}
            variant={isActive ? "contained" : "outlined"}
            size="small"
            onClick={() => onPageChange(page)}
            aria-label={`Page ${page}`}
            aria-current={isActive ? "page" : undefined}
            sx={{
              minWidth: 32,
              height: 32,
              padding: "5px",
              backgroundColor: isActive ? "rgba(15,73,119,1)" : "white",
              color: isActive ? "white" : "#212B36",
              borderColor: "rgba(15,73,119,1)",
              fontSize: "0.75rem",
              fontWeight: 700,
              borderRadius: 0, // 👈 optional: page number buttons also square
              "&:hover": {
                backgroundColor: isActive ? "rgba(15,73,119,0.9)" : "#f0f0f0",
              },
            }}
          >
            {page}
          </Button>
        );
      })}

      {/* Next Button */}
      <IconButton
        onClick={handleNext}
        disabled={currentPage === totalPages}
        aria-label="Next page"
        sx={{
          width: 32,
          height: 32,
          bgcolor: "white",
          border: "1px solid rgba(119, 122, 125, 0.5)",
          color: "#C4CDD5",
          borderRadius: 0, // 👈 no border radius = square button
          "&:hover": {
            bgcolor: "#f0f0f0",
          },
        }}
      >
        <NavigateNextIcon />
      </IconButton>
    </Stack>
  );
};
