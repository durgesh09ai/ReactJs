import React from "react";
import MainContent from "../components/dashboard/MainContent";
import StatsPanel from "../components/dashboard/StatsPanel";
import { Box } from "@mui/material";

const DashBoard = () => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: { xs: "column", md: "row" },
        gap: 2,
        width: "100%",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          flexGrow: 1,
          minWidth: 0, 
        }}
      >
        <MainContent />
      </Box>

      <Box
        sx={{
          // width: "100%",
          flexShrink: 0, 
        }}
      >
        <StatsPanel />
      </Box>
    </Box>
  );
};

export default DashBoard;
