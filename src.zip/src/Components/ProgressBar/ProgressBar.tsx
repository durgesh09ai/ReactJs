import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";

interface ContentProps {
  backgroundColor: string;
}

export const ProgressBar = ({ backgroundColor }: ContentProps) => (
    <Box sx={{ width: 300, p: 2, backgroundColor, color: "#fff", height: "100vh" }}>
      <Typography sx={{ fontSize: "14px", color: "#ECECF1",textAlign: "center" }}>Agent Process Status</Typography>
      <Paper sx={{ p: 2, mt: 2, textAlign: "center", backgroundColor: backgroundColor === "#222" ? "#333" : "#aaa" }}>
        <Typography sx={{ fontSize: "12px", color: "#ECECF1",textAlign: "center" }}>Fetching from ..</Typography>
      </Paper>
    </Box>
  );