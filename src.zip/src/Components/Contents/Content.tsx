import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch, TextField, InputAdornment } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import SendIcon from "@mui/icons-material/Send";

interface ContentProps {
  backgroundColor: string;
}

export const Content = ({ backgroundColor }: ContentProps) => {
  const [messages, setMessages] = useState<{ user: string; model: string }[]>([]);
  const [inputValue, setInputValue] = useState("");

  const handleSend = () => {
    if (inputValue.trim()) {
      const userMessage = inputValue;
      setMessages([...messages, { user: userMessage, model: "This is a model response." }]);
      setInputValue("");
    }
  };

  return (
    <Box sx={{ flexGrow: 1, p: 3, color: "#fff", backgroundColor, minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
      <Box>
        <Toolbar />
        <Box sx={{ display: "flex", justifyContent: "center", mb: 4 }}>
          <Paper
            sx={{
              p: 2,
              backgroundColor: backgroundColor === "#121212" ? "#333" : "#bbb",
              color: "#fff",
              textAlign: "center"
            }}
          >
            <Typography sx={{ fontSize: "22px", fontWeight: 600, color: "#ECECF1" }} gutterBottom>
              Hello Durgesh, Welcome to Litsense.
            </Typography>
          </Paper>
        </Box>
        <Box sx={{ px: 4 }}>
          {messages.map((msg, index) => (
            <React.Fragment key={index}>
              <Paper sx={{ p: 2, mb: 1, backgroundColor: backgroundColor === "#121212" ? "#444" : "#ccc" }}>
                <Typography sx={{ fontSize: "16px", color: "#ECECF1" }}>{msg.user}</Typography>
              </Paper>
              <Paper sx={{ p: 2, mb: 2, backgroundColor: backgroundColor === "#121212" ? "#333" : "#bbb" }}>
                <Typography sx={{ fontSize: "16px", color: "#ECECF1" }}>{msg.model}</Typography>
              </Paper>
            </React.Fragment>
          ))}
        </Box>
      </Box>
      <Box sx={{ display: "flex", justifyContent: "center", width: "100%", mb: 2, position: "relative" }}>
        <TextField
          variant="outlined"
          placeholder="Type your message..."
          multiline
          rows={4}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton sx={{ color: "#fff" }} onClick={handleSend}>
                  <SendIcon />
                </IconButton>
              </InputAdornment>
            )
          }}
          sx={{
            width: "100%",
            maxWidth: 800,
            backgroundColor: backgroundColor === "#121212" ? "#343541" : "#e0e0e0",
            borderRadius: 2,
            border: "1px solid #444",
            color: "#fff",
            '& .MuiOutlinedInput-root': {
              color: "#fff",
              '& fieldset': {
                borderColor: "#444"
              },
              '&:hover fieldset': {
                borderColor: "#444"
              },
              '&.Mui-focused fieldset': {
                borderColor: "#444"
              }
            },
            '& .MuiInputBase-input': {
              color: "#ECECF1",
              fontSize: "16px"
            }
          }}
        />
      </Box>
    </Box>
  );
};