import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import { Content } from "../Components/Contents/Content";
import { ProgressBar } from "../Components/ProgressBar/ProgressBar";
import { Sidebar } from "../Components/Sidebar/Sidebar";

const Home = () => {
    const [open, setOpen] = useState(true);
    const [darkMode, setDarkMode] = useState(true);
    const [backgroundColor, setBackgroundColor] = useState("#121212");
  
    const handleToggle = () => setOpen(!open);
    const handleThemeToggle = () => {
      setDarkMode(!darkMode);
      setBackgroundColor(darkMode ? "#e3e3e3" : "#121212");
    };
  
    return (
      <Box sx={{ display: "flex" }}>
       <CssBaseline />
        <Sidebar open={open} handleToggle={handleToggle} darkMode={darkMode} handleThemeToggle={handleThemeToggle} />
        <Content backgroundColor={backgroundColor} />
        <ProgressBar backgroundColor={darkMode ? "#222" : "#282a2c"} />
      </Box>
    );
  };
  
  export default Home;