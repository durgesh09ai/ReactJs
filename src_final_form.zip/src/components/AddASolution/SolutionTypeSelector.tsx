import React, { useState } from "react";
import {
  Typography,
  Box,
  Paper,
  Radio,
  RadioGroup,
  FormControlLabel,
  Stack
} from "@mui/material";

interface SolutionType {
  id: string;
  label: string;
}

interface SolutionTypeSelectorProps {
  options: SolutionType[];
  defaultSelected?: string;
  onChange?: (selectedId: string) => void;
}

export const SolutionTypeSelector: React.FC<SolutionTypeSelectorProps> = ({
  options,
  defaultSelected,
  onChange,
}) => {
  const [selected, setSelected] = useState<string>(defaultSelected || "");

  const handleSelect = (id: string) => {
    setSelected(id);
    if (onChange) {
      onChange(id);
    }
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Typography variant="body1" sx={{ mb: 1 }}>
        Add a solution type
      </Typography>

      <RadioGroup
        value={selected}
        onChange={(e) => handleSelect(e.target.value)}
        row
      >
        <Stack
          direction="row"
          spacing={1}
          sx={{ flexWrap: 'nowrap', overflowX: 'auto' }}
        >
          {options.map((option) => (
            <Paper
              key={option.id}
              elevation={0}
              sx={{
                border: 1,
                borderColor: 'rgba(211,209,209,0.4)',
                borderRadius: 2,
                px: 1,
                py: 0.5,
                minWidth: 100,
                height: 40,
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <FormControlLabel
                value={option.id}
                control={
                  <Radio
                    size="small"
                    sx={{
                      color: 'rgba(211,209,209,0.4)',
                      '&.Mui-checked': {
                        color: 'rgba(15,73,119,1)',
                      },
                      p: 0.5
                    }}
                  />
                }
                label={option.label}
                sx={{
                  m: 0,
                  '.MuiFormControlLabel-label': {
                    fontSize: '0.7rem'
                  }
                }}
              />
            </Paper>
          ))}
        </Stack>
      </RadioGroup>
    </Box>
  );
};
