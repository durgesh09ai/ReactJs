import React from "react";
import { 
  Button, 
  Stack,
  Box
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

interface ActionButtonsProps {
  onCancel: () => void;
  onPrevious: () => void;
  onSave: () => void;
  onNext: () => void;
  isPreviousDisabled?: boolean;
  isNextDisabled?: boolean;
}

export const ActionButtons: React.FC<ActionButtonsProps> = ({
  onCancel,
  onPrevious,
  onSave,
  onNext,
  isPreviousDisabled = false,
  isNextDisabled = false,
}) => {
  const primaryColor = 'rgba(15,73,119,1)';

  return (
    <Stack 
      direction="row" 
      spacing={2} 
      sx={{ mt: 4 }}
    >
      <Button
        variant="outlined"
        size="small"
        onClick={onCancel}
        sx={{ 
          color: primaryColor,
          borderColor: primaryColor
        }}
      >
        Cancel
      </Button>
      
      <Button
        variant="outlined"
        size="small"
        startIcon={<ArrowBackIcon fontSize="small" />}
        disabled={isPreviousDisabled}
        onClick={onPrevious}
        sx={{ 
          color: primaryColor,
          borderColor: primaryColor,
          width: '105px',
          '&.Mui-disabled': {
            opacity: 0.5
          }
        }}
      >
        Previous
      </Button>
      
      <Button
        variant="contained"
        size="small"
        onClick={onSave}
        sx={{ 
          bgcolor: primaryColor,
          width: '78px',
          '&:hover': {
            bgcolor: 'rgba(15,73,119,0.9)'
          }
        }}
      >
        Save
      </Button>
      
      <Button
        variant="outlined"
        size="small"
        endIcon={<ArrowForwardIcon fontSize="small" />}
        disabled={isNextDisabled}
        onClick={onNext}
        sx={{ 
          color: primaryColor,
          borderColor: primaryColor,
          width: '78px',
          '&.Mui-disabled': {
            opacity: 0.5
          }
        }}
      >
        Next
      </Button>
    </Stack>
  );
};
