// src/pages/CIP/Demos/DatagenAiSynthetic/Layout.tsx
import React from "react";
import { Outlet } from "react-router-dom";
import DatagenAiSyntheticMenu from "./DatagenAiSyntheticMenu";

const DatagenAiSyntheticLayout = () => {
  return (
    <div>
      <DatagenAiSyntheticMenu />
      <div style={{ padding: "1rem" }}>
        <Outlet />
      </div>
    </div>
  );
};

export default DatagenAiSyntheticLayout;
