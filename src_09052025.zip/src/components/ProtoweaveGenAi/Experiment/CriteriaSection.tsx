import React, { useState } from "react";
import { 
  Box, 
  Typography, 
  Button, 
  Chip, 
  TextField, 
  IconButton 
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";

interface CriteriaSectionProps {
  initialCriteria?: string[];
}

const CriteriaSection: React.FC<CriteriaSectionProps> = ({ 
  initialCriteria = ["Age > 45", "No prior Chemotherapy"] 
}) => {
  const [criteria, setCriteria] = useState<string[]>(initialCriteria);
  const [newCriterion, setNewCriterion] = useState<string>("");

  const handleAddCriterion = () => {
    if (newCriterion.trim()) {
      setCriteria([...criteria, newCriterion]);
      setNewCriterion("");
    }
  };

  const handleRemoveCriterion = (index: number) => {
    setCriteria(criteria.filter((_, i) => i !== index));
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Typography 
        sx={{ 
          fontWeight: "bold",
          fontSize:14,
          color: "black",
          lineHeight: 1.2
        }}
      >
        Inclusion / Exclusion Criteria
      </Typography>
      
      {criteria.map((criterion, index) => (
        <Box 
          key={index} 
          sx={{
            display: "flex",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 1,
            mt: 1
          }}
        >
          <Chip
            label={criterion}
            variant="outlined"
            sx={{
              bgcolor: "white",
              borderColor: "rgba(18,18,21,0.30)",
              borderRadius: 1,
              py: 1.5,
              px: 1
            }}
          />
          <IconButton 
            onClick={() => handleRemoveCriterion(index)}
            aria-label="Remove criterion"
            size="small"
          >
            <DeleteIcon sx={{ fontSize: 20 }} />
          </IconButton>
        </Box>
      ))}
      
      <Box 
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1,
          mt: 2
        }}
      >
        <TextField
          value={newCriterion}
          onChange={(e) => setNewCriterion(e.target.value)}
          placeholder="Add new criterion"
          fullWidth
          variant="outlined"
          size="small"
          sx={{
            '& .MuiOutlinedInput-root': {
              borderRadius: 1,
              bgcolor: "white"
            }
          }}
        />
        <Button 
          variant="contained" 
          onClick={handleAddCriterion}
          aria-label="Add criterion"
          sx={{
            minWidth: "auto",
            bgcolor: "#0F4977",
            borderRadius: 2,
            p: 1,
            height: 40
          }}
        >
          <AddIcon />
        </Button>
      </Box>
    </Box>
  );
};

export default CriteriaSection;
