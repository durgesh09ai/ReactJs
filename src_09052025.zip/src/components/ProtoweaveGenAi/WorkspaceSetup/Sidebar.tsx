import React from "react";
import {
  Box,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
} from "@mui/material";

interface SidebarItemProps {
  icon: string;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

interface SidebarProps {
  selectedLabel: string;
  onSelect: (label: string) => void;
}


const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  isActive = false,
  onClick,
}) => {
  return (
    <ListItem disablePadding sx={{ mt: 1 }}>
      <ListItemButton
        onClick={onClick}
        sx={{
          bgcolor: isActive ? "#A5D3FF" : "white",
          borderRadius: 1,
          py: 0.75,
          minHeight: "41px",
          "&:hover": {
            backgroundColor: "#E0F0FF",
          },
        }}
      >
        <ListItemIcon sx={{ minWidth: 40 }}>
          <Box
            component="img"
            src={icon}
            alt={label}
            sx={{ width: 24, height: 24 }}
          />
        </ListItemIcon>
        <ListItemText
          primary={label}
          primaryTypographyProps={{ variant: "body2" }}
        />
      </ListItemButton>
    </ListItem>
  );
};


const Sidebar: React.FC<SidebarProps> = ({ selectedLabel, onSelect }) => {
  const items = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f849b7b5e91a6833d41721cddada01c142d59533?placeholderIfAbsent=true",
      label: "User Profile",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/a12b354711c5b5d4aedeff71306bc83a3ea34bec?placeholderIfAbsent=true",
      label: "Workspace Setup",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/3f38f30de23b3910211b924354153e221addfb43?placeholderIfAbsent=true",
      label: "Databricks Schema Setup",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/2adbb509f3251aa48fe1fc96cad1a88ca485e2a8?placeholderIfAbsent=true",
      label: "LLM Model Selection",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b0fe3c1b05141ffa631abfec899a2f02a1f0360a?placeholderIfAbsent=true",
      label: "External Agents / MCP Setup",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/fcab67debb2d6868607b41cffe16fa4a839905d7?placeholderIfAbsent=true",
      label: "Internal Sites",
    },
  ];

  return (
    <Paper
      sx={{
        width: "261px",
        minWidth: "240px",
        borderRadius: 1,
        p: 1,
        fontSize: "0.875rem",
        fontWeight: "normal",
        lineHeight: 1.2,
      }}
    >
      <Typography
        sx={{
          borderBottom: "1px solid #E4E4E5",
          p: 1,
          color: "black",
          fontSize: 14,
          fontWeight: 400,
          textAlign: "center",
        }}
      >
        Settings
      </Typography>

      <List sx={{ p: 0 }}>
        {items.map((item) => (
          <SidebarItem
            key={item.label}
            icon={item.icon}
            label={item.label}
            isActive={selectedLabel === item.label}
            onClick={() => onSelect(item.label)}
          />
        ))}
      </List>
    </Paper>
  );
};

export default Sidebar;
