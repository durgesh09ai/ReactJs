import React, { useState } from "react";
import { FormControl, Typography, Box, Select, MenuItem, SelectChangeEvent } from "@mui/material";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

interface FormSelectProps {
  label: string;
  placeholder?: string;
  options?: Array<{ value: string; label: string }>;
}

const FormSelect: React.FC<FormSelectProps> = ({
  label,
  placeholder = "Your answer",
  options = []
}) => {
  const [selectedOption, setSelectedOption] = useState("");

  const handleChange = (event: SelectChangeEvent) => {
    setSelectedOption(event.target.value);
  };

  return (
    <Box sx={{ width: "100%", mt: 2 }}>
      <Typography variant="body1" sx={{ mb: 0.5 }}>
        {label}
      </Typography>
      <FormControl fullWidth>
        <Select
          displayEmpty
          value={selectedOption}
          onChange={handleChange}
          IconComponent={KeyboardArrowDownIcon}
          renderValue={(selected) => {
            if (!selected) {
              return <Typography sx={{ color: 'text.secondary' }}>{placeholder}</Typography>;
            }
            return selected;
          }}
          sx={{
            mt: 0.5,
            '& .MuiOutlinedInput-input': {
              py: 1.5,
            }
          }}
        >
          {options.length > 0 ? (
            options.map((option) => (
              <MenuItem key={option.value} value={option.label}>
                {option.label}
              </MenuItem>
            ))
          ) : (
            <MenuItem disabled value="">
              No options available
            </MenuItem>
          )}
        </Select>
      </FormControl>
    </Box>
  );
};

export default FormSelect;
