import { makeAutoObservable, runInAction } from "mobx";
import { fetchJson } from "../../../utils/http";

export class ProtoweaveGenAiStore {
  sidebarData: any = null;
  error: string | null = null;
  workspaceList: any[] = [];
  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  constructor() {
    makeAutoObservable(this);
  }

  fetchSideMenuData = async () => {
    try {
      const result = await fetchJson("./sidemenudata.json");
      runInAction(() => {
        this.sidebarData = result;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };

  addResearchItem = async (data: {id: string, title: string; description: string; researchId: string }) => {
    try {
      const res = await fetch("/addresearch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add research item");
      }
        // Re-fetch the SideMenu data
      await this.fetchSideMenuData();
      } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };


  fetchWorkspaces = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/listworkspaces/`);
      if (!res.ok) throw new Error("Failed to fetch workspaces");
      const data = await res.json();
      runInAction(() => {
        this.workspaceList = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  addWorkspace = async (workspace: any) => {
    try {
      const res = await fetch(`${this.apiUrl}/addworkspace/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workspace),
      });
      if (!res.ok) throw new Error("Failed to add workspace");
      const newWorkspace = await res.json();
      runInAction(() => {
        this.workspaceList.unshift(newWorkspace);
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  editWorkspace = async (id: string, updated: any) => {
    try {
      const res = await fetch(`${this.apiUrl}/editworkspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updated),
      });
      if (!res.ok) throw new Error("Failed to edit workspace");
      const updatedWs = await res.json();
      runInAction(() => {
        const index = this.workspaceList.findIndex((w) => w.id === id);
        if (index !== -1) this.workspaceList[index] = updatedWs;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };
 

}

export const dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();
