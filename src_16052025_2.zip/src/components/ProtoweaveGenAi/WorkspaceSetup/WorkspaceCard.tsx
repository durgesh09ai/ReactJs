import React, { useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Switch,
  TextField,
} from "@mui/material";
import TeamMember from "./TeamMember";

interface WorkspaceCardProps {
  id: string;
  name: string;
  description: string;
  fullDescription: string;
  owner: string;
  members: string[];
  isToggleOn: boolean;

  onAddMember: (workspaceId: string, email: string) => Promise<void>;
  onUpdateDetails: (
    workspaceId: string,
    updated: { name: string; description: string }
  ) => Promise<void>;
  onToggleArchive: (workspaceId: string, archive: boolean) => Promise<void>;
}

const WorkspaceCard: React.FC<WorkspaceCardProps> = ({
  id,
  name,
  description,
  fullDescription,
  owner,
  members,
  isToggleOn,
  onAddMember,
  onUpdateDetails,
  onToggleArchive,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isArchived, setIsArchived] = useState(isToggleOn);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMember, setNewMember] = useState("");
  const [membersList, setMembersList] = useState<string[]>(members);
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(name);
  const [editedDescription, setEditedDescription] = useState(fullDescription);
  const [loading, setLoading] = useState(false);

  const handleAddMember = async () => {
    if (newMember.trim()) {
      try {
        setLoading(true);
        await onAddMember(id, newMember.trim());
        setMembersList([...membersList, newMember.trim()]);
        setNewMember("");
        setShowAddMember(false);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleUpdateDetails = async () => {
    try {
      setLoading(true);
      await onUpdateDetails(id, {
        name: editedName,
        description: editedDescription,
      });
      setIsEditing(false);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleArchive = async () => {
    const newArchivedState = !isArchived;
    try {
      setLoading(true);
      await onToggleArchive(id, newArchivedState);
      setIsArchived(newArchivedState);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        border: "1px solid #E4E4E5",
        width: "100%",
        maxWidth: "527px",
        mt: 2,
        p: 2,
      }}
    >
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Box>
          <Typography variant="body2" sx={{ color: "black", fontWeight: "bold" }}>
            {name}
          </Typography>
          <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
            {description}
          </Typography>
        </Box>
      </Box>

      <Box sx={{ mt: 1 }}>
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Description
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
          {isExpanded ? fullDescription : `${fullDescription.slice(0, 100)}...`}
          <Box
            component="span"
            onClick={() => setIsExpanded(!isExpanded)}
            sx={{
              ml: 0.5,
              color: "#0F4977",
              textDecoration: "underline",
              cursor: "pointer",
            }}
          >
            See {isExpanded ? "less" : "more"}
          </Box>
        </Typography>
      </Box>

      <Box sx={{ mt: 1 }}>
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Team Members:
        </Typography>

        {showAddMember && (
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
            <TextField
              size="small"
              label="Add team member"
              required
              value={newMember}
              onChange={(e) => setNewMember(e.target.value)}
              sx={{
                flexGrow: 1,
                "& input": { fontSize: 12 },
                "& .MuiInputLabel-root": { fontSize: 12 },
              }}
            />
            <Button variant="contained" onClick={handleAddMember} disabled={loading}>
              Add
            </Button>
          </Box>
        )}

        <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
          <Typography variant="body2" sx={{ color: "#121215" }}>
            Owner
          </Typography>
          <TeamMember email={owner} />
        </Box>

        <Box sx={{ pl: 2, mt: 1 }}>
          {membersList.map((member, index) => (
            <Box key={index} sx={{ mt: index > 0 ? 1 : 0 }}>
              <TeamMember email={member} />
            </Box>
          ))}
        </Box>

        <Button variant="outlined" onClick={() => setShowAddMember(true)} sx={{ mt: 2 }}>
          Add Member
        </Button>
      </Box>

      <Box sx={{ mt: 2 }}>
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Workspace Settings
        </Typography>

        {isEditing ? (
          <Box sx={{ mt: 2, display: "flex", flexDirection: "column", gap: 2 }}>
            <TextField
              label="Workspace Name"
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              fullWidth
              size="small"
            />
            <TextField
              label="Workspace Description"
              value={editedDescription}
              onChange={(e) => setEditedDescription(e.target.value)}
              fullWidth
              multiline
              minRows={2}
            />
            <Box sx={{ display: "flex", gap: 1 }}>
              <Button variant="contained" onClick={handleUpdateDetails} disabled={loading}>
                Update
              </Button>
              <Button variant="outlined" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            </Box>
          </Box>
        ) : (
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
            <Button variant="text" onClick={() => setIsEditing(true)}>
              Edit Details
            </Button>
            <Typography variant="body2" sx={{ color: "gray" }}>
              (Update name or description)
            </Typography>
          </Box>
        )}

        <Box sx={{ mt: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Box>
            <Typography variant="body2" sx={{ fontWeight: "bold" }}>
              Archive Workspace
            </Typography>
            <Typography variant="body2" sx={{ color: "gray" }}>
              (Hide this workspace for all users)
            </Typography>
          </Box>
          <Switch
            checked={isArchived}
            onChange={handleToggleArchive}
            disabled={loading}
          />
        </Box>
      </Box>
    </Paper>
  );
};

export default WorkspaceCard;
