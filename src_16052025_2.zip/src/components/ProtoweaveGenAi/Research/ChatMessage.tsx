import { Avatar, Box, CircularProgress, Paper, Stack, Typography } from "@mui/material";

interface ChatMessageProps {
  content: string;
  sender: "user" | "assistant";
  isThinking?: boolean;
}

export const ChatMessage = ({ content, sender, isThinking = false }: ChatMessageProps) => {
  const isAssistant = sender === "assistant";

  return (
    <Stack
      direction={isAssistant ? "row" : "row-reverse"}
      alignItems="flex-start"
      spacing={1}
      sx={{ width: "100%", mt: 1 }}
    >
      <Avatar
        src={isAssistant ? "./chaticon.png" : undefined}
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          fontSize: 12,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      >
        {isAssistant ? "A" : "U"}
      </Avatar>

      <Paper
        elevation={0}
        sx={{
          minWidth: 240,
          maxWidth: 352,
          bgcolor: isAssistant ? "#F3FAFF" : "#E0F7FA",
          p: 2.5,
          borderRadius: 2,
        }}
      >
        {isThinking ? (
          <Box display="flex" alignItems="center" gap={1}>
            <CircularProgress size={16} thickness={5} />
            <Typography
              fontSize="0.875rem"
              fontWeight={400}
              color="black"
              lineHeight={1.5}
              whiteSpace="pre-wrap"
            >
              Thinking...
            </Typography>
          </Box>
        ) : (
          <Typography
            fontSize="0.875rem"
            fontWeight={400}
            color="black"
            lineHeight={1.5}
            whiteSpace="pre-wrap"
          >
            {content}
          </Typography>
        )}
      </Paper>
    </Stack>
  );
};
