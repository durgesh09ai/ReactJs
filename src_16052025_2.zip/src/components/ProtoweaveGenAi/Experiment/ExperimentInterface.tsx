import React, { useState } from "react";
import { Box, Paper } from "@mui/material";
import FormHeader from "./FormHeader";
import ResearchInfo from "./ResearchInfo";
import CriteriaSection from "./CriteriaSection";
import MedicalCodingSection from "./MedicalCodingSection";
import ParametersSection from "./ParametersSection";
import UploadSection from "./UploadSection";
import ActionButtons from "./ActionButtons";

const ExperimentInterface: React.FC = () => {
  const [activeTab, setActiveTab] = useState("Configuration Form 1");

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const handleUploadProtocol = () => {
    console.log("Upload protocol clicked");
    // Implement protocol upload functionality
  };

  const handleUploadData = () => {
    console.log("Upload data clicked");
    // Implement data upload functionality
  };

  const handleDuplicate = () => {
    console.log("Duplicate clicked");
    // Implement duplication functionality
  };

  const handleRunExperiment = () => {
    console.log("Run experiment clicked");
    // Implement experiment execution functionality
  };

  return (
    <Box sx={{ maxWidth: "684px", fontSize: "0.875rem" }}>
      <FormHeader
        activeTab={activeTab}
        onTabChange={handleTabChange}
        onUploadProtocol={handleUploadProtocol}
      />
      
      <Box 
        sx={{ 
          width: "100%", 
          bgcolor: "#D9EDFF", 
          borderRadius: "0px 12px 12px 12px",
          p: 2,
          overflow: "hidden"
        }}
      >
        <ResearchInfo
          researchName="Diabetes type1"
          experimentName="Config 1"
          createdDate="April 30, 2025"
          ownerName="@dr.meera"
        />
        
        <Paper 
          elevation={0}
          sx={{ 
            mt: 2, 
            p: 2, 
            borderRadius: 2,
            width: "100%"
          }}
        >
          <CriteriaSection />
          
          <MedicalCodingSection />
          
          <Box sx={{ mt: 2, width: "100%" }}>
            <ParametersSection />
            
            {/* <UploadSection onUploadData={handleUploadData} /> */}
          </Box>
          
          <ActionButtons
            onDuplicate={handleDuplicate}
            onRunExperiment={handleRunExperiment}
          />
        </Paper>
      </Box>
    </Box>
  );
};

export default ExperimentInterface;
