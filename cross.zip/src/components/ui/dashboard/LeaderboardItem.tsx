import React from "react";

interface LeaderboardItemProps {
  image: string;
  rank: number;
  name: string;
}

const LeaderboardItem: React.FC<LeaderboardItemProps> = ({
  image,
  rank,
  name,
}) => {
  return (
    <div className="bg-white border flex min-h-[103px] w-full items-stretch mt-4 rounded-[16px_10px_10px_16px] border-[rgba(253,244,238,1)] border-solid">
      <div className="flex w-[170px] rounded-[0px_9px_0px_0px]">
        <img
          src={image}
          alt={`Contributor ${rank}`}
          className="aspect-[1.65] object-contain w-[170px] rounded-[0px_0px_0px_0px]"
        />
      </div>
      <div className="w-[179px]">
        <div className="flex w-full flex-col items-stretch font-semibold justify-center">
          <div className="bg-[rgba(15,73,119,1)] flex min-h-[34px] w-full flex-col items-stretch justify-center pl-[13px] pr-1.5 py-1.5 rounded-[0px_9px_0px_0px]">
            <div className="flex max-w-full w-40 items-center gap-[33px] justify-between">
              <div className="text-white text-sm self-stretch my-auto">
                No.{rank} Contributor
              </div>
              <div className="self-stretch flex flex-col text-[8px] text-[rgba(15,73,119,1)] whitespace-nowrap justify-center w-[22px] my-auto px-1 py-[7px]">
                <div className="z-10 bg-white w-[9px] h-[9px] px-0.5 rounded-[50%]">
                  {rank}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch w-full gap-2.5 text-sm text-[rgba(52,52,52,1)] font-medium flex-1 h-full">
          {name}
        </div>
      </div>
    </div>
  );
};

export default LeaderboardItem;
