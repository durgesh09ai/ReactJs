
import React from "react";
import { Box, Card, Typography, SxProps, Theme } from "@mui/material";

interface DataCardProps {
  icon: string;
  label: string;
  value: string;
  labelSx?: SxProps<Theme>;
}

const DataCard = ({ icon, label, value, labelSx }: DataCardProps) => {
  return (
    <Card 
      variant="outlined" 
      sx={{
        p: 2,
        display: 'flex',
        alignItems: 'center',
        gap: 2,
        borderRadius: 2,
        height: '100%',
        backgroundColor: 'rgba(243,250,255,1)', // Updated background color
        borderColor: 'rgba(0, 0, 0, 0.12)',
        boxShadow: '0px 1px 3px rgba(16, 24, 40, 0.1), 0px 1px 2px rgba(16, 24, 40, 0.06)'
      }}
    >
      <Box 
        component="img" 
        src={icon} 
        alt={label}
        sx={{ width: 32, height: 32 }}
      />
      <Box sx={{ flex: 1 }}>
        <Typography 
          variant="body2" 
          sx={{ ...labelSx }}
        >
          {label}
        </Typography>
        <Typography 
          variant="h6" 
          sx={{ fontWeight: 600, color: '#0F4977' }}
        >
          {value}
        </Typography>
      </Box>
    </Card>
  );
};

export default DataCard;
