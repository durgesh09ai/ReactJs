import React from "react";

interface UserProfileProps {
  name: string;
  role: string;
  avatar: string;
  points: number;
}

const UserProfile: React.FC<UserProfileProps> = ({
  name,
  role,
  avatar,
  points,
}) => {
  return (
    <div className="bg-white border-neutral-50 border flex w-full flex-col items-stretch mt-[19px] px-2 py-4 rounded-xl border-solid">
      <div className="flex items-center gap-4 px-4">
        <div className="self-stretch flex flex-col w-[90px] my-auto">
          <img
            src={avatar}
            alt={name}
            className="aspect-[1] object-contain w-[90px] rounded-[0px_0px_0px_0px]"
          />
        </div>
        <div className="self-stretch flex flex-col items-stretch text-sm text-[rgba(52,52,52,1)] w-[155px] my-auto">
          <div className="w-full">
            <div className="font-semibold">{name}</div>
            <div className="font-medium mt-2.5">{role}</div>
          </div>
          <div className="flex items-center gap-2 whitespace-nowrap mt-[9px]">
            <div className="self-stretch flex gap-1 font-semibold my-auto">
              <img
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/566f28b4f05524de15d41317b898acaf26ed729e?placeholderIfAbsent=true"
                alt="Points"
                className="aspect-[1/1] object-contain w-4 shadow-[0px_1px_4px_0px_rgba(110,116,134,0.12)] shrink-0"
              />
              <div>{points}</div>
            </div>
            <div className="font-normal self-stretch my-auto">Points</div>
          </div>
        </div>
      </div>
      <div className="bg-[rgba(243,250,255,1)] flex w-full items-center gap-2 text-sm text-black font-medium mt-[35px] p-2 rounded-lg">
        <img
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/20e04cdfd4c8ee870043aa12903acd7bf9ebcd51?placeholderIfAbsent=true"
          alt="Goal"
          className="aspect-[1] object-contain w-5 self-stretch shrink-0 my-auto"
        />
        <div className="self-stretch my-auto">Goals in a Month:</div>
        <div className="self-stretch my-auto">Read 6 case studies</div>
      </div>
    </div>
  );
};

export default UserProfile;
