
import React from "react";
import UserProfile from "../ui/dashboard/UserProfile";
import LeaderboardItem from "../ui/dashboard/LeaderboardItem";
import FilterDropdown from "../ui/dashboard/FilterDropdown";

const StatsPanel: React.FC = () => {
  return (
    <aside className="bg-[rgba(243,250,255,1)] border min-w-60 w-[397px] p-4 rounded-[20px] border-[rgba(15,73,119,0.5)] border-solid">
      <button className="bg-white flex w-full items-center gap-4 text-sm text-black font-medium px-4 py-3.5 rounded-[20px]">
        <img
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae9d15c00f2e9ae28f7d0d8c3b621bb745ab4cbe?placeholderIfAbsent=true"
          alt="Close"
          className="aspect-[1] object-contain w-[18px] self-stretch shrink-0 my-auto rounded-lg"
        />
        <span className="self-stretch gap-2 my-auto">
          Close My stats & rank
        </span>
      </button>

      <UserProfile
        name="Umesh jain"
        role="Sales & info manager"
        avatar="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b522349175b734ad87f721737d0337e9eac00b6e?placeholderIfAbsent=true"
        points={453}
      />

      <div className="bg-white flex w-full flex-col items-center mt-[19px] pb-4 px-2 rounded-xl">
        <div className="bg-white flex w-[164px] max-w-full flex-col overflow-hidden items-stretch text-base text-black font-semibold justify-center p-4 rounded-[8px_0px_0px_0px]">
          <h3 className="self-stretch w-full">Leaderboard FIlter</h3>
        </div>
        <div className="self-stretch w-full py-4">
          <div className="flex w-full flex-col items-stretch text-sm justify-center mb-4">
            <div className="w-full max-w-[347px] whitespace-nowrap mb-3">
              <label className="text-black font-medium block mb-1">IMU</label>
              <FilterDropdown label="Healthcare" />
            </div>
            <div className="w-full max-w-[347px] whitespace-nowrap mt-3">
              <label className="text-black font-medium block mb-1">SGU</label>
              <FilterDropdown label="Healthcare" />
            </div>
            <div className="w-full max-w-[347px] mt-3">
              <label className="text-black font-medium block mb-1">Timeframe</label>
              <FilterDropdown label="This month" />
            </div>
          </div>

          <div className="flex w-full flex-col items-stretch justify-center mt-6">
            <h3 className="text-black text-base font-semibold self-center mb-2">
              Top 3 Contributors
            </h3>

            <LeaderboardItem image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/593b94be8cb9a648463cfeb0e0358289550ff142?placeholderIfAbsent=true" rank={1} name="Abhishek Wadhwa" />

            <LeaderboardItem image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f8c93e7ce2bd0551f68f73336b86944c8fba3ef3?placeholderIfAbsent=true" rank={2} name="Abhishek Wadhwa" />

            <LeaderboardItem image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/591c01d24467f2c2a8d6c083930c05d2ace27632?placeholderIfAbsent=true" rank={3} name="Abhishek Wadhwa" />
          </div>
        </div>

        <button className="flex gap-4 text-xs text-[rgba(15,73,119,1)] font-medium leading-none mt-2">
          <div className="flex items-stretch gap-2">
            <div className="self-stretch border shadow-[0px_1px_3px_0px_rgba(96,108,128,0.05)] bg-white gap-2.5 h-full px-2 py-2.5 rounded-lg border-solid border-[#0F4977]">
              View Top contributors
            </div>
          </div>
        </button>
      </div>
    </aside>
  );
};

export default StatsPanel;
