
import React, { useState } from "react";
import { Box, Paper, Stack } from "@mui/material";
import Sidebar from "./Sidebar";
import Header from "./Header";
import MainContent from "./MainContent";
import StatsPanel from "./StatsPanel";
import { ChevronLeft, ChevronRight } from "lucide-react";
 import { Button } from "../ui/button";

const TaskBoards: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  return (
    <Paper sx={{
      bgcolor: 'background.paper',
      overflow: 'hidden',
      pb: 2,
      borderRadius: 4
    }}>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
        <Box sx={{ 
          width: { 
            xs: '100%', 
            md: sidebarCollapsed ? '80px' : '280px' 
          },
          flexShrink: 0,
          transition: 'width 0.3s ease'
        }}>
          <Sidebar collapsed={sidebarCollapsed} />
        </Box>
        <Box 
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '50%',
            mt: 2,
            ml: -2,
            zIndex: 2
          }}
        >
          {/* <Button 
            variant="outline" 
            size="icon" 
            onClick={toggleSidebar}
            className="h-8 w-8 rounded-full bg-white border shadow-sm"
          >
            {sidebarCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </Button> */}
        </Box>
        <Box sx={{ 
          width: { xs: '100%', md: 'auto' },
          flexGrow: 1
        }}>
          <Box sx={{ width: '100%' }}>
            <Header />
            <Box sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              p: 4,
              '@media (max-width: 768px)': { p: 2 }
            }}>
              <Box sx={{ 
                display: 'flex', 
                flexWrap: 'wrap', 
                gap: 2,
                height: '100%'
              }}>
                <MainContent />
                <StatsPanel />
              </Box>
            </Box>
          </Box>
        </Box>
      </Stack>
    </Paper>
  );
};

export default TaskBoards;
