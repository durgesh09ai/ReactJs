
import React from "react";
import { Typography } from "@mui/material";

interface NavSectionProps {
  title: string;
}

const NavSection: React.FC<NavSectionProps> = ({ title }) => {
  if (!title) return null;

  return (
    <div className="flex w-full items-stretch mt-8 px-4">
      <Typography variant="subtitle2" sx={{ 
        color: 'rgba(0,0,0,0.6)', 
        fontWeight: 600, 
        fontSize: '0.75rem', 
        textTransform: 'uppercase',
        letterSpacing: '0.05em'
      }}>
        {title}
      </Typography>
    </div>
  );
};

export default NavSection;
