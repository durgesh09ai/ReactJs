import React from "react";
import NavItem from "./NavItem";
import NavSection from "./NavSection";

interface SidebarProps {
  collapsed?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed = false }) => {
  return (
    <div className="px-4">
      <div className="w-full">


        
        <div className="flex w-full items-center gap-[40px_100px] text-[28px] text-[rgba(15,73,119,1)] font-semibold whitespace-nowrap justify-between px-4 py-2 border-[rgba(0,0,0,0.1)] border-b">
          <div className="self-stretch my-auto">{!collapsed && "EXL"}</div>
          {!collapsed && (
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9df66a2e096fffaa4eec49ff70db980f5326516a?placeholderIfAbsent=true"
              alt="Logo"
              className="aspect-[1] object-contain w-6 self-stretch shrink-0 my-auto"
            />
          )}
        </div>






        <div className="flex w-full flex-col items-stretch">
          <NavSection title={collapsed ? "" : "Home"} />
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b628d78a4baec2798a453ffd9a4bcf1d35c8e6d6?placeholderIfAbsent=true" 
            label="Quality and Compliance" 
            count={20}
            collapsed={collapsed}
            subItems={[
              { label: "Quality Reports" },
              { label: "Compliance Dashboard" },
              { label: "Audit Logs" }
            ]}
          />
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/051c15b961652ad186fe0257c1a414a1ffc91dc0?placeholderIfAbsent=true" 
            label="Data and analytics LOB" 
            count={20}
            collapsed={collapsed}
            subItems={[
              { label: "Data Insights" },
              { label: "Analytics Dashboard" }
            ]}
          />
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/4ef76a64142b66e6d38acbd0f1522f8f190fc5d1?placeholderIfAbsent=true" 
            label="Life Science LOB" 
            count={20}
            collapsed={collapsed}
          />
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/d90d47cac85a8af782e6618e8ecae6037f193310?placeholderIfAbsent=true" 
            label="Risk Quality Measures" 
            count={20}
            collapsed={collapsed}
          />
        </div>
      </div>
      {!collapsed && (
        <div className="w-full text-sm text-black font-normal whitespace-nowrap mt-[831px] max-md:mt-10">
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/3904791a901d558c2c5d7347a0090cb8906978c9?placeholderIfAbsent=true" 
            label="Bookmarked" 
            showCount={false}
            collapsed={collapsed}
          />
          <NavItem 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff595e8aeb1d76299e427e0b5390f825a7dd6d5?placeholderIfAbsent=true" 
            label="Settings" 
            showCount={false}
            collapsed={collapsed}
          />
        </div>
      )}
    </div>
  );
};

export default Sidebar;
