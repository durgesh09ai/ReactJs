
import React from "react";
import { Box, CssBaseline, ThemeProvider, createTheme } from "@mui/material";
import TaskBoards from "../components/dashboard/TaskBoards";

// Create a theme instance
const theme = createTheme({
  palette: {
    primary: {
      main: '#0F4977',
    },
    secondary: {
      main: '#F3FAFF',
    },
    background: {
      default: '#F5F7FA',
      paper: '#FFFFFF',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
  shape: {
    borderRadius: 8,
  },
});

const Index: React.FC = () => {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ minHeight: '100vh', p: 2, bgcolor: 'background.default' }}>
        <TaskBoards />
      </Box>
    </ThemeProvider>
  );
};

export default Index;
