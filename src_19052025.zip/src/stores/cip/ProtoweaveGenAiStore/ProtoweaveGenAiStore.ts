import { makeAutoObservable, runInAction } from "mobx";
import { fetchJson } from "../../../utils/http";

export class ProtoweaveGenAiStore {
  sidebarData: any = null;
  error: string | null = null;
  workspaceList: any[] = [];
  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  constructor() {
    makeAutoObservable(this);
  }

  fetchSideMenuData = async () => {
    try {
      const result = await fetchJson("http://localhost:3000/sidemenudata.json");
      runInAction(() => {
        this.sidebarData = result;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };

  addResearchItem = async (data: {id: string, title: string; description: string; researchId: string }) => {
    try {
      const res = await fetch("/addresearch", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      if (!res.ok) {
        throw new Error("Failed to add research item");
      }
        // Re-fetch the SideMenu data
      await this.fetchSideMenuData();
      } catch (e: any) {
      runInAction(() => {
        this.error = e.message || "Unknown error";
      });
    }
  };


  fetchWorkspaces = async (userId:string) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/workspaces/${userId}`);
      if (!res.ok) throw new Error("Failed to fetch workspaces");
      const data = await res.json();
      runInAction(() => {
        this.workspaceList = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWorkspace = async (id: string, updates: {id:string,userId:string, WS_name: string; WS_descrip: string }) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/RenameWorkspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
  
      if (!res.ok) throw new Error("Failed to update workspace");
  
      const updatedWorkspace = await res.json();
      runInAction(() => {
        const index = this.workspaceList.findIndex((ws) => ws.id === id);
        if (index !== -1) {
          this.workspaceList[index] = updatedWorkspace;
        }
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWorkspaceArchive = async (id: string, updates: {id:string,userId:string, archive: boolean;}) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/Archive_workspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
    if (!res.ok) throw new Error("Failed to update workspace");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  addWorkspace = async (workspace: any) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/create_workspace`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workspace),
      });
      if (!res.ok) throw new Error("Failed to add workspace");
      const newWorkspace = await res.json();
      runInAction(() => {
        this.workspaceList.unshift(newWorkspace);
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  updateWSTeamMember = async (id: string, updates: {id:string,userId:string, team_members: string[];}) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/ReTeam_Workspace/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
    if (!res.ok) throw new Error("Failed to update workspace");
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };
 

}

export const dataProtoweaveGenAiStore = new ProtoweaveGenAiStore();
