import React, { useState, useEffect } from 'react';
import { Box, Typography, TextField, Paper,Switch } from '@mui/material';
import { Agent } from './AgentCard';
import { ActionButtons } from './ActionButtons';

interface AgentFormProps {
  agent?: Agent;
  onSave: (agent: Partial<Agent>) => void;
  onCancel: () => void;
}

export const AgentForm: React.FC<AgentFormProps> = ({
  agent,
  onSave,
  onCancel
}) => {
  const [formData, setFormData] = useState<Partial<Agent>>({
    name: '',
    description: '',
    url: '',
    enabled: true,
    isDefault: false,
  });

    const [isArchived, setIsArchived] = useState(false);
  
  useEffect(() => {
    if (agent) {
      setFormData(agent);
    }
  }, [agent]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (

<Paper
      component="form"
      onSubmit={handleSubmit}
      elevation={1}
      sx={{
        width: '78%',
        p: 3,
        mt:2,
        border: '1px solid #E4E4E5',
        borderRadius: 1,
        boxShadow: 'none',
      }}
    >
        <Typography
        variant="body1"
        sx={{ color: "#1d1b20", fontWeight: 'bold', lineHeight: 1.2,fontSize:14 }}
      >
        {agent ? 'Edit Agent' : 'Add New Agent'}
        </Typography>

      <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3, gap: 1 }}>
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 1 ,fontSize:14}}>Name</Typography>
          <TextField
            fullWidth
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter agent name"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 1,fontSize:14 }}>Description</Typography>
          <TextField
            fullWidth
            id="endpoint"
            name="endpoint"
            value={formData.description}
            onChange={handleChange}
            placeholder="Enter agent description"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: "bold", mb: 1 ,fontSize:14 }}>API Key</Typography>
          <TextField
            fullWidth
            id="apiKey"
            name="apiKey"
            type="password"
            value={formData.url}
            onChange={handleChange}
            placeholder="Enter API key"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: "bold", mb: 1 ,fontSize:14 }}>URL</Typography>
          <TextField
            fullWidth
            id="url"
            name="url"
            onChange={handleChange}
            placeholder="Enter URL"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: "bold", mb: 1 ,fontSize:14 }}>Input Parameters</Typography>
          <TextField
            fullWidth
            id="inputParams"
            name="inputParams"
            onChange={handleChange}
            placeholder="Enter Input Parameters"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <Typography
        variant="body2"
        sx={{ fontWeight: 'bold', fontSize: 14 }}
        >
        Default Agent
        </Typography>
        <Switch
        checked={isArchived}
        onChange={() => setIsArchived(!isArchived)}
        sx={{
        '& .MuiSwitch-track': {
        backgroundColor: '#0F4977',
        },
        '& .MuiSwitch-thumb': {
        backgroundColor: 'white',
        },
        }}
        />
        </Box>


        <ActionButtons
          onCancel={onCancel}
          onSave={() => onSave(formData)}
        />
      </Box>
    </Paper>
  );
};
