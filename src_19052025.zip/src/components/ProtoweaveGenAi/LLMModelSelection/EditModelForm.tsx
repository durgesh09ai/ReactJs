import React, { useState, useEffect } from "react";
import { Box, TextField, Typography, Paper } from "@mui/material";
import { ActionButtons } from "./ActionButtons";

export interface ModelData {
  id: string;
  name: string;
  endpoint: string;
  apiKey: string;
}

interface EditModelFormProps {
  model: ModelData | null;
  onUpdate: (model: ModelData) => void;
  handleCancel: () => void;
  handleSave: () => void;
}

export const EditModelForm: React.FC<EditModelFormProps> = ({
  model,
  onUpdate,
  handleCancel,
  handleSave
}) => {
  const [formData, setFormData] = useState<ModelData>({
    id: '',
    name: '',
    endpoint: '',
    apiKey: ''
  });

  useEffect(() => {
    if (model) {
      setFormData(model);
    } else {
      setFormData({
        id: '',
        name: '',
        endpoint: '',
        apiKey: ''
      });
    }
  }, [model]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData);
  };

  return (
    <Paper
      component="form"
      onSubmit={handleSubmit}
      elevation={1}
      sx={{
        width: '100%',
        p: 3,
        border: '1px solid #E4E4E5',
        borderRadius: 1,
        boxShadow: 'none',
      }}
    >
        <Typography
        variant="body1"
        sx={{ color: "#1d1b20", fontWeight: 'bold', lineHeight: 1.2,fontSize:14 }}
      >
        {model ? "Edit LLM" : "Add LLM"}
      </Typography>

      <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3, gap: 1 }}>
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 1 ,fontSize:14}}>LLM Model Name</Typography>
          <TextField
            fullWidth
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter model name"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: 'bold', mb: 1,fontSize:14 }}>Endpoint URL</Typography>
          <TextField
            fullWidth
            id="endpoint"
            name="endpoint"
            value={formData.endpoint}
            onChange={handleChange}
            placeholder="https://<your-instance>.cloud.databricks.com"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <Box>
          <Typography variant="body2" sx={{ fontWeight: "bold", mb: 1 ,fontSize:14 }}>API Key</Typography>
          <TextField
            fullWidth
            id="apiKey"
            name="apiKey"
            type="password"
            value={formData.apiKey}
            onChange={handleChange}
            placeholder="Enter API key"
            InputProps={{
              sx: {
                backgroundColor: "#EAF2F7",
                height: 30, 
                fontSize: 14,
                px: 1,
              }
            }}
          />
        </Box>

        <ActionButtons
          onCancel={handleCancel}
          onSave={handleSave}
        />
      </Box>
    </Paper>
  );
};
