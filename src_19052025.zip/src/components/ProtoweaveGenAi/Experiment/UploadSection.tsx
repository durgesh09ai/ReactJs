import React from "react";
import { Box, Typography, Button } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

interface UploadSectionProps {
  onUploadData: () => void;
}

const UploadSection: React.FC<UploadSectionProps> = ({ onUploadData }) => {
  return (
    <Box sx={{ mt: 4, width: "100%" }}>
      <Typography 
        variant="h6" 
        sx={{ 
          fontWeight: 500,
          color: "black",
          lineHeight: 1.2
        }}
      >
        Upload Data for Your Report
      </Typography>
      
      <Button
        variant="contained"
        startIcon={<CloudUploadIcon />}
        onClick={onUploadData}
        sx={{
          mt: 2,
          bgcolor: "#D9EDFF",
          color: "black",
          textTransform: "none",
          "&:hover": {
            bgcolor: "#b8ddff"
          }
        }}
      >
        Upload user data
      </Button>
    </Box>
  );
};

export default UploadSection;
