import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import { dataProtoweaveGenAiStore } from "../../../stores/cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";

import {
  Box,
  Typography,
  Paper,
  Button,
  Switch,
  TextField,
} from "@mui/material";
import TeamMember from "./TeamMember";

interface WorkspaceCardProps {
  id: string;
  name: string;
  description: string;
  userId: string;
  team_members?: string[];
  archive: boolean;
}

const WorkspaceCard: React.FC<WorkspaceCardProps> = ({
  id,
  name,
  description,
  userId,
  team_members,
  archive,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isArchived, setIsArchived] = useState(archive);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMember, setNewMember] = useState("");
  const [membersList, setMembersList] = useState<string[]>(team_members);
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(name);
  const [editedDescription, setEditedDescription] = useState(description);
  const [loading, setLoading] = useState(false);

  const handleAddMember = async () => {
    if (newMember.trim()) {
      try {
        const updatedMemebers = [...membersList, newMember.trim()];
         await dataProtoweaveGenAiStore.updateWSTeamMember(id, {
          id: id,
          userId: userId,
          team_members: updatedMemebers
        });
        setMembersList(updatedMemebers);
        setNewMember("");
        setShowAddMember(false);
      } finally {
        setLoading(false);
      }
    }
  };

  const removeTeamMember = async (removedTeamMemeber) => {
    if (removedTeamMemeber) {
      try {
        const updatedMemebers = membersList.filter(member => member !== removedTeamMemeber);
        await dataProtoweaveGenAiStore.updateWSTeamMember(id, {
          id: id,
          userId: userId,
          team_members: updatedMemebers
        });
        setMembersList(updatedMemebers);
        setNewMember("");
        setShowAddMember(false);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleUpdateDetails = async () => {
    try {
      setLoading(true);
      await dataProtoweaveGenAiStore.updateWorkspace(id, {
        id: id,
        userId: userId,
        WS_name: editedName,
        WS_descrip: editedDescription,
      });
      setIsEditing(false);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleArchive = async () => {
    const newArchivedState = !isArchived;
    try {
      setLoading(true);
     await dataProtoweaveGenAiStore.updateWorkspaceArchive(id, {
      id: id,
      userId: userId,
      archive: newArchivedState,
    });
      setIsArchived(newArchivedState);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper 
        elevation={0}
        sx={{ 
          border: '1px solid #E4E4E5',
          width: '100%', 
          maxWidth: '527px', 
          mt: 2,
          p: 2
        }}
      >
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box>
            <Typography variant="body2" sx={{ color: 'black', fontWeight: 'bold' }}>
              {name}
            </Typography>
          </Box>
          <Box 
            component="img"
            src="../delete.svg"
            sx={{ width: 24, height: 24 }}
            alt="Options"
          />
        </Box>
        
        <Box sx={{ mt: 1 }}>
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Description
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
          {isExpanded ? description : `${description?.slice(0, 100)}...`}
          <Box
            component="span"
            onClick={() => setIsExpanded(!isExpanded)}
            sx={{
              ml: 0.5,
              color: "#0F4977",
              textDecoration: "underline",
              cursor: "pointer",
            }}
          >
            See {isExpanded ? "less" : "more"}
          </Box>
        </Typography>
      </Box>
        
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          mt: 1,
          flexWrap: 'wrap'
        }}>
          <Box sx={{ width: '255px', minWidth: '240px' }}>
            <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
              Team Members:
            </Typography>

            {showAddMember && (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
                <TextField
                  size="small"
                  label="Add team member"
                  required
                  onChange={(e) => setNewMember(e.target.value)}
                  sx={{ 
                    "& input": { fontSize: 12 },
                    "& .MuiInputLabel-root": { fontSize: 12 } ,
                    flexGrow: 1, minWidth: '240px'
                  }} 
                />
                <Button variant="contained" onClick={handleAddMember} sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" 
            }}>
                  Add
                </Button>
              </Box>
            )}

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1, pl: 2 }}>
              <Typography variant="body2" sx={{ color: '#121215' }}>
                Owner
              </Typography>
              <TeamMember email={userId} userType='owner'/>
            </Box>
            <Box sx={{ pl: 2, mt: 1 }}>
              {membersList && membersList.map((member, index) => (
                <Box key={index} sx={{ mt: index > 0 ? 1 : 0 }}>
                  <TeamMember email={member} userType='member' removeTeamMember = {removeTeamMember}/>
                </Box>
              ))}
            </Box>
          </Box>
          
          <Button
            variant="outlined"
            onClick={()=>setShowAddMember(true)}
            startIcon={
              <Box 
                component="img"
                src={archive ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/35002a56fd64e9d397909d58bdd04fc4371c7257?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/e8e239c0d5d2f94a887cf482d258e047cec5deb7?placeholderIfAbsent=true"}
                sx={{ width: 24, height: 24 }}
                alt="Add member"
              />
            }
            sx={{
              color: '#0F4977',
              borderColor: '#0F4977',
              textTransform: 'none',
              fontWeight: 'medium',
              py: 0.5,
              px: 1,
              height: 'fit-content'
            }}
          >
            Add Member
          </Button>
        </Box>
        
        <Box sx={{ mt: 1 }}>
          <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
            Workspace Settings
          </Typography>
          
          <Box sx={{ mt: 1, pl: 2 }}>

          {isEditing && (
  <Box sx={{ mt: 2, pl: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
    <TextField
      label="Workspace Name"
      value={editedName}
      onChange={(e) => setEditedName(e.target.value)}
      fullWidth
      size="small"
      sx={{ 
        "& input": { fontSize: 12 },
        "& .MuiInputLabel-root": { fontSize: 12 } ,
      }} 
    />
    <TextField
      label="Workspace Description"
      value={editedDescription}
      onChange={(e) => setEditedDescription(e.target.value)}
      fullWidth
      multiline
      sx={{ 
        "& .MuiInputBase-root": { fontSize: 14 },
        "& .MuiInputLabel-root": { fontSize: 14 } ,
      }} 
    />
    <Box sx={{ display: 'flex', gap: 1 }}>
      <Button
        variant="contained"
          onClick={handleUpdateDetails}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Update
      </Button>
      <Button
        variant="outlined"
        onClick={() => {
          setIsEditing(false);
        }}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Cancel
      </Button>
    </Box>
  </Box>
)}


            {!isEditing && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Button
                variant="text"
                onClick={() => setIsEditing(!isEditing)}
                startIcon={
                  <Box 
                    component="img"
                    src={archive ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/38d78a3aa6d5f99b6b5c2b9d2da99d2587b8bcab?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/69523dae9b503db0228e28a943c595ab1beed123?placeholderIfAbsent=true"}
                    sx={{ width: 24, height: 24 }}
                    alt="Edit"
                  />
                }
                sx={{
                  color: '#0F4977',
                  textTransform: 'none',
                  fontWeight: 'medium',
                  py: 0.5,
                  px: 1,
                  minWidth: 'auto'
                }}
              >
                Edit Details
              </Button>
              <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)' }}>
                (Update name or description)
              </Typography>
            </Box>
              )}

              <Box sx={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                mt: 2,
                pl: 2
              }}>
                <Box sx={{ 
                  display: 'flex', 
                  flexDirection: 'column',
                  bgcolor: 'white',
                  borderRadius: 1,
                  p: 0.5
                }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box 
                      component="img"
                      src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/190889642f933327d884e606f642c062034e414d?placeholderIfAbsent=true"
                      sx={{ width: 24, height: 24 }}
                      alt="Archive"
                    />
                    <Typography variant="body2" sx={{ fontWeight: 'bold', color: 'black' }}>
                      Archive Workspace
                    </Typography>
                  </Box>
                  <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)', textAlign: 'center' }}>
                    (Hide this workspace for all user)
                  </Typography>
                </Box>
                <Switch
                  checked={isArchived}
                  onChange={handleToggleArchive}
                  sx={{
                    '& .MuiSwitch-track': {
                      backgroundColor: 'red',
                    },
                    '& .MuiSwitch-thumb': {
                      backgroundColor: 'white',
                    },
                  }}
                />
              </Box>
         
          </Box>
        </Box>
      </Paper>
  );
};

export default observer(WorkspaceCard);
