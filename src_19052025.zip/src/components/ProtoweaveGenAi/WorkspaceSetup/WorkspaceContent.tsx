import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Paper, Typography } from "@mui/material";
import AddWorkspaceName from "./AddWorkspaceName";
import WorkspaceCard from "./WorkspaceCard";
import AddWorkspaceCard from "./AddWorkspaceCard";
import { dataProtoweaveGenAiStore } from "../../../stores/cip/ProtoweaveGenAiStore/ProtoweaveGenAiStore";

const WorkspaceContent: React.FC = observer(() => {
  const store = dataProtoweaveGenAiStore;
  const [localNewWorkspaces, setLocalNewWorkspaces] = useState<any[]>([]);
  const loggedInUserId = "admin@gmail.com";

  useEffect(() => {
    store.fetchWorkspaces(loggedInUserId);
  }, [store]);

  const handleAddWorkspace = (name: string) => {
    const newWorkspace = {
      name,
      description: "",
      userId: loggedInUserId,
      team_members: [],
      archive: false,
    };

    console.log("added form",newWorkspace);
    setLocalNewWorkspaces((prev) => [newWorkspace, ...prev]);
  };

  const submitWorkspace = async (updatedWorkspace: any, index: number) => {
    await store.addWorkspace(updatedWorkspace);
    setLocalNewWorkspaces((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <Paper sx={{ width: "605px", p: 2, borderRadius: 1 }}>
      <Typography
        variant="body1"
        sx={{
          py: 1,
          borderBottom: "1px solid rgba(18,18,21,0.30)",
          color: "#1d1b20",
        }}
      >
        Workspace Setup
      </Typography>

      <Box sx={{ display: "flex", gap: 4, mt: 2 }}>
        <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
          <AddWorkspaceName onAddWorkspace={handleAddWorkspace} />

          {localNewWorkspaces && localNewWorkspaces.map((ws, index) => (
            <AddWorkspaceCard
              key={`new-${index}`}
              {...ws}
              onSubmit={(updatedWs) => submitWorkspace(updatedWs, index)}
            />
          ))}

          {store.workspaceList && store.workspaceList.map((ws, index) => (
            <WorkspaceCard key={`ws-${index}`} {...ws} />
          ))}
        </Box>
      </Box>
    </Paper>
  );
});

export default WorkspaceContent;
