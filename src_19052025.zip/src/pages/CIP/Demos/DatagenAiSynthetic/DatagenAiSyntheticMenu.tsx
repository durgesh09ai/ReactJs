import { NavLink } from "react-router-dom";
import "./DatagenAiSyntheticMenu.css"; 

const DatagenAiSyntheticMenu = () => {
  return (
    <div className="datagen-menu">
      <NavLink to="/cip/datagenaisynthetic" end>
        Overview
      </NavLink>
      <NavLink to="/cip/datagenaisynthetic/aboutus">
        About Us
      </NavLink>
      <NavLink to="/cip/datagenaisynthetic/detailpage">
        Detail Page
      </NavLink>
    </div>
  );
};

export default DatagenAiSyntheticMenu;
