export async function fetchJson(url: string) {
  const res = await fetch(url);

  const contentType = res.headers.get("content-type");
  if (!res.ok) {
    throw new Error(`Fetch failed`);
  }
  if (!contentType?.includes("application/json")) {
    throw new Error(`Expected JSON but got HTML`);
  }

  return res.json();
}
