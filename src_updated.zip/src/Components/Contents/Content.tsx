import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch, TextField, InputAdornment } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import SendIcon from "@mui/icons-material/Send";

interface ContentProps {
  backgroundColor: string;
  messages: { user: string; model: string }[];
}

export const Content = ({ backgroundColor, messages }: ContentProps) => {
  return (
    <Box sx={{ flexGrow: 1, p: 3, color: "#fff", backgroundColor, minHeight: "calc(100vh - 64px)", display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
      <Toolbar />
      <Typography sx={{ fontSize: "14px", color: "#ECECF1", textAlign: "center", mb: 2 }}>Agent Process Status</Typography>
      {messages.map((msg, index) => (
        <Paper key={index} sx={{ p: 1, mb: 1, backgroundColor: backgroundColor === "#222" ? "#333" : "#bbb" }}>
          <Typography sx={{ fontSize: "14px", color: "#ECECF1" }}>{msg.model}</Typography>
        </Paper>
      ))}
    </Box>
  );
};