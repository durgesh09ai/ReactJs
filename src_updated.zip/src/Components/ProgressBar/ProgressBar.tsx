import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch, TextField, InputAdornment } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import SendIcon from "@mui/icons-material/Send";

interface ContentProps {
  backgroundColor: string;
}

export const ProgressBar = ({ backgroundColor, messages, inputValue, setInputValue, handleSend }: { backgroundColor: string; messages: { user: string }[]; inputValue: string; setInputValue: (val: string) => void; handleSend: () => void }) => (
  <Box sx={{ width: 400, p: 2, backgroundColor, color: "#fff", height: "calc(100vh - 64px)", display: "flex", flexDirection: "column" }}>
    <Toolbar />
    <Box sx={{ flexGrow: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 1 }}>
      {messages.map((msg, index) => (
        <Box
          key={index}
          sx={{
            alignSelf: "flex-end",
            background: "#1e1e1e",
            color: "#ECECF1",
            borderRadius: "16px",
            px: 2,
            py: 1,
            maxWidth: "85%",
            wordBreak: "break-word",
            fontSize: "14px"
          }}
        >
          {msg.user}
        </Box>
      ))}
    </Box>
    <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
      <TextField
        variant="outlined"
        placeholder="Type your message..."
        multiline
        rows={2}
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton sx={{ color: "#fff" }} onClick={handleSend}>
                <SendIcon />
              </IconButton>
            </InputAdornment>
          )
        }}
        sx={{
          width: "100%",
          backgroundColor: backgroundColor === "#121212" ? "#343541" : "#121212",
          borderRadius: 2,
          border: "1px solid #444",
          '& .MuiOutlinedInput-root': {
            color: "#fff",
            '& fieldset': {
              borderColor: "#444"
            },
            '&:hover fieldset': {
              borderColor: "#444"
            },
            '&.Mui-focused fieldset': {
              borderColor: "#444"
            }
          },
          '& .MuiInputBase-input': {
            color: "#ECECF1",
            fontSize: "16px"
          }
        }}
      />
    </Box>
  </Box>
);