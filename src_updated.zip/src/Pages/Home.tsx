import React, { useState } from "react";
import { AppBar, Box, CssBaseline, Drawer, IconButton, List, ListItem, ListItemText, Toolbar, Typography, Paper, Button, Switch } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import SettingsIcon from "@mui/icons-material/Settings";
import { Content } from "../Components/Contents/Content";
import { ProgressBar } from "../Components/ProgressBar/ProgressBar";
import { Sidebar } from "../Components/Sidebar/Sidebar";

const Home = () => {
  const [open, setOpen] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [backgroundColor, setBackgroundColor] = useState("#121212");
  const [messages, setMessages] = useState<{ user: string; model: string }[]>([]);
  const [inputValue, setInputValue] = useState("");

  const handleToggle = () => setOpen(!open);
  const handleThemeToggle = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    setBackgroundColor(newDarkMode ? "#121212" : "#999");
  };

  const handleSend = () => {
    if (inputValue.trim()) {
      const userMessage = inputValue;
      const modelResponse = `You said: "${userMessage}" — This is a model response.`;
      setMessages([...messages, { user: userMessage, model: modelResponse }]);
      setInputValue("");
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column" }}>
      <CssBaseline />
      <AppBar position="static" sx={{ backgroundColor: backgroundColor === "#121212" ? "#1e1e1e" : "#999", color: "#ECECF1", textAlign: "center" }}>
        <Toolbar>
          <Typography variant="h6" sx={{ width: "100%", textAlign: "center", fontWeight:600,fontSize:"22px"}}>Hello Durgesh ,Welcome to the Litsense</Typography>
        </Toolbar>
      </AppBar>
      <Box sx={{ display: "flex", flexGrow: 1 }}>
      <Sidebar open={open} handleToggle={handleToggle} darkMode={darkMode} handleThemeToggle={handleThemeToggle} />
      <ProgressBar backgroundColor={backgroundColor} messages={messages} inputValue={inputValue} setInputValue={setInputValue} handleSend={handleSend} />
      <Content backgroundColor={darkMode ? "#222" : "#ccc"} messages={messages} />
    </Box>
    </Box>
  );
};

  
  export default Home;