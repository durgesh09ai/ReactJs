import React, { useState } from "react";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Stack,
  TextField,
} from "@mui/material";

interface ResearchInputProps {
  onSubmit?: (content: string) => void;
}

export const ResearchInput: React.FC<ResearchInputProps> = ({ onSubmit }) => {
  const [content, setContent] = useState("");

  const handleUpload = () => {
    alert("Upload functionality would be implemented here");
  };

  return (
    <Stack spacing={1.5} mt={4} width="100%" maxWidth={{ md: "100%" }}>
      <Paper
        elevation={0}
        sx={{
          border: "1px solid rgba(18,18,21,0.30)",
          minHeight: 171,
          width: "100%",
          bgcolor: "white",
          px: 2,
          py: 2,
          borderRadius: 3.75,
          position: "relative",
        }}
      >
        <TextField
          multiline
          fullWidth
          placeholder="Start writing your research or experiment here!"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          InputProps={{
            style: { paddingBottom: 80 }, // Avoid overlap with icons
          }}
          sx={{
            "& .MuiOutlinedInput-root": {
              fontSize: "0.875rem",
              fontWeight: 400,
              color: "black",
              padding: 0,
              "& .MuiOutlinedInput-notchedOutline": {
                border: "none",
              },
            },
          }}
        />

        {/* Bottom-right icons (inside Paper) */}
        <Box
          sx={{
            position: "absolute",
            bottom: 16,
            right: 16,
            display: "flex",
            gap: 1.5,
          }}
        >
          <IconButton>
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/208c98e9fb324089677fa2c76539c52b7b4c731c?placeholderIfAbsent=true"
              alt="Attachment"
              style={{ width: 24, height: 24, objectFit: "contain" }}
            />
          </IconButton>
          <IconButton
          onClick={() => {
            if (onSubmit && content.trim()) {
              onSubmit(content.trim());
              setContent(""); 
            }
          }}
            sx={{
              width: 34,
              height: 34,
              bgcolor: "#0F4977",
              p: 0.875,
              borderRadius: "50%",
              "&:hover": { bgcolor: "#0c3d68" },
            }}
          >
            <img
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f9b62b1d965bb49c78d05f90501225ad1be2b363?placeholderIfAbsent=true"
              alt="Send"
              style={{ width: 20, height: 20, objectFit: "contain" }}
            />
          </IconButton>
        </Box>
      </Paper>

      {/* Upload button outside the Paper, right-aligned */}
      <Box display="flex" justifyContent="flex-end">
        <Button
          onClick={handleUpload}
          variant="outlined"
          sx={{
            color: "#0F4977",
            fontSize: "0.875rem",
            fontWeight: 500,
            px: 2,
            py: 0.75,
            borderRadius: 1.5,
            border: "1px solid rgba(15,73,119,1)",
            textTransform: "none",
          }}
        >
          Upload Research
        </Button>
      </Box>
    </Stack>
  );
};
