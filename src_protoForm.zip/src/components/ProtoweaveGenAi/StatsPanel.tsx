import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";

import { useNavigate } from "react-router-dom";
import UserProfile from "./ui/dashboard/UserProfile";

const StatsPanel  = () => {

  const navigate = useNavigate();
  const handleClick = () => {
    navigate("/dashboarddetail");
  };

  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "370x",
        height:"600px",
        p: 2,
      }}
    >
     <Button
  fullWidth
  sx={{
    backgroundColor: "white",
    borderRadius: "2px",
    px: 2,
    py: 1.5,
    textTransform: "none",
    fontWeight: 500,
    fontSize: "0.875rem",
    color: "black",
    display: "flex",
    alignItems: "center",
    gap: 1,
    justifyContent: "flex-start", // ✅ THIS makes it left-aligned
  }}
>
 
<Typography
  sx={{
    my: "auto",
    color: "#000",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 500,
    lineHeight: "normal",
  }}
>
Reasoning
</Typography>
</Button>

<Paper
      elevation={0}
      sx={{
        backgroundColor: "white",
        border: "1px solid #F5F5F5",
        borderRadius: 2,
        px: 1,
        py: 3,
        mt: "19px",
        width: "100%",
      }}
    >
      <Typography fontWeight={600} fontSize="0.8rem">
      Diabetes Overtreatment and Hypoglycemia in Older Patients With Type Diabetes Overtreatment and Hypoglycemia in Older Patients With Type 
        </Typography>
   </Paper>
    
    </Paper>
  );
};

export default StatsPanel;
