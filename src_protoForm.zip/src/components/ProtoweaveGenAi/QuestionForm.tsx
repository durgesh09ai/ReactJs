import React, { useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

interface Question {
  id: string;
  text: string;
}

interface QuestionFormProps {
  questions: Question[];
  onSave?: (answers: Record<string, string>) => void;
}

export const QuestionForm: React.FC<QuestionFormProps> = ({
  questions,
  onSave,
}) => {
  const [answers, setAnswers] = useState<Record<string, string>>(
    questions.reduce((acc, question) => {
      acc[question.id] = "";
      return acc;
    }, {} as Record<string, string>)
  );

  const handleInputChange = (questionId: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const handleSave = () => {
    onSave?.(answers);
  };

  return (
    <Stack direction="row" spacing={1} width="100%">
      <Avatar
        src={"./chaticon.png"}
        alt="Assistant"
        sx={{
          width: 24,
          height: 24,
          bgcolor: "#0F4977",
          p: 0.5,
          "& img": {
            width: 16,
            height: 16,
            objectFit: "contain",
          },
        }}
      />
      <Paper
        elevation={0}
        sx={{
          flex: 1,
          p: 2.5,
          bgcolor: "#F3FAFF",
          borderRadius: 2,
        }}
      >
        <Stack spacing={2}>
          {questions.map((question) => (
            <Box key={question.id}>
              <Typography
                variant="body2"
                sx={{ color: "black", lineHeight: "17px", fontSize: "0.875rem" }}
              >
                {question.text}
              </Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Your answer"
                value={answers[question.id]}
                onChange={(e) =>
                  handleInputChange(question.id, e.target.value)
                }
                sx={{
                  mt: 1.25,
                  "& .MuiOutlinedInput-root": {
                    bgcolor: "white",
                    fontSize: "0.875rem",
                  },
                }}
              />
            </Box>
          ))}
          <Box>
            <Button
              variant="contained"
              onClick={handleSave}
              sx={{
                bgcolor: "#4CAF50",
                color: "white",
                fontWeight: 500,
                textTransform: "none",
                borderRadius: 3,
                px: 2,
                py: 0.75,
                "&:hover": {
                  bgcolor: "#3d9140",
                },
              }}
            >
              Save
            </Button>
          </Box>
        </Stack>
      </Paper>
    </Stack>
  );
};
