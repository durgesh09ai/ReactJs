import React, { useState } from 'react';
import { Box, Typography, Paper, IconButton, Switch } from '@mui/material';
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";

import { ActionButton } from './ActionButton';
import { ToggleSwitch } from './ToggleSwitch';

export interface Agent {
  id: string;
  name: string;
  url: string;
  description: string;
  enabled: boolean;
  isDefault: boolean;
}

interface AgentCardProps {
  agent: Agent;
  onEdit: (agent: Agent) => void;
  onDelete: (agent: Agent) => void;
  onToggleStatus: (agent: Agent, enabled: boolean) => void;
  onSetDefault: (agent: Agent, isDefault: boolean) => void;
}

export const AgentCard: React.FC<AgentCardProps> = ({
  agent,
  onEdit,
  onDelete,
  onToggleStatus,
  onSetDefault
}) => {

const [isArchived, setIsArchived] = useState(true);

  return (
    <Paper 
    elevation={0}
    sx={{
      border: '1px solid rgba(18,18,21,0.10)',
      width: '100%',
      bgcolor: 'white',
      mt: 2,
      p: 2
    }}>
      <Box sx={{ width: '100%' }}>
        <Box sx={{
          display: 'flex',
          width: '100%',
          alignItems: 'center',
          gap: { xs: '40px' },
          justifyContent: 'space-between'
        }}>
          <Box sx={{
            alignSelf: 'stretch',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '14px',
            color: '#1d1b20',
            fontWeight: '400',
            whiteSpace: 'nowrap',
            lineHeight: 1.2,
            my: 'auto'
          }}>
            <Box sx={{ alignSelf: 'stretch', my: 'auto' }}>Name:</Box>
            <Box sx={{ alignSelf: 'stretch', my: 'auto' }}>{agent.name}</Box>
          </Box>
          <Box sx={{
            alignSelf: 'stretch',
            display: 'flex',
            alignItems: 'center',
            // gap: '8px',
            fontSize: '14px',
            color: '#1d1b20',
            fontWeight: 'normal',
            lineHeight: 1.2,
            my: 'auto'
          }}>
            <img
              src={agent.enabled ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/5ab811f2eb0780d348a194855f0674983dbf85e4?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f328155d04b0e78b2a54f98761656a1d0157e85a?placeholderIfAbsent=true"}
              style={{ width: 20, height: 20, objectFit: 'contain' }}
              alt=""
            />
            <Box sx={{ alignSelf: 'stretch', my: 'auto' }}>{agent.url}</Box>
          </Box>
          <Box sx={{ alignSelf: 'stretch', display: 'flex', alignItems: 'center', gap: '8px', my: 'auto' }}>
            {agent.enabled ? (
              <>
                <Box sx={{
                  alignSelf: 'stretch',
                  position: 'relative',
                  display: 'flex',
                  alignItems: 'start',
                  justifyContent: 'center',
                  width: '22px',
                  my: 'auto',
                  p: '2px',
                  borderRadius: '100px'
                }}>
                  <Box sx={{
                    zIndex: 0,
                    display: 'flex',
                    width: '18px',
                    height: '18px',
                    bgcolor: '#4CAF50',
                    my: 'auto',
                    borderRadius: '2px'
                  }} />
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/08624399241da2feeac29c58c3c7ab161d2608e1?placeholderIfAbsent=true"
                    style={{
                      aspectRatio: '1',
                      objectFit: 'contain',
                      width: '24px',
                      position: 'absolute',
                      zIndex: 0,
                      transform: 'translate(-50%, -50%)',
                      height: '24px',
                      left: '50%',
                      top: '50%'
                    }}
                    alt=""
                  />
                </Box>
                <Typography sx={{
                  alignSelf: 'stretch',
                  fontSize: '14px',
                  color: '#1d1b20',
                  fontWeight: 'normal',
                  whiteSpace: 'nowrap',
                  lineHeight: 1.2,
                  my: 'auto'
                }}>
                  Enabled
                </Typography>
              </>
            ) : (
              <>
                <Box sx={{
                  alignItems: 'center',
                  alignSelf: 'stretch',
                  display: 'flex',
                 // gap: '10px',
                  width: '20px',
                  height: '20px',
                  bgcolor: '#B3261E',
                  my: 'auto',
                  p: '2px',
                  borderRadius: '2px'
                }}>
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/018b71b2769854b7365788752160ea599a05f547?placeholderIfAbsent=true"
                    style={{ 
                      aspectRatio: '1', 
                      objectFit: 'contain', 
                      width: '16px', 
                      alignSelf: 'stretch', 
                    }}
                    alt=""
                  />
                </Box>
                <Typography sx={{
                  alignSelf: 'stretch',
                  fontSize: '14px',
                  color: '#1d1b20',
                  fontWeight: 'normal',
                  whiteSpace: 'nowrap',
                  lineHeight: 1.2,
                  my: 'auto'
                }}>
                  Disabled
                </Typography>
              </>
            )}
          </Box>
        </Box>
        <Box sx={{
          display: 'flex',
          width: '324px',
          maxWidth: '100%',
          alignItems: 'center',
          gap: '16px',
          fontSize: '14px',
          color: '#1d1b20',
          fontWeight: 'normal',
          lineHeight: 1.2,
          mt: '23px'
        }}>
          <Box sx={{ alignSelf: 'stretch', whiteSpace: 'nowrap', my: 'auto' }}>
            Description
          </Box>
          <Box sx={{ alignSelf: 'stretch', my: 'auto' }}>
            {agent.description}
          </Box>
        </Box>
      </Box>
      <Box sx={{
        display: 'flex',
        width: '100%',
        alignItems: 'center',
        gap: { xs: '40px', md: '88px' },
        justifyContent: 'space-between',
        mt: 2
      }}>
        <Box sx={{
          alignSelf: 'stretch',
          display: 'flex',
          minWidth: '240px',
          alignItems: 'center',
          gap: '12px',
          fontSize: '14px',
          fontWeight: 500,
          lineHeight: 1,
          my: 'auto'
        }}>

          <ActionButton 
            variant="secondary" 
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/69523dae9b503db0228e28a943c595ab1beed123?placeholderIfAbsent=true"
            onClick={() => onEdit(agent)}
          >
            Edit Details
          </ActionButton>
          <ActionButton 
            variant="danger" 
            icon={agent.enabled ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ec5f540356098a261f0dbb4eedb2ba3a79480c97?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/701be2f9a7eef1aa062219b0922dd9b5c8c27e1f?placeholderIfAbsent=true"}
            onClick={() => onDelete(agent)}
          >
            Delete
          </ActionButton>


        </Box>
        <Box sx={{
          justifyContent: 'center',
          alignItems: 'center',
          alignSelf: 'stretch',
          display: 'flex',
          minHeight: '32px',
          my: 'auto'
        }}>
          <Typography sx={{
            color: 'black',
            fontSize: '14px',
            fontWeight: 'normal',
            lineHeight: 1,
            alignSelf: 'stretch',
            my: 'auto',
            mr: 1
          }}>
            Default:
          </Typography>
            <Switch
            checked={isArchived}
            onChange={() => setIsArchived(!isArchived)}
            sx={{
                '& .MuiSwitch-switchBase.Mui-checked': {
                  color: '#34C759',
                  '&:hover': {
                    backgroundColor: 'rgba(52, 199, 89, 0.08)',
                  },
                },
                '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  backgroundColor: '#34C759',
                },
                '& .MuiSwitch-track': {
                  borderRadius: 80.645,
                },
                '& .MuiSwitch-thumb': {
                  boxShadow: '0px 0px 0px 1px rgba(0,0,0,0.04)',
                 },
              }}
            />

        </Box>
      </Box>
    </Paper>
  );
};
