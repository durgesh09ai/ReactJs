import React, { useState } from "react";
import { Box, Paper, Typography } from "@mui/material";
import AddWorkspaceForm from "./AddWorkspaceForm";
import WorkspaceCard from "./WorkspaceCard";
import AddWorkspaceCard from "./AddWorkspaceCard";

const WorkspaceContent: React.FC = () => {
  const [workspaces, setWorkspaces] = useState([
    {
      name: "Workspace 1",
      description: "Diabetes Type 1",
      fullDescription: "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling.",
      owner: "admin65@gamil.com",
      members: ["gaurav34@gmail.com", "gaurav34@gmail.com"],
      isToggleOn: true,
      isNew: false
    }
  ]);

  const handleAddWorkspace = (name: string) => {
    const newWorkspace = {
      name,
      description: "",
      fullDescription: "",
      owner: "admin65@gamil.com",
      members: [],
      isToggleOn: false,
      isNew: true // <-- mark as new
    };
    setWorkspaces((prev) => [newWorkspace,...prev]);
  };

  const handleSubmitWorkspace = (updatedWorkspace: any, index: number) => {
    setWorkspaces((prev) =>
      prev.map((ws, i) => (i === index ? updatedWorkspace : ws))
    );
  };

  return (
    <Paper sx={{ width: '605px', p: 2, borderRadius: 1 }}>
      <Typography
        variant="body1"
        sx={{
          py: 1,
          borderBottom: '1px solid rgba(18,18,21,0.30)',
          color: '#1d1b20',
        }}
      >
        Workspace Setup
      </Typography>

      <Box sx={{ display: 'flex', gap: 4, mt: 2 }}>
        <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
          <AddWorkspaceForm onAddWorkspace={handleAddWorkspace} />
          {workspaces.map((ws, index) =>
            ws.isNew ? (
              <AddWorkspaceCard
                key={index}
                {...ws}
                onSubmit={(updatedWs) => handleSubmitWorkspace(updatedWs, index)}
              />
            ) : (
              <WorkspaceCard key={index} {...ws} />
            )
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default WorkspaceContent;
