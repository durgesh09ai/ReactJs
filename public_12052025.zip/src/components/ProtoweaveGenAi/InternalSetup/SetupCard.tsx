import React, { useState } from 'react';
import { Box, Typography, Paper, IconButton, Switch, CardContent, Stack, Divider, FormControlLabel } from '@mui/material';
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { ActionButton } from './ActionButton';
export interface Setup {
  id: string;
  name: string;
  url: string;
  username:string;
  password:string;
  description: string;
  enabled: boolean;
}

interface SetupCardProps {
  Setup: Setup;
  onEdit: (Setup: Setup) => void;
  onDelete: (Setup: Setup) => void;
  onToggleStatus: (Setup: Setup, enabled: boolean) => void;
}

export const SetupCard: React.FC<SetupCardProps> = ({
  Setup,
  onEdit,
  onDelete,
  onToggleStatus,
}) => {

const [isArchived, setIsArchived] = useState(true);

  return (
    <Paper
    elevation={0}
    sx={{ maxWidth: 495, borderRadius: 1, boxShadow: 1, mb: 2 }}
  >
    <CardContent>
    <Stack direction="row" justifyContent="space-between" alignItems="center" spacing={2}>
      <Typography  fontWeight="bold" fontSize={14}>
        {Setup.name}
      </Typography>
      <Box display="flex" gap={1}>
      <ActionButton 
              variant="danger"
              icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/69523dae9b503db0228e28a943c595ab1beed123?placeholderIfAbsent=true"
              onClick={() => onEdit(Setup)} children={''}      >
      </ActionButton>
      <ActionButton 
              variant="danger"
              icon={Setup.enabled ? "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ec5f540356098a261f0dbb4eedb2ba3a79480c97?placeholderIfAbsent=true" : "https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/701be2f9a7eef1aa062219b0922dd9b5c8c27e1f?placeholderIfAbsent=true"}
              onClick={() => onDelete(Setup)} children={''}      >
      </ActionButton>
      </Box>
    </Stack>

      
    <Box mt={2} display="flex" flexDirection="column" gap={1}>
  <Box display="flex">
    <Box width="33.33%">
      <Typography variant="body2" color="#000">
        Description:
      </Typography>
    </Box>
    <Box width="66.66%">
      <Typography variant="body2" color="#000">
        {Setup.description}
      </Typography>
    </Box>
  </Box>

  <Box display="flex">
    <Box width="33.33%">
      <Typography variant="body2" color="#000">
        SharePoint Site URL:
      </Typography>
    </Box>
    <Box width="66.66%">
      <Typography variant="body2" color="#000">
        {Setup.url}
      </Typography>
    </Box>
  </Box>
</Box>
  </CardContent>


    <CardContent sx={{ pb: 1 }}>
      <Paper variant="outlined" sx={{ padding: 2, borderRadius: 1 }}>
      <Box>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          mb: 2,
        }}
      >
  <Typography variant="subtitle2">AD Credentials:</Typography>

  <FormControlLabel
    control={
      <Switch
        size="small"
        checked={Setup.enabled}
        color="primary"
        onChange={(e) => onToggleStatus(Setup, e.target.checked)}
      />
    }
    label={
      <Typography variant="body2">
        {Setup.enabled ? "Enabled" : "Disabled"}
      </Typography>
    }
    labelPlacement="start"
  />
</Box>


  <Box display="flex" flexDirection="column" gap={1}>
    <Box display="flex">
      <Box width="33.33%">
        <Typography variant="body2" color="text.secondary">
          Username:
        </Typography>
      </Box>
      <Box width="66.66%">
        <Typography variant="body2">{Setup.username}</Typography>
      </Box>
    </Box>

    <Box display="flex">
      <Box width="33.33%">
        <Typography variant="body2" color="text.secondary">
          Password:
        </Typography>
      </Box>
      <Box width="66.66%">
        <Typography variant="body2">{Setup.password}</Typography>
      </Box>
    </Box>
  </Box>
</Box>



    
      </Paper>
    </CardContent>
  </Paper>
  );
};
