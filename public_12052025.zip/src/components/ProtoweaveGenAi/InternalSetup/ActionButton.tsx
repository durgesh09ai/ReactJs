import React from 'react';
import { Button, ButtonProps } from '@mui/material';
import { styled } from '@mui/material/styles';

interface ActionButtonProps {
  variant: 'primary' | 'secondary' | 'danger' | 'outline';
  onClick?: () => void;
  icon?: string;
  children: React.ReactNode;
  className?: string;
}

const StyledButton = styled(Button)<ButtonProps>(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  padding: '4px 8px',
  borderRadius: '8px',
  textTransform: 'none',
  minHeight: '32px',
  fontWeight: 500,
  fontSize: '14px',
  lineHeight: '16px',
}));

export const ActionButton: React.FC<ActionButtonProps> = ({
  variant,
  onClick,
  icon,
  children,
  className = ''
}) => {
  const getButtonProps = () => {
    switch (variant) {
      case 'primary':
        return {
          variant: 'contained' as const,
          color: 'primary' as const,
          sx: { bgcolor: '#0F4977', borderColor: '#0F4977', color: 'white' }
        };
      case 'secondary':
        return {
          variant: 'outlined' as const,
          color: 'primary' as const,
          sx: { color: '#0F4977', borderColor: '#0F4977' }
        };
      case 'danger':
        return {
          variant: 'text' as const,
          color: 'error' as const,
          sx: { color: '#B3261E' }
        };
      case 'outline':
        return {
          variant: 'outlined' as const,
          color: 'primary' as const,
          sx: { color: '#0F4977', borderColor: '#0F4977' }
        };
      default:
        return {
          variant: 'outlined' as const,
          color: 'primary' as const,
          sx: { color: '#0F4977', borderColor: '#0F4977' }
        };
    }
  };

  const buttonProps = getButtonProps();

  return (
    <StyledButton
      onClick={onClick}
      className={className}
      variant={buttonProps.variant}
      color={buttonProps.color}
      sx={buttonProps.sx}
    >
      {icon && (
        <img
          src={icon}
          style={{ width: 24, height: 24, objectFit: 'contain' }}
          alt=""
        />
      )}
      {children}
    </StyledButton>
  );
};
