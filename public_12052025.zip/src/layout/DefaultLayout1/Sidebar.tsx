import { Link } from "react-router-dom";
import { FaHome, FaProjectDiagram, FaBrain } from "react-icons/fa";

const Sidebar = () => (
  <aside style={{ width: "200px", padding: "1rem", background: "#f0f0f0" }}>
    <nav>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li style={{ marginBottom: "1rem" }}>
          <Link to="/" style={{ textDecoration: "none", color: "#333", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <FaHome /> Main
          </Link>
        </li>
        <li style={{ marginBottom: "1rem" }}>
          <Link to="/cip" style={{ textDecoration: "none", color: "#333", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <FaProjectDiagram /> CIP
          </Link>
        </li>
        <li style={{ marginBottom: "1rem" }}>
          <Link to="/cip/datagenaisynthetic" style={{ textDecoration: "none", color: "#333", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <FaBrain />Demo1
          </Link>
        </li>
      </ul>
    </nav>
  </aside>
);

export default Sidebar;
