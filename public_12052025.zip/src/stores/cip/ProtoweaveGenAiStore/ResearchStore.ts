import { makeAutoObservable, runInAction } from "mobx";

class ResearchStore {
  sessionId: string | null = null;
  messages: any[] = [];
  thinkingData: any[] = [];
  isResearching: boolean = false;
  report: { markdown: string; docx: string } | null = null;
  ws: WebSocket | null = null;

  apiUrl: string = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";


setMessages(newMessages: any[]) {
  this.messages = newMessages;
}

addMessage(newMessage: any) {
  this.messages.push(newMessage);
}


  constructor() {
    makeAutoObservable(this);
  }

  connectWebSocket() {
    if (!this.sessionId || !this.isResearching) return;

    this.ws = new WebSocket(`${this.apiUrl.replace("http", "ws")}/ws/research/${this.sessionId}`);

    this.ws.onopen = () => {
      console.log("WebSocket connected");
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      runInAction(() => {
        this.thinkingData.push(data);
      });

      if (data.step === "completed") {
        this.fetchReport();
      }
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    this.ws.onclose = () => {
      console.log("WebSocket disconnected");
    };
  }

  async fetchReport() {
    try {
      const response = await fetch(`${this.apiUrl}/research/report/${this.sessionId}`);
      const data = await response.json();
      runInAction(() => {
        this.report = { markdown: data.report, docx: data.docx };
        this.isResearching = false;
      });
    } catch (error) {
      console.error("Error fetching report:", error);
    }
  }

  cleanup() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }



  // Add inside the ResearchStore class

async handleSendTopic(topic: string) {
    try {
      const response = await fetch(`${this.apiUrl}/research/plan`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ topic }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        this.sessionId = data.plan_id;
        this.messages = [
          { role: "user", content: topic },
          {
            role: "assistant",
            content: "I need some clarification to better understand your research needs:",
            questions: data.questions,
          },
        ];
      });
    } catch (error) {
      console.error("Error creating research plan:", error);
    }
  }
  
  async handleSubmitAnswers(answers: Record<string, string>, approved: boolean) {
    try {
      const response = await fetch(`${this.apiUrl}/research/plan/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan_id: this.sessionId,
          answers,
          approved,
          feedback: approved ? null : "Please revise the plan based on my answers.",
        }),
      });
  
      const data = await response.json();
  
      runInAction(() => {
        if (approved) {
          this.isResearching = true;
          this.messages.push(
            { role: "user", content: "I approve this research plan." },
            {
              role: "assistant",
              content:
                "Thank you! I'll start the research process now. You can see my progress on the right panel.",
            },
          );
        } else {
          this.messages.push(
            { role: "user", content: "I need some adjustments to the plan." },
            {
              role: "assistant",
              content: "I've revised the plan. Please provide more information:",
              questions: data.questions,
            },
          );
        }
      });
    } catch (error) {
      console.error("Error submitting feedback:", error);
    }
  }
  



}







export const researchStore = new ResearchStore();
