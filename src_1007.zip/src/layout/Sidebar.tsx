// src/components/Sidebar.tsx
import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import {
  Box,
  Typography,
  Avatar,
  Button,
  IconButton,
} from "@mui/material";
import NavItem from "./NavItem";
import { mainPageStore } from "../stores/MainPageStore";
import { Add } from "@mui/icons-material";
import { SearchInput } from "../components/DashboardEmblem/SearchInput";
import { ChatHistory } from "../components/DashboardEmblem/ChatHistory";
import { WorkspaceSection } from "../components/DashboardEmblem/WorkspaceSection";

interface SidebarProps {
  collapsed?: boolean;
}

const Sidebar: React.FC<SidebarProps> = observer(({ collapsed = false }) => {

   const [messages, setMessages] = useState<string[]>([]);
  
    const handleNewChat = () => {
      setMessages([]);
      console.log('Starting new chat...');
    };

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh"
      px={2}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
      sx={{ borderRight: "1px solid rgba(0,0,0,0.1)" }}
    >
      {/* -------------- HEADER -------------- */}
      <Box flexGrow={1}>
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          px={2}
          py={1.5}
          borderBottom="1px solid rgba(0,0,0,0.1)"
        >
          <Typography
            variant="h6"
            sx={{ fontSize: 28, fontWeight: 600, color: "#e7552b" }}
          >
            {!collapsed && "EXL"}
          </Typography>
          {!collapsed && (
            <Avatar
              src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9df66a2e096fffaa4eec49ff70db980f5326516a"
              sx={{ width: 24, height: 24 }}
              variant="square"
            />
          )}
        </Box>

        {/* -------------- NAV ITEMS -------------- */}
        <Box display="flex" flexDirection="column" mt={2}>
          {!collapsed && (
            <Typography
              sx={{
                fontSize: 12,
                textTransform: "uppercase",
                color: "#888",
                px: 2,
                py: 1,
              }}
            >
              Home
            </Typography>
          )}


         <Box sx={{ width: '100%', flex: 1 }}>
                  
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              alignItems: 'stretch',
              gap: 0.625,
              fontSize: '16px',
              color: 'white',
              fontWeight: 500,
              letterSpacing: '-0.11px',
              lineHeight: 1,
              mt: 1
            }}
          >
            <Button
              onClick={handleNewChat}
              sx={{
                backgroundColor: '#0F4977',
                color: 'white',
                display: 'flex',
                alignItems: 'stretch',
                gap: 5,
                px: 1.75,
                py: 1,
                borderRadius: '10px',
                border: '1px solid #0F4977',
                textTransform: 'none',
                fontSize: '16px',
                fontWeight: 500,
                '&:hover': {
                  backgroundColor: '#0d3f63'
                }
              }}
            >
              <Typography sx={{ color: 'white' }}>New Chat</Typography>
              <Add sx={{ width: 18, height: 20, color: 'white' }} />
            </Button>
            <IconButton
              sx={{
                width: '39px',
                height: '39px',
                backgroundColor: '#f5f5f5',
                borderRadius: '8px',
                '&:hover': {
                  backgroundColor: '#e0e0e0'
                }
              }}
              aria-label="More options"
            >
              <Add sx={{ width: 20, height: 20 }} />
            </IconButton>
          </Box>
          
          <SearchInput />
          
          <ChatHistory />
          
          <WorkspaceSection />
          
          <Box sx={{ display: 'flex', minHeight: '178px', width: '100%', mt: 1 }} />
        </Box>

          
        </Box>
      </Box>

      {/* -------------- FOOTER -------------- */}
      {!collapsed && (
        <Box mt={2}>
          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/3904791a901d558c2c5d7347a0090cb8906978c9"
            label="Bookmarked"
            collapsed={collapsed}
          />
          <NavItem
            icon="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/9ff595e8aeb1d76299e427e0b5390f825a7dd6d5"
            label="Settings"
            collapsed={collapsed}
          />
        </Box>
      )}
    </Box>
  );
});

export default Sidebar;
