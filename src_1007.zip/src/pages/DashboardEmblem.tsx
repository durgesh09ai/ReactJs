import React, { useState } from 'react';
import { Box, ThemeProvider, createTheme } from '@mui/material';
import { Sidebar } from '../components/DashboardEmblem/Sidebar';
import { MainContent } from '../components/DashboardEmblem/MainContent';


const theme = createTheme({
  typography: {
    fontFamily: 'system-ui, -apple-system, sans-serif',
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
        },
      },
    },
  },
});

const DashboardEmblem = () => {
  const [messages, setMessages] = useState<string[]>([]);

  const handleNewChat = () => {
    setMessages([]);
    console.log('Starting new chat...');
  };

  const handleBackClick = () => {
    console.log('Going back...');
  };

  const handleMessageSend = (message: string) => {
    setMessages(prev => [...prev, message]);
    console.log('Message sent:', message);
  };

  return (
    <ThemeProvider theme={theme}>
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexWrap: 'wrap',
          width:'100%',
          height: '86vh',
          minHeight: '86vh'
        }}
      >
        <MainContent onMessageSend={handleMessageSend} />
      </Box>
    </ThemeProvider>
  );
};

export default DashboardEmblem;
