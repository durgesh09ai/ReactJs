import React, { useEffect, useRef, useState } from 'react';
import { Box, Paper, TextField, IconButton, Fab, Typography } from '@mui/material';
import { AttachFile, Mic, Send } from '@mui/icons-material';
import { SuggestionPills } from './SuggestionPills';
import { PersonOutline, SmartToy } from '@mui/icons-material'; 

interface MainContentProps {
  onMessageSend?: (message: string) => void;
}

export const MainContent: React.FC<MainContentProps> = ({ onMessageSend }) => {
  const [message, setMessage] = useState('');
  const [conversations, setConversations] = useState<{ prompt: string; response: string }[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      const userPrompt = message.trim();
      const dummyResponse = `This is a dummy response for: "${userPrompt}"`;

      setConversations(prev => [...prev, { prompt: userPrompt, response: dummyResponse }]);
      onMessageSend?.(userPrompt);
      setMessage('');
    }
  };

  const handleSuggestionClick = (suggestion: { id: string; label: string }) => {
    setMessage(suggestion.label);
  };

  // Auto scroll to bottom
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [conversations]);



  return (
    <Box
      component="main"
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minWidth: '240px',
        flexDirection: 'column',
        flex: 1,
        backgroundColor: 'white',
        p: 1.5,
        '@media (max-width: 768px)': {
          maxWidth: '100%'
        }
      }}
    >
      <Box sx={{ width: '732px', maxWidth: '100%' }}>
        <Box
          component="section"
          sx={{
            display: 'flex',
            width: '100%',
            flexDirection: 'column',
            alignItems: 'stretch',
            justifyContent: 'center',
            px: 2.375,
            '@media (max-width: 768px)': {
              maxWidth: '100%'
            }
          }}
        >
            
        {/* Header only shown when no conversation */}
        {conversations.length === 0 && (
          <Typography variant="h4" sx={{ mb: 2, fontWeight: 600, color: '#000' }}>
            What can I help with?
          </Typography>
        )}
          
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              flexDirection: 'column',
              alignItems: 'stretch',
              justifyContent: 'center',
              mt: 1,
              '@media (max-width: 768px)': {
                maxWidth: '100%'
              }
            }}
          >

{conversations.length > 0 && (
  <Box
    ref={scrollRef}
    sx={{
      maxHeight: 'calc(100vh - 350px)',
      overflowY: 'auto',
      mb: 2,
      pr: 1,
    }}
  >
    {conversations.map((item, index) => (
      <Box key={index} mb={2}>
        {/* User Prompt */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: 1,
            p: 1.5,
            borderRadius: 2,
            backgroundColor: '#f1f5f9',
          }}
        >
        <PersonOutline sx={{ color: '#0F4977', mt: '2px' }} />
        <Typography>{item.prompt}</Typography>
        </Box>

        {/* Bot Response */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: 1,
            p: 1.5,
            mt: 1,
            borderRadius: 2,
            backgroundColor: '#e8f1fc',
          }}
        >
          <SmartToy sx={{ color: '#0F4977', mt: '2px' }} />
          <Typography>{item.response}</Typography>
        </Box>
      </Box>
    ))}
  </Box>
)}


            
            <Paper
  component="form"
  onSubmit={handleSubmit}
  sx={{
    display: 'flex',
    alignItems: 'stretch',
    minHeight: '85px', // Reduced height
    width: '100%',
    gap: 1.25,
    backgroundColor: 'white',
    px: 1.875,
    py: 2,
    borderRadius: '15px',
    border: '1px solid rgba(18,18,21,0.30)',
    position: 'relative', // Added for positioning the icons
    '@media (max-width: 768px)': {
      maxWidth: '100%'
    }
  }}
>
  <Box
    sx={{
      minWidth: '240px',
      width: '100%',
      flex: 1,
      '@media (max-width: 768px)': {
        maxWidth: '100%'
      }
    }}
  >
    <Box
      sx={{
        display: 'flex',
        width: '100%',
        gap: 4.75,
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        '@media (max-width: 768px)': {
          maxWidth: '100%'
        }
      }}
    >
      <Box
        sx={{
          display: 'flex',
          minWidth: '240px',
          alignItems: 'center',
          gap: 1,
          width: '519px',
          '@media (max-width: 768px)': {
            maxWidth: '100%'
          }
        }}
      >
        <TextField
          multiline
          rows={3}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Ask anything..."
          variant="standard"
          sx={{
            flex: 1,
            '& .MuiInputBase-root': {
              color: '#000000',
              fontSize: '14px',
              fontWeight: 'normal',
              minHeight: '70px',
              border: 'none',
              '&::before': {
                display: 'none'
              },
              '&::after': {
                display: 'none'
              }
            },
            '& .MuiInputBase-input': {
              padding: 0
            },
            '@media (max-width: 768px)': {
              maxWidth: '100%'
            }
          }}
        />
      </Box>

    {/* Moved to absolute top-right */}
<Box
  sx={{
    position: 'absolute',
    top: 8,
    right: 8,
    display: 'flex',
    alignItems: 'center',
    gap: 1.5
  }}
>
  <IconButton
    size="small"
    sx={{
      width: '32px',
      height: '32px',
      p: 0.5,
      '&:hover': {
        backgroundColor: 'rgba(0,0,0,0.04)'
      }
    }}
    aria-label="Attach file"
  >
    <AttachFile sx={{ fontSize: 22, color: 'black' }} />
  </IconButton>

  <IconButton
    size="small"
    sx={{
      width: '32px',
      height: '32px',
      p: 0.5,
      '&:hover': {
        backgroundColor: 'rgba(0,0,0,0.04)'
      }
    }}
    aria-label="Voice input"
  >
    <Mic sx={{ fontSize: 24, color: 'black' }} />
  </IconButton>

<IconButton
  type="submit"
  disabled={!message.trim()}
  sx={{
    width: 32,
    height: 32,
    backgroundColor: '#0F4977',
    '&:hover': {
      backgroundColor: '#0d3f63'
    },
    '&.Mui-disabled': {
      backgroundColor: '#ccc'
    }
  }}
  aria-label="Send message"
>
  <Box sx={{ color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Send sx={{ fontSize: 16 }} />
  </Box>
</IconButton>


</Box>
</Box>
<SuggestionPills onSuggestionClick={handleSuggestionClick} />
 </Box>
</Paper>



          </Box>
        </Box>
      </Box>
    </Box>
  );
};
