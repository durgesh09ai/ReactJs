import React, { useState } from 'react';
import { Box, Button, Collapse, List, ListItemButton, ListItemText, Typography } from '@mui/material';
import { ExpandMore, ExpandLess } from '@mui/icons-material';

interface ChatHistoryItem {
  id: string;
  name: string;
  isActive?: boolean;
}

interface ChatHistoryProps {
  items?: ChatHistoryItem[];
}

export const ChatHistory: React.FC<ChatHistoryProps> = ({
  items = [
    { id: '1', name: 'Abc pdf', isActive: true },
    { id: '2', name: 'Abc2' },
    { id: '3', name: 'Abc3' }
  ]
}) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <Box sx={{ width: '100%', mt: 1 }}>
      <Button
        fullWidth
        onClick={() => setIsExpanded(!isExpanded)}
        sx={{
          justifyContent: 'space-between',
          minHeight: '37px',
          color: '#121215',
          fontSize: '14px',
          fontWeight: 'normal',
          textTransform: 'none',
          px: 1,
          '&:hover': {
            backgroundColor: 'rgba(0,0,0,0.04)'
          }
        }}
      >
        <Typography variant="body2" sx={{ color: '#121215' }}>
          History
        </Typography>
        {isExpanded ? <ExpandLess /> : <ExpandMore />}
      </Button>
      
      <Collapse in={isExpanded}>
        <List sx={{ pl: 1.5 }}>
          {items.map((item) => (
            <ListItemButton
              key={item.id}
              sx={{
                minHeight: '37px',
                borderLeft: item.isActive 
                  ? '1px solid #0F4977' 
                  : '1px solid #E4E4E5',
                '&:hover': {
                  backgroundColor: 'rgba(0,0,0,0.04)'
                }
              }}
            >
              <ListItemText 
                primary={item.name}
                primaryTypographyProps={{
                  sx: {
                    color: 'black',
                    fontSize: '14px',
                    fontWeight: 'normal'
                  }
                }}
              />
            </ListItemButton>
          ))}
        </List>
      </Collapse>
    </Box>
  );
};
