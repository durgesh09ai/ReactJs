import React, { useState } from 'react';
import { Box, Button, Collapse, List, ListItemButton, ListItemText, Typography, Paper } from '@mui/material';
import { ExpandMore, ExpandLess, Add, MoreHoriz } from '@mui/icons-material';

interface WorkspaceItem {
  id: string;
  name: string;
  items?: string[];
  isExpanded?: boolean;
}

interface WorkspaceSectionProps {
  workspaces?: WorkspaceItem[];
}

export const WorkspaceSection: React.FC<WorkspaceSectionProps> = ({
  workspaces = [
    {
      id: '1',
      name: 'Name 1 - WB 1',
      items: ['Type A', 'Type B', 'Type C', 'Type D'],
      isExpanded: true
    },
    { id: '2', name: 'Name 2 - WB 2' },
    { id: '3', name: 'Name 3 - WB 3' },
    { id: '4', name: 'Name 4 - WB 4' }
  ]
}) => {
  const [isMainExpanded, setIsMainExpanded] = useState(true);
  const [expandedWorkspaces, setExpandedWorkspaces] = useState<Set<string>>(
    new Set(['1'])
  );

  const toggleWorkspace = (id: string) => {
    const newExpanded = new Set(expandedWorkspaces);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedWorkspaces(newExpanded);
  };

  return (
    <Box sx={{ 
      width: '100%', 
      mt: 2, 
      borderTop: '1px solid rgba(18,18,21,0.10)'
    }}>
      <Button
        fullWidth
        onClick={() => setIsMainExpanded(!isMainExpanded)}
        sx={{
          justifyContent: 'space-between',
          minHeight: '37px',
          color: '#121215',
          fontSize: '14px',
          fontWeight: 'normal',
          textTransform: 'none',
          px: 1,
          maxWidth: '272px',
          '&:hover': {
            backgroundColor: 'rgba(0,0,0,0.04)'
          }
        }}
      >
        <Typography variant="body2" sx={{ color: '#121215' }}>
          Workspace
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <Add sx={{ width: 14, height: 16, color: '#E4E4E5' }} />
          {isMainExpanded ? <ExpandLess /> : <ExpandMore />}
        </Box>
      </Button>
      
      <Collapse in={isMainExpanded}>
        <Box sx={{ width: '100%', mt: 1 }}>
          {workspaces.map((workspace) => (
            <Box key={workspace.id} sx={{ width: '100%', maxWidth: '272px', px: 1.25, mb: 1 }}>
              {workspace.items ? (
                <Paper sx={{ 
                  width: '100%', 
                  backgroundColor: '#fafafa',
                  elevation: 0,
                  borderRadius: 1
                }}>
                  <Button
                    fullWidth
                    onClick={() => toggleWorkspace(workspace.id)}
                    sx={{
                      justifyContent: 'space-between',
                      px: 1,
                      pt: 1.25,
                      pb: 1,
                      color: 'black',
                      fontSize: '14px',
                      fontWeight: 'normal',
                      textTransform: 'none',
                      borderRadius: '4px 4px 0 0',
                      '&:hover': {
                        backgroundColor: 'rgba(0,0,0,0.08)'
                      }
                    }}
                  >
                    <Typography variant="body2" sx={{ color: 'black' }}>
                      {workspace.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      {expandedWorkspaces.has(workspace.id) ? <ExpandLess /> : <ExpandMore />}
                      <MoreHoriz sx={{ width: 16, height: 16 }} />
                    </Box>
                  </Button>
                  
                  <Collapse in={expandedWorkspaces.has(workspace.id)}>
                    <List sx={{ px: 0.5, pb: 1 }}>
                      {workspace.items.map((item, index) => (
                        <ListItemButton
                          key={index}
                          sx={{
                            minHeight: '37px',
                            borderLeft: '1px solid #E4E4E5',
                            '&:hover': {
                              backgroundColor: 'rgba(0,0,0,0.08)'
                            }
                          }}
                        >
                          <ListItemText 
                            primary={item}
                            primaryTypographyProps={{
                              sx: {
                                color: 'black',
                                fontSize: '14px',
                                fontWeight: 'normal'
                              }
                            }}
                          />
                        </ListItemButton>
                      ))}
                    </List>
                  </Collapse>
                </Paper>
              ) : (
                <Button
                  fullWidth
                  sx={{
                    justifyContent: 'space-between',
                    px: 1,
                    pt: 1.25,
                    pb: 1,
                    color: 'black',
                    fontSize: '14px',
                    fontWeight: 'normal',
                    textTransform: 'none',
                    borderRadius: 1,
                    '&:hover': {
                      backgroundColor: 'rgba(0,0,0,0.04)'
                    }
                  }}
                >
                  <Typography variant="body2" sx={{ color: 'black' }}>
                    {workspace.name}
                  </Typography>
                  <ExpandMore sx={{ width: 16, height: 16 }} />
                </Button>
              )}
            </Box>
          ))}
        </Box>
      </Collapse>
    </Box>
  );
};
