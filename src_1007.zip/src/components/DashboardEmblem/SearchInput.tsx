import React from 'react';
import { TextField, InputAdornment, Box } from '@mui/material';
import { Search } from '@mui/icons-material';

interface SearchInputProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
}

export const SearchInput: React.FC<SearchInputProps> = ({
  placeholder = "Search anything..",
  value = "",
  onChange
}) => {
  return (
    <Box sx={{ mt: 1 }}>
      <TextField
        fullWidth
        size="small"
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        variant="outlined"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Search sx={{ color: '#121215', width: 20, height: 20 }} />
            </InputAdornment>
          ),
          sx: {
            minHeight: '38px',
            fontSize: '14px',
            color: '#121215',
            backgroundColor: 'white',
            borderRadius: '8px',
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: 'rgba(18,18,21,0.10)',
              borderWidth: '0 0 1px 0',
            },
            '&:hover .MuiOutlinedInput-notchedOutline': {
              borderColor: 'rgba(18,18,21,0.20)',
            },
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
              borderColor: 'rgba(18,18,21,0.30)',
            }
          }
        }}
      />
    </Box>
  );
};
