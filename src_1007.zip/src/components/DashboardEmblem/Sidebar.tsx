import React from 'react';
import { Box, Button, IconButton, Typography } from '@mui/material';
import { ChevronLeft, Add, Settings } from '@mui/icons-material';
import { SearchInput } from './SearchInput';
import { ChatHistory } from './ChatHistory';
import { WorkspaceSection } from './WorkspaceSection';


interface SidebarProps {
  onNewChat?: () => void;
  onBackClick?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onNewChat, onBackClick }) => {
  return (
    <Box
      component="aside"
      sx={{
        minWidth: '240px',
        minHeight: '914px',
        width: '288px',
        backgroundColor: 'white',
        px: 1,
        borderRight: '1px solid #E4E4E5'
      }}
    >
      <Box sx={{ maxWidth: '100%', width: '272px', flex: 1 }}>
        <Box sx={{ width: '100%', flex: 1 }}>
          <Box
            component="nav"
            sx={{
              display: 'flex',
              minHeight: '40px',
              width: '100%',
              alignItems: 'center',
              gap: 1,
              px: 1,
              py: 0.875
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <IconButton
                onClick={onBackClick}
                size="small"
                sx={{
                  p: 0.5,
                  borderRadius: '8px',
                  '&:hover': {
                    backgroundColor: 'rgba(0,0,0,0.04)'
                  }
                }}
                aria-label="Go back"
              >
                <Box sx={{ 
                  transform: 'rotate(90deg)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1.25,
                  overflow: 'hidden',
                  p: 0.5,
                  borderRadius: '8px'
                }}>
                  <ChevronLeft sx={{ width: 18, height: 18 }} />
                </Box>
              </IconButton>
              <Typography
                variant="body2"
                sx={{
                  color: 'black',
                  fontSize: '14px',
                  fontWeight: 'normal',
                  ml: 1
                }}
              >
                Back
              </Typography>
            </Box>
          </Box>
          
          <Box
            sx={{
              display: 'flex',
              width: '100%',
              alignItems: 'stretch',
              gap: 0.625,
              fontSize: '16px',
              color: 'white',
              fontWeight: 500,
              letterSpacing: '-0.11px',
              lineHeight: 1,
              mt: 1
            }}
          >
            <Button
              onClick={onNewChat}
              sx={{
                backgroundColor: '#0F4977',
                color: 'white',
                display: 'flex',
                alignItems: 'stretch',
                gap: 5,
                px: 1.75,
                py: 1,
                borderRadius: '10px',
                border: '1px solid #0F4977',
                textTransform: 'none',
                fontSize: '16px',
                fontWeight: 500,
                '&:hover': {
                  backgroundColor: '#0d3f63'
                }
              }}
            >
              <Typography sx={{ color: 'white' }}>New Chat</Typography>
              <Add sx={{ width: 18, height: 20, color: 'white' }} />
            </Button>
            <IconButton
              sx={{
                width: '39px',
                height: '39px',
                backgroundColor: '#f5f5f5',
                borderRadius: '8px',
                '&:hover': {
                  backgroundColor: '#e0e0e0'
                }
              }}
              aria-label="More options"
            >
              <Add sx={{ width: 20, height: 20 }} />
            </IconButton>
          </Box>
          
          <SearchInput />
          
          <ChatHistory />
          
          <WorkspaceSection />
          
          <Box sx={{ display: 'flex', minHeight: '178px', width: '100%', mt: 1 }} />
        </Box>
      </Box>
      
      <Box
        component="footer"
        sx={{
          width: '243px',
          maxWidth: '100%',
          fontSize: '14px',
          color: 'black',
          fontWeight: 'normal',
          mt: 1
        }}
      >
        <Box sx={{ display: 'flex', width: '100%', alignItems: 'stretch' }}>
          <Button
            fullWidth
            sx={{
              display: 'flex',
              minWidth: '240px',
              alignItems: 'center',
              gap: 1,
              height: '100%',
              flex: 1,
              p: 1,
              borderRadius: 1,
              textTransform: 'none',
              color: 'black',
              fontSize: '14px',
              fontWeight: 'normal',
              '&:hover': {
                backgroundColor: 'rgba(0,0,0,0.04)'
              }
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Settings sx={{ width: 24, height: 24 }} />
              <Typography variant="body2" sx={{ color: 'black' }}>
                Setting
              </Typography>
            </Box>
          </Button>
        </Box>
      </Box>
    </Box>
  );
};
