import React from 'react';
import { Box, Chip } from '@mui/material';
import { BarChart, Edit, Lightbulb } from '@mui/icons-material';

interface SuggestionPill {
  id: string;
  label: string;
  icon?: React.ReactElement;
}

interface SuggestionPillsProps {
  suggestions?: SuggestionPill[];
  onSuggestionClick?: (suggestion: SuggestionPill) => void;
}

export const SuggestionPills: React.FC<SuggestionPillsProps> = ({
  suggestions = [
    {
      id: '1',
      label: 'Analyze Data',
      icon: (
        <BarChart
          fontSize="small"
          sx={{ color: '#28a745 !important' }} // green
        />
      )
    },
    {
      id: '2',
      label: 'Help me write',
      icon: (
        <Edit
          fontSize="small"
          sx={{ color: '#dc3545 !important' }} // red
        />
      )
    },
    {
      id: '3',
      label: 'Brainstorming',
      icon: (
        <Lightbulb
          fontSize="small"
          sx={{ color: '#ffc107 !important' }} // yellow
        />
      )
    }
  ],
  onSuggestionClick
}) => {
  return (
    <Box
      sx={{
        display: 'flex',
        width: '100%',
        maxWidth: '676px',
        flexDirection: 'column',
        mt: 1,
        '@media (max-width: 768px)': {
          maxWidth: '100%',
          mt: 1
        }
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          flexWrap: 'wrap'
        }}
      >
        {suggestions.map((suggestion) => (
          <Chip
            key={suggestion.id}
            label={suggestion.label}
            icon={suggestion.icon}
            onClick={() => onSuggestionClick?.(suggestion)}
            sx={{
              backgroundColor: '#F3FAFF',
              border: '1px solid #EAF2F7',
              borderRadius: '50px',
              px: 1,
              py: 1.75,
              fontSize: '14px',
              color: '#000000',
              fontWeight: 'normal',
              '&:hover': {
                backgroundColor: '#E8F4FE'
              },
              '@media (max-width: 768px)': {
                px: 2.5
              }
            }}
          />
        ))}
      </Box>
    </Box>
  );
};
