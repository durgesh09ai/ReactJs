
import React from "react";
import { Box, Card, Typography, SxProps, Theme } from "@mui/material";

interface DataCardProps {
  icon: string;
  label: string;
  value: string;
  labelSx?: SxProps<Theme>;
}

const DataCard = ({ icon, label, value, labelSx }: DataCardProps) => {
  return (
    <Card 
    sx={{
      p: 2,
      display: 'flex',
      alignItems: 'center',
      gap: 2,
      borderRadius: 2,
      height: '100%',
      backgroundColor: 'rgba(243,250,255,1)', // keep or customize this
      border: 'none', // ⛔ removes the border
      boxShadow: 'none' // ⛔ removes the shadow
    }}
  >
  
      <Box 
        component="img" 
        src={icon} 
        alt={label}
        sx={{ width: 32, height: 32 }}
      />
      <Box sx={{ flex: 1 }}>
        <Typography 
          variant="body2" 
          sx={{ ...labelSx }}
        >
          {label}
        </Typography>
        <Typography 
          variant="h6" 
          sx={{ fontWeight: 600, color: '#000'}}
        >
          {value}
        </Typography>
      </Box>
    </Card>
  );
};

export default DataCard;
