import React from "react";
import {
  Box,
  Button,
  Typography,
  Paper,
  Avatar,
  Stack,
} from "@mui/material";
import UserProfile from "../ui/dashboard/UserProfile";
import LeaderboardItem from "../ui/dashboard/LeaderboardItem";
import LeaderboardFilterDropdown from "../ui/dashboard/LeaderboardFilterDropdown";

const StatsPanel: React.FC = () => {
  return (
    <Paper
      elevation={0}
      sx={{
        backgroundColor: "rgba(243,250,255,1)",
        border: "1px solid rgba(15,73,119,0.5)",
        borderRadius: "20px",
        width: "397px",
        p: 2,
      }}
    >
     <Button
  fullWidth
  sx={{
    backgroundColor: "white",
    borderRadius: "20px",
    px: 2,
    py: 1.5,
    textTransform: "none",
    fontWeight: 500,
    fontSize: "0.875rem",
    color: "black",
    display: "flex",
    alignItems: "center",
    gap: 2,
    justifyContent: "flex-start", // ✅ THIS makes it left-aligned
  }}
>
  <Avatar
    src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ae9d15c00f2e9ae28f7d0d8c3b621bb745ab4cbe?placeholderIfAbsent=true"
    alt="Close"
    sx={{ width: 18, height: 18, borderRadius: "8px" }}
  />
  <Typography sx={{ my: "auto" }}>Close My stats & rank</Typography>
</Button>


      <UserProfile
        name="Umesh jain"
        role="Sales & info manager"
        avatar="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/b522349175b734ad87f721737d0337e9eac00b6e?placeholderIfAbsent=true"
        points={453}
      />

      {/* Leaderboard Filter Box (No Shadow) */}
      <Box
        sx={{
          mt: 2.5,
          backgroundColor: "white",
          borderRadius: "20px",
          px: 2,
          pb: 2,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            backgroundColor: "white",
            borderTopLeftRadius: 1,
            px: 2,
            py: 1,
          }}
        >
        <Box>
        <Typography variant="h6" fontSize={16} fontWeight={600}>
        Leaderboard Filter
        </Typography>
        </Box>
        </Box>

        <Box sx={{ width: "100%", py: 2 }}>
          <Stack spacing={2}>
            {["IMU", "SGU", "Timeframe"].map((label, index) => (
              <Box key={index}>
                <Typography variant="body2" fontWeight={500} mb={0.5}>
                  {label}
                </Typography>
                <LeaderboardFilterDropdown
                  label={label === "Timeframe" ? "This month" : "Healthcare"}
                />
              </Box>
            ))}
          </Stack>

          <Box mt={4}>
            <Typography
              variant="h6"
              fontSize={16}
              fontWeight={600}
              align="center"
              mb={2}
            >
              Top 3 Contributors
            </Typography>

            <LeaderboardItem
              image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/593b94be8cb9a648463cfeb0e0358289550ff142?placeholderIfAbsent=true"
              rank={1}
              name="Abhishek Wadhwa"
            />
            <LeaderboardItem
              image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/f8c93e7ce2bd0551f68f73336b86944c8fba3ef3?placeholderIfAbsent=true"
              rank={2}
              name="Abhishek Wadhwa"
            />
            <LeaderboardItem
              image="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/591c01d24467f2c2a8d6c083930c05d2ace27632?placeholderIfAbsent=true"
              rank={3}
              name="Abhishek Wadhwa"
            />
          </Box>


          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
  <Button
    variant="outlined"
    sx={{
      fontSize: "0.75rem",
      textTransform: "none",
      borderColor: "#0F4977",
      color: "#0F4977",
      borderRadius: 2,
      px: 2,
      py: 1.2,
      boxShadow: "0px 1px 3px 0px rgba(96,108,128,0.05)",
      borderWidth: '1px',
    }}
  >
    View Top contributors
  </Button>
</Box>

        </Box>
      </Box>
    </Paper>
  );
};

export default StatsPanel;
