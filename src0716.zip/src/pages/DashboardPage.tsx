import { Dashboard } from "../components/Dashboard/Dashboard";

function DashboardPage() {
  return <Dashboard />;
}

export default DashboardPage;
