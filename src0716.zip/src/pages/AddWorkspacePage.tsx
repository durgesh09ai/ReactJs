import React, { useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Chip,
  RadioGroup,
  FormControlLabel,
  Radio,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Select,
  MenuItem,
  OutlinedInput,
  Checkbox,
  Stack,
  IconButton,
  Divider,
} from '@mui/material';
import { DeleteOutlineOutlined } from '@mui/icons-material';
import { Breadcrumb } from '../components/Breadcrumb';

const llmOptions = ['DataStage', 'InsightLLM', 'ClaimLogic'];

export default function AddWorkspacePage() {
  const [step, setStep] = useState(1);
  const [storeOption, setStoreOption] = useState('same');
  const [llmLinked, setLlmLinked] = useState<string[]>(['InsightLLM', 'ClaimLogic']);
  const [analysedFiles, setAnalysedFiles] = useState<Record<string, string[]>>({});

  const handleInitialSave = () => {
    setStep(2);
  };

  const handleEdit = () => {
    alert('Edit clicked');
  };

  const handleDelete = () => {
    alert('Delete clicked');
  };

  const handleFolderSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const groupedByType: Record<string, string[]> = {};

    Array.from(files).forEach((file) => {
      const extension = file.name.split('.').pop()?.toLowerCase() || 'Unknown';
      if (!groupedByType[extension]) {
        groupedByType[extension] = [];
      }
      groupedByType[extension].push(file.name);
    });

    setAnalysedFiles(groupedByType);
    setStep(2);
  };

  const sourceTechList = [
    { source: 'Python', target: 'SQL', count: 12, status: 'Mapped' },
    { source: 'Javascript', target: 'Typescript', count: 11, status: 'Mapped' },
    { source: 'Html', target: '', count: 14, status: 'Skipped' },
  ];

  const breadcrumbItems = [
    { label: 'My Workspace', href: 'workspace', active: false },
    { label: 'Add Workspace', active: true },
  ];

  return (
    <Box sx={{ p: 4, fontSize: '14px' }}>
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Breadcrumb items={breadcrumbItems} />
      </Box>

      <Divider sx={{ mt: 1 }} />

      {(step === 1 || step === 2) && (
        <Box>
          <Box display="flex" justifyContent="flex-end" alignItems="center" mb={2}>
            <Stack direction="row" spacing={1}>
              <IconButton onClick={handleDelete}>
                <DeleteOutlineOutlined fontSize="small" />
              </IconButton>
              <IconButton onClick={handleEdit}>
                <Box
                  component="img"
                  src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/ed8ddb289907d235e70955598ebfc3fc43c56f1d"
                  alt="Edit"
                  sx={{ width: 16, height: 16 }}
                />
              </IconButton>
            </Stack>
          </Box>

          <Box display="flex" gap={2} mb={2}>
            <Box flex={1}>
              <Typography fontSize={14} fontWeight={600}>
                Workspace Name
              </Typography>
              <TextField fullWidth size="small" placeholder="Enter workspace name" />
            </Box>
            <Box flex={1}>
              <Typography fontSize={14} fontWeight={600}>
                Description
              </Typography>
              <TextField fullWidth size="small" placeholder="Enter description" />
            </Box>
          </Box>

          <Box display="flex" alignItems="center" gap={2} mb={2}>
            <Box flex={5}>
              <TextField
                fullWidth
                size="small"
                label="Git URL"
                placeholder="https://github.com/"
                InputLabelProps={{ style: { fontSize: '12px' } }}
              />
            </Box>
            <Box flex={1} width="fit-content">
              <Typography fontSize={14}>OR</Typography>
            </Box>
            <Box flex={4}>
              <Box display="flex" marginLeft="auto" gap={1}>
                <Typography fontSize={12}>Select folder path</Typography>
                <input
                  type="file"
                  multiple
                  // @ts-ignore
                  webkitdirectory="true"
                  onChange={handleFolderSelect}
                />
              </Box>
            </Box>
          </Box>
          <Box display="flex" justifyContent="flex-end">
          <Button variant="contained"  disabled={step === 2} onClick={handleInitialSave}>
            Save
          </Button>
          </Box>
        </Box>
      )}

      {step === 2 && (
        <Box>
          <Typography fontWeight={600} mt={3} fontSize={14}>
            Analysed File Summary:
          </Typography>

          <Box
            sx={{
              maxHeight: 200,
              overflowY: 'auto',
              mt: 1,
              mb: 3,
              border: '1px solid #ccc',
              borderRadius: 1,
            }}
          >
            <Table size="small">
              <TableHead>
                <TableRow sx={{ backgroundColor: '#0F4977' }}>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>File Name</TableCell>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>Type</TableCell>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>Path</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {Object.entries(analysedFiles).map(([type, files]) => (
                  <React.Fragment key={type}>
                    <TableRow>
                      <TableCell colSpan={3}>
                        <Typography fontWeight={600} fontSize={12}>
                          {type.toUpperCase()} Total File ({files.length})
                        </Typography>
                      </TableCell>
                    </TableRow>
                    {files.map((file: string, i: number) => (
                      <TableRow key={`${type}-${i}`}>
                        <TableCell sx={{ fontSize: 12 }}>{file}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{type.toUpperCase()}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>/src/{file}</TableCell>
                      </TableRow>
                    ))}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </Box>

          <Typography fontWeight={600} fontSize={14}>
            Target Files
          </Typography>
          <RadioGroup
            row
            value={storeOption}
            onChange={(e) => setStoreOption(e.target.value)}
          >
            <FormControlLabel
              value="same"
              control={<Radio />}
              label={<Typography fontSize={12}>Use same folder as source</Typography>}
            />
            <FormControlLabel
              value="different"
              control={<Radio />}
              label={<Typography fontSize={12}>If 'different folder' selected</Typography>}
            />
          </RadioGroup>

          {storeOption === 'different' && (
            <TextField
              size="small"
              fullWidth
              defaultValue="/output/refactored/"
              sx={{ mb: 2 }}
            />
          )}

          <Typography fontWeight={600} fontSize={14}>
            File Naming Pattern
          </Typography>
          <TextField
            fullWidth
            size="small"
            multiline
            rows={2}
            sx={{ mt: 1, mb: 3 }}
            defaultValue="[source_name]_refactored.py"
          />

          <Typography fontWeight={600} fontSize={14} mb={1}>
            Mapping Files
          </Typography>
          <Table size="small" sx={{ mb: 3 }}>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#0F4977' }}>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Source Tech</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Target Tech</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Total File Count</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Status</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sourceTechList.map((item, i) => (
                <TableRow key={i}>
                  <TableCell sx={{ fontSize: 12 }}>{item.source}</TableCell>
                  <TableCell>
                    <Select size="small" fullWidth defaultValue={item.target}>
                      <MenuItem value="">Select target</MenuItem>
                      <MenuItem value="SQL">SQL</MenuItem>
                      <MenuItem value="Typescript">Typescript</MenuItem>
                    </Select>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{item.count}</TableCell>
                  <TableCell>
                    {item.status === 'Mapped' ? (
                      <Chip label="Mapped" size="small" color="success" />
                    ) : (
                      <Typography fontSize={12}>Skipped</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1}>
                      <Button size="small">View</Button>
                      <Button size="small">Skip</Button>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            sx={{ width: '100%' }}
            >
          <Box sx={{width:'48%'}}>
          <Typography fontWeight={600} fontSize={14} mb={1} >
            LLM Linked
          </Typography>
          <Select
            multiple
            fullWidth
            size="small"
            value={llmLinked}
            onChange={(e) => setLlmLinked(e.target.value as string[])}
            input={<OutlinedInput />}
            renderValue={(selected) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {selected.map((val) => (
                  <Chip key={val} label={val} />
                ))}
              </Box>
            )}
          >
            {llmOptions.map((option) => (
              <MenuItem key={option} value={option}>
                <Checkbox checked={llmLinked.indexOf(option) > -1} />
                {option}
              </MenuItem>
            ))}
          </Select>
          </Box>
          <Box sx={{width:'48%'}}>
          <Typography fontWeight={600} fontSize={14} mb={1} >
          Generator LLM
         </Typography>
          <Select
            multiple
            fullWidth
            size="small"
            value={llmLinked}
            onChange={(e) => setLlmLinked(e.target.value as string[])}
            input={<OutlinedInput />}
            renderValue={(selected) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {selected.map((val) => (
                  <Chip key={val} label={val} />
                ))}
              </Box>
            )}
          >
            {llmOptions.map((option) => (
              <MenuItem key={option} value={option}>
                <Checkbox checked={llmLinked.indexOf(option) > -1} />
                {option}
              </MenuItem>
            ))}
          </Select>
          </Box>

         </Stack>

          <Box mt={3} display="flex" justifyContent="flex-end" gap={2}>
            <Button variant="outlined">Cancel</Button>
            <Button variant="contained">+ Add WorkSpace</Button>
          </Box>
        </Box>
      )}
    </Box>
  );
}
