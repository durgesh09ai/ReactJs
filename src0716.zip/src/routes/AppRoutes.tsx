import { BrowserRouter, Routes, Route } from "react-router-dom";
import IntelliwiseLayout from "../layout/IntelliwiseLayout/Layout";
import WorkspaceSetup from "../pages/WorkspaceSetup";
import DashboardPage from "../pages/DashboardPage";
import AddWorkspacePage from "../pages/AddWorkspacePage";
import UserProfile from "../components/UserProfile/UserProfile";
import WorkBookSpace from "../components/WorkBookSpace/WorkBookSpace";
import { EditModelForm } from "../components/LLMModelSelection/EditModelForm";
import { ModelConfigurationPanel } from "../components/LLMModelSelection/ModelConfigurationPanel ";
import WorkSpaceDetailSetup from "../components/WorkSpaceDetailSetup/WorkSpaceDetailSetup";
import { LanguageConfigurationPanel } from "../components/Languages/LanguageConfigurationPanel ";

export const AppRoutes = () => (
   <Routes>
     <Route element={<IntelliwiseLayout />}>
       <Route path="/" element={<DashboardPage />} />
       <Route path="/settings" element={<WorkspaceSetup />}>
       <Route path="user-profile" element={<UserProfile/>}/>
       <Route path="workspace" element={<WorkBookSpace/>}/>
       <Route path="llm-setting" element={<ModelConfigurationPanel/>}/>   
       <Route path="add-workspace" element={<AddWorkspacePage/>}/> 
       <Route path="workspace-detail" element={<WorkSpaceDetailSetup/>}/> 
       <Route path="languages" element={<LanguageConfigurationPanel/>}/>

       </Route>       
       
       {/* <Route path="/settings" element={<WorkspaceSetup />} />
       <Route path="/add-workspace" element={<AddWorkspacePage/>}/>
       <Route path="/workspace-detail/" element={<WorkSpaceDetailSetup/>}/> */}
    </Route>
   </Routes>
);
