import React, { useState } from "react";
import { Paper, Box } from "@mui/material";
import { EditLanguageForm, LanguageData } from "./EditLanguageForm";
import SetupHeader from "./SetupHeader";
import { ExistingLanguageSection } from "./ExistingLanguageSection";

// Mock initial data
const initialLanguage: LanguageData[] = [
  {
    id: '123',
    name: "Python"
  },
  {
    id: '1234',
    name: "Java"
  },
  {
    id: '12345',
    name: "JavaScript"
  }
];

export const LanguageConfigurationPanel: React.FC = () => {
  const [models, setModels] = useState<LanguageData[]>(initialLanguage);
  const [selectedModel, setSelectedModel] = useState<LanguageData | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const handleAddModel = () => {
    setIsEditing(true);
  };


  const handleUpdateModel = (updatedModel: LanguageData) => {
    if (updatedModel.id) {
      setModels(models.map(model =>
        model.id === updatedModel.id ? updatedModel : model
      ));
    } else {
      const newModel: LanguageData = {
        id: '54321',
        name: "New Language",
      };
      setModels((prevModels) => [...prevModels, newModel]);
      setSelectedModel(newModel);
    }
    setIsEditing(false);
    setSelectedModel(null);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setSelectedModel(null);
  };

  const handleSave = () => {
    if (selectedModel) {
      handleUpdateModel(selectedModel);
    }
  };

  const handleEditModel = (id: string) => {
    const modelToEdit = models.find((m) => m.id === id);
    if (modelToEdit) {
      setSelectedModel(modelToEdit);
      setIsEditing(true);
    }
  };
  
  const handleDeleteModel = (id: string) => {
    setModels((prev) => prev.filter((model) => model.id !== id));
  };

  return (
    <Paper elevation={1} sx={{ maxWidth: "820px", pb: "20px", px: 1, borderRadius: 2 }}>
      <SetupHeader title="Language List" />
    <Box
      sx={{
        display: "flex",
        maxWidth: "527px",
        flexDirection: "column",
        justifyContent: "center",
        textTransform: "none",
      }}
    >
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          border: "1px solid rgba(18,18,21,0.10)",
          padding: 2,
          width: "100%",
        }}
      >
        <ExistingLanguageSection
          language={models}
          onAddModel={handleAddModel}
          onEditModel={handleEditModel}
          onDeleteModel={handleDeleteModel}
        />

        {isEditing && (
          <EditLanguageForm
          language={selectedModel}
            onUpdate={setSelectedModel}
            handleCancel={handleCancel}
            handleSave={handleSave}
          />
        )}
        
      </Paper>
    </Box>
        </Paper>
  );
};
