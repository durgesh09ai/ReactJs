import React, { useState } from "react";
import { observer } from "mobx-react-lite";

import {
  Box,
  Typography,
  Paper,
  Button,
  
  TextField,
  Select,
  MenuItem,
  

  RadioGroup,
  FormControlLabel,
  Radio,
  Chip,
  Stack, 
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  OutlinedInput,
  Checkbox,
} from "@mui/material";


interface WorkspaceCardProps {
  id: string;
  name: string;
  git_url:string;
  analyse_summary:[];
  language_name:string;
  import_folder_path:string;
  description: string;
  llm_linked:[];
  userId: string;
  archive: boolean;
  emptyTFS:boolean;
  createPHF:boolean;
}

const WorkSpaceSetupCard: React.FC<WorkspaceCardProps> = ({
  id,
  name,
  git_url,
  analyse_summary,
  language_name,
  import_folder_path,
  description,
  llm_linked,
  userId,
  archive,
  emptyTFS,
  createPHF
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(name);
  const [editedDescription, setEditedDescription] = useState(description);
  const [nameError, setNameError] = useState(false);
 

  const [storeOption, setStoreOption] = useState('same');
  const [llmLinked, setLlmLinked] = useState<string[]>(['InsightLLM', 'ClaimLogic']);
  const llmOptions = ['DataStage', 'InsightLLM', 'ClaimLogic'];

  
   const fileMappingType = [
    {
      sourceType: 'GitHub',
      techType: 'JavaScript',
      totalFiles: 120,
      status: 'Mapped',
    },
    {
      sourceType: 'Azure Blob',
      techType: 'Python',
      totalFiles: 87,
      status: 'Mapped',
    },
    {
      sourceType: 'Python',
      techType: 'Python',
      totalFiles: 87,
      status: 'Skipped',
    },
  ];

  
  const sourceTechList = [
    { source: 'Python', target: 'SQL', count: 12, status: 'Mapped' },
    { source: 'Javascript', target: 'Typescript', count: 11, status: 'Mapped' },
    { source: 'Html', target: '', count: 14, status: 'Skipped' },
  ];

  const analysedFiles = {
    Python: ['main.py', 'main.py', 'main.py'],
    Javascript: ['index.js', 'helper.js'],
    Html: ['dashboard.html', 'Product Detail.html', 'Category.html'],
  };

console.log('analyse_summary',analyse_summary);


  return (
    <Paper 
        elevation={0}
        sx={{ 
          border: '1px solid #E4E4E5',
          width: '80%', 
          mt: 2,
          p: 2
          
        }}
      >
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box>
            <Typography variant="body2" sx={{ color: 'black', fontWeight: 'bold',mb:1 }}>
             WorkSpace Name 
            </Typography>
            <Typography variant="body2" sx={{ color: 'black' }}>
             {name}
            </Typography>
          </Box>

         <Box display={"flex"}>
          {!isEditing && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Button
                variant="text"
                onClick={() => setIsEditing(!isEditing)}
                startIcon={
                  <Box 
                    component="img"
                    src="/edit.svg"
                    sx={{ width: 24, height: 24 }}
                    alt="Edit"
                  />
                }
                sx={{
                  color: '#0F4977',
                  textTransform: 'none',
                  fontWeight: 'medium',
                  py: 0.5,
                  px: 1,
                  minWidth: 'auto'
                }}
              >
              </Button>
            </Box>
              )}

          <Box 
            component="img"
            src="../delete.svg"
            sx={{ width: 24, height: 24,mt:0.2 }}
            alt="Options"
          />
        </Box>
        </Box>
        
      {!isEditing && (
       <Box sx={{ mt: 1 }}>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Description
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
          {isExpanded ? description : `${description?.slice(0, 100)}...`}
          <Box
            component="span"
            onClick={() => setIsExpanded(!isExpanded)}
            sx={{
              ml: 0.5,
              color: "#0F4977",
              textDecoration: "underline",
              cursor: "pointer",
            }}
          >
            See {isExpanded ? "less" : "more"}
          </Box>
        </Typography>

        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          sx={{ width: '100%',mt:2 }}
        >
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black", mt:1 }}>
          GIT URL
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {git_url}
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black", mt:1 }}>
          OR
        </Typography>
        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black", mt:1 }}>
          Source Path
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        <Chip
        onClick = {()=>{console.log('clicked')}}
          label="/var/www/html/sourceProject"
          sx={{ 
            bgcolor: '#F3FAFF',
            color: '#0F4977',
            borderRadius: '1rem',
            height: 'auto',
            py: 0.5,
            }}
      />
        </Typography>
        </Stack>


        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:2 }}>
        Analysed File Summary 
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {analyse_summary && analyse_summary.map((sname, index) => (
        <Chip
        onClick = {()=>{console.log('clicked')}}
          label={sname}
          sx={{ 
            bgcolor: '#E0F0FF',
            color: '#0F4977',
            borderRadius: '1rem',
            height: 'auto',
            py: 0.5,
            m:0.5,
            }}
      />
      ))}
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1 }}>
        Target Project 
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {analyse_summary && analyse_summary.map((sname, index) => (
        <Chip
        onClick = {()=>{console.log('clicked')}}
          label={sname}
          sx={{ 
            bgcolor: '#E0F0FF',
            color: '#0F4977',
            borderRadius: '1rem',
            height: 'auto',
            py: 0.5,
            m:0.5,
            }}
      />
      ))}
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1,mb:1}}>
        Store Files
       </Typography>

<Stack
  direction="row"
  justifyContent="space-between"
  alignItems="center"
  sx={{ width: '100%' }}
>
  {/* Custom "chip" box on the left */}
  <Box
    sx={{
      bgcolor: '#F3FAFF',
      color: '#0F4977',
      borderRadius: '1rem',
      px: 2,
      py: 0.5,
      display: 'inline-block',
    }}
  >
    <Typography variant="body2">
    <FormControlLabel value="Save files in the same folder as source"   checked={true}
     control={<Radio />} 
    label="Save files in the same folder as source" 
    sx={{'& .MuiFormControlLabel-label':{fontSize:12}}}
    />
    </Typography>
  </Box>

  {/* Custom "chip" box on the right */}
  <Box>
  <Typography variant="body2" fontWeight="bold">
    If "different folder" selected
  </Typography>
  <Box
    sx={{
      bgcolor: '#F3FAFF',
      color: '#0F4977',
      borderRadius: '1rem',
      px: 2,
      py: 0.5,
      display: 'inline-block',
    }}
  >
    <Typography variant="body2" fontWeight={500}>
    [ /output/refactored/ ]  
    </Typography>
  </Box>
  </Box>
</Stack>

 <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1,mb:1}}>
  File Naming Pattern
  </Typography>
       <Box
    sx={{
      bgcolor: '#F3FAFF',
      color: '#0F4977',
      borderRadius: '1rem',
      px: 2,
      py: 0.5,
      display: 'inline-block',
    }}
  >
    <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1,fontSize:12 }}>
    {import_folder_path}
    </Typography>
     </Box>   


        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1,mb:2}}>
        FIle Mapping types
       </Typography>

       <TableContainer component={Paper} elevation={0} sx={{
        border:'1px dotted #000',
        borderRadius:1,
       }}>
      <Table>
        <TableHead>
        <TableRow
            sx={{
              backgroundColor: '#F3FAFF',
            }}
          >
            {['Source Type', 'Tech Type', 'Total Files Content', 'Status'].map((label) => (
              <TableCell
                key={label}
                sx={{
                  fontWeight: 'bold',
                  fontSize: '11px',
                  color: '#0F4977',
                  py:1,
                }}
              >
                {label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {fileMappingType.map((row, index) => (
            <TableRow key={index}>
              <TableCell sx={{ py: 0.5,fontSize:12 }}>{row.sourceType}</TableCell>
              <TableCell sx={{ py: 0.5,fontSize:12 }}>{row.techType}</TableCell>
              <TableCell sx={{ py: 0.5 ,fontSize:12}}>{row.totalFiles}</TableCell>
              <TableCell sx={{ py: 0.5 ,fontSize:12}}>
                <Chip
                  label={row.status}
                  color={row.status === 'Mapped' ? 'success' : 'warning'}
                  size="small"
                  sx={{ fontWeight: 400,fontSize:12 }}
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

    <Stack
  direction="row"
  justifyContent="space-between"
  alignItems="center"
  sx={{ width: '100%' }}
   >
      <Box>
       <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:2,mb:1}}>
       LLM Linked
        </Typography>
        {llm_linked && llm_linked.map((llm, index) => (
        <Box  sx={{
          bgcolor: '#E0F0FF',
          color: '#0F4977',
          borderRadius: '1rem',
          px: 2,
          py: 0.5,
          m:0.5,
          display: 'inline-block',
          fontSize:12,
        }}>{llm}</Box>
        ))}
   </Box>
    <Box>
    <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:2,mb:1}}>
        Generator LLM 
        </Typography>
        {llm_linked && llm_linked.map((llm, index) => (
        <Box  sx={{
          bgcolor: '#E0F0FF',
          color: '#0F4977',
          borderRadius: '1rem',
          px: 2,
          py: 0.5,
          m:0.5,
          display: 'inline-block',
          fontSize:12,
        }}>{llm}</Box>
        ))}
      </Box>  
     </Stack>

      </Box>
      )}
      
        
{isEditing && (
     
<Box sx={{ mt: 1 ,width:'100%'}}>

<Box display="flex" gap={2} mb={2}>
  <Box flex={1}>
    <Typography fontSize={14} fontWeight={600}>Workspace Name</Typography>
    <TextField
      value={editedName}
      onChange={(e) =>{
         setEditedName(e.target.value)
         if(e.target.value.trim()){
          setNameError(false);
         }
      }
      }
      error={nameError}
      helperText = {nameError ? "Workspace name is required." :""} 
      fullWidth
      size="small"
      sx={{ 
        "& input": { fontSize: 12 },
        "& .MuiInputLabel-root": { fontSize: 12 } ,
      }} 
    />
  </Box>
  <Box flex={1}>
    <Typography fontSize={14} fontWeight={600}>Description</Typography>
    <TextField
      fullWidth
      value={editedDescription}
      onChange={(e) => setEditedDescription(e.target.value)}
      size="small"
      placeholder="Enter description"
      sx={{ 
        "& .MuiInputBase-root": { fontSize: 14 },
        "& .MuiInputLabel-root": { fontSize: 14 } ,
      }} 
    />
  </Box>
</Box>

<Box display="flex" alignItems="center" gap={2} mb={2} >
  <Box flex={5}>
  <TextField
    fullWidth              
    size="small"
    value="www.github.com"
    onChange={(e) =>{
       setEditedName(e.target.value)
       if(e.target.value.trim()){
        setNameError(false);
       }
    }
    }
    sx={{ 
      "& input": { fontSize: 12 },
      "& .MuiInputLabel-root": { fontSize: 12 } ,
    }} 
  />
  </Box>
  <Box flex={1} width='fit-content'>
  <Typography fontSize={14}>OR</Typography>
  </Box>
    <Box flex={4}>
  <Box display="flex" flexDirection={"row"} marginLeft="auto" gap={1}>
    <Typography fontSize={12} sx={{mt:1}}>Select folder path : </Typography>
    <Button variant="outlined" size="small">Browse</Button>
  </Box>
</Box>
  </Box>


    <Box>
          <Typography fontWeight={600} mt={3} fontSize={14}>
            Analysed File Summary:
          </Typography>

          <Box
            sx={{
              maxHeight: 200,
              overflowY: 'auto',
              mt: 1,
              mb: 3,
              border: '1px solid #ccc',
              borderRadius: 1,
            }}
          >
            <Table size="small">
              <TableHead>
                <TableRow sx={{ backgroundColor: '#0F4977' }}>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>File Name</TableCell>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>Type</TableCell>
                  <TableCell sx={{ color: 'white', fontSize: 12 }}>Path</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {Object.entries(analysedFiles).map(([tech, files]) => (
                  <React.Fragment key={tech}>
                    <TableRow>
                      <TableCell colSpan={3}>
                        <Typography fontWeight={600} fontSize={12}>
                          {tech} Total File ({files.length})
                        </Typography>
                      </TableCell>
                    </TableRow>
                    {files.map((file: string, i: number) => (
                      <TableRow key={`${tech}-${i}`}>
                        <TableCell sx={{ fontSize: 12 }}>{file}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>{tech}</TableCell>
                        <TableCell sx={{ fontSize: 12 }}>/src/{file}</TableCell>
                      </TableRow>
                    ))}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </Box>

          <Typography fontWeight={600} fontSize={14}>Target Files</Typography>
          <RadioGroup
            row
            value={storeOption}
            onChange={(e) => setStoreOption(e.target.value)}
          >
            <FormControlLabel
              value="same"
              control={<Radio />}
              label={<Typography fontSize={12}>Use same folder as source</Typography>}
            />
            <FormControlLabel
              value="different"
              control={<Radio />}
              label={<Typography fontSize={12}>If 'different folder' selected</Typography>}
            />
          </RadioGroup>
          {storeOption === 'different' && (
            <TextField
              size="small"
              fullWidth
              defaultValue="/output/refactored/"
              sx={{ 
                mb: 2 ,
                "& input": { fontSize: 12 },
                "& .MuiInputLabel-root": { fontSize: 12 } ,
              }} 
            />
          )}

          <Typography fontWeight={600} fontSize={14}>File Naming Pattern</Typography>
          <TextField
            fullWidth
            size="small"
            rows={2}
            sx={{
              mt: 1, 
              mb: 2 ,
              "& input": { fontSize: 12 },
              "& .MuiInputLabel-root": { fontSize: 12 } ,
            }} 
            defaultValue="[source_name]_refactored.py"
          />

          <Typography fontWeight={600} fontSize={14} mb={1}>
            Mapping Files
          </Typography>
          <Table size="small" sx={{ mb: 3 }}>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#0F4977' }}>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Source Tech</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Target Tech</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Total File Count</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Status</TableCell>
                <TableCell sx={{ color: 'white', fontSize: 12 }}>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sourceTechList.map((item, i) => (
                <TableRow key={i}>
                  <TableCell sx={{ fontSize: 12 }}>{item.source}</TableCell>
                  <TableCell>
                    <Select size="small" fullWidth defaultValue={item.target} sx={{
                    height: 36,
                    fontSize: 13,
                  }}>
                      <MenuItem value="">Select target</MenuItem>
                      <MenuItem value="SQL">SQL</MenuItem>
                      <MenuItem value="Typescript">Typescript</MenuItem>
                    </Select>
                  </TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{item.count}</TableCell>
                  <TableCell>
                    {item.status === 'Mapped' ? (
                      <Chip label="Mapped" size="small" color="success" />
                    ) : (
                      <Typography fontSize={12}>Skipped</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Stack direction="row" spacing={1}>
                      <Button size="small" sx={{fontSize:12}}>View</Button>
                      <Button size="small">Skip</Button>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            sx={{ width: '100%' }}
            >
          <Box sx={{width:'48%'}}>
          <Typography fontWeight={600} fontSize={14} mb={1} >
            LLM Linked
          </Typography>
          <Select
            multiple
            fullWidth
            size="small"
            value={llmLinked}
            onChange={(e) => setLlmLinked(e.target.value as string[])}
            input={<OutlinedInput />}
            renderValue={(selected) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {selected.map((val) => (
                  <Chip key={val} label={val} />
                ))}
              </Box>
            )}
          >
            {llmOptions.map((option) => (
              <MenuItem key={option} value={option}>
                <Checkbox checked={llmLinked.indexOf(option) > -1} />
                {option}
              </MenuItem>
            ))}
          </Select>
          </Box>
          <Box sx={{width:'48%'}}>
          <Typography fontWeight={600} fontSize={14} mb={1} >
          Generator LLM
         </Typography>
          <Select
            multiple
            fullWidth
            size="small"
            value={llmLinked}
            onChange={(e) => setLlmLinked(e.target.value as string[])}
            input={<OutlinedInput />}
            renderValue={(selected) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {selected.map((val) => (
                  <Chip key={val} label={val} />
                ))}
              </Box>
            )}
          >
            {llmOptions.map((option) => (
              <MenuItem key={option} value={option}>
                <Checkbox checked={llmLinked.indexOf(option) > -1} />
                {option}
              </MenuItem>
            ))}
          </Select>
          </Box>

         </Stack>


          <Box mt={3} display="flex" justifyContent="flex-end" gap={2}>
            <Button variant="outlined"  onClick={() => {
          setIsEditing(false);
        }}>Cancel</Button>
            <Button variant="contained" >+ Add WorkSpace</Button>
          </Box>
    </Box>


</Box>


)}

</Paper>
  );
};

export default observer(WorkSpaceSetupCard);
