import React, { useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Switch,
  SelectChangeEvent,
  Select,
  MenuItem
} from "@mui/material";

import { mainPageStore } from "../../stores/MainPageStore";

interface AddWorkspaceCardProps {
  name: string;
  description: string;
  userId: string;
  archive: boolean;
  emptyTFS: boolean;
  createPHF: boolean;
  onSubmit: (updatedWorkspace: any) => void;
}

const AddWorkSpaceCard: React.FC<AddWorkspaceCardProps> = ({
  name,
  description,
  userId,
  archive, 
  onSubmit
}) => {

  const [WSName, setWSName] = useState(name);
  const [WSdescription, setWSdescription] = useState(description);
  const [isArchived, setIsArchived] = useState(archive);
  const [selectedType, setSelectedType] = useState<string>("");



  const {languageList}  = mainPageStore;

  const handleSubmit = () => {
    const updatedWorkspace = {
      WS_name:WSName,
      WS_descrip:WSdescription,
      userId:userId,
      archive: isArchived,
    };
    onSubmit(updatedWorkspace);
  };



  // const handleFolderUpload = (event) => {
  //   const uploadedFiles = Array.from(event.target.files);
  //   setFiles(uploadedFiles);
  // };

  const handleTypeChange = (event: SelectChangeEvent<string>) => {
    setSelectedType(event.target.value);
  };


  return (
    <Paper
      elevation={0}
      sx={{
        border: "1px solid #E4E4E5",
        width: "100%",
        maxWidth: "527px",
        mt: 2,
        p: 2
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Typography variant="body2" fontWeight="bold">
          {name}
        </Typography>
        <Box
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/467fbc5a970c7fab7573b24ac1a4b6a612a0ddb3?placeholderIfAbsent=true"
          sx={{ width: 24, height: 24 }}
          alt="Options"
        />
      </Box>

      <Box mt={2}>
        <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1}}>
          WorkSpace Name
        </Typography>
        <TextField
          fullWidth
          size="small"
          value={WSName}
          onChange={(e) => setWSName(e.target.value)}
          sx={{ "& input": { fontSize: 12 } }} 
        />

       <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
       Source Code Linked
        </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
            width:300
          }}
        >
          <MenuItem value="">
            <em>Select Source Code</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
        </Select>

       <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
       Target Code Linked
        </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
            width:300
          }}
        >
          <MenuItem value="">
            <em>Select Target Code</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
        </Select>


        <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
        LLM Linked
        </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
            width:300
          }}
        >
          <MenuItem value="">
            <em>Select LLM</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
        </Select>
 
</Box>

     
      <Box mt={1}>
        <Typography variant="body2" fontWeight="bold" fontSize={12} >
          WorkSpace Settings
        </Typography>

     <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mt: 1,
          pl: 2
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            bgcolor: 'white',
            borderRadius: 1,
            p: 0.5
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box 
                component="img"
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/190889642f933327d884e606f642c062034e414d?placeholderIfAbsent=true"
                sx={{ width: 24, height: 24 }}
                alt="Archive"
              />
              <Typography variant="body2" sx={{ color: 'black' }}>
                Status
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)', textAlign: 'center' }}>
              (Hide this Source Code for all user)
            </Typography>
          </Box>
          <Switch
            checked={isArchived}
            onChange={() => setIsArchived(!isArchived)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: '#0F4977',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          />
        </Box>

        <Box textAlign="right" mt={2}>

        <Button
            variant="contained"
            // onClick={handleSubmit}
            sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" ,
              mr:2
            }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" 
            }}
          >
            Save
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default AddWorkSpaceCard;
