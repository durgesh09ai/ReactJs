import React, { useState } from 'react';
import { Box, Typography, Paper } from '@mui/material';
import Editor from '@monaco-editor/react';
import { ReflexContainer, ReflexSplitter, ReflexElement } from 'react-reflex';
import 'react-reflex/styles.css';

const sourceCode = `def fetch_user_data(user_id):
    response = api_call("https://example.com/user/" + user_id)
    print("User data fetched:", response)

def api_call(url):
    import requests
    result = requests.get(url)
    return result.json()

fetch_user_data("12345")`;

const targetCode = `def fetch_user_data(user_id):
    response = api_call("https://example.com/user/" + user_id)
    print("User data fetched:", response)

def api_call(url):
    import requests
    result = requests.get(url)
    return result.json()

fetch_user_data("12345")`;

export const CodeEditor: React.FC = () => {
  const [sourceCodeValue, setSourceCodeValue] = useState(sourceCode);
  const [targetCodeValue, setTargetCodeValue] = useState(targetCode);

  return (
    <Paper sx={{ height: 400, p: 0, overflow: 'hidden', borderRadius: 2 }}>
      <ReflexContainer orientation="vertical" style={{ height: '100%' }}>
        {/* Source Code Panel */}
        <ReflexElement flex={0.5} minSize={200}>
          <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ p: 1, borderBottom: '1px solid #e0e0e0', bgcolor: '#F3FAFF' }}>
              <Typography variant="subtitle2" fontWeight={600} fontSize={14}>
                Source Code
              </Typography>
            </Box>
            <Box sx={{ flex: 1 }}>
              <Editor
                height="100%"
                language="python"
                value={sourceCodeValue}
                onChange={(value) => setSourceCodeValue(value || '')}
                theme="vs-light"
                options={{
                  minimap: { enabled: false },
                  lineNumbers: 'on',
                  fontSize: 12,
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  wordWrap: 'on',
                  padding: { top: 10, bottom: 10 },
                }}
              />
            </Box>
          </Box>
        </ReflexElement>

        {/* Splitter */}
        <ReflexSplitter />

        {/* Target Code Panel */}
        <ReflexElement flex={0.5} minSize={200}>
          <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ p: 1, borderBottom: '1px solid #e0e0e0', bgcolor: '#F3FAFF' }}>
              <Typography variant="subtitle2" fontWeight={600} fontSize={14}>
                Target Code
              </Typography>
            </Box>
            <Box sx={{ flex: 1 }}>
              <Editor
                height="100%"
                language="python"
                value={targetCodeValue}
                onChange={(value) => setTargetCodeValue(value || '')}
                theme="vs-light"
                options={{
                  minimap: { enabled: false },
                  lineNumbers: 'on',
                  fontSize: 12,
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  wordWrap: 'on',
                  padding: { top: 10, bottom: 10 },
                }}
              />
            </Box>
          </Box>
        </ReflexElement>
      </ReflexContainer>
    </Paper>
  );
};
