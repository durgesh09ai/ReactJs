import React, { useEffect, useState } from 'react';
import { observer } from "mobx-react-lite";
import { Box, AppBar, Toolbar, Avatar, IconButton, Paper, Typography } from '@mui/material';
import { Menu as MenuIcon, Settings as SettingsIcon } from '@mui/icons-material';
import { ReflexContainer, ReflexSplitter, ReflexElement } from 'react-reflex';
import 'react-reflex/styles.css';
import Editor from '@monaco-editor/react';
import { PushPin as PushPinIcon } from '@mui/icons-material';
import { FileExplorer } from './FileExplorer';
import { AssessmentPanel } from './AssessmentPanel';
import { TipsTooltip } from './TipsTooltip';

import { mainPageStore } from "../../stores/MainPageStore";


const sourceCode = `def fetch_user_data(user_id):
    response = api_call("https://example.com/user/" + user_id)
    print("User data fetched:", response)

def api_call(url):
    import requests
    result = requests.get(url)
    return result.json()

fetch_user_data("12345")`;

const targetCode = `def fetch_user_data(user_id):
    response = api_call("https://example.com/user/" + user_id)
    print("User data fetched:", response)

def api_call(url):
    import requests
    result = requests.get(url)
    return result.json()

fetch_user_data("12345")`;

export const Dashboard: React.FC = observer(() => {
  const [sourceCodeValue, setSourceCodeValue] = useState(sourceCode);
  const [targetCodeValue, setTargetCodeValue] = useState(targetCode);
  //const [isPinned, setIsPinned] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      if (
        e.message === 'ResizeObserver loop completed with undelivered notifications.' ||
        e.message === 'ResizeObserver loop limit exceeded'
      ) {
        e.stopImmediatePropagation();
      }
    };
    window.addEventListener('error', handler);
    return () => window.removeEventListener('error', handler);
  }, []);


  
  const {
    isPinned,
    isPinnedAssPanel
   }  = mainPageStore;

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', bgcolor: '#fff' }}>

      <Box sx={{ flexGrow: 1, minHeight: 0 }}>
        <ReflexContainer orientation="vertical">
          
          {/* <ReflexElement minSize={0} maxSize={400} flex={0.25} >
            <Box sx={{ height: '100%', p: 1, bgcolor: '#f9f9f9', overflow: 'auto' }}>
              <FileExplorer />
            </Box>
          </ReflexElement> */}

        <ReflexElement minSize={isPinned ? 0 : 150} flex={isPinned ? 0 : 0.2}>
          <Box sx={{ height: '100%', bgcolor: '#f9f9f9', overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
            {/* <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 1, borderBottom: '1px solid #ddd' }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>File Explorer</Typography>
              <IconButton size="small" onClick={() => setIsPinned()} title={isPinned ? "Unpin" : "Pin"}>
                <PushPinIcon sx={{ transform: isPinned ? 'rotate(45deg)' : 'rotate(0deg)', color: isPinned ? 'primary.main' : 'inherit' }} />
              </IconButton>
            </Box> */}

            {!isPinned && (
              <Box sx={{ flex: 1, overflow: 'auto', p: 1 }}>
                <FileExplorer />
              </Box>
            )}
          </Box>
        </ReflexElement>

          {!isPinned && (
          <ReflexSplitter propagate />
          )}

{isPinnedAssPanel ? (
  // When pinned, show only AssessmentPanel
  <ReflexElement>
    <Box sx={{ height: '100%', p: 1, bgcolor: '#f5f5f5', overflow: 'auto' }}>
      <AssessmentPanel />
    </Box>
  </ReflexElement>
) : (
  // When not pinned, show editor + assessment in horizontal layout
  <ReflexElement>
    <ReflexContainer orientation="horizontal">
      {/* Editors */}
      <ReflexElement flex={0.6} minSize={150}>
        <Box sx={{ height: '100%', p: 1, overflow: 'hidden' }}>
          <ReflexContainer orientation="vertical" style={{ height: '100%' }}>
            {/* Source Editor */}
            <ReflexElement flex={0.5} minSize={150}>
              <Paper
                elevation={0}
                sx={{
                  height: '100%',
                  bgcolor: '#F3FAFF',
                  border: '1px solid #e0e0e0',
                  borderRadius: 1,
                  overflow: 'hidden',
                }}
              >
                <Box sx={{ p: 1.5, borderBottom: '1px solid #e0e0e0' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: '14px' }}>
                    Source Code
                  </Typography>
                </Box>
                <Editor
                  height="calc(100% - 50px)"
                  language="python"
                  value={sourceCodeValue}
                  onChange={(val) => setSourceCodeValue(val || '')}
                  theme="vs-light"
                  options={{
                    minimap: { enabled: false },
                    fontSize: 12,
                    scrollBeyondLastLine: false,
                    wordWrap: 'on',
                    automaticLayout: true,
                    padding: { top: 10, bottom: 10 },
                  }}
                />
              </Paper>
            </ReflexElement>

            <ReflexSplitter propagate />

            {/* Target Editor */}
            <ReflexElement flex={0.5} minSize={150}>
              <Paper
                elevation={0}
                sx={{
                  height: '100%',
                  bgcolor: '#f5f5f5',
                  border: '1px solid #e0e0e0',
                  borderRadius: 1,
                  overflow: 'hidden',
                }}
              >
                <Box sx={{ p: 1.5, borderBottom: '1px solid #e0e0e0' }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: '14px' }}>
                    Target Code
                  </Typography>
                </Box>
                <Editor
                  height="calc(100% - 50px)"
                  language="python"
                  value={targetCodeValue}
                  onChange={(val) => setTargetCodeValue(val || '')}
                  theme="vs-light"
                  options={{
                    minimap: { enabled: false },
                    fontSize: 12,
                    scrollBeyondLastLine: false,
                    wordWrap: 'on',
                    automaticLayout: true,
                    padding: { top: 10, bottom: 10 },
                  }}
                />
              </Paper>
            </ReflexElement>
          </ReflexContainer>
        </Box>
      </ReflexElement>

      <ReflexSplitter propagate />

      {/* Assessment Panel */}
      <ReflexElement flex={0.4} minSize={100}>
        <Box sx={{ height: '100%', p: 1, bgcolor: '#f5f5f5', overflow: 'auto' }}>
          <AssessmentPanel />
        </Box>
      </ReflexElement>
    </ReflexContainer>
  </ReflexElement>
)}
        </ReflexContainer>
      </Box>

      {/* <TipsTooltip /> */}
    </Box>
  );
});