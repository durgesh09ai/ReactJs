import React, { useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Switch,
  SelectChangeEvent,
  Select,
  MenuItem,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio
} from "@mui/material";

import { mainPageStore } from "../../stores/MainPageStore";

interface AddWorkspaceCardProps {
  name: string;
  description: string;
  userId: string;
  archive: boolean;
  emptyTFS: boolean;
  createPHF: boolean;
  onSubmit: (updatedWorkspace: any) => void;
}

const AddTargetCard: React.FC<AddWorkspaceCardProps> = ({
  name,
  description,
  userId,
  archive,
  emptyTFS,
  createPHF,
  onSubmit
}) => {

  const [WSName, setWSName] = useState(name);
  const [WSdescription, setWSdescription] = useState(description);
  const [isArchived, setIsArchived] = useState(archive);
  const [selectedType, setSelectedType] = useState<string>("");
  const [files, setFiles] = useState([]);
  const [value, setValue] = React.useState('same_folder_source');
  const [isEmptyTFS, setIsEmptyTFS] = useState(emptyTFS);
  const [iscreatePHF, setIscreatePHF] = useState(createPHF);


  const {
    fetchLanguageListData,
    languageList,
    loading
   }  = mainPageStore;

  const handleSubmit = () => {
    const updatedWorkspace = {
      WS_name:WSName,
      WS_descrip:WSdescription,
      userId:userId,
      archive: isArchived,
    };
    onSubmit(updatedWorkspace);
  };


  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value);
  };

  // const handleFolderUpload = (event) => {
  //   const uploadedFiles = Array.from(event.target.files);
  //   setFiles(uploadedFiles);
  // };

  const handleTypeChange = (event: SelectChangeEvent<string>) => {
    setSelectedType(event.target.value);
  };


  return (
    <Paper
      elevation={0}
      sx={{
        border: "1px solid #E4E4E5",
        width: "100%",
        maxWidth: "527px",
        mt: 2,
        p: 2
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Typography variant="body2" fontWeight="bold">
          {name}
        </Typography>
        <Box
          component="img"
          src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/467fbc5a970c7fab7573b24ac1a4b6a612a0ddb3?placeholderIfAbsent=true"
          sx={{ width: 24, height: 24 }}
          alt="Options"
        />
      </Box>

      <Box mt={2}>
        <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1}}>
          Target Code Name
        </Typography>
        <TextField
          fullWidth
          size="small"
          value={WSName}
          onChange={(e) => setWSName(e.target.value)}
          sx={{ "& input": { fontSize: 12 } }} 
        />

       <Typography variant="body2" fontWeight="bold" mt={2} fontSize={12} sx={{mb:1,mt:1}}>
          Target Description
        </Typography>
        <TextField
          fullWidth
          multiline
          value={WSdescription}
          onChange={(e) => setWSdescription(e.target.value)}
          sx={{ "& textarea": { fontSize: 12 } }} 
        />

       <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
          Git URL
        </Typography>
        <TextField
          fullWidth
          size="small"
          value={WSName}
          onChange={(e) => setWSName(e.target.value)}
          sx={{ "& input": { fontSize: 12 } }} 
        />
       <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
          Target Language
        </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
          }}
        >
          <MenuItem value="">
            <em>Select Language</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
        </Select>

        
        <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}} >
        Store Files
        </Typography>

    <Box sx={{ 
         fontSize:12,
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mt: 1,
          pl: 2
        }}>
     
    <FormControl>
      <RadioGroup
        aria-labelledby="demo-controlled-radio-buttons-group"
        name="controlled-radio-buttons-group"
        value={value}
        onChange={handleChange}
      >
        <FormControlLabel  sx={{'& .MuiFormControlLabel-label':{fontSize:12}}} value="same_folder_source" control={<Radio />} label="Save files in the same folder as source" />
        <FormControlLabel sx={{'& .MuiFormControlLabel-label':{fontSize:12}}} value="diffrent_folder_source" control={<Radio />} label="Save files in a different folder" />
      </RadioGroup>
    </FormControl>
  </Box>

    {value && value=='diffrent_folder_source' && (
      <Box>
      <Typography variant="body2" fontWeight="bold" mt={2} fontSize={12} sx={{mb:1,mt:1}}>
      If "different folder" selected , Choose path:
      </Typography>
      <TextField
        fullWidth
        size="small"
        value="/home/documents/PythonProject"
        onChange={(e) => setWSName(e.target.value)}
        sx={{ "& input": { fontSize: 12 } }} 
      />
      </Box>
    )}
  
    <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
     File Naming Pattern
    </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
          }}
        >
          <MenuItem value="">
            <em>By Source Name</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
      </Select>

    <Typography variant="body2" fontWeight="bold" fontSize={12} sx={{mb:1,mt:1}}>
    Folder Structure Options :
    </Typography>
      <Box sx={{fontSize:12}}>
      <Switch
            checked={isEmptyTFS}
            onChange={() => setIsEmptyTFS(!isEmptyTFS)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: 'red',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          />
          Generate empty target folder structure 
      </Box>

      <Box  sx={{fontSize:12}}>
        <Switch
            checked={iscreatePHF}
            onChange={() => setIscreatePHF(!iscreatePHF)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: 'red',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          />
          Create placeholder files
        </Box> 

</Box>

     
      <Box mt={1}>
        <Typography variant="body2" fontWeight="bold" fontSize={12} >
          Target Settings
        </Typography>

     <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mt: 1,
          pl: 2
        }}>
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            bgcolor: 'white',
            borderRadius: 1,
            p: 0.5
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box 
                component="img"
                src="https://cdn.builder.io/api/v1/image/assets/b22a1f591db946d8a5b6fadc33b7c231/190889642f933327d884e606f642c062034e414d?placeholderIfAbsent=true"
                sx={{ width: 24, height: 24 }}
                alt="Archive"
              />
              <Typography variant="body2" sx={{ color: 'black' }}>
                Status
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ color: 'rgba(18, 18, 21, 0.30)', textAlign: 'center' }}>
              (Hide this Source Code for all user)
            </Typography>
          </Box>
          <Switch
            checked={isArchived}
            onChange={() => setIsArchived(!isArchived)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: '#0F4977',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          />
        </Box>

        <Box textAlign="right" mt={2}>

        <Button
            variant="contained"
            // onClick={handleSubmit}
            sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" ,
              mr:2
            }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            onClick={handleSubmit}
            sx={{
              height: 32, 
              fontSize: 12, 
              padding: "6px 16px" 
            }}
          >
            Save
          </Button>
        </Box>
      </Box>
    </Paper>
  );
};

export default AddTargetCard;
