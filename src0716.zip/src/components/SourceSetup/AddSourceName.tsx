import React, { useState } from "react";
import { Box, Typography, TextField, Button } from "@mui/material";

interface Props {
  onAddSourceName: (name: string) => void;
}

const AddSourceName: React.FC<Props> = ({ onAddSourceName }) => {
  const [sourceName, setSourceName] = useState("");

  const SubmitResourceName = (e: React.FormEvent) => {
    e.preventDefault();
    if (sourceName.trim()) {
      onAddSourceName(sourceName.trim());
      setSourceName("");
    }
  };

  return (
    <Box sx={{ width: '100%', maxWidth: '527px' }}>
      <Typography variant="body2" sx={{ color: '#1d1b20', fontWeight: 'medium', lineHeight: 1.2 }}>
        <Box component="span" sx={{ fontWeight: 'bold' }}>Add a Source</Box>
      </Typography>

      <Box component="form" onSubmit={SubmitResourceName} sx={{ display: 'flex', gap: 1, mt: 1, flexWrap: 'wrap' }}>
        <TextField
          value={sourceName}
          onChange={(e) => setSourceName(e.target.value)}
          placeholder="Source Name"
          required
          variant="outlined"
          size="small"
          sx={{ flexGrow: 1, minWidth: '240px' }}
        />
        <Button
          type="submit"
          variant="outlined"
          sx={{
            color: '#0F4977',
            borderColor: '#0F4977',
            textTransform: 'none',
            fontWeight: 'bold',
            height: '40px',
          }}
        >
          Add Source
        </Button>
      </Box>
    </Box>
  );
};

export default AddSourceName;
