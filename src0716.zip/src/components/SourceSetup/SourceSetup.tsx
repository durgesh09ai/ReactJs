import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, Paper, Typography } from "@mui/material";
import { mainPageStore } from "../../stores/MainPageStore";
import AddSourceName from "./AddSourceName";
import AddSourceCard from "./AddSourceCard";
import SourceCard from "./SourceCard";

const SourceSetup: React.FC = observer(() => {
  const [localNewSourceSetup, setLocalNewSourceSetup] = useState<any[]>([]);
  const {
    fetchSourceSetUp,
    addSource,
    sourceList,
    loading
   }  = mainPageStore;


  useEffect(() => {
    fetchSourceSetUp();
  }, []);

  const handleAddSourceSetup = (name: string) => {
    const newSourceSetup = {
      name,
      description: "",
      archive: false,
    };
    setLocalNewSourceSetup((prev) => [newSourceSetup, ...prev]);
  };

  const submitSource = async (updatedSource: any, index: number) => {
    await addSource(updatedSource);
    setLocalNewSourceSetup((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <Paper sx={{ width: "605px", p: 2, borderRadius: 1 }}>
      <Typography
        variant="body1"
        sx={{
          py: 1,
          borderBottom: "1px solid rgba(18,18,21,0.30)",
          color: "#1d1b20",
        }}
      >
        Source Project Setup
      </Typography>

      <Box sx={{ display: "flex", gap: 4, mt: 2 }}>
        <Box sx={{ display: "flex", flexDirection: "column", width: "100%" }}>
          <AddSourceName onAddSourceName={handleAddSourceSetup} />
          {loading && ( 
            <Box textAlign={"center"}><img src="../contentloader.gif" width={100} height={100}/></Box>
          )}
          
          {localNewSourceSetup && localNewSourceSetup.map((ws, index) => (
            <AddSourceCard
              key={`new-${index}`}
              {...ws}
              onSubmit={(updatedSR) => submitSource(updatedSR, index)}
            />
          ))}

          {sourceList && sourceList.map((ws, index) => (
            <SourceCard key={`ws-${index}`} {...ws} />
          ))}
        </Box>
      </Box>
    </Paper>
  );
});

export default SourceSetup;
