import React, { useState } from "react";
import { observer } from "mobx-react-lite";

import {
  Box,
  Typography,
  Paper,
  Button,
  Switch,
  TextField,
  Select,
  MenuItem,
  SelectChangeEvent,
} from "@mui/material";
import { mainPageStore } from "../..//stores/MainPageStore";

interface WorkspaceCardProps {
  id: string;
  name: string;
  git_url:string;
  language_name:string;
  import_folder_path:string;
  description: string;
  userId: string;
  team_members?: string[];
  archive: boolean;
}

const SourceCard: React.FC<WorkspaceCardProps> = ({
  id,
  name,
  git_url,
  language_name,
  import_folder_path,
  description,
  userId,
  team_members,
  archive,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isArchived, setIsArchived] = useState(archive);
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(name);
  const [editedDescription, setEditedDescription] = useState(description);
  const [nameError, setNameError] = useState(false);
  const [selectedType, setSelectedType] = useState<string>("");

  const handleTypeChange = (event: SelectChangeEvent<string>) => {
    setSelectedType(event.target.value);
  };

  const {
    languageList   }  = mainPageStore;

  // const handleUpdateDetails = async () => {
  //   if(!editedName.trim()){
  //     setNameError(true);
  //     return;
  //   }
  //   setNameError(false);
  //   try {
  //     setLoading(true);
  //     await dataProtoweaveGenAiStore.updateWorkspace(id, {
  //       id: id,
  //       userId: userId,
  //       WS_name: editedName,
  //       WS_descrip: editedDescription,
  //     });
  //     setIsEditing(false);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const handleToggleArchive = async () => {
  //   const newArchivedState = !isArchived;
  //   try {
  //     setLoading(true);
  //    await dataProtoweaveGenAiStore.updateWorkspaceArchive(id, {
  //     id: id,
  //     userId: userId,
  //     archive: newArchivedState,
  //   });
  //     setIsArchived(newArchivedState);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  return (
    <Paper 
        elevation={0}
        sx={{ 
          border: '1px solid #E4E4E5',
          width: '100%', 
          maxWidth: '527px', 
          mt: 2,
          p: 2
        }}
      >
        <Box sx={{ 
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Box>
            <Typography variant="body2" sx={{ color: 'black', fontWeight: 'bold' }}>
              {name}
            </Typography>
          </Box>

         <Box display={"flex"}>
          {!isEditing && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Button
                variant="text"
                onClick={() => setIsEditing(!isEditing)}
                startIcon={
                  <Box 
                    component="img"
                    src="/edit.svg"
                    sx={{ width: 24, height: 24 }}
                    alt="Edit"
                  />
                }
                sx={{
                  color: '#0F4977',
                  textTransform: 'none',
                  fontWeight: 'medium',
                  py: 0.5,
                  px: 1,
                  minWidth: 'auto'
                }}
              >
              </Button>
            </Box>
              )}

          <Box 
            component="img"
            src="../delete.svg"
            sx={{ width: 24, height: 24,mt:0.2 }}
            alt="Options"
          />
        </Box>
        </Box>
        
      {!isEditing && (
       <Box sx={{ mt: 1 }}>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" }}>
          Description
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
          {isExpanded ? description : `${description?.slice(0, 100)}...`}
          <Box
            component="span"
            onClick={() => setIsExpanded(!isExpanded)}
            sx={{
              ml: 0.5,
              color: "#0F4977",
              textDecoration: "underline",
              cursor: "pointer",
            }}
          >
            See {isExpanded ? "less" : "more"}
          </Box>
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black", mt:1 }}>
          GIT URL
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {git_url}
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1 }}>
        Language
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {language_name}
        </Typography>

        <Typography variant="body2" sx={{ fontWeight: "bold", color: "black" , mt:1}}>
        Imported File/Folder
        </Typography>
        <Typography variant="body2" sx={{ color: "#1d1b20", mt: 1 }}>
        {import_folder_path}
        </Typography>

      </Box>
      )}
        
{isEditing && (
     
<Box sx={{ mt: 1 }}>
  <Box sx={{ mt: 1 }}>
  <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>

  <Typography variant="body2" sx={{ fontWeight: "bold", color: "black"}}>
  Source Code Name</Typography>
    <TextField
      value={editedName}
      onChange={(e) =>{
         setEditedName(e.target.value)
         if(e.target.value.trim()){
          setNameError(false);
         }
      }
      }
      error={nameError}
      helperText = {nameError ? "SourceCode Name is required." :""} 
      fullWidth
      size="small"
      sx={{ 
        "& input": { fontSize: 12 },
        "& .MuiInputLabel-root": { fontSize: 12 } ,
      }} 
    />
<Typography variant="body2" sx={{ fontWeight: "bold", color: "black"}}>
Source Code Description
</Typography>

    <TextField
      value={editedDescription}
      onChange={(e) => setEditedDescription(e.target.value)}
      fullWidth
      multiline
      sx={{ 
        "& .MuiInputBase-root": { fontSize: 14 },
        "& .MuiInputLabel-root": { fontSize: 14 } ,
      }} 
    />


<Typography variant="body2" sx={{ fontWeight: "bold", color: "black"}}>
          GIT URL
</Typography>
<TextField
      value={editedName}
      onChange={(e) =>{
         setEditedName(e.target.value)
         if(e.target.value.trim()){
          setNameError(false);
         }
      }
      }
      error={nameError}
      helperText = {nameError ? "GIT URL is required." :""} 
      fullWidth
      size="small"
      sx={{ 
        "& input": { fontSize: 12 },
        "& .MuiInputLabel-root": { fontSize: 12 } ,
      }} 
    />

<Typography variant="body2" fontWeight="bold" fontSize={14}>
          Language
        </Typography>
        <Select
          value={selectedType}
          onChange={handleTypeChange}
          displayEmpty
          size="small"
          sx={{
            height: 36,
            fontSize: 13,
          }}
        >
          <MenuItem value="">
            <em>Select Language</em> 
          </MenuItem>
          {languageList.map((opt) => (
            <MenuItem key={opt.id} value={opt.id}>
              {opt.name}
            </MenuItem>
          ))}
        </Select>

   <Typography variant="body2" fontSize={14}>
          Import File / Folder
    </Typography>
      <input type="file" multiple /> 

    <Typography variant="body2" fontSize={14}>
          Status 
          
           <Switch
            checked={isArchived}
            onChange={() => setIsArchived(!isArchived)}
            sx={{
              '& .MuiSwitch-track': {
                backgroundColor: 'red',
              },
              '& .MuiSwitch-thumb': {
                backgroundColor: 'white',
              },
            }}
          /> 
    </Typography>
     


    <Box sx={{ display: 'flex', gap: 1 }}>
      <Button
        variant="contained"
          // onClick={handleUpdateDetails}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Update
      </Button>
      <Button
        variant="outlined"
        onClick={() => {
          setIsEditing(false);
        }}
        sx={{
          height: 32, 
          fontSize: 12, 
          padding: "6px 16px" 
        }}
      >
        Cancel
      </Button>
    </Box>
  </Box>

</Box>
</Box>
)}

</Paper>
  );
};

export default observer(SourceCard);
