import React from "react";
import { observer } from "mobx-react-lite";
import { Box, CssBaseline, ThemeProvider } from "@mui/material";
import DefaultSidebar from "./DefaultSidebar";
import DefaultHeader from "./DefaultHeader";
import { Outlet } from "react-router-dom";
import { theme } from "./BaseLayout.style";
import { mainPageStore } from "../../stores/MainPageStore";

interface BaseLayoutProps {
  header?: React.ReactNode;
  sidebar?: React.ReactNode;
}

const HEADER_HEIGHT = 48; // match your Header height

const BaseLayout = observer((props?: BaseLayoutProps) => {
  const header = props?.header ?? <DefaultHeader />;
  const sidebar = props?.sidebar ?? <DefaultSidebar />;
  const { sidebarCollapsed } = mainPageStore;

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      {/* ROOT Layout: Vertical */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: "100vh",
          overflow: "hidden",
        }}
      >
        {/* HEADER */}
        <Box
          sx={{
            height: `${HEADER_HEIGHT}px`,
            flexShrink: 0,
            borderBottom: "1px solid rgba(0,0,0,0.1)",
            zIndex: 10,
          }}
        >
          {header}
        </Box>

        {/* BODY: Horizontal layout of sidebar and content */}
        <Box
          sx={{
            display: "flex",
            flexGrow: 1,
            minHeight: 0, // Required to prevent layout breaking
            overflow: "hidden",
          }}
        >
          {/* SIDEBAR */}
          <Box
            sx={{
              width: sidebarCollapsed ? 50 : 240,
              borderRight: "1px solid rgba(0,0,0,0.1)",
              overflowY: "auto",
              flexShrink: 0,
              backgroundColor: "#fff",
            }}
          >
            {sidebar}
          </Box>

          {/* MAIN CONTENT */}
          <Box
            sx={{
              flexGrow: 1,
              overflowY: "auto",
              padding: 0,
              backgroundColor: "#F9FAFB",
            }}
          >
            <Outlet />
          </Box>
        </Box>
      </Box>
    </ThemeProvider>
  );
});

export default BaseLayout;