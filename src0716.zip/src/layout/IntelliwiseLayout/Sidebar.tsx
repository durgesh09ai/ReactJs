import React, { useEffect, useState } from "react";
import { observer } from "mobx-react-lite";
import { Box, IconButton, ListItem, ListItemText } from "@mui/material";
import { Link } from "react-router-dom";
import NavItem from "./NavItem";
import { mainPageStore } from "../../stores/MainPageStore";
import SettingsIcon from "@mui/icons-material/Settings";
import { PushPin as PushPinIcon } from '@mui/icons-material';

const Sidebar = observer(() => {
   const {
    sidebarCollapsed,
    setSidebarCollapsed,
    isPinned,
    setIsPinned
  } = mainPageStore;

 const collapsed = sidebarCollapsed;
  const toggleSidebar = () => {
    setSidebarCollapsed();
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="90vh"
      px={!collapsed ? 0 : 0}
      fontFamily="Montserrat, sans-serif"
      fontSize="14px"
      color="#343434"
    >
      {/* Top Section */}
      <Box flexGrow={1}>

        {/* Expanded Sidebar Navigation */}
          <Box display="flex" flexDirection="column" sx={{ mt: 2 }}>
            
          {/* <Box display="flex"  sx={{textAlign: "center",mb:1,ml:1.8,color:'#000' }}>
            <Avatar
            src={!collapsed ? "/menu_Close.svg" : "/menu_open.svg"}
            alt="Logo"
            sx={{ width: 24, height: 24, cursor: "pointer" }}
            variant="square"
            onClick={toggleSidebar}
          /> 
            </Box> */}

            <Box display="flex"  sx={{textAlign: "center",ml:1 }}>
            <IconButton size="small" onClick={() => setIsPinned()} title={isPinned ? "Unpin" : "Pin"}>
                <PushPinIcon sx={{ transform: isPinned ? 'rotate(45deg)' : 'rotate(0deg)', color: isPinned ? 'primary.main' : 'inherit' }} />
              </IconButton>
            </Box>

            {/* Dynamic Sections */}
                <Link to="/" style={{textDecoration:"none",color:"inherit"}}>
                 <NavItem
                  key="Home"
                  icon="/Home.svg"
                  label="Home"
                  collapsed={collapsed}
                />
                </Link>
          </Box>
       
      </Box>

      {/* Footer Items pinned to bottom */}
        <Box mt={2}>
        <ListItem
          component={Link}
          to="/settings/user-profile"
          sx={{
            textDecoration: "none",
            color: "inherit",
            px: 1,
            py: 1,
            borderRadius: 1,
            "&:hover": { backgroundColor: "#f5f5f5" },
          }}
        >
          <SettingsIcon fontSize="small" sx={{ mr: 1 ,ml:1}} />
          {!collapsed && (
          <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: "14px" }} />
          )}
        </ListItem>
       </Box>
      
    </Box>
  );
});

export default Sidebar;