import { makeAutoObservable, runInAction, toJS } from "mobx";
import { API_BASE_URL } from "./config/config";

const seourceList  = [
  {
      "id": "c2c050a0-13b8-408d-bf88-0220ab6dfbc7",
      "name": "Python Source Code",
      "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling1",
      "git_url":"https://wwww.git.com/",
      "language_name":"Python",
      "import_folder_path":"C:/\Documents/\intelliwise/\public/\logout.svg",
     "userId": "admin@gmail.com",
      "created_at": 1747460878,
      "archive": true,
  },
  {
      "id": "681b77fe-b97c-8013-8110-199103902612",
      "name": "Java Source Code",
      "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling and protein modeling",
      "git_url":"https://wwww.git.com/",
      "language_name":"Python",
      "import_folder_path":"C:\Documents\intelliwise\public\logout.svg",
      "userId": "admin@gmail.com",
      "created": "1747301149",
      "archive": false,

  }
];


const targetLists  = [
  {
      "id": "c2c050a0-13b8-408d-bf88-0220ab6dfbc7",
      "name": "Python Target Code",
      "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling1",
      "git_url":"https://wwww.git.com/",
      "analyse_summary":['Python','Html','java','SQL'],
      "language_name":"Python",
      "import_folder_path":"C:/\Documents/\intelliwise/\public/\logout.svg",
      "llm_linked":['DataSage','InsightLLM','ClaimLogic'],
      "userId": "admin@gmail.com",
      "created_at": 1747460878,
      "archive": true,
  },
  // {
  //     "id": "681b77fe-b97c-8013-8110-199103902612",
  //     "name": "Java Target Code",
  //     "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling and protein modeling",
  //     "git_url":"https://wwww.git.com/",
  //     "analyse_summary":['Python','Html','java','SQL'],
  //     "language_name":"Python",
  //     "import_folder_path":"C:\Documents\intelliwise\public\logout.svg",
  //     "llm_linked":['DataSage','InsightLLM','ClaimLogic'],
  //     "userId": "admin@gmail.com",
  //     "created": "1747301149",
  //     "archive": false,

  // }
];


const workSpaceLists  = [
  {
      "id": "c2c050a0-13b8-408d-bf88-0220ab6dfbc7",
      "name": "Python Target Code",
      "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling1",
      "git_url":"https://wwww.git.com/",
      "language_name":"Python",
      "import_folder_path":"C:/\Documents/\intelliwise/\public/\logout.svg",
     "userId": "admin@gmail.com",
      "created_at": 1747460878,
      "archive": true,
  },
  {
      "id": "681b77fe-b97c-8013-8110-199103902612",
      "name": "Java Target Code",
      "description": "A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling A shared space for collaborating on DNA sequencing, gene analysis, and protein modeling and protein modeling",
      "git_url":"https://wwww.git.com/",
      "language_name":"Python",
      "import_folder_path":"C:\Documents\intelliwise\public\logout.svg",
      "userId": "admin@gmail.com",
      "created": "1747301149",
      "archive": false,

  }
];



export class MainPageStore {
  static fetchSourceSetUp() {
    throw new Error("Method not implemented.");
  }
  data: any = null;
  loading: boolean = false;
  error: string | null = null;
  sidebarCollapsed: boolean = true;
  sourceList: any[] = [];
  targetList: any[] = [];
  workSpaceList: any[] = [];
  languageList: any[] = [];
  workSourceSetUpList: any[] = [];
  selectedItem:string = 'User Profile';
  isPinned:boolean = false;
  isPinnedAssPanel:boolean = false;

  apiUrl: string = API_BASE_URL;

  constructor() {
    makeAutoObservable(this);
  }

  setIsPinned = () => {
    this.isPinned = !this.isPinned;
  }

  setIsPinnedAssPanel = () => {
    this.isPinnedAssPanel = !this.isPinnedAssPanel;
  }

  setSidebarCollapsed = () => {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }


  setSelectedItem = (menuItems:string) => {
    console.log('licked',menuItems);
    this.selectedItem = menuItems;
  }

  fetchSourceSetUp = async () => {
    try {
      this.loading = true;
      // const res = await fetch(`${this.apiUrl}/source/sourceSetup`);
      // if (!res.ok) throw new Error("Failed to fetch workspaces");
      // const data = await res.json();
      runInAction(() => {
        this.sourceList = seourceList;
        this.loading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchTargetSetUp = async () => {
    try {
      this.loading = true;
      // const res = await fetch(`${this.apiUrl}/source/sourceSetup`);
      // if (!res.ok) throw new Error("Failed to fetch workspaces");
      // const data = await res.json();
      runInAction(() => {
        this.targetList = targetLists;
        this.loading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };

  fetchWorkSpaceSetUp = async () => {
    try {
      this.loading = true;
      // const res = await fetch(`${this.apiUrl}/source/sourceSetup`);
      // if (!res.ok) throw new Error("Failed to fetch workspaces");
      // const data = await res.json();
      runInAction(() => {
        this.workSpaceList = workSpaceLists;
        this.loading = false;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  addSource = async (source: any) => {
    try {
      const res = await fetch(`${this.apiUrl}/workspace/create_workspace`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(source),
      });
      if (!res.ok) throw new Error("Failed to add workspace");
      const newSource = await res.json();
      runInAction(() => {
        this.sourceList.unshift(newSource);
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
  };


  fetchLanguageListData = async () => {
    try {
      const res = await fetch(`${this.apiUrl}/dashboard/languagelist`);
      if (!res.ok) throw new Error("Failed to fetch languagelist");
      const data = await res.json();
      runInAction(() => {
        this.languageList = data;
      });
    } catch (e: any) {
      runInAction(() => {
        this.error = e.message;
      });
    }
    return [];
  };


 
}

export const mainPageStore = new MainPageStore();
